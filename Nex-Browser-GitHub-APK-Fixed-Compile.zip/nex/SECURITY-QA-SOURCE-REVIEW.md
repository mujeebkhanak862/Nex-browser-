# Security QA — source-level review (jo bina device ke check ho sakta tha)

Section 6 ke security items mein se zyada tar (TLS device test, biometric
lock test, sync-conflict test, background/restart test, layouts) sirf
real Android device par hi test ho sakte hain. Lekin **3 items aise the
jo source code padh kar hi verify/fix ho sakte the** — wo maine kiye:

## 1. ✅ TLS/certificate error handling — already sahi tha

`onReceivedSslError` check kiya: ye already **cancel-by-default** hai,
sirf tabhi proceed karta hai jab user khud ek warning dialog par
"Proceed anyway" tap kare (jisme exact problem bataya jata hai — expired/
mismatched/untrusted certificate). Koi blind/unconditional bypass nahi
mila. Ye already ek pichle security audit mein fix ho chuka tha —
maine sirf confirm kiya ke ye sahi hai.

## 2. ✅ NexPasswordCapture JS bridge — already reasonably mitigated

Check kiya: ye bridge sirf non-incognito tabs par attach hota hai, aur
koi bhi save automatic nahi hota — hamesha user se "Save password?"
confirmation leta hai jisme asal domain dikhta hai. Ek chhota residual
risk documented hai (koi page ka apna script fake values ke saath
`onFormSubmit()` seedha call kar sakta hai) — lekin blast radius bahut
mehdood hai (sirf ek confirmation dialog trigger hota hai, kuch bhejta
nahi bina tap ke). Asli poora fix (`WebMessageListener` par migrate
karna) ek bada architecture change hai jo bina device ke test kiye
risky hota — isliye maine wahi nahi kiya jo already sahi documented tha,
sirf review confirm kiya.

## 3. 🔧 Backend Server URL — HTTPS ab enforce hoti hai (naya fix)

Ye genuinely missing tha: "Backend Server URL" (jahan sign-in tokens,
Cloud Sync data, AI keys, Custom API keys sab jaate hain) mein user
plain `http://` daal sakta tha aur koi warning nahi aati thi — jabke
general web browsing ke liye http:// allowed hona sahi hai
(AndroidManifest mein documented), backend traffic alag cheez hai
kyunki usme **sensitive credentials** jaate hain.

**Fix**:
- Agar koi scheme na de (jaise sirf "myserver.com"), to khud-ba-khud
  `https://` laga di jaati hai
- Agar koi explicitly `http://` de (aur ye local development address na
  ho — localhost/127.0.0.1/192.168.x/10.x), to ek warning dikhti hai:
  "Your sign-in, Cloud Sync data, and any AI/Custom API keys... would be
  sent unencrypted" — user chahe to phir bhi aage badh sakta hai
  (local testing ke liye), lekin ab **chup-chap** nahi hota

## Kahan implement hua

`MainActivity.java` — `showBackendUrlDialog()`, naye helpers
`saveBackendUrl()` aur `isLocalDevAddress()`.

## Baaki bache security items (sirf real device par test ho sakte hain)

- Incognito process isolation on-device verify
- Vault encryption/decryption, biometric lock, auto-lock, backup/restore
- Offline sync conflicts + queue draining
- Background/process-death/restart agent behavior
- Phone/tablet/landscape layouts + accessibility
- Poora crash/regression matrix

In sab ke liye Android Studio + real device chahiye — source-level review
se aage nahi badh sakte.
