# Nex Browser — GitHub par pehla build (step by step)

## 1. Repo banao aur code daalo
1. github.com → **New repository** → naam `nex-browser` → **Private** → Create.
2. Is zip ko apne computer par extract karo. Root folder me ye dikhna chahiye:
   `.github/`, `DevilBrowser/`, `nex-backend/`, `README`-type files.
   (`.github` hidden folder hai — isko bhi upload karna zaroori hai, warna CI nahi chalegi.)
3. Upload ka sabse aasan tareeka (computer par git ho to):
   ```
   cd nex-browser-extracted-folder
   git init
   git add -A
   git commit -m "Hardened baseline"
   git branch -M main
   git remote add origin https://github.com/<tumhara-username>/nex-browser.git
   git push -u origin main
   ```
   Phone/browser se: repo page → **Add file → Upload files** → poore folder ko drag karo
   (hidden `.github` ke liye git wala tareeka behtar hai).

## 2. Pehla CI run
1. Repo → **Actions** tab. Do jobs chalenge: **Backend tests** aur **Android build**.
2. **Backend tests** hara ✅ hona chahiye (31 tests).
3. **Android build** pehli baar fail ho sakta hai — ye normal hai, kyunki is code ne kabhi
   compile nahi dekha. Failed job kholo → red step → error text copy karke mujhe bhejo.
   Main ek-ek karke theek kar dunga.
4. Pass hone par job ke neeche **Artifacts → nex-debug-apk** download karo = installable APK.

## 3. Firebase file (push ke liye) — optional
- `app/google-services.json` .gitignore me hai (secret hai). **Iske bina bhi build chalega**:
  `build.gradle` ka google-services plugin tabhi lagta hai jab ye file maujood ho. Bas push notifications nahi aayenge.
- Push chahiye to `DevilBrowser/PUSH_NOTIFICATIONS_SETUP.md` follow karo.
  CI par is file ko GitHub Secret (base64) se likhwana padega — jab push test karna ho tab batao, main workflow me step jod dunga.

## 4. Release APK ke liye signing (baad me, jab debug theek chal jaye)
1. Keystore banao (ek baar, safe jagah rakho — kho diya to app update nahi hoga):
   ```
   keytool -genkeypair -v -keystore nex.jks -alias nex -keyalg RSA -keysize 2048 -validity 10000
   base64 -w0 nex.jks   # output copy karo
   ```
2. Repo → Settings → Secrets and variables → Actions → New repository secret:
   `NEX_KEYSTORE_B64` (upar ka base64), `NEX_KEYSTORE_PASSWORD`, `NEX_KEY_ALIAS` (=nex), `NEX_KEY_PASSWORD`.
3. `main` branch par push karte hi signed release APK artifact banega.
4. `nex.jks` ko kabhi GitHub par commit mat karna.

## 5. Backend deploy (Railway)
Variables:
| Name | Kya |
|---|---|
| `ANTHROPIC_API_KEY` | AI features ke liye |
| `GOOGLE_CLIENT_ID` | Google Sign-In ka Web Client ID |
| `NEX_SECRET_KEY` | `python -c "from cryptography.fernet import Fernet;print(Fernet.generate_key().decode())"` |
| `FCM_SERVICE_ACCOUNT_JSON` | Firebase service account JSON (push ke liye) |
| `DB_PATH` | `/data/nex.db` (Railway Volume `/data` par mount karo) |
Sirf **1 instance** chalao (SQLite hai). Deploy ke baad `/health` ya `/docs` kholke check karo.

## 6. Final device-testing checklist (sabse aakhir)
- [ ] Register / login / wrong password (8+ chars) / logout
- [ ] Google Sign-In
- [ ] Kisi site par file upload (jaise photo upload form)
- [ ] Kisi site par camera/mic (jaise webcam test site) — Allow aur Block dono
- [ ] "Near me" wali site — location Allow/Block
- [ ] Login-protected download (cookie wala)
- [ ] Heavy page se renderer crash / memory low — app band nahi honi chahiye
- [ ] Agent job: start → Pause → app force-stop → app kholo → Resume (wahin se chalna chahiye)
- [ ] Progress % aur "~X left" dikhe
- [ ] Push notification (backend `/notifications/send`)
- [ ] Vault: save/open, biometric
- [ ] Rotation, back button, tablet/landscape, bada font size
