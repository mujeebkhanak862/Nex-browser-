# Accent Color cleanup — Gaps F & G closed

## F. Java constants aur XML resources ab sync mein enforce hote hain

Pehle 5 built-in accent colors (Violet/Rose/Ocean/Forest/Amber) do jagah
defined the: `ThemeManager.ACCENT_PRESETS` (Java hex literals) aur
`colors.xml` (`accent_violet`, `accent_rose`, wagera). Koi bhi cheez dono
ko sync nahi rakhti thi — koi ek jagah badal de to doosri jagah purani
reh jaati.

**Fix**: `ThemeManager.syncAccentPresetsFromResources(context)` — app
start hote hi (onCreate ka bilkul pehla step) `colors.xml` ke asal
compiled values padhta hai aur Java ke `ACCENT_PRESETS` array ko unhi
values se overwrite kar deta hai. Ab `colors.xml` hi **asli source of
truth** hai — Java sirf usse follow karta hai. Agar koi bhavishya mein
sirf ek file badle, doosri khud-ba-khud sahi ho jayegi, chupke se galat
nahi rahegi.

(Dark-mode variants Java mein hi rehte hain, kyunki `colors.xml` mein
unka koi XML counterpart hai hi nahi — jaisa file ka apna comment kehta
hai.)

## G. Custom RGB ka colorSecondary overlay ab "nearest match" deta hai

Pehle: agar user **Custom RGB** color choose karta (na ki 5 presets
mein se koi), to `applyAccentOverlay()` hamesha **Violet** overlay laga
deta tha — chahe user ne koi bhi color chuna ho — kyunki Custom RGB ke
liye koi compiled XML resource ban hi nahi sakta (runtime value hai).

**Fix**: Ab jab bhi accent ka naam kisi 5 known presets mein se match
nahi karta (Custom RGB ya kisi imported theme ka anjaan naam), system
us custom color ko **5 presets se RGB distance** ke hisaab se compare
karta hai aur **sabse qareeb wala preset overlay** laga deta hai — Violet
par blindly atakne ke bajaye. 

**Zaroori note**: Jahan bhi app pehle se `ThemeManager.getAccentColor()`
seedha padhta hai (jaise switches jo explicitly tint hoti hain — report
khud kehta hai "no current visible control depends on that remaining
overlay gap"), wahan exact custom color pehle se bhi sahi dikhta tha aur
ab bhi dikhta hai. Ye fix sirf us theoretical fallback ko behtar banata
hai jo kabhi bhi kisi visible widget par asar nahi daal raha tha —
asli engineering limit yeh hai ke Android ke compiled theme attribute
mein runtime par arbitrary RGB value daalna possible hi nahi (resource
id chahiye hoti hai), isliye "nearest match" hi sabse sahi/honest
solution hai.

## Kahan implement hua

`ThemeManager.java`:
- `syncAccentPresetsFromResources()` — naya (gap F)
- `nearestPresetOverlay()` — naya (gap G)
- `applyAccentOverlay()` — default case ab nearest-match use karta hai

`MainActivity.java` — `onCreate()` ke bilkul shuru mein
`ThemeManager.syncAccentPresetsFromResources(this);` call add hua.

## Testing note

Sab kuch preset-name ya file-level cheez hai — koi UI change nahi hai
jo dikhega, isliye normal use mein kuch alag nahi lagega. Android Studio
mein confirm karna:
- App start ho aur crash na kare
- Presets (Violet/Rose/Ocean/Forest/Amber) pehle jaisa hi dikhein
- Custom RGB choose karke koi switch/checkbox dekho jo explicitly tint
  nahi hai — ab wo Violet ke bajaye chune gaye color ke sabse qareeb
  wale preset jaisa dikhna chahiye
