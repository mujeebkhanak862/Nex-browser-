# Toolbar Customization — Gap E closed: drag-drop + top/bottom

Report gap E: "Moving the entire toolbar from top to bottom is not
implemented, and drag-and-drop reordering is not implemented."

## Kya add hua

1. **⬆ Top / ⬇ Bottom toggle** — Toolbar customizer sheet ke sabse upar
   ab do chips hain. Tap karte hi poori nav bar (Back/Forward/Home/
   Refresh/Tabs/Menu) screen ke **top ya bottom** par chali jaati hai —
   bilkul Chrome/Firefox ke "move toolbar to bottom" jaisa. Omnibox, tab
   strip, aur webpage apni jagah waise hi rehte hain, sirf nav bar
   move hoti hai.
2. **Drag-and-drop reordering** — har row ke saath ab ek "⠿" drag handle
   hai. Usse **long-press** karke drag karo aur kisi doosri row par
   **drop** karo — order badal jata hai. ▲▼ buttons bhi waise hi maujood
   hain (drag se zyada reliable/accessible hain kuch logon ke liye).

## Engineering note

Drag-drop ke liye poori list ko RecyclerView mein convert nahi kiya —
Android ka **real View drag-and-drop framework**
(`startDragAndDrop` + `OnDragListener`) kisi bhi ViewGroup (yahan plain
LinearLayout) par kaam karta hai, isliye genuine drag-drop mila bina
poori UI dobara likhe.

## Kahan implement hua

`MainActivity.java`:
- `applyToolbarPosition()` / `setToolbarPosition()` — naya
- `buildToolbarPositionToggle()` — naya
- `buildToolbarRow()` — drag handle + `OnDragListener` add kiya

## Testing note

Android Studio mein:
- "⬇ Bottom" tap karo — nav bar screen ke neeche aa jaani chahiye,
  webpage/omnibox upar hi rahe
- Kisi row ko long-press karke drag karo, doosri row par drop karo —
  order turant badalna chahiye
- ▲▼ buttons ab bhi pehle jaisa hi kaam karein
