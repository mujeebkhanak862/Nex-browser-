# Accent Color — Closing the Scope Gap

Follows up on ACCENT-COLOR-CHANGES.md's "SCOPE NOTE": the 5 spots that were
still fixed brand Violet (Go button, 2 card-border drawables, and
`colorSecondary`) now follow the chosen accent preset too.

## Files changed

1. **`app/src/main/res/values/colors.xml`** / **`values-night/colors.xml`**
   - Added `accent_violet/rose/ocean/forest/amber` tokens, one set per
     mode, duplicating `ThemeManager.ACCENT_PRESETS`' values as real
     compiled color resources (needed because a `ThemeOverlay` has to
     point at a resource, not an arbitrary runtime int). The comment in
     both files flags that these must be kept in sync with the Java
     constants by hand — see "Known limitation" below.

2. **`app/src/main/res/values/themes.xml`**
   - Added five `ThemeOverlay.Nex.Accent.*` styles (`parent=""`, so each
     only carries its own overrides), one per preset, each setting
     `colorSecondary`/`colorSecondaryVariant`/`colorOnSecondary`.

3. **`app/src/main/java/com/devil/browser/ThemeManager.java`**
   - `applyAccentOverlay(Activity)` — picks the overlay matching the saved
     preset *name* and calls `getTheme().applyStyle(overlayRes, true)`.
     Unknown/imported names fall back to the Violet overlay.
   - `shade(int color, float factor)` — HSV-based darken/lighten, used to
     synthesize a second gradient stop from one accent color.
   - `buildGoButtonDrawable()`, `buildProminentCardDrawable()`,
     `buildAddCardDrawable()` — recreate `bg_go_button.xml` /
     `bg_new_tab_prominent.xml` / `bg_home_add_card.xml` as code-built
     `GradientDrawable`s using the live accent instead of the static
     `@color/ember`.

4. **`app/src/main/java/com/devil/browser/MainActivity.java`**
   - `ThemeManager.applyAccentOverlay(this)` added to `onCreate()`, right
     after `super.onCreate()` and before `setContentView()` (the order
     Android's own docs specify for `applyStyle()`).
   - `btnGo.setBackground(ThemeManager.buildGoButtonDrawable(this))`
     right after `btnGo` is found.
   - `newTabBtn.setBackgroundResource(R.drawable.bg_new_tab_prominent)` →
     `newTabBtn.setBackground(ThemeManager.buildProminentCardDrawable(...))`.
   - `tile.setBackgroundResource(R.drawable.bg_home_add_card)` →
     `tile.setBackground(ThemeManager.buildAddCardDrawable(...))`.
   - The original three XML drawables are left in the project unused
     (not deleted), in case a future pass wants them as reference.

## Known limitation

The `accent_*` color resources and `ThemeManager.ACCENT_PRESETS`'s Java
ints now describe the same five colors **in two places**. They're
correct as shipped in this change (checked by eye against each other),
but nothing enforces they stay identical if either is edited later —
there's no single source of truth here, just a comment in both files
pointing at the other. A cleaner long-term fix would generate one from
the other at build time; out of scope for this pass.

## How it works

Selecting an accent preset now affects: the ~22 runtime-read spots from
ACCENT-COLOR-CHANGES.md, the Go button, the New Tab prominent card, the
Add Shortcut dashed card, and (via `colorSecondary`) any Material
component that doesn't set an explicit color, such as default-styled
Switches/CheckBoxes/RadioButtons. `recreate()` (already called after
`ThemeManager.setAccentPreset()`) is what makes the overlay take effect,
since `applyStyle()` only affects the theme actually read during
`onCreate()`.

## Testing note

Static source edit only — no Android SDK/emulator in this environment.
Before shipping: build in Android Studio, switch through all 5 presets,
and confirm the Go button / New Tab button / Add Shortcut card / any
default-tinted switch all update together with the rest of the UI.
