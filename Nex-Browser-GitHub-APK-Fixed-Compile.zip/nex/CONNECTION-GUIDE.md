# Nex Browser — App aur Backend Kaise Connect Hote Hain

Ye do alag cheezein hain jo mil ke ek app banati hain:

| | Kya hai | Kahan chalta hai |
|---|---|---|
| **DevilBrowser folder** | Tumhara asli Android app (Nex Browser) | Tumhare phone par, ek APK ke taur par |
| **nex-backend folder** | Ek chhota server (FastAPI + Python) | Internet par kahin (Railway par free mein) |

**Simple tareeke se samjho**: App tumhare phone par akela chal sakta hai —
browsing, tabs, bookmarks, history, downloads, incognito, ad block, vault
(passwords) — ye SAB kuch bina backend ke bhi kaam karta hai. Backend sirf
un cheezon ke liye chahiye jinme **AI lagti hai** ya jo **cross-device sync**
karni hai — jaise agar tum apna phone kho do to doosre phone par bhi apna
data wapas mile.

---

## 1. Connection Kaise Kaam Karta Hai (technical)

1. App ke Settings mein ek field hai: **"Backend Server URL"**
2. Tum wahan apne deployed backend ka URL daalte ho (jaise
   `https://nex-backend-production.up.railway.app`)
3. App is URL ko phone ki local storage (`SharedPreferences`, key:
   `backend_url`) mein save kar leta hai
4. Jab bhi koi AI ya sync feature use hota hai, app is URL par seedha
   internet request bhejta hai — jaise `backendUrl + "/summarize"` ya
   `backendUrl + "/agent/plan"`
5. Agar URL set nahi hai, wo features chup-chaap disabled rehte hain (Toast
   message dikhta hai: "Set Backend Server URL first") — baaki poora app
   normally chalta rehta hai

**Matlab**: App aur Backend do bilkul alag cheezein hain jo sirf ek text
field (URL) se judi hain — koi complex "pairing" nahi hai.

---

## 2. Backend Deploy Karo (ek baar ka kaam)

### Step 1 — GitHub par daalo
`nex-backend` folder ko ek GitHub repo mein push karo (web browser se
drag-and-drop bhi chalega, terminal zaroori nahi).

### Step 2 — Railway par Deploy Karo
1. [railway.app](https://railway.app) khologe → **New Project** → **Deploy
   from GitHub repo**
2. Apna repo select karo — Railway khud samajh jayega ye Python app hai
   (`Procfile` se)
3. Ek **Volume** mount karo `/data` par (database yahan persist hoga,
   warna har restart par data mit jayega)

### Step 3 — Environment Variables Set Karo
Railway dashboard → **Variables** tab:

| Variable | Kis Liye | Zaroori Hai? |
|---|---|---|
| `ANTHROPIC_API_KEY` | Saare AI features (Summary, Reader Mode cleanup, Automation Agent, Fact-Check, Source Reliability, waghera) | Sirf AI features ke liye — baaki sab isके bina bhi chalta hai |
| `FCM_SERVICE_ACCOUNT_JSON` | Push Notifications (Firebase) | Sirf push notifications ke liye |
| `DB_PATH` | Database file location | `/data/nex.db` rakho agar Volume mount kiya hai |
| `ALLOWED_ORIGINS` | Kaunse domains request bhej sakte hain | Optional, default `*` hai |

**Sabse zaroori ek hi hai**: `ANTHROPIC_API_KEY` — ye set kar do to AI wale
saare features (Automation, Reader Mode, Fact-Check, Research Workspace,
sab) turant chalne lagenge.

### Step 4 — Apna URL Copy Karo
Railway deploy hone ke baad ek URL degi, jaisa:
```
https://nex-backend-production-xxxx.up.railway.app
```
Yahi URL agle step mein app mein daalna hai.

---

## 3. App Ko Backend Se Connect Karo

1. Nex Browser app kholo (phone par install karne ke baad)
2. **Settings** → **Backend Server URL** par tap karo
3. Railway wala URL paste karo (koi trailing `/` mat lagao)
4. Save karo

Bas ho gaya — ab app us backend se baat karega.

**Optional**: Automation ke kuch features (Autopilot) ke liye tumhari apni
AI key bhi honi chahiye — wo **Settings → 🤖 AI** mein alag se add hoti hai
(Anthropic/OpenAI/Gemini mein se koi bhi).

---

## 4. Kaunsa Feature Backend Maangta Hai?

**Bina backend ke bhi chalta hai** (poora app ka core):
Tabs, Bookmarks, History, Downloads, Incognito, Ad Block, Speed Dial, Vault
(local passwords), Smart Search, Tab Groups, Tab Relationship Graph, waghera.

**Backend chahiye** (AI ya sync involved hai):
AI Summary, Reader Mode (cleanup pass), Automation/Agent (saari
Phase 5-6 features), Fact-Check, Source Reliability, Web Comparison,
Contradiction Detector, AI Web Memory + Semantic Search, Research
Workspace, Watch List, Bookmark/History/Vault Cloud Sync, Push
Notifications.

Agar backend URL set nahi hai, ye wale features bas kaam nahi karenge — app
crash nahi hoga, sirf ek chhota Toast message dikhega.

---

## 5. Quick Troubleshooting

| Problem | Wajah |
|---|---|
| "Set Backend Server URL first" | Settings mein URL nahi daala |
| AI features kaam nahi kar rahe | Railway par `ANTHROPIC_API_KEY` set nahi hai |
| Sync/data gayab ho raha hai restart par | Railway Volume `/data` par mount nahi kiya |
| Push notifications nahi aa rahe | `FCM_SERVICE_ACCOUNT_JSON` set nahi hai |

---

*Ye document `nex-backend/README.md` ka hi ek chhota, connection-focused
version hai — poori backend detail (sab endpoints, Vault encryption ka
tareeka, waghera) uss README mein hai.*
