# My Themes — Gap C closed: Duplicate + Rename

MY-THEMES-CHANGES.md ke "Not yet done" mein likha tha:
> Duplicate/rename an existing saved theme (currently: save a new one,
> delete the old one).

Ab har saved theme row mein 4 buttons hain: **✎ Rename**, **⎘ Duplicate**,
📤 Export, ✕ Delete (name tap karne se abhi bhi apply hota hai, jaisa
pehle tha).

## Kya add hua

- `duplicateMyTheme(theme)` — poora theme JSON copy karta hai (mode, accent,
  wallpaper sab), naya `id` deta hai (taake original se collide na ho),
  aur naam ke aage " (Copy)" laga deta hai. Turant list mein naya row
  dikh jata hai.
- `renameMyTheme(id, newName)` — sirf naam update karta hai, baaki sab
  (mode/accent/wallpaper) wahi rehta hai.
- `promptRenameMyTheme(theme)` — chhota dialog, current naam pehle se
  bhara hua, Save dabate hi naam badal jata hai.

Sab kuch `MainActivity.java` ke andar, `buildMyThemeRow()` aur uske
paas ke methods mein — koi naya file nahi chahiye tha.

## Testing note

Android Studio mein build karke check karna:
- Duplicate tap karne se ek naya "(Copy)" wala row turant dikhna chahiye
- Rename se naam turant update hona chahiye, theme ka accent/mode/wallpaper
  na badle
- Duplicate + Rename dono existing Export/Delete/Apply ko affect na karein
