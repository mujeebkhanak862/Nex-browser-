# My Themes — What Changed

Implements Design v2 item #16 ("Export/Import themes — versioned JSON
package") plus the "My Themes" section from the Theme Center spec:
save the current Appearance mode + Accent preset + Home Background choice
as a named, reusable theme; apply, delete, export, or import them.

## Files changed

1. **`app/src/main/res/xml/file_paths.xml`**
   - Added a `<cache-path name="theme_exports" .../>` entry. Without this,
     `exportMyTheme()`'s call to `FileProvider.getUriForFile()` on a file
     under `getCacheDir()/theme_exports/` would throw at runtime — caught
     and fixed during this pass, not shipped broken.

2. **`app/src/main/java/com/devil/browser/MainActivity.java`**
   - `importThemeLauncher` — `ActivityResultContracts.GetContent()`
     restricted to `application/json`, reads the picked file and hands it
     to `importMyTheme()`.
   - `showThemeCenter()` extended with a "My Themes" section: the saved
     list, a "Save current as theme…" row, and an "Import theme file…" row.
   - `loadMyThemes()` / `saveMyThemesArray()` — a JSON array stored under
     one more key (`my_themes`) in the same `theme_prefs` file
     `ThemeManager` already uses.
   - `promptSaveCurrentAsTheme()` — small `AlertDialog` with a name
     `EditText`, then calls `saveCurrentAsTheme(name)`.
   - `saveCurrentAsTheme(name)` — snapshots the current mode
     (`ThemeManager.getSavedMode`), accent preset name + colors, and
     `home_wallpaper_index` into one JSON object, appends it to the array.
   - `applyMyTheme(theme)` — reverse of the above: sets mode, sets accent
     (reconstructing an `AccentPreset` from the stored colors, so it still
     works even if the name doesn't match a currently-known built-in
     preset), sets the wallpaper index, then `recreate()`.
   - `deleteMyTheme(id)` — filters the theme out of the array and re-saves.
   - `exportMyTheme(theme)` — writes the theme's JSON to
     `getCacheDir()/theme_exports/<name>.nextheme.json`, gets a
     `FileProvider` `Uri` (same authority the app already uses for shared
     downloads), and opens a standard share sheet (`ACTION_SEND`).
   - `importMyTheme(theme)` — re-stamps the incoming JSON with a fresh
     `id` (never trusts an imported file's id, in case of a collision with
     an existing local theme) and appends it to the local array.
   - `buildMyThemeRow(theme, dialog)` — one row per saved theme: an accent
     color swatch, the name (tap to apply), an export (📤) button, and a
     delete (✕) button.

## JSON shape

```json
{
  "schema": 1,
  "id": "1737400000000",
  "name": "Sunset Ocean",
  "mode": "dark",
  "accentName": "Ocean",
  "accentLight": -31946041,
  "accentDark": -10079233,
  "homeWallpaperIndex": 2
}
```

`accentLight`/`accentDark` are raw ARGB ints (`Color.parseColor` /
`getColor()` return values as signed 32-bit ints — this is completely
normal for how Android stores colors, just not human-readable if you open
the file by hand).

## Known limitation — Personal Image is not portable

If the saved theme's Home Background was a Personal Image
(`homeWallpaperIndex == -1`), the actual photo is **not** included in the
exported JSON (it's a local file on that device, not something that
belongs in a small theme-settings file). Importing such a theme on another
device — or even re-importing it after the local photo was changed/removed
— falls back to the Default gradient rather than failing or showing a
blank Home screen. This is stated in the Theme Center sheet's note, not
just in this doc.

## Not yet done

- Duplicate/rename an existing saved theme (currently: save a new one,
  delete the old one).
- The remaining "reaches everything" gap from ACCENT-COLOR-CHANGES.md
  (Go button, two card borders, `colorSecondary`) still applies here too,
  since My Themes reuses the same accent mechanism.
- Universal side panel consolidating this with Bookmarks/History/AI/Agent.

## Testing note

Static source edit only — no Android SDK/emulator in this environment.
Before shipping: build in Android Studio, save/apply/delete a theme,
export one and confirm the share sheet actually opens (this is exactly
the kind of thing that silently breaks without the FileProvider path fix
above), and import it back in via a different app (e.g. a file manager)
to confirm round-tripping works.
