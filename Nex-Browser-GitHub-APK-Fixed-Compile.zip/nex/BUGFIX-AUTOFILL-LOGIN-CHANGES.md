# Bug fix: "autofill_login" was in the wrong method (pre-existing, not from any of my earlier changes)

Yeh bug is conversation ke shuru se maujood original code mein tha —
maine gap-fixing ke dauran notice kiya aur ab fix kar diya.

## Asal masla

`executeAutopilotAction(JSONObject actionObj)` (Autopilot ka single-tab
action executor) ke andar ek `"autofill_login"` case tha jo `step`,
`lane`, `jobId`, `steps`, `index` naam ke variables use kar raha tha —
lekin ye method sirf `actionObj` leta hai, in mein se koi bhi variable
is method mein exist hi nahi karta. Ye **compile error** hota — poori
app build hi nahi hoti.

Wajah: ye code block asal mein **doosre method**
(`executeAutomationStep(int lane, int jobId, JSONArray steps, int index)`
— Automation jobs ka multi-lane executor) ke liye likha gaya tha, jahan
`step`, `lane`, `jobId`, `steps`, `index` sab genuinely exist karte hain
— lekin galti se galat method ke andar paste ho gaya.

Ek chhota doosra bug bhi mila: password-manager-off wala check condition
compute karta tha lekin us par kuch karta hi nahi tha (empty `if` body)
— matlab password manager band hone par bhi credential fill ho jaata.

## Fix

1. Broken `"autofill_login"` case `executeAutopilotAction` se hata diya.
2. Sahi (fixed) version `executeAutomationStep` ke switch mein daal diya
   — jahan `step`/`lane`/`jobId`/`steps`/`index` sab sahi se resolve
   hote hain, "navigate" case ke turant baad.
3. Password-manager-off check ab genuinely rok deta hai (error report
   karke agla step chalata hai), khali check nahi rehta.

## Kahan

`MainActivity.java` — `executeAutopilotAction()` se hataya,
`executeAutomationStep()` mein sahi jagah daala.

## Testing note

Ye ek genuine compile-blocking bug tha — is fix ke baad Android Studio
mein build hona chahiye jahan pehle ye specific error aata. Test karna:
- Automation job mein `"action": "autofill_login"` step chalao — Vault
  se credential fill hona chahiye
- Password manager Settings se band karke wahi step chalao — "Password
  manager is turned off" error aana chahiye, credential fill nahi hona
  chahiye
