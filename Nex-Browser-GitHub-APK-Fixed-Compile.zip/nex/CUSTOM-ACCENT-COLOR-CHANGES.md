# Custom Accent Color (RGB Picker) — What Changed

Closes the "custom color picker" gap noted at the end of
ACCENT-COLOR-CHANGES.md. Adds a 6th option — "Custom…" — after the 5
built-in accent swatches in Theme Center.

## Files changed

**`app/src/main/java/com/devil/browser/MainActivity.java`** only.

1. Added `SeekBar` to the imports.
2. `showThemeCenter()` — added a "Custom…" swatch after the loop over
   `ACCENT_PRESETS`, showing either the current custom color (if
   selected) or an empty outlined circle, opening `showCustomAccentPicker()`.
3. `showCustomAccentPicker()` — an `AlertDialog` with a live color preview
   and three `SeekBar`s (Red/Green/Blue, 0-255), starting from whatever
   custom color was last saved (or Violet if none was ever set). Moving
   any slider updates the preview instantly. "Apply" derives a light and
   dark variant from the chosen RGB via `ThemeManager.shade()` (the same
   helper used for the Go button's gradient) and saves it as an
   `AccentPreset` named `"Custom"`.

## SCOPE NOTE — same boundary as the 5 presets, stated up front

A custom color reaches the same runtime-read spots the 5 built-in presets
do (see ACCENT-COLOR-CHANGES.md's ~22+3 call sites), but **not** the
`colorSecondary` `ThemeOverlay` mechanism from
ACCENT-COLOR-FULL-COVERAGE-CHANGES.md — that needs a precompiled XML
color resource per preset, which isn't possible for an arbitrary RGB
value chosen at runtime. `ThemeManager.applyAccentOverlay()`'s existing
`default` case already falls back to the Violet overlay for any
unrecognized preset name, "Custom" included, so this is a visual
inconsistency in one small set of Material-default-tinted controls (like
a plain `Switch`), not a crash risk. The picker dialog says this
directly, rather than only being documented here.

## How it works

Customize → Accent Color → Custom… → drag sliders, watch the preview
swatch update live → Apply → `recreate()` repaints the app with the
chosen color.

## Testing note

Static source edit only — no Android SDK/emulator in this environment.
Before shipping: build in Android Studio, pick a few different colors
across the RGB range (including very dark/very light ones, where the
`shade()` derivation could push a channel out of a sensible range) and
confirm both the light-mode and dark-mode variants stay legible.
