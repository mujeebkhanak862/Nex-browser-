# Closing Two More Gaps — Switch Tinting + Panel Quick Access

Two follow-ups after being asked to genuinely finish as much of the
remaining list as possible.

## 1. Accent color now reaches every on/off Switch (closes a real gap)

CUSTOM-ACCENT-COLOR-CHANGES.md said custom RGB colors couldn't reach
`colorSecondary` because that needs a precompiled resource. That's still
true in general — but while re-checking the scope, a search for every
`Switch` in the file turned up that there are exactly **five** of them,
all built directly in Java, and the shared one (`buildSettingsToggleRow`,
used across every settings screen) was the actual practical source of
"switches stay Violet regardless of accent." Instead of relying on
`colorSecondary` at all for these, they're now tinted explicitly and
correctly at creation time.

**Files changed:** `app/src/main/java/com/devil/browser/MainActivity.java` only.

- New `tintSwitch(Switch)` helper: builds a checked/unchecked
  `ColorStateList` from `ThemeManager.getAccentColor()` (thumb) and a
  darkened version via `ThemeManager.shade()` (track), and applies both.
- Called from all five `Switch` construction sites: the shared
  `buildSettingsToggleRow()`, the Ad Block toggle, the download-notification
  toggle, the Facebook-notification toggle, and the password manager
  master toggle.

Net effect: **every** switch in the app now follows the chosen accent —
presets and custom RGB alike — with no dependency on the static
`colorSecondary` overlay for this widget type. The `colorSecondary`
overlay from ACCENT-COLOR-FULL-COVERAGE-CHANGES.md is still in place and
still only reaches the 5 named presets, but in practice there was nothing
else in this codebase using a plain, untinted Material default control —
no `RadioButton`, no bare `CheckBox` outside the one this session already
tinted explicitly (the toolbar customizer's). So the remaining gap really is
just "colorSecondary itself," an internal Material Components detail with
no visible effect anywhere in this app, rather than a user-facing one.

## 2. Universal Panel: real quick access to AI/Agent, Vault, Ad Block, Customize

UNIVERSAL-PANEL-CHANGES.md deliberately left AI/Agent/Privacy out of the
Bookmarks/History/Tabs panel, reasoning that merging their full screens
in was too large/risky a change. That reasoning still holds — but leaving
them completely unlinked meant the panel wasn't really "universal" in any
sense, just "Bookmarks/History/Tabs." This adds a middle ground: a
horizontal quick-access strip at the top of the panel (below the
Bookmarks/History/Tabs header, above the content) with four chips:

- **✨ AI & Agent** → `buildAgentOsHubView()` (existing screen, unchanged)
- **🔒 Vault** → `buildPasswordsView()` (existing screen, unchanged)
- **🛡 Ad Block** → `buildAdBlockDashboard()` (existing screen, unchanged)
- **🎨 Customize** → `showThemeCenter()` (this session's Theme Center)

**Files changed:** same file, same method (`buildBookmarksHistoryView`).

- `buildPanelQuickAccessChip(label, onClick)` — small reusable chip
  builder (label + background + click handler).
- The strip itself, added right after the header, using a
  `HorizontalScrollView` so it doesn't force the sheet wider on small
  screens.

Each chip calls the **existing, unmodified** screen builder for that
feature — none of their internal logic was touched, so this carries
none of the risk a real merge would have. What it does do: turn one
screen into the actual "start here" hub the design doc wanted, even
though the underlying screens are still separate rather than one
seamless panel.

## What's still genuinely not done

- The panel is still a full-page screen (this app's existing
  `pageContainer` pattern), not an edge-anchored sliding drawer with the
  live page dimmed behind it — unchanged from UNIVERSAL-PANEL-CHANGES.md.
- AI/Agent/Vault/Ad Block are reachable from the panel now, but their
  content still isn't *inside* it — tapping a chip leaves the panel
  entirely rather than expanding within it.
- `colorSecondary` itself is still fixed per-preset (not custom-RGB-aware)
  for anything that might read it directly in the future, even though
  nothing currently in the app does.

## Testing note

Static source edit only — no Android SDK/emulator in this environment.
Before shipping: build in Android Studio, toggle a few switches under
each accent (presets and a custom color) and confirm they visibly match,
and open the panel, scroll the quick-access strip, and confirm all four
chips land on the right screen.
