# AI-Command Mode — What Changed

Implements the "AI-command mode" item — a distinct focused-address-bar
state, separate from normal search/URL entry (Blueprint section 4, Design
v2 section 13-14).

## Files changed

### App (DevilBrowser)
1. `app/src/main/res/drawable/ic_nav_ai.xml` (new) — sparkle toggle icon.
2. `app/src/main/res/layout/activity_main.xml` — added `btnAiMode` at the
   start of the omnibox pill. Pill order: AI toggle -> text -> QR -> mic -> Go.
3. `app/src/main/res/values/strings.xml` — added ai_command_* strings.
4. `app/src/main/java/com/devil/browser/MainActivity.java` —
   `btnAiMode` field + `isAiCommandMode` flag; `submitOmnibox()` branches to
   `runAiCommand()` when the mode is on; `toggleAiCommandMode()` recolors the
   icon and swaps the hint; `runAiCommand()` reuses the same httpPostJson /
   networkExecutor / mainHandler pattern as AI Summary's callSummarizeApi(),
   pointed at a new `/ai-command` endpoint.

### Backend (nex-backend)
5. `main.py` — new `AiCommandRequest` model + `POST /ai-command` endpoint,
   built the same way as `/summarize` (same Claude Haiku call, same
   ANTHROPIC_API_KEY check). Only the current URL is passed as optional
   context — no page text is extracted for this one.

## How it works
Tap the sparkle icon -> hint becomes "Ask AI anything...". Type a
question/command and hit Go -> POSTs {command, url} to /ai-command instead
of navigating -> backend calls Claude -> reply shown in a dialog -> AI mode
turns back off automatically (one command per toggle).

## Testing note
Static source edits on both sides. `python -m py_compile` passed on
main.py. Java side checked for balanced braces/parens only, not compiled.
Needs a real ANTHROPIC_API_KEY + backendUrl configured to actually call out.
