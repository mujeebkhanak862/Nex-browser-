# Toolbar Customization — What Changed

Implements the Blueprint's "toolbar customization (reorder/enable/disable)"
item. Scoped to the four navigation buttons — Back, Forward, Home,
Refresh. Tabs and Menu are intentionally left out (always shown): Tabs is
paired with the tab counter, and Menu is the only way to reach most other
screens, so both are structural rather than optional.

## Files changed

**`app/src/main/java/com/devil/browser/MainActivity.java`** only.

1. Added `CheckBox` to the imports (not previously used anywhere in this file).

2. `TOOLBAR_BUTTON_IDS` — the four customizable ids: `back`, `forward`,
   `home`, `refresh`.

3. Persistence, two SharedPreferences keys (the existing `prefs` field,
   same one everything else in the file already uses):
   - `toolbar_all_order` — JSON array of **all four** ids, in the user's
     preferred order, regardless of visibility.
   - `toolbar_hidden` — JSON array of the subset currently hidden.
   Keeping the full order separate from the hidden set means re-enabling
   a hidden button puts it back where it was, not at the end.

4. `applyToolbarCustomization()` — removes all four buttons from `topBar`,
   then re-adds only the non-hidden ones in saved order, at the front of
   the bar (before the flexible spacer). Called once from `onCreate()`
   right after the four buttons are found, and again after every change
   made in the customizer sheet — no activity `recreate()` needed for
   this particular setting, unlike the Theme Center options.

5. `showToolbarCustomizer()` / `buildToolbarRow()` — a `BottomSheetDialog`
   listing the four buttons in their current order: a checkbox (visible/
   hidden), the label, and ▲/▼ buttons to move that row (greyed out and
   inert at the top/bottom respectively). Any change saves immediately,
   calls `applyToolbarCustomization()`, then rebuilds the sheet — same
   dismiss-and-reopen pattern already used for My Themes' delete button.

6. `moveToolbarButton(fromIndex, toIndex)` — swaps positions in the saved
   order list.

7. `showThemeCenter()` — added a "Toolbar buttons…" row right after Home
   Background, opening `showToolbarCustomizer()`.

## How it works

Customize → Toolbar buttons… → uncheck Refresh, tap ▲ next to Home a
couple of times → toolbar immediately reflects it, no restart needed.

## Not yet done

- Tabs/Menu are not customizable (by design, see above — not a gap, a
  scope decision).
- Top/bottom toolbar placement (moving the whole bar, not just
  reordering within it) is not implemented.
- No drag-and-drop — reordering is via ▲/▼ buttons. A real drag handle
  would need a drag-and-drop or `ItemTouchHelper`-style implementation;
  the button approach was chosen as the lower-risk option that doesn't
  need a new library or gesture-conflict testing against the bottom
  sheet's own swipe-to-dismiss.

## Testing note

Static source edit only — no Android SDK/emulator in this environment.
Before shipping: build in Android Studio, hide/show and reorder buttons,
confirm the omnibox row below is unaffected, and check that hiding all
four still leaves a usable toolbar (Tabs/Menu remain).
