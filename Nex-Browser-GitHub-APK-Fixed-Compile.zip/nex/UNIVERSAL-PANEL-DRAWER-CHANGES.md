# Universal Panel — Gap A closed: true edge-anchored drawer

Pehle Bookmarks/History/Tabs panel ek **full-page screen** tha (pura screen
cover karta tha, peeche wala page dikhta hi nahi tha). Ab ye ek **asli
edge-anchored sliding drawer** hai — Design v2 ka "universal side panel"
goal jo bacha hua tha.

## Kya badla

1. **Naya overlay, `pageContainer` se bilkul alag**: `universalPanelContainer`
   (dimmed scrim, poori screen) + `universalPanelDrawer` (screen ke 86%
   chauda, dayen se slide hota hua, andar Bookmarks/History/Tabs content).
   `pageContainer` (Settings, AI, Automation, wagera ~50+ dusre screens)
   bilkul waisa hi raha — unhe touch nahi kiya, kyunki wo genuinely full
   page hone chahiye, drawer nahi.
2. Panel ab **slide-in animation** ke saath khulta hai (240ms), scrim
   dim hota hai (peeche wala page dhundhla dikhta hai, gayab nahi hota),
   aur scrim par tap karne se ya hardware **Back** button se band ho jata
   hai.
3. Panel ke andar se kahin bhi (AI/Vault/Ad Block/Customize quick-access
   chips, tab list, "+ New Tab") ab sahi tareeqe se sirf drawer band karte
   hain (`hideUniversalPanel()`), pehle ki tarah poori page container
   nahi.
4. Ek shared row (bookmark/history row) jo Timeline aur Semantic Search
   jaise alag full-page screens mein bhi reuse hoti hai, usko
   `hideAnyOverlay()` diya gaya hai — chahe wo drawer ke andar ho ya full
   page ke andar, sahi wala hi band hoga.

## Kahan implement hua

`DevilBrowser/app/src/main/java/com/devil/browser/MainActivity.java` —
sirf ye ek file, koi naya layout/resource file nahi chahiye tha.

## Testing note (zaroori)

Sandbox mein Android SDK/emulator nahi hai, isliye ye sirf source-level
edit + manual verification (brace/paren balance) hai — asli build/run
Android Studio mein hi ho sakta hai. Build karke check karna:
- Panel kisi bhi entry point se khulne par slide-in hota hai, scrim dim
  dikhta hai
- Scrim tap aur hardware Back dono se band hota hai
- Bookmarks ↔ History ↔ Tabs switch karne par flicker/re-animate nahi
  hota (sirf content swap)
- Tabs section se tab switch/close/+New Tab sahi kaam karte hain
- Quick-access chips (AI, Vault, Ad Block, Customize) drawer band karke
  sahi full page kholte hain
- History → Timeline aur Semantic Search se khula row tap karne par sahi
  overlay band hota hai (drawer ya full page, jo bhi khula ho)
