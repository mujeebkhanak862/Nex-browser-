# Theme Center — What Changed (Phase 1 + Appearance slice of Phase 2)

Implements the Light/Dark/System switch from the design docs' Theme/Customize
Side Panel — the core subject of Browser_Design_v2_Updated.docx. This is a
foundation, not the whole feature: see "Not yet done" below.

## Files changed

1. **`app/src/main/res/values/colors.xml`** (rewritten)
   - Is now the **default/Light** palette for the theme-dependent tokens
     (bg_primary, bg_secondary, bg_tertiary, ember, ember_dim, gold,
     line_color, text_primary, text_dim, card_bg, card_bg_soft, search_pill_bg).
   - Still holds white/black and the `wallpaper_*` Home-background presets
     unchanged — those are user content choices, not the system theme, so
     they intentionally don't switch with Light/Dark (see the comment in
     the file for the "Default" preset's specific caveat).

2. **`app/src/main/res/values-night/colors.xml`** (new file)
   - Overrides just the theme-dependent tokens with the app's **original**
     dark palette, unchanged in value — so Dark mode looks pixel-identical
     to how the app looked before this change.
   - Because Android resource resolution falls back to `values/colors.xml`
     for anything not redefined here, white/black/wallpaper_* don't need to
     be repeated in this file.

3. **`app/src/main/java/com/devil/browser/ThemeManager.java`** (new file)
   - Three modes: `MODE_LIGHT`, `MODE_DARK`, `MODE_SYSTEM`.
   - `getSavedMode()` / `setMode()` — persisted in a dedicated SharedPreferences
     file, default `"dark"` so existing installs don't silently re-theme.
   - `apply()` — calls `AppCompatDelegate.setDefaultNightMode(...)`. Must run
     before `super.onCreate()`.

4. **`app/src/main/java/com/devil/browser/MainActivity.java`**
   - `ThemeManager.apply(this)` added as the very first line of `onCreate()`,
     before `super.onCreate()`.
   - New main-menu item **"Customize"** (with a new `ic_menu_customize.xml`
     palette icon), between Ad Block and Tools, wired to `showThemeCenter()`.
   - `showThemeCenter()` — a `BottomSheetDialog` (this codebase's existing
     pattern for menus/pickers) listing Light / Dark / System with a
     checkmark on the active one. Tapping a different mode calls
     `ThemeManager.setMode()` then `recreate()`.
   - `buildThemeModeRow()` — row builder for the three options.

## How it works

Because `themes.xml`'s `Theme.DevilBrowser` already extends
`Theme.MaterialComponents.DayNight.NoActionBar` and every layout/Java call
already referenced `@color/...` names rather than hardcoded hex, splitting
those names across `values/` (Light) and `values-night/` (Dark) makes the
**entire existing UI** theme-aware automatically — no per-screen rewiring
needed. `ThemeManager` just decides which of the two resource sets is active.

- **Dark** -> `AppCompatDelegate.MODE_NIGHT_YES` -> forces `values-night/`
  (today's exact look).
- **Light** -> `MODE_NIGHT_NO` -> forces the new `values/` palette.
- **System** -> `MODE_NIGHT_FOLLOW_SYSTEM` -> follows the device's Android
  Light/Dark setting.

## Not yet done (still open from the design docs)

- Built-in theme gallery, "My Themes" (save/duplicate/export), a custom
  color picker, and personal-image backgrounds — these are Phase 2's
  remaining pieces and Phase 5's "universal side panel" (Bookmarks/
  History/AI/Agent all in one panel). None of these are stubbed here with
  fake buttons; "Customize" currently opens Appearance only, with an
  honest "coming in a future update" note in the sheet itself.
- The `wallpaper_*` Home-background presets (separate from this system
  theme) were left unchanged — flagged in `colors.xml`'s comments for
  whoever builds the theme gallery next.

## Testing note

Static source edit only — no Android SDK/emulator in this environment.
Before shipping: build in Android Studio, toggle all three modes on a real
device (including a device set to system dark mode, to check System mode),
and spot-check a few screens (Home, Tabs, Settings) for any hardcoded
non-token colors that don't adapt — a full app this size may have a few
that were missed by this pass.
