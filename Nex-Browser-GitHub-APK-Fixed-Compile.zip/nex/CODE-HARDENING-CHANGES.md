# Code-hardening pass (30 Sep 2026)

Goal: make the source correct and safe **before** the first real build. Nothing here was
device-tested — build + device QA still happen last, on GitHub Actions and a real phone.
What WAS verified: Java parses, all `R.*` resources exist, backend `py_compile` + 37 pytest tests pass.

## Build / release
- Added the official `gradle/wrapper/gradle-wrapper.jar` (Gradle 8.0) — `./gradlew` now works from a clean checkout.
- Added `app/proguard-rules.pro` (the release build referenced it but it did not exist).
- Release signing via env vars (`NEX_KEYSTORE_FILE`, `NEX_KEYSTORE_PASSWORD`, `NEX_KEY_ALIAS`, `NEX_KEY_PASSWORD`) — no secrets in git.
- Removed `android.enableJetifier` (all dependencies are AndroidX). Lint no longer blocks on warnings.
- `.github/workflows/ci.yml`: backend tests + Android lint/debug APK (+ signed release if secrets exist).
- Manifest: `allowBackup="false"` (restored backups cannot decrypt the Keystore-bound vault), camera/mic `uses-feature required="false"`.

## Backend security (nex-backend/main.py)
- **13 AI endpoints were open to the internet** (`/summarize`, `/ai-command`, `/reader/clean`, `/web/*`, `/history/*`, `/files/analyze`, `/ai/tab-*`) and spent the owner's `ANTHROPIC_API_KEY`. Now they need login + are capped at 120 calls/hour/user. Android now sends the token on these calls.
- **Google Sign-In accepted tokens meant for other apps** (no `aud` check). Now requires `GOOGLE_CLIENT_ID`, matching `aud`, and `email_verified`.
- Passwords: PBKDF2 100k → 600k iterations (old hashes upgrade silently on next login), minimum length 6 → 8 (Android UI updated), emails normalised (case-insensitive), constant-time-ish login for unknown emails.
- Rate limits on login / register / reset-password / delete-account.
- SSRF guard on Watch List and Custom API (blocks localhost, private, link-local, metadata IPs; redirects re-checked hop by hop).
- Saved AI keys and Custom-API keys are encrypted at rest (Fernet). Legacy plaintext rows keep working.
- CORS default is now closed (the Android app does not need CORS).
- Push notifications moved from the shut-down FCM legacy API to **FCM HTTP v1** (service-account JSON); dead tokens are pruned.
- Scheduler/watch checks use atomic claims → cannot double-fire with multiple workers.

## Android browser-core fixes (MainActivity.java)
- **Website file uploads** (`<input type=file>`) were not implemented at all — added `onShowFileChooser`.
- **Web camera / microphone** permission prompts were never answered — added `onPermissionRequest` with allow/block dialog + runtime permission.
- **Renderer crash killed the whole app** — added `onRenderProcessGone` recovery with a crash-loop guard.
- HTTP Basic/Digest auth dialog (`onReceivedHttpAuthRequest`).
- Downloads now carry the page's cookies (downloads behind a login used to fail).
- WebView hardening: file/content access off, Google Safe Browsing on.
- The "Nex Automation API" curl (contains the access token) is copied as a *sensitive* clip and auto-cleared after 60 s.

## Round 2
- **Pause / Resume (#62/#63) is now durable.** Before, "paused" lived only in the phone's memory: restarting the app (or opening another device) silently resumed a job the user had paused, and "Resume" said "Nothing paused". New endpoints `POST /agent/jobs/{id}/pause` and `/resume`; a step already in flight when you pause still records its result but the job stays paused; Resume continues from the saved step. Android calls them, and Resume now also works after an app restart.
- **Progress / ETA (#66):** `/agent/jobs` now returns `progress_pct`, `steps_done`, `steps_total`, `eta_seconds`, `avg_step_seconds`, measured server-side (paused time is excluded). Android shows it when it has no local timer (i.e. after a restart). Note: progress/ETA already existed on Android; this only makes it survive restarts.
- **Website location** (`navigator.geolocation`) was silently denied everywhere; now there is an Allow/Block prompt + Android runtime permission (manifest: coarse/fine location, marked optional hardware).
- Tests: +3 (pause/resume, ETA from measured step time, cross-user pause blocked).

## Round 3
- **File Intelligence now reads PDFs** (#111/#14): backend `/files/analyze` accepts `content_base64` + `mime_type` (png/jpg/gif/webp/pdf, 5 MB cap, validated) and the model reads them directly, so scanned PDFs / photos of documents work without OCR libraries. Android shows "Analyze with AI" on `.pdf` downloads. (Images already had their own "Understand Image" button.) +3 tests.
- Audit: the only endpoints without auth are `/health` and the `/auth/*` login routes.
- **Ad Block rewritten (#15):**
  - Matching is now by *host and its parent domains* instead of `url.contains(domain)`. The old test could block normal pages whose URL merely mentioned an ad domain, and was a linear scan of every request.
  - The main page you navigate to is never blocked, only sub-resources.
  - Built-in list grew from 21 to ~130 well-known ad / popup / native-ad / tracker domains.
  - New: **Import filter list** (EasyList or hosts file) on the Ad Block screen, with Remove. Only plain-domain rules are used (`||domain^`, hosts lines, bare domains); cosmetic rules, `@@` exceptions, path rules and `$options` are skipped on purpose because honouring them needs a real filter engine. Be honest in marketing: this is domain-level blocking, not uBlock-level.

## Round 4
- **Incognito is now really isolated (#8/#6).** Private tabs use their own WebView *profile* (androidx.webkit 1.11 `MULTI_PROFILE`): separate cookies, site storage, cache. No second OS process needed (the old docs claimed that was the only way). Closing the last private tab deletes only that profile.
- **Bug fixed: closing the last Private tab called `CookieManager.removeAllCookies()` — logging the person out of EVERY normal tab.** Gone.
- **Bug fixed: closing a tab to the left of the current one switched the view to the wrong tab** (index wasn't shifted). Closing the current tab now returns to the tab it was opened from.
- **`window.open` / `target=_blank` popups** now open as a real linked tab (OAuth / payment popups work), `window.close()` closes it, and popups with no tap behind them stay blocked.
- New dependency: `androidx.webkit:webkit:1.11.0`. If the first build complains about `Profile`/`ProfileStore`/`setProfile`, tell me the exact error — those are the lines I could not compile here.

## Round 5
- **Real compile error fixed:** `onResume()` had `@Override` written twice (Java rejects duplicate annotations) - it would have failed the very first build. Also added the missing `@Override` on `onPause()`. Added an AST-level check for duplicate methods/fields/annotations (none left).
- **Password bridge locked (#22):** now an `androidx.webkit` `WebMessageListener` - main frame only, and the sender's origin must equal the page shown in the tab. An ad/iframe script can no longer trigger a fake "Save password?" prompt. Old `addJavascriptInterface` is used only on very old WebViews.
- **Background agent (#9) - what is and is not delivered:**
  - NEW `AgentForegroundService` (+ manifest `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_DATA_SYNC`, `foregroundServiceType="dataSync"`): while any agent lane (or Autopilot) is busy, a low-priority "Nex agent is working" notification keeps the process alive, so switching to another app no longer lets Android kill the job half-way. It stops itself when all lanes are idle.
  - **Bug fixed:** the 5-second job poller was stopped in `onPause()`, so the moment you left the app no new queued jobs were picked up and finished jobs were not reported. It now keeps running while the service is up and stops when idle.
  - NEW: when a **scheduled** workflow fires, the backend sends a push "Scheduled task is ready - open Nex to run it" (+2 tests).
  - NOT delivered (honest limit): swiping Nex away from Recents still ends running jobs, and scheduled tasks still need the app opened, because the browser engine runs inside the Activity. Running with the app fully closed would need the agent loop moved out of `MainActivity` into a Service (large refactor) - recommended only after the first build proves the current code.
  - Android 12+ blocks starting a foreground service from the background; if that happens the job still runs while Nex is visible (caught, no crash). Android 13+ also needs the notification permission for the notification to be visible.

## Round 6
- **Theme gap F closed:** `colors.xml` (values/ + values-night/) is now the single source of truth for BOTH the light and dark side of the five built-in accents; the Java presets are only a fallback. **Bug fixed on the way:** the old sync read the "light" accent through the current configuration, so on a phone that was in dark mode at startup the light accent was overwritten with the dark value.
- **Theme gap G (custom RGB) - accepted limitation:** a compiled ThemeOverlay cannot take a runtime colour. Every place that reads the accent in code shows the exact custom colour; only a few Material widgets that rely purely on the theme's `colorSecondary` use the nearest built-in preset. Not fixable without replacing those widgets; documented, not hidden.
- **Structured extraction (#112):** limits raised 15x6 -> 50 rows x 10 columns (page text sent 6k -> 20k chars). **Bug fixed:** `max_tokens` was 800, so any longer table was cut mid-JSON and the app silently returned an EMPTY table ("no table on this page"). Cut-off replies now keep every complete row, rows are padded/truncated to the column count, and the app tells you when a large table was cut. +1 test.
- **Ad-block filter engine upgraded:** imported lists now also support `||host/path` rules (block only under that path), `@@||host^` exceptions (never block that host - also skips cosmetic hiding there), and cosmetic "hide this element" rules (`##.ad`, `###id`, `site.com##.sel`) injected as CSS, one rule at a time so a selector the WebView does not understand cannot break the rest. Still deliberately NOT supported (skipped, never guessed): `$options` (third-party, script, domain=), regex rules, scriptlets `+js`, procedural cosmetics (`:has-text`, `:xpath`). Compared with uBlock Origin this is a smaller engine - say so in store listings.

## Round 7 - the code is now compiled by a REAL javac
- **New capability:** the whole app (`MainActivity` 19k lines + 3 other classes) is now compiled with a real `javac` against the real Android API 34 `android.jar`, with generated `R.java` and small hand-written stubs for androidx / Firebase / Google classes (`DevilBrowser/tools/javac-check/run.sh`). Result: **0 errors**. All 41 XML resource files are well-formed and every `@drawable/@color/@style/...` reference resolves; manifest classes exist; Gradle dependencies cover every import.
- **Real compile errors that this found and fixed** (javalang's syntax-only parse had missed all of them):
  1. 3x `illegal forward reference` in the home-image picker launcher (field initializer lambda used `networkExecutor`/`mainHandler`/`prefs` before their declaration) - now `this.`-qualified.
  2. `topBar` declared as `View` but `removeView()/addView()` called on it (toolbar reorder feature) - now cast to `ViewGroup`.
  3. Missing `import android.content.Intent` (from my own foreground-service code).
  (The duplicate `@Override` from round 5 was also a compile error.)
- **What this does NOT prove:** the androidx/Firebase stubs are written from memory of the real APIs (notably `ProfileStore`, `WebViewCompat.setProfile/addWebMessageListener`, `ContextCompat.startForegroundService`), AAPT2 resource compilation, manifest merging, minSdk-24 API-level lint, and runtime behaviour. `./gradlew assembleDebug` remains the final authority.
- **`MainActivity` split, step 1:** the ad/tracker filter engine moved out into `AdFilterEngine.java` (360 lines, no Android dependency, hand-rolled URL parsing so odd ad URLs can never throw). It has a JUnit test (`app/src/test/.../AdFilterEngineTest.java`, 38 checks) that I ran on a real JVM: all pass. `MainActivity` keeps only the Android glue. CI now runs `testDebugUnitTest` and the quick javac check.

## Round 8 - more of MainActivity split out, with unit tests that found real bugs
Two more pure-logic classes extracted from `MainActivity` (now 19,244 lines) with 13 JUnit tests that I ran on a real JVM (all pass); `MainActivity` keeps thin delegates, whole app re-checked with real javac: 0 errors.
- `AgentRetryPolicy` - error classifier, retry caps, adaptive delays (#59/#75).
- `DownloadUtils` - media URL detection, HLS playlist parsing, file names, MIME, sizes, durations, CSV escaping, private-host test.

**Real bugs found while extracting (all fixed, each has a test):**
1. `isLikelyMediaUrl` matched `.ts` / `.mov` anywhere in the path, so `main.tsx`, `export.tsv`, `movie-reviews` were offered as "Download video". Extension must now end the token.
2. File name from a URL was percent-decoded **twice**: `C%2B%2B guide.pdf` became `C  guide.pdf`, and `100%25.pdf` threw and fell back to a timestamp name.
3. `sanitizeFileName` cut names at 120 chars **including the extension**, so a long `...apk` lost `.apk` and slipped past the risky-download warning. It also accepted `..` and control characters. Extension is now kept, `.`/`..`/dot-leading/control-character names are neutralised.
4. `formatBytes` had no GB tier (5 GB showed "5120.0 MB").
5. Address bar: any search that merely *starts with* `http` ("httpie tutorial", "http2 vs http3") was turned into a broken `https://httpie tutorial` URL instead of a Google search. Now only real `http://` / `https://` inputs count.
6. `isLocalDevAddress` treated any host starting with `10.` or `192.168.` as local, including real hostnames such as `10.example.com`. Now a proper private-IPv4 check.
7. **CSV export formula injection:** extracted table cells beginning with `=`, `+`, `-`, `@` would execute as formulas when the CSV is opened in Excel/Sheets (the data comes from arbitrary web pages). Such cells are now prefixed with `'` (plain numbers like `-5` are left alone).

## Round 9 - the remaining code items
- **Agent with the app closed (#9) - what is now true:** swiping Nex away from Recents while a task runs now shows a tap-to-continue notification ("Agent task paused - Nex was closed"), because the job is saved server-side after every step and the queue already resumes a `running` job from its saved step on the next launch. **The browser lanes still stop when the app is closed** (they live in `MainActivity`: ~3,900 lines of agent code with ~290 UI statements and ~260 Activity-context uses - moving that to a Service is a rewrite, not a refactor, and cannot be done safely without running the app). Also fixed: the foreground-service flag lived on the Activity, so a recreated Activity could leave a stale "agent is working" notification; the service now reports its own state.
- **Custom RGB accent (gap G) closed in practice:** `ThemeManager.tintViewTree()` tints the widgets that only follow the theme overlay (check boxes, radio buttons, seek bars, progress bars, text cursors/selection, switches) with the exact custom colour, applied to every full page, the side panel, the main screen and - via the new `AccentDialogBuilder` (replaces all 86 `AlertDialog.Builder` calls) - every dialog's buttons and inputs. Backgrounds are never touched.
- **Ad-block engine, `$options` and patterns now supported:** general URL patterns (`/ads/*`, `-ad-banner-`, `|https://x.com/pixel|`, `*` wildcard, `^` separator, `|` anchors), `$third-party`/`~third-party`, resource types (`script`, `image`, `stylesheet`, `xmlhttprequest`, `subdocument`, `media`, `font`, `other`, each negatable), `domain=a.com|~b.com`, `important`, and `@@` exceptions with options. Resource type and third-party status are inferred from the request (extension, Accept header, registrable-domain compare with a small built-in two-level-suffix list - not the full Public Suffix List). Still skipped, never guessed: regex rules, `redirect=`, `removeparam=`, `csp=`, `popup`, `badfilter`, scriptlets, procedural cosmetics. Rules are indexed by host or prefiltered by a literal keyword; 2,000 lookups against 50,000 rules run in well under 3 s in the unit test.
- **Bug fixed in my own parser while testing:** a bare pattern such as `-ad-banner-` was mistaken for an (invalid) domain and dropped.
- **Real concurrency bugs fixed:** (1) `recordAdBlocked` ran on WebView's request threads and did a SharedPreferences JSON read-modify-write per blocked request - counters lost updates when requests raced and every ad request paid for JSON parsing; now lock-free counters flushed once on the main thread. (2) `DevilTab.detectedMediaUrls` was written from the request thread and read on the UI thread without a lock (`ConcurrentModificationException` risk) - now synchronized. (3) `blockedThisLoad` is volatile.
- Unit tests: 20 on a real JVM (engine 8, downloads 8, retry 4), all pass.

## Still open (code)
- Browser lanes cannot keep executing after the app is closed (needs the agent subsystem rewritten as a headless Service).
- Rest of the `MainActivity` split (it is UI/Activity-bound code; the pure-logic parts are already extracted and tested).
- Not done by design: regex filter rules, uBlock scriptlets, the full Public Suffix List.
- Out of scope per owner: #117 Cloud PC, #118 Master API.
