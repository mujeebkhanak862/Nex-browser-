"""
Nex Browser Backend
====================
Covers the features that genuinely cannot exist without a server:
  1. AI Summarizer     -> POST /summarize
  2. Cloud Sync         -> POST/GET /sync/bookmarks  (needs accounts)
  3. Push Notifications -> POST /notifications/register-token, /notifications/send
  4. Vault Backup       -> POST /vault/sync, GET /vault/download
     (passwords + history + bookmarks + shortcuts, one row per user
     in the `vault` table — each account's sync only ever touches
     its own row)
  5. Agent Automation   -> POST /agent/plan, POST /agent/report, GET /agent/result/{id}
     (plain-language instruction -> Claude breaks it into browser steps ->
     the Android app executes them for real in its own WebView -> result
     available both in-app and via the API)

Everything else in Nex Browser runs entirely on-device and does NOT
need this backend. Only wire the app to this server for these things.
"""

import os
import sqlite3
import secrets
import hashlib
import hmac
import time
import threading
import re
import socket
import ipaddress
from urllib.parse import urlparse
from contextlib import contextmanager
from typing import Optional, List

from fastapi import FastAPI, HTTPException, Header, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import httpx

# ============================================================
# CONFIG — set these as environment variables on Railway
# ============================================================
DB_PATH = os.environ.get("DB_PATH", "/data/nex.db")  # mount a Railway Volume at /data
VAULT_FILE_PATH = os.environ.get("VAULT_FILE_PATH", "/data/vault.json")  # only read once, by the legacy migration below — new vault storage is per-user rows in the `vault` DB table
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")

# Autopilot uses each user's OWN key for whichever provider they pick —
# never this server's own key. One default vision-capable model per
# provider; "gemini-flash-latest" is Google's own rolling alias for
# their current-generation Flash model (chosen deliberately over a
# pinned version like "gemini-2.0-flash" since Google retires specific
# versions every few months — the alias is Google's documented way to
# avoid that breaking callers). OpenAI and Anthropic don't offer an
# equivalent floating alias for a stable vision model, so those two are
# pinned to a specific, known-current model string — update here if
# either provider retires it.
AUTOPILOT_MODELS = {
    "gemini": "gemini-flash-latest",
    "openai": "gpt-4o",
    "anthropic": "claude-sonnet-4-6",
}
# Push notifications use FCM HTTP v1 (the legacy "server key" API was shut down
# by Google in 2024). Provide the Firebase service-account JSON either inline
# in FCM_SERVICE_ACCOUNT_JSON or as a file path in FCM_SERVICE_ACCOUNT_FILE.
FCM_SERVICE_ACCOUNT_JSON = os.environ.get("FCM_SERVICE_ACCOUNT_JSON", "")
FCM_SERVICE_ACCOUNT_FILE = os.environ.get("FCM_SERVICE_ACCOUNT_FILE", "")
# CORS: the Android app is a native client and does not need CORS at all, so the
# secure default is "no browser origins allowed". Set ALLOWED_ORIGINS to a
# comma-separated list only if a web frontend is added later.
ALLOWED_ORIGINS = [o.strip() for o in os.environ.get("ALLOWED_ORIGINS", "").split(",") if o.strip()]
# Google Sign-In: the Web Client ID that ID tokens must have been issued for.
GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", "").strip()

# Session Management (#21): short-lived access tokens + long-lived refresh
# tokens, instead of one token that's valid forever. A leaked access token
# is only useful for this long, not indefinitely.
ACCESS_TOKEN_TTL_SECONDS = 30 * 60          # 30 minutes
REFRESH_TOKEN_TTL_SECONDS = 30 * 24 * 60 * 60  # 30 days

app = FastAPI(title="Nex Browser Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================
# DATABASE — plain SQLite, no ORM, kept intentionally simple
# ============================================================
@contextmanager
def get_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                salt TEXT NOT NULL,
                token TEXT UNIQUE NOT NULL,
                created_at INTEGER NOT NULL
            )
        """)
        # Account Recovery (#25): added after the table already existed on
        # any already-deployed instance, so it's a migration, not part of
        # the CREATE TABLE above — wrapped so it's a no-op once the column
        # is already there (SQLite has no "ADD COLUMN IF NOT EXISTS").
        for migration in (
            "ALTER TABLE users ADD COLUMN recovery_code_hash TEXT",
            "ALTER TABLE users ADD COLUMN recovery_code_salt TEXT",
            "ALTER TABLE users ADD COLUMN recovery_code_created_at INTEGER",
            # Superseded by the ai_keys table below (multiple keys, one per
            # provider, each with its own per-feature toggles) — left here
            # unused rather than dropped (SQLite DROP COLUMN needs 3.35+).
            "ALTER TABLE users ADD COLUMN autopilot_provider TEXT",
            "ALTER TABLE users ADD COLUMN autopilot_api_key TEXT",
        ):
            try:
                db.execute(migration)
            except sqlite3.OperationalError:
                pass  # column already exists — already migrated

        # Multiple AI keys: one row per (user, provider) — a user can add
        # Gemini AND OpenAI AND Anthropic keys at once. Each key has its
        # own 3 feature toggles (planning/autopilot/visual); turning one
        # ON for a provider turns that SAME feature OFF for every other
        # provider (enforced in the /flags endpoint), so a feature never
        # has more than one active key to choose between at run time.
        db.execute("""
            CREATE TABLE IF NOT EXISTS ai_keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                provider TEXT NOT NULL,
                api_key TEXT NOT NULL,
                use_for_planning INTEGER NOT NULL DEFAULT 0,
                use_for_autopilot INTEGER NOT NULL DEFAULT 0,
                use_for_visual INTEGER NOT NULL DEFAULT 0,
                use_for_forms INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL,
                UNIQUE(user_id, provider),
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        try:
            db.execute("ALTER TABLE ai_keys ADD COLUMN use_for_forms INTEGER NOT NULL DEFAULT 0")
        except sqlite3.OperationalError:
            pass  # column already exists — already migrated

        # Custom APIs (Settings → 🔌 Custom APIs): any third-party API's
        # key + base URL, stored per-account so the SAME saved API is
        # usable from every device the user signs into — not local-only.
        # Unlike ai_keys (locked to gemini/openai/anthropic), "name" here
        # is whatever the user types (e.g. "OpenWeather", "My n8n webhook"),
        # so it's unique per-user rather than a fixed provider enum.
        db.execute("""
            CREATE TABLE IF NOT EXISTS custom_apis (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                base_url TEXT NOT NULL,
                api_key TEXT NOT NULL,
                auth_style TEXT NOT NULL DEFAULT 'header',
                header_name TEXT NOT NULL DEFAULT 'Authorization',
                header_prefix TEXT NOT NULL DEFAULT 'Bearer ',
                query_param_name TEXT NOT NULL DEFAULT 'api_key',
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL,
                UNIQUE(user_id, name),
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        # Session Management (#21) + Multi-device Sessions (#22) + Sign Out
        # Everywhere (#23): one row PER LOGGED-IN DEVICE, not one token per
        # account. users.token above is kept in the schema for backward
        # compatibility but no longer read or written — auth now runs
        # entirely through this table.
        db.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                access_token TEXT UNIQUE NOT NULL,
                refresh_token TEXT UNIQUE NOT NULL,
                device_label TEXT,
                created_at INTEGER NOT NULL,
                last_used_at INTEGER NOT NULL,
                access_expires_at INTEGER NOT NULL,
                refresh_expires_at INTEGER NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS bookmarks (
                user_id INTEGER PRIMARY KEY,
                data TEXT NOT NULL,
                updated_at INTEGER NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        # History Sync (#40) — same one-row-per-user shape as bookmarks
        # above, own table (separate from the merge-only "history" field
        # already inside the vault blob) so it gets its own real two-way
        # GET+POST sync pair, not just one-way backup.
        db.execute("""
            CREATE TABLE IF NOT EXISTS history (
                user_id INTEGER PRIMARY KEY,
                data TEXT NOT NULL,
                updated_at INTEGER NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        # Settings Sync (#43) — same one-row-per-user shape as bookmarks/
        # history above. Only a curated whitelist of real user-preference
        # toggles ever lands in here (see SYNCABLE settings on the
        # Android side) — never device-specific things like the backend
        # URL, push tokens, or biometric hardware settings.
        db.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                user_id INTEGER PRIMARY KEY,
                data TEXT NOT NULL,
                updated_at INTEGER NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)

        # Tab Sync — unlike bookmarks/history/settings, this is ONE ROW
        # PER DEVICE (not per user) — device_id is a stable per-install
        # Android ID, separate from device_label (just the human-readable
        # "Pixel 7" shown in the UI, not guaranteed unique on its own).
        # This lets "Tabs from other devices" show each device's open
        # tabs separately instead of one device's sync silently
        # overwriting another's.
        db.execute("""
            CREATE TABLE IF NOT EXISTS open_tabs (
                user_id INTEGER NOT NULL,
                device_id TEXT NOT NULL,
                device_label TEXT,
                data TEXT NOT NULL,
                updated_at INTEGER NOT NULL,
                PRIMARY KEY (user_id, device_id),
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS device_tokens (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                fcm_token TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS agent_jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                instruction TEXT NOT NULL,
                plan_json TEXT NOT NULL,
                status TEXT NOT NULL,
                priority INTEGER NOT NULL,
                current_step INTEGER NOT NULL DEFAULT 0,
                current_url TEXT,
                result_json TEXT,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        # Job Dependencies (#91): a job only becomes eligible to run once
        # the job it depends_on has status 'done'. NULL means no
        # dependency (runs whenever its turn comes up, as before).
        try:
            db.execute("ALTER TABLE agent_jobs ADD COLUMN depends_on INTEGER")
        except sqlite3.OperationalError:
            pass
        # Pause/Resume (#62/#63) + progress/ETA (#66): server-side timing so the
        # estimate survives app restarts and works from any device.
        for _col in ("last_step_at INTEGER", "steps_time_total INTEGER NOT NULL DEFAULT 0",
                     "steps_timed INTEGER NOT NULL DEFAULT 0"):
            try:
                db.execute(f"ALTER TABLE agent_jobs ADD COLUMN {_col}")
            except sqlite3.OperationalError:
                pass
        # Account/email context for Agent form/login tasks. Stored with the
        # job so the executor can use the same account identity throughout
        # the task without placing credentials in the task payload.
        try:
            db.execute("ALTER TABLE agent_jobs ADD COLUMN account_email TEXT")
        except sqlite3.OperationalError:
            pass
        # Error Reason Tracking (#69) / Last Successful Step (#68): kept
        # separate from current_step/status — current_step is "where to
        # resume from", last_successful_step is "how far did we actually
        # get without a problem", and last_error is "what went wrong on
        # the step after that", if anything did.
        try:
            db.execute("ALTER TABLE agent_jobs ADD COLUMN last_error TEXT")
        except sqlite3.OperationalError:
            pass
        # Goal-Based Agent (#71): 'plan' jobs (default, existing behavior)
        # get their full step list upfront from /agent/plan. 'goal' jobs
        # are created with an empty plan_json and grow it one action at a
        # time via /agent/goal/next as the task actually unfolds.
        try:
            db.execute("ALTER TABLE agent_jobs ADD COLUMN mode TEXT NOT NULL DEFAULT 'plan'")
        except sqlite3.OperationalError:
            pass
        # Multi-Agent Orchestrator (#72): NULL for an ordinary job; set
        # when a job is one sub-task of a larger orchestrated goal (see
        # agent_orchestrations below).
        try:
            db.execute("ALTER TABLE agent_jobs ADD COLUMN orchestration_id INTEGER")
        except sqlite3.OperationalError:
            pass
        # Agent-to-Agent Verification (#73): opt-in per job. When set, a
        # SECOND, independent AI call reviews the worker agent's claimed
        # final result against a real screenshot before the job is
        # allowed to be marked truly "done" — catches confidently-wrong
        # "task complete" claims instead of trusting them at face value.
        try:
            db.execute("ALTER TABLE agent_jobs ADD COLUMN verify_result INTEGER NOT NULL DEFAULT 0")
        except sqlite3.OperationalError:
            pass
        # Agent Sandbox (#76): opt-in per job. Android clears that lane's
        # WebView cache/history/form-data before the job's first step
        # (and again once it finishes) and blocks third-party cookies
        # for that WebView instance while it runs — so a sandboxed job
        # can't ride along on whatever's cached from the user's regular
        # browsing, and doesn't leave its own traces behind either.
        try:
            db.execute("ALTER TABLE agent_jobs ADD COLUMN sandbox INTEGER NOT NULL DEFAULT 0")
        except sqlite3.OperationalError:
            pass
        # Dry Run Mode (#77): opt-in per job. A dry-run job gets planned
        # normally (its full step list is visible right away, same
        # stepper UI as any job) but the queue (maybeStartAutomationQueue,
        # Android) skips it until the user explicitly confirms via
        # /agent/jobs/{id}/confirm-run — nothing actually executes until
        # then, so a risky-looking plan can be reviewed first.
        try:
            db.execute("ALTER TABLE agent_jobs ADD COLUMN dry_run INTEGER NOT NULL DEFAULT 0")
        except sqlite3.OperationalError:
            pass
        # Human Approval Layer (#78): opt-in per job. Generalizes Self-
        # Healing (#57)'s existing needs_approval pause+resume UI so it
        # can fire PROACTIVELY too — before attempting a click/fill_form
        # step whose target text looks consequential (checkout, delete,
        # pay, etc.), not only reactively when self-heal proposes a
        # replacement guess for a missing element.
        try:
            db.execute("ALTER TABLE agent_jobs ADD COLUMN require_approval INTEGER NOT NULL DEFAULT 0")
        except sqlite3.OperationalError:
            pass
        # Agent Permission Firewall (#79): one row per user — a domain
        # allow/block list the agent's own navigation must respect.
        # mode: 'off' (no restriction), 'whitelist' (ONLY these domains
        # allowed), or 'blacklist' (these domains blocked, everything
        # else allowed). Enforced client-side (Android checks before a
        # "navigate" step AND via shouldOverrideUrlLoading for clicks/
        # redirects) — this table is just the user's stored config.
        db.execute(
            "CREATE TABLE IF NOT EXISTS agent_firewall ("
            "user_id INTEGER PRIMARY KEY, "
            "mode TEXT NOT NULL DEFAULT 'off', "
            "domains_json TEXT NOT NULL DEFAULT '[]', "
            "updated_at INTEGER NOT NULL, "
            "FOREIGN KEY(user_id) REFERENCES users(id)"
            ")"
        )
        # Agent Policy Engine (#80): one row per user — generalizes
        # Human Approval Layer (#78)'s hardcoded sensitive-keyword list
        # into something the user can extend, plus two more global
        # safety knobs that apply across every job regardless of that
        # job's own per-job checkboxes.
        db.execute(
            "CREATE TABLE IF NOT EXISTS agent_policy ("
            "user_id INTEGER PRIMARY KEY, "
            "custom_keywords_json TEXT NOT NULL DEFAULT '[]', "
            "always_require_approval INTEGER NOT NULL DEFAULT 0, "
            "max_steps_per_job INTEGER, "
            "updated_at INTEGER NOT NULL, "
            "FOREIGN KEY(user_id) REFERENCES users(id)"
            ")"
        )
        # Web Page Change Monitor (#104) + Semantic Page Diff (#105): one
        # row per watched URL. last/previous content snippets are what
        # let the diff summary describe WHAT changed, not just THAT it
        # changed. Checked periodically by _scheduler_loop below
        # (piggybacks on its existing 30s tick) — no push notification
        # yet, Android sees changes by opening the Watched Pages screen
        # (pull, not push).
        db.execute(
            "CREATE TABLE IF NOT EXISTS watched_pages ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "user_id INTEGER NOT NULL, "
            "url TEXT NOT NULL, "
            "title TEXT, "
            "last_content_hash TEXT, "
            "last_content_snippet TEXT, "
            "previous_content_snippet TEXT, "
            "last_checked_at INTEGER, "
            "last_changed_at INTEGER, "
            "created_at INTEGER NOT NULL, "
            "FOREIGN KEY(user_id) REFERENCES users(id)"
            ")"
        )
        # AI Research Workspace (#106): a simple persistent collection of
        # saved pages the user is researching together — content
        # snippets stored the same way as AI Web Memory (#101), so
        # "Synthesize" can combine everything without re-fetching pages.
        db.execute(
            "CREATE TABLE IF NOT EXISTS research_items ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "user_id INTEGER NOT NULL, "
            "url TEXT NOT NULL, "
            "title TEXT, "
            "content TEXT, "
            "created_at INTEGER NOT NULL, "
            "FOREIGN KEY(user_id) REFERENCES users(id)"
            ")"
        )
        # Persistent Research Projects (#107): generalizes the single
        # flat workspace (#106) into multiple named, switchable
        # collections. Existing research_items predate this — their
        # project_id stays NULL, shown to the user as "Unsorted" rather
        # than silently losing them.
        try:
            db.execute("ALTER TABLE research_items ADD COLUMN project_id INTEGER")
        except sqlite3.OperationalError:
            pass
        db.execute(
            "CREATE TABLE IF NOT EXISTS research_projects ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "user_id INTEGER NOT NULL, "
            "name TEXT NOT NULL, "
            "created_at INTEGER NOT NULL, "
            "FOREIGN KEY(user_id) REFERENCES users(id)"
            ")"
        )
        # AI Notes (#108) + Source-to-Note Linking (#109): a note
        # optionally belongs to a project and optionally links back to
        # ONE specific saved source (research_items.id) it was written
        # about — both nullable, so a quick freeform note needs neither.
        db.execute(
            "CREATE TABLE IF NOT EXISTS research_notes ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "user_id INTEGER NOT NULL, "
            "project_id INTEGER, "
            "source_item_id INTEGER, "
            "title TEXT, "
            "content TEXT NOT NULL, "
            "created_at INTEGER NOT NULL, "
            "updated_at INTEGER NOT NULL, "
            "FOREIGN KEY(user_id) REFERENCES users(id)"
            ")"
        )
        db.execute(
            "CREATE TABLE IF NOT EXISTS agent_orchestrations ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "user_id INTEGER NOT NULL, "
            "goal TEXT NOT NULL, "
            "sub_tasks_json TEXT NOT NULL, "
            "current_index INTEGER NOT NULL DEFAULT 0, "
            "status TEXT NOT NULL DEFAULT 'running', "
            "final_result TEXT, "
            "created_at INTEGER NOT NULL, "
            "updated_at INTEGER NOT NULL"
            ")"
        )
        try:
            db.execute("ALTER TABLE agent_jobs ADD COLUMN last_successful_step INTEGER NOT NULL DEFAULT -1")
        except sqlite3.OperationalError:
            pass
        # Saved Workflows/Macros (#82): a user records/builds an agent task
        # once, then saves its steps here under a name so it can be run
        # again later without re-typing the instruction or re-planning.
        # steps_json is the exact same shape agent_jobs.plan_json already
        # uses, so running a saved workflow is just "make a new agent_job
        # with these steps" (see /workflows/{id}/run) — no re-plan call.
        db.execute("""
            CREATE TABLE IF NOT EXISTS workflows (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                steps_json TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        # Workflow Versioning (#86): version column added after the table
        # already existed elsewhere — a migration, wrapped so it's a no-op
        # once already applied (same pattern as the vault.checksum migration
        # above).
        try:
            db.execute("ALTER TABLE workflows ADD COLUMN version INTEGER NOT NULL DEFAULT 1")
        except sqlite3.OperationalError:
            pass

        # Every previous name+steps snapshot of a workflow, archived here
        # right before each edit or restore — same "archive-before-overwrite"
        # pattern as vault_backups above, so an edit is never destructive.
        db.execute("""
            CREATE TABLE IF NOT EXISTS workflow_versions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                workflow_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                version INTEGER NOT NULL,
                name TEXT NOT NULL,
                steps_json TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                FOREIGN KEY(workflow_id) REFERENCES workflows(id)
            )
        """)

        # Workflow Scheduling (#87): at most one active schedule per
        # workflow — 'once' (a single future run_at, stored in
        # next_run_at) or 'daily' (a repeating HH:MM, with next_run_at
        # always holding the next upcoming occurrence). A background
        # thread (see _scheduler_loop below) polls this table and turns
        # a due row into a normal agent_job — scheduling never bypasses
        # the regular automation queue.
        db.execute("""
            CREATE TABLE IF NOT EXISTS workflow_schedules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                workflow_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                recurrence TEXT NOT NULL,
                daily_time TEXT,
                next_run_at INTEGER NOT NULL,
                last_run_at INTEGER,
                enabled INTEGER NOT NULL DEFAULT 1,
                created_at INTEGER NOT NULL,
                FOREIGN KEY(workflow_id) REFERENCES workflows(id)
            )
        """)

        # One vault row PER USER (user_id is the primary key, same pattern
        # as the bookmarks table above) — replaces the old single shared
        # VAULT_FILE_PATH file that every logged-in user read and wrote to.
        db.execute("""
            CREATE TABLE IF NOT EXISTS vault (
                user_id INTEGER PRIMARY KEY,
                data TEXT NOT NULL,
                updated_at INTEGER NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        # Secure Vault Backup (#36): checksum column for integrity
        # verification, added after the table already existed elsewhere —
        # a migration, wrapped so it's a no-op once already applied.
        try:
            db.execute("ALTER TABLE vault ADD COLUMN checksum TEXT")
        except sqlite3.OperationalError:
            pass

        # Versioned history of PREVIOUS vault snapshots — archived here
        # right before each overwrite, so a bad sync/overwrite is
        # recoverable instead of the vault being a single row that's
        # always just "whatever was synced most recently".
        db.execute("""
            CREATE TABLE IF NOT EXISTS vault_backups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                data TEXT NOT NULL,
                checksum TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)


init_db()


# ============================================================
# ONE-TIME MIGRATION — the old code kept a single shared vault.json
# file on disk for EVERY logged-in user (the actual bug we're fixing).
# On first boot after this fix, if that old file still exists, its
# contents can only honestly belong to whichever single account last
# wrote it ("synced_by") — that's the one migration we can do safely.
# Anyone else's data was already being silently overwritten by the bug
# before this fix, so there's nothing else recoverable. Runs once —
# the old file is renamed afterward so this never re-runs.
# ============================================================
def migrate_legacy_shared_vault():
    import json
    legacy_path = VAULT_FILE_PATH
    if not os.path.exists(legacy_path):
        return
    try:
        with open(legacy_path, "r") as f:
            blob = json.load(f)
        owner_email = blob.get("synced_by")
        if not owner_email:
            os.rename(legacy_path, legacy_path + ".migrated")
            return
        with get_db() as db:
            row = db.execute("SELECT id FROM users WHERE email = ?", (owner_email,)).fetchone()
            if row:
                existing = db.execute("SELECT user_id FROM vault WHERE user_id = ?", (row["id"],)).fetchone()
                if not existing:
                    db.execute(
                        "INSERT INTO vault (user_id, data, updated_at) VALUES (?, ?, ?)",
                        (row["id"], json.dumps(blob), int(time.time())),
                    )
        os.rename(legacy_path, legacy_path + ".migrated")
    except Exception:
        # If anything about the old file is unreadable, leave it in place
        # untouched rather than risk losing it — just skip the migration.
        pass


migrate_legacy_shared_vault()


# ============================================================
# AUTH HELPERS — pbkdf2 password hashing (stdlib only, no
# extra native-compiled dependency like bcrypt)
# ============================================================
PBKDF2_ITERATIONS = 600_000        # OWASP 2023 recommendation for PBKDF2-HMAC-SHA256
LEGACY_PBKDF2_ITERATIONS = 100_000  # what every hash created before this fix used


def hash_password(password: str, salt: str) -> str:
    """New hashes are self-describing: 'pbkdf2$<iterations>$<hex>'. Old hashes
    (bare hex, 100k iterations) still verify and are upgraded on next login."""
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), PBKDF2_ITERATIONS).hex()
    return f"pbkdf2${PBKDF2_ITERATIONS}${digest}"


def verify_password(password: str, salt: str, stored: str) -> bool:
    if not stored:
        return False
    if stored.startswith("pbkdf2$"):
        try:
            _, iterations, digest = stored.split("$", 2)
            iterations = int(iterations)
        except ValueError:
            return False
    else:
        iterations, digest = LEGACY_PBKDF2_ITERATIONS, stored
    candidate = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), iterations).hex()
    return hmac.compare_digest(candidate, digest)


def password_needs_upgrade(stored: str) -> bool:
    return not stored.startswith("pbkdf2$") or int(stored.split("$", 2)[1]) < PBKDF2_ITERATIONS


def normalize_email(email: str) -> str:
    return (email or "").strip().lower()


# ------------------------------------------------------------
# Tiny in-memory rate limiter (per process). Enough to stop online password /
# recovery-code guessing on a single-instance deployment; use a shared store
# (Redis) if the backend is ever scaled to several instances.
# ------------------------------------------------------------
_rate_hits: dict = {}
_rate_lock = threading.Lock()


def client_ip(request: Request) -> str:
    fwd = request.headers.get("x-forwarded-for")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def rate_limit(key: str, limit: int, window_seconds: int):
    now = time.time()
    with _rate_lock:
        hits = [t for t in _rate_hits.get(key, []) if now - t < window_seconds]
        if len(hits) >= limit:
            _rate_hits[key] = hits
            raise HTTPException(429, "Too many attempts — please wait a few minutes and try again")
        hits.append(now)
        _rate_hits[key] = hits
        if len(_rate_hits) > 5000:  # opportunistic cleanup so the dict can't grow forever
            for k in [k for k, v in _rate_hits.items() if not v or now - v[-1] > window_seconds]:
                _rate_hits.pop(k, None)


# ------------------------------------------------------------
# SSRF guard: any URL the *user* supplies that the server then fetches must
# resolve to a public address, otherwise a user could make the backend probe
# localhost / cloud-metadata / private-network services.
# ------------------------------------------------------------
def assert_public_http_url(url: str) -> str:
    parsed = urlparse((url or "").strip())
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise HTTPException(400, "Only http:// and https:// URLs are allowed")
    try:
        infos = socket.getaddrinfo(parsed.hostname, parsed.port or (443 if parsed.scheme == "https" else 80), proto=socket.IPPROTO_TCP)
    except socket.gaierror:
        raise HTTPException(400, "Could not resolve that host")
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast
                or ip.is_reserved or ip.is_unspecified):
            raise HTTPException(400, "That address is not allowed")
    return url.strip()


# ------------------------------------------------------------
# Secrets at rest: user-saved AI / custom-API keys are encrypted (Fernet =
# AES-128-CBC + HMAC) before they touch SQLite, so a leaked nex.db or backup
# doesn't hand out everybody's third-party keys. Key comes from
# NEX_SECRET_KEY (recommended: set in Railway variables); if absent, one is
# generated once and kept beside the DB on the persistent volume.
# Values without the "enc:v1:" prefix are legacy plaintext and still work.
# ------------------------------------------------------------
from cryptography.fernet import Fernet, InvalidToken

_ENC_PREFIX = "enc:v1:"


def _load_fernet() -> Fernet:
    env_key = os.environ.get("NEX_SECRET_KEY", "").strip()
    if env_key:
        return Fernet(env_key.encode())
    key_path = os.path.join(os.path.dirname(DB_PATH) or ".", "secret.key")
    try:
        if os.path.exists(key_path):
            with open(key_path, "rb") as f:
                return Fernet(f.read().strip())
        os.makedirs(os.path.dirname(key_path), exist_ok=True)
        new_key = Fernet.generate_key()
        fd = os.open(key_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(new_key)
        return Fernet(new_key)
    except OSError as e:
        raise RuntimeError(f"Cannot load or create the secret-encryption key ({key_path}): {e}. Set NEX_SECRET_KEY instead.")


_fernet = _load_fernet()


def enc_secret(plain: str) -> str:
    if plain is None or plain.startswith(_ENC_PREFIX):
        return plain
    return _ENC_PREFIX + _fernet.encrypt(plain.encode()).decode()


def dec_secret(stored: str) -> str:
    if stored is None or not stored.startswith(_ENC_PREFIX):
        return stored  # legacy plaintext row
    try:
        return _fernet.decrypt(stored[len(_ENC_PREFIX):].encode()).decode()
    except InvalidToken:
        raise HTTPException(500, "A saved key could not be decrypted (server secret changed?) — please re-save it in Settings")


def get_current_user(authorization: Optional[str] = Header(None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing or invalid Authorization header")
    access_token = authorization.replace("Bearer ", "")
    with get_db() as db:
        row = db.execute(
            """
            SELECT sessions.id AS session_id, sessions.access_expires_at AS session_access_expires_at,
                   users.*
            FROM sessions
            JOIN users ON sessions.user_id = users.id
            WHERE sessions.access_token = ?
            """,
            (access_token,),
        ).fetchone()
        if not row:
            raise HTTPException(401, "Invalid or expired token")
        if row["session_access_expires_at"] < int(time.time()):
            raise HTTPException(401, "Access token expired — use /auth/refresh to get a new one")
        db.execute(
            "UPDATE sessions SET last_used_at = ? WHERE id = ?",
            (int(time.time()), row["session_id"]),
        )
        return dict(row)


def get_ai_user(user=Depends(get_current_user)):
    """Auth + per-user cost cap for endpoints that spend the server owner's
    ANTHROPIC_API_KEY. Previously these were open to the whole internet."""
    rate_limit(f"ai:{user['id']}", 120, 3600)
    return user


# ============================================================
# MODELS
# ============================================================
class RegisterRequest(BaseModel):
    email: str
    password: str
    device_label: Optional[str] = None


class LoginRequest(BaseModel):
    email: str
    password: str
    device_label: Optional[str] = None


class GoogleAuthRequest(BaseModel):
    id_token: str
    device_label: Optional[str] = None


class RefreshRequest(BaseModel):
    refresh_token: str


class SignOutEverywhereRequest(BaseModel):
    # If true, also ends the CURRENT session (so this device must sign in
    # again too). Default false — the common case is "someone else has my
    # account open somewhere, kick them out, but keep me logged in here".
    include_current_device: bool = False


class ResetPasswordRequest(BaseModel):
    email: str
    recovery_code: str
    new_password: str
    device_label: Optional[str] = None


class DeleteAccountRequest(BaseModel):
    # Re-confirming identity for a destructive, irreversible action, even
    # though the request is already authenticated. Accepts EITHER the
    # account password OR the Recovery Code — password-based accounts use
    # the former, Google-only accounts (whose password is a random value
    # they never see) use the latter.
    password: Optional[str] = None
    recovery_code: Optional[str] = None


class RenameSessionRequest(BaseModel):
    device_label: str


class BatchPlanRequest(BaseModel):
    instructions: List[str]
    sequential: bool = False  # if true, each job depends_on the previous one in the list


class BookmarksSyncRequest(BaseModel):
    bookmarks: list


class HistorySyncRequest(BaseModel):
    history: list


class SettingsSyncRequest(BaseModel):
    settings: dict


class TabsSyncRequest(BaseModel):
    device_id: str
    device_label: Optional[str] = None
    tabs: list


class VaultSyncRequest(BaseModel):
    # Deliberately loose typing — this is a single combined blob covering
    # whatever the app wants to back up (passwords, history, bookmarks,
    # shortcuts, ...). The app decides its shape; the server just stores it.
    #
    # End-to-End Encrypted Vault (#32): current app builds encrypt
    # bookmarks/history/shortcuts/passwords ALL client-side with the Vault
    # Passphrase and send the *_encrypted fields below instead of these
    # plain ones. The plain fields are kept only for backward compatibility
    # with an app build from before that — a current client never sends them.
    bookmarks: Optional[list] = None
    history: Optional[list] = None
    passwords: Optional[list] = None
    shortcuts: Optional[list] = None

    bookmarks_encrypted: Optional[str] = None
    history_encrypted: Optional[str] = None
    shortcuts_encrypted: Optional[str] = None
    passwords_encrypted: Optional[str] = None
    vault_salt: Optional[str] = None  # not secret — needed to re-derive the same key from the same passphrase on a new device
    # Download history METADATA only (filename/url/status/timestamp) — never
    # the actual downloaded file bytes, which stay on the device that
    # downloaded them. This just lets the same account see what it
    # downloaded from any device, same "your box, your token" rule as
    # everything else here.
    downloads: Optional[list] = None
    # Currently open tabs' URL/title metadata (Smart Tab Suspension) — same
    # "your box, your token" rule; the actual page/session state is never
    # stored, just enough to know what was open and reopen it.
    tabs: Optional[list] = None


class SummarizeRequest(BaseModel):
    text: str
    url: Optional[str] = None


class AiCommandRequest(BaseModel):
    command: str
    url: Optional[str] = None


class ReaderCleanRequest(BaseModel):
    title: Optional[str] = None
    text: str
    url: Optional[str] = None


class WebCompareRequest(BaseModel):
    pages: list  # [{"title": str, "url": str, "text": str}, ...]


class SourceReliabilityRequest(BaseModel):
    url: str
    title: Optional[str] = None
    text: str


class ContradictionRequest(BaseModel):
    pages: list  # same shape as WebCompareRequest.pages


class FactCheckRequest(BaseModel):
    claim: str
    context_url: Optional[str] = None
    context_text: Optional[str] = None


class HistorySemanticSearchRequest(BaseModel):
    query: str
    entries: list  # [{"title": str, "url": str, "content": str}, ...]


class DaySummaryRequest(BaseModel):
    entries: list  # same shape as above, one day's worth


class WatchPageRequest(BaseModel):
    url: str
    title: Optional[str] = None


class ResearchItemRequest(BaseModel):
    url: str
    title: Optional[str] = None
    content: Optional[str] = None
    project_id: Optional[int] = None


class ResearchProjectRequest(BaseModel):
    name: str


class ResearchNoteRequest(BaseModel):
    content: str
    title: Optional[str] = None
    project_id: Optional[int] = None
    source_item_id: Optional[int] = None


class FileAnalyzeRequest(BaseModel):
    filename: str
    content: str = ""                 # text of a plain-text file
    content_base64: Optional[str] = None   # raw bytes of an image / PDF
    mime_type: Optional[str] = None        # required with content_base64


class StructuredExtractRequest(BaseModel):
    title: Optional[str] = None
    url: Optional[str] = None
    text: str


class TabSearchTab(BaseModel):
    id: int
    title: str
    extract: Optional[str] = ""


class TabSearchRequest(BaseModel):
    query: str
    tabs: List[TabSearchTab]


class TabGroupsRequest(BaseModel):
    tabs: List[TabSearchTab]


class RegisterTokenRequest(BaseModel):
    fcm_token: str


class SendNotificationRequest(BaseModel):
    title: str
    body: str
    # If omitted, sends to every registered device for the authenticated user
    fcm_token: Optional[str] = None


class AiKeyRequest(BaseModel):
    provider: str  # "gemini", "openai", or "anthropic"
    api_key: str


class AiKeyFlagsRequest(BaseModel):
    use_for_planning: Optional[bool] = None
    use_for_autopilot: Optional[bool] = None
    use_for_visual: Optional[bool] = None
    use_for_forms: Optional[bool] = None


# ---- Custom APIs (Settings → 🔌 Custom APIs) ----
# Lets a user store ANY third-party API's key/base URL once (server-side,
# tied to their account — same pattern as ai_keys) so it works from every
# signed-in device, not just the one it was typed on. auth_style controls
# HOW the stored key gets attached when the app asks the backend to call
# that API on its behalf:
#   "header" — sent as a request header, e.g. "Authorization: Bearer <key>"
#   "query"  — sent as a URL query parameter, e.g. "?apikey=<key>"
# (some public APIs — weather, maps, stock data, etc. — require query-param
# auth instead of a header, so both are supported rather than assuming
# Authorization/Bearer for everything.)
class CustomApiRequest(BaseModel):
    name: str
    base_url: str
    api_key: str
    auth_style: str = "header"          # "header" or "query"
    header_name: str = "Authorization"  # used when auth_style == "header"
    header_prefix: str = "Bearer "      # used when auth_style == "header"
    query_param_name: str = "api_key"   # used when auth_style == "query"


class CustomApiUpdateRequest(BaseModel):
    name: Optional[str] = None
    base_url: Optional[str] = None
    api_key: Optional[str] = None
    auth_style: Optional[str] = None
    header_name: Optional[str] = None
    header_prefix: Optional[str] = None
    query_param_name: Optional[str] = None


# What the app sends when it wants the browser to actually USE a saved
# custom API — "path" is appended to that API's stored base_url, method
# is any HTTP verb, and the stored key is attached server-side so the
# raw key never has to round-trip back down to the device on every call.
class CustomApiCallRequest(BaseModel):
    path: str = ""
    method: str = "GET"
    query: dict = {}
    json_body: Optional[dict] = None
    headers: dict = {}


class AutopilotNextRequest(BaseModel):
    goal: str
    screenshot_base64: str
    dom_summary: str = ""
    current_url: str = ""
    history: list = []


class AgentSignalRequest(BaseModel):
    instruction: str
    # Email/account context for browser forms and login tasks. If omitted,
    # the signed-in Nex account email is used when available.
    account_email: Optional[str] = None
    depends_on: Optional[int] = None
    verify_result: bool = False
    sandbox: bool = False
    dry_run: bool = False
    require_approval: bool = False


class AgentPlanRequest(BaseModel):
    instruction: str
    account_email: Optional[str] = None
    depends_on: Optional[int] = None
    verify_result: bool = False
    sandbox: bool = False
    dry_run: bool = False
    require_approval: bool = False


class GoalPlanRequest(BaseModel):
    goal: str
    depends_on: Optional[int] = None
    verify_result: bool = False
    sandbox: bool = False
    dry_run: bool = False
    require_approval: bool = False


class GoalNextRequest(BaseModel):
    job_id: int
    current_url: str = ""
    dom_summary: str = ""


class OrchestratePlanRequest(BaseModel):
    goal: str


class FirewallConfigRequest(BaseModel):
    mode: str = "off"  # 'off' | 'whitelist' | 'blacklist'
    domains: list = []


class PolicyConfigRequest(BaseModel):
    custom_keywords: list = []
    always_require_approval: bool = False
    max_steps_per_job: Optional[int] = None


class VisualUnderstandRequest(BaseModel):
    screenshot_base64: str
    question: Optional[str] = None


class FormFillRequest(BaseModel):
    fields: List[str]
    instructions: str = ""
    current_url: str = ""


class ScreenshotTextRequest(BaseModel):
    screenshot_base64: str


class ImageUnderstandRequest(BaseModel):
    image_base64: str
    filename: Optional[str] = None


class VerifyScreenshotRequest(BaseModel):
    screenshot_base64: str
    expectation: str


class VerifyResultRequest(BaseModel):
    job_id: int
    instruction: str
    final_result: str
    screenshot_base64: str


class SelfHealRequest(BaseModel):
    target: str
    action: str  # "click" or "type"
    dom_json: str = "{}"
    goal: str = ""
    screenshot_base64: Optional[str] = None


class JobDependRequest(BaseModel):
    depends_on: Optional[int] = None  # null clears the dependency


class AgentReportRequest(BaseModel):
    job_id: int
    step_index: int
    step_result: str
    done: bool = False
    final_result: Optional[str] = None
    current_url: Optional[str] = None
    error: Optional[str] = None  # set when this step failed/timed out — the step still gets skipped past, not retried in place
    needs_approval: bool = False  # Self-Healing Agent (#57): a healed replacement was found but looks sensitive — job parks here until the user approves or skips it client-side
    verified: Optional[bool] = None  # Agent-to-Agent Verification (#73): set only when this report is the job's done=True report AND the job opted into verification. False routes to status 'needs_verification' instead of 'done'
    verification_reason: Optional[str] = None


class WorkflowSaveRequest(BaseModel):
    name: str
    steps: list


class WorkflowEditRequest(BaseModel):
    name: Optional[str] = None
    steps: Optional[list] = None


class WorkflowDuplicateRequest(BaseModel):
    name: Optional[str] = None


class WorkflowScheduleRequest(BaseModel):
    recurrence: str                 # "once" or "daily"
    run_at: Optional[int] = None    # unix timestamp — required for "once"
    daily_time: Optional[str] = None  # "HH:MM" 24-hour — required for "daily"


class AgentReorderRequest(BaseModel):
    direction: str  # "top" — move this job to the front of the queue


# ============================================================
# HEALTH CHECK
# ============================================================
@app.get("/health")
def health():
    return {"status": "ok", "service": "nex-browser-backend"}


# ============================================================
# 1) AUTH — needed for Cloud Sync (bookmarks) and Push Notifications
# ============================================================
def create_session(db, user_id: int, device_label: Optional[str]) -> dict:
    """Creates a new session row (one logged-in device) and returns the
    token pair + expiry the client should use. Called by register/login/
    google-auth — every successful sign-in is a NEW session, so signing in
    on a second device doesn't invalidate the first one (that's the whole
    point of Multi-device Sessions)."""
    access_token = secrets.token_urlsafe(32)
    refresh_token = secrets.token_urlsafe(32)
    now = int(time.time())
    db.execute(
        """
        INSERT INTO sessions
            (user_id, access_token, refresh_token, device_label, created_at, last_used_at, access_expires_at, refresh_expires_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            user_id,
            access_token,
            refresh_token,
            device_label or "Unknown device",
            now,
            now,
            now + ACCESS_TOKEN_TTL_SECONDS,
            now + REFRESH_TOKEN_TTL_SECONDS,
        ),
    )
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "expires_in": ACCESS_TOKEN_TTL_SECONDS,
    }


# Account Recovery (#25): a self-serve recovery code instead of an
# email-based "forgot password" flow, since this backend has no outbound
# email/SMTP setup — a code the user saves themselves works without any
# extra infrastructure. Alphabet excludes visually-ambiguous characters
# (0/O, 1/I) since this is meant to be hand-copied.
RECOVERY_CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"


def generate_recovery_code() -> str:
    chars = [secrets.choice(RECOVERY_CODE_ALPHABET) for _ in range(12)]
    code = "".join(chars)
    return f"{code[0:4]}-{code[4:8]}-{code[8:12]}"


@app.post("/auth/register")
def register(req: RegisterRequest, request: Request):
    rate_limit(f"register:{client_ip(request)}", 10, 3600)
    req.email = normalize_email(req.email)
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", req.email) or len(req.password) < 8:
        raise HTTPException(400, "Valid email and a password of 8+ characters required")

    salt = secrets.token_hex(16)
    password_hash = hash_password(req.password, salt)
    # users.token is no longer used for auth (sessions table replaces it)
    # but the column is still NOT NULL, so keep filling it with a random,
    # never-checked value rather than doing a schema migration to drop it.
    placeholder_token = secrets.token_hex(32)

    recovery_code = generate_recovery_code()
    recovery_salt = secrets.token_hex(16)
    recovery_hash = hash_password(recovery_code, recovery_salt)

    with get_db() as db:
        existing = db.execute("SELECT id FROM users WHERE lower(email) = ?", (req.email,)).fetchone()
        if existing:
            raise HTTPException(409, "An account with this email already exists")
        cursor = db.execute(
            """
            INSERT INTO users
                (email, password_hash, salt, token, created_at,
                 recovery_code_hash, recovery_code_salt, recovery_code_created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (req.email, password_hash, salt, placeholder_token, int(time.time()),
             recovery_hash, recovery_salt, int(time.time())),
        )
        session = create_session(db, cursor.lastrowid, req.device_label)

    # recovery_code is returned in PLAIN TEXT exactly once, right here —
    # the server only ever stores its hash from this point on, same as a
    # password. If it's lost, the only way back in is Recovery Code
    # regeneration from an already-signed-in device, or a brand new account.
    return {**session, "email": req.email, "recovery_code": recovery_code}



@app.post("/auth/login")
def login(req: LoginRequest, request: Request):
    email = normalize_email(req.email)
    rate_limit(f"login-ip:{client_ip(request)}", 30, 600)
    rate_limit(f"login-acct:{email}", 8, 600)
    with get_db() as db:
        row = db.execute("SELECT * FROM users WHERE lower(email) = ?", (email,)).fetchone()
        if not row:
            # burn the same CPU as a real check so response time doesn't reveal
            # which emails are registered
            verify_password(req.password, "0" * 32, "0" * 64)
            raise HTTPException(401, "Invalid email or password")
        if not verify_password(req.password, row["salt"], row["password_hash"]):
            raise HTTPException(401, "Invalid email or password")
        if password_needs_upgrade(row["password_hash"]):
            db.execute("UPDATE users SET password_hash = ? WHERE id = ?",
                       (hash_password(req.password, row["salt"]), row["id"]))

        session = create_session(db, row["id"], req.device_label)

    return {**session, "email": row["email"]}


@app.post("/auth/google")
async def google_auth(req: GoogleAuthRequest):
    # Verify the Google ID token by asking Google directly — simplest
    # approach, no extra library/service-account setup needed on our side.
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.get(
            "https://oauth2.googleapis.com/tokeninfo",
            params={"id_token": req.id_token},
        )
    if resp.status_code != 200:
        raise HTTPException(401, "Invalid Google token")

    info = resp.json()
    # SECURITY: tokeninfo only proves the token is a valid Google token for
    # *some* app. Without an audience check, a token minted for any other
    # app could be replayed here to sign in as that Google user.
    if not GOOGLE_CLIENT_ID:
        raise HTTPException(503, "Google Sign-In isn't configured on this server (set GOOGLE_CLIENT_ID)")
    if info.get("aud") != GOOGLE_CLIENT_ID:
        raise HTTPException(401, "Google token was issued for a different app")
    if str(info.get("email_verified", "")).lower() != "true":
        raise HTTPException(401, "Google account email isn't verified")
    email = normalize_email(info.get("email"))
    if not email:
        raise HTTPException(401, "Google token didn't include an email")

    with get_db() as db:
        row = db.execute("SELECT * FROM users WHERE lower(email) = ?", (email,)).fetchone()
        recovery_code = None

        if row:
            user_id = row["id"]
        else:
            # Google-linked accounts don't need a usable password — store a
            # random one that can never be guessed or used to log in via
            # /auth/login (only /auth/google will work for this account).
            salt = secrets.token_hex(16)
            password_hash = hash_password(secrets.token_hex(32), salt)
            placeholder_token = secrets.token_hex(32)
            recovery_code = generate_recovery_code()
            recovery_salt = secrets.token_hex(16)
            recovery_hash = hash_password(recovery_code, recovery_salt)
            cursor = db.execute(
                """
                INSERT INTO users
                    (email, password_hash, salt, token, created_at,
                     recovery_code_hash, recovery_code_salt, recovery_code_created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (email, password_hash, salt, placeholder_token, int(time.time()),
                 recovery_hash, recovery_salt, int(time.time())),
            )
            user_id = cursor.lastrowid

        session = create_session(db, user_id, req.device_label)

    result = {**session, "email": email}
    if recovery_code:
        # Only present the first time this Google account signs in here —
        # same one-time reveal as /auth/register.
        result["recovery_code"] = recovery_code
    return result


# ============================================================
# 1b) SESSION MANAGEMENT — refresh an expired access token, list every
# device currently signed in (#22 Multi-device Sessions), sign out one
# specific device, or sign out everywhere at once (#23).
# ============================================================
@app.post("/auth/refresh")
def refresh_access_token(req: RefreshRequest):
    with get_db() as db:
        row = db.execute("SELECT * FROM sessions WHERE refresh_token = ?", (req.refresh_token,)).fetchone()
        if not row:
            raise HTTPException(401, "Invalid refresh token")
        if row["refresh_expires_at"] < int(time.time()):
            db.execute("DELETE FROM sessions WHERE id = ?", (row["id"],))
            raise HTTPException(401, "Refresh token expired — please sign in again")

        new_access_token = secrets.token_urlsafe(32)
        now = int(time.time())
        new_access_expires = now + ACCESS_TOKEN_TTL_SECONDS
        db.execute(
            "UPDATE sessions SET access_token = ?, access_expires_at = ?, last_used_at = ? WHERE id = ?",
            (new_access_token, new_access_expires, now, row["id"]),
        )

    return {"access_token": new_access_token, "expires_in": ACCESS_TOKEN_TTL_SECONDS}


@app.get("/auth/sessions")
def list_sessions(user=Depends(get_current_user)):
    with get_db() as db:
        rows = db.execute(
            "SELECT id, device_label, created_at, last_used_at FROM sessions WHERE user_id = ? ORDER BY last_used_at DESC",
            (user["id"],),
        ).fetchall()
    return {
        "sessions": [
            {
                "session_id": r["id"],
                "device_label": r["device_label"] or "Unknown device",
                "created_at": r["created_at"],
                "last_used_at": r["last_used_at"],
                "is_current_device": r["id"] == user["session_id"],
            }
            for r in rows
        ]
    }


@app.delete("/auth/sessions/{session_id}")
def revoke_session(session_id: int, user=Depends(get_current_user)):
    with get_db() as db:
        row = db.execute(
            "SELECT id FROM sessions WHERE id = ? AND user_id = ?", (session_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "Session not found")
        db.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
    return {"status": "revoked"}


@app.post("/auth/sign-out-everywhere")
def sign_out_everywhere(req: SignOutEverywhereRequest, user=Depends(get_current_user)):
    with get_db() as db:
        if req.include_current_device:
            db.execute("DELETE FROM sessions WHERE user_id = ?", (user["id"],))
        else:
            db.execute(
                "DELETE FROM sessions WHERE user_id = ? AND id != ?",
                (user["id"], user["session_id"]),
            )
        revoked = db.execute("SELECT changes()").fetchone()[0]
    return {"status": "signed_out", "sessions_revoked": revoked}


# ============================================================
# 1c) ACCOUNT RECOVERY (#25) — a self-serve recovery code instead of an
# email "forgot password" link, since this backend has no SMTP/outbound
# email set up. The code is shown to the user exactly once (at register,
# or right after linking a new Google account) and only its hash is ever
# stored — same handling as a password.
# ============================================================
@app.post("/auth/reset-password")
def reset_password(req: ResetPasswordRequest, request: Request):
    email = normalize_email(req.email)
    rate_limit(f"reset-ip:{client_ip(request)}", 20, 3600)
    rate_limit(f"reset-acct:{email}", 5, 3600)
    if len(req.new_password) < 8:
        raise HTTPException(400, "New password must be 8+ characters")

    with get_db() as db:
        row = db.execute("SELECT * FROM users WHERE lower(email) = ?", (email,)).fetchone()
        if not row or not row["recovery_code_hash"]:
            raise HTTPException(401, "Invalid email or recovery code")

        if not verify_password(req.recovery_code.strip().upper(), row["recovery_code_salt"], row["recovery_code_hash"]):
            raise HTTPException(401, "Invalid email or recovery code")

        new_salt = secrets.token_hex(16)
        new_password_hash = hash_password(req.new_password, new_salt)

        # The recovery code just used is rotated out — same principle as a
        # single-use 2FA backup code, so it can't be reused if it ever leaks.
        new_recovery_code = generate_recovery_code()
        new_recovery_salt = secrets.token_hex(16)
        new_recovery_hash = hash_password(new_recovery_code, new_recovery_salt)

        db.execute(
            """
            UPDATE users
            SET password_hash = ?, salt = ?,
                recovery_code_hash = ?, recovery_code_salt = ?, recovery_code_created_at = ?
            WHERE id = ?
            """,
            (new_password_hash, new_salt, new_recovery_hash, new_recovery_salt, int(time.time()), row["id"]),
        )

        # A password reset means the old password may have been
        # compromised — end every existing session rather than leaving a
        # stale device silently still logged in on the old credentials.
        db.execute("DELETE FROM sessions WHERE user_id = ?", (row["id"],))
        session = create_session(db, row["id"], req.device_label)

    return {**session, "email": row["email"], "new_recovery_code": new_recovery_code}


@app.post("/auth/recovery-code/regenerate")
def regenerate_recovery_code(user=Depends(get_current_user)):
    new_code = generate_recovery_code()
    new_salt = secrets.token_hex(16)
    new_hash = hash_password(new_code, new_salt)
    with get_db() as db:
        db.execute(
            "UPDATE users SET recovery_code_hash = ?, recovery_code_salt = ?, recovery_code_created_at = ? WHERE id = ?",
            (new_hash, new_salt, int(time.time()), user["id"]),
        )
    return {"recovery_code": new_code}


# ============================================================
# 1d) SECURITY CENTER (#24) — one endpoint the app's dashboard screen
# calls to show account-level security status at a glance, instead of
# the user having to piece it together from several other screens.
# ============================================================
@app.get("/auth/me")
def get_account_info(user=Depends(get_current_user)):
    with get_db() as db:
        session_count = db.execute(
            "SELECT COUNT(*) AS c FROM sessions WHERE user_id = ?", (user["id"],)
        ).fetchone()["c"]
    return {
        "email": user["email"],
        "account_created_at": user["created_at"],
        "active_sessions": session_count,
        "recovery_code_set": bool(user.get("recovery_code_hash")),
    }


# ============================================================
# 1e) DEVICE MANAGEMENT (#26) — builds on Multi-device Sessions (#22):
# lets a device's label be renamed (e.g. the default "samsung SM-G991B"
# → "My Office Phone") so the sessions list in Security Center/Manage
# Sessions is actually easy to tell apart, not just viewable/revokable.
# ============================================================
@app.patch("/auth/sessions/{session_id}")
def rename_session(session_id: int, req: RenameSessionRequest, user=Depends(get_current_user)):
    label = req.device_label.strip()[:100]
    if not label:
        raise HTTPException(400, "Device name can't be empty")
    with get_db() as db:
        row = db.execute(
            "SELECT id FROM sessions WHERE id = ? AND user_id = ?", (session_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "Session not found")
        db.execute("UPDATE sessions SET device_label = ? WHERE id = ?", (label, session_id))
    return {"status": "renamed", "device_label": label}


# ============================================================
# 1f) DATA DELETE (#38, second half — Export was the first) — a real
# "delete my account and everything in it" for the whole box: sessions,
# bookmarks, vault (passwords/history/shortcuts/downloads/tabs),
# automation jobs, and push-notification device tokens, all scoped to
# this one user_id. Requires re-confirming the account password even
# though the request is already authenticated — irreversible, so an
# extra check is worth the friction. This is genuinely unrecoverable:
# there's no soft-delete/undo.
# ============================================================
@app.delete("/auth/account")
def delete_account(req: DeleteAccountRequest, request: Request, user=Depends(get_current_user)):
    rate_limit(f"delacct:{user['id']}", 5, 3600)
    with get_db() as db:
        row = db.execute("SELECT * FROM users WHERE id = ?", (user["id"],)).fetchone()
        if not row:
            raise HTTPException(404, "Account not found")

        verified = False
        if req.password:
            verified = verify_password(req.password, row["salt"], row["password_hash"])
        elif req.recovery_code and row["recovery_code_hash"]:
            verified = verify_password(req.recovery_code.strip().upper(), row["recovery_code_salt"], row["recovery_code_hash"])

        if not verified:
            raise HTTPException(401, "Incorrect password or recovery code")

        user_id = user["id"]
        db.execute("DELETE FROM sessions WHERE user_id = ?", (user_id,))
        db.execute("DELETE FROM bookmarks WHERE user_id = ?", (user_id,))
        db.execute("DELETE FROM history WHERE user_id = ?", (user_id,))
        db.execute("DELETE FROM vault WHERE user_id = ?", (user_id,))
        db.execute("DELETE FROM agent_jobs WHERE user_id = ?", (user_id,))
        db.execute("DELETE FROM device_tokens WHERE user_id = ?", (user_id,))
        db.execute("DELETE FROM users WHERE id = ?", (user_id,))

    return {"status": "account_deleted"}



# ============================================================
# 2) CLOUD SYNC — bookmarks only, for now. One JSON blob per
# user; the app pushes its full bookmark list, and pulls it
# back down on other devices logged into the same account.
# ============================================================
@app.get("/sync/bookmarks")
def get_bookmarks(user=Depends(get_current_user)):
    with get_db() as db:
        row = db.execute("SELECT data, updated_at FROM bookmarks WHERE user_id = ?", (user["id"],)).fetchone()
        if not row:
            return {"bookmarks": [], "updated_at": None}
        import json
        return {"bookmarks": json.loads(row["data"]), "updated_at": row["updated_at"]}


@app.post("/sync/bookmarks")
def save_bookmarks(req: BookmarksSyncRequest, user=Depends(get_current_user)):
    import json
    with get_db() as db:
        db.execute(
            """
            INSERT INTO bookmarks (user_id, data, updated_at) VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at
            """,
            (user["id"], json.dumps(req.bookmarks), int(time.time())),
        )
    return {"status": "synced", "count": len(req.bookmarks)}


# ============================================================
# HISTORY SYNC (#40) — same shape as Bookmark Sync above: a real
# GET+POST pair the app merges against locally (matching by URL, higher
# visit count / most recent visit wins), not just a one-way backup like
# the "history" field already inside the vault blob.
# ============================================================
@app.get("/sync/history")
def get_history(user=Depends(get_current_user)):
    with get_db() as db:
        row = db.execute("SELECT data, updated_at FROM history WHERE user_id = ?", (user["id"],)).fetchone()
        if not row:
            return {"history": [], "updated_at": None}
        import json
        return {"history": json.loads(row["data"]), "updated_at": row["updated_at"]}


@app.post("/sync/history")
def save_history(req: HistorySyncRequest, user=Depends(get_current_user)):
    import json
    with get_db() as db:
        db.execute(
            """
            INSERT INTO history (user_id, data, updated_at) VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at
            """,
            (user["id"], json.dumps(req.history), int(time.time())),
        )
    return {"status": "synced", "count": len(req.history)}


# ============================================================
# SETTINGS SYNC (#43) — same shape as Bookmark/History Sync above: a
# real GET+POST pair. The merge itself (which side wins per-key on a
# conflict) happens on the Android side, same as bookmarks/history —
# this endpoint just stores/returns whatever whitelisted key-value map
# the app sends it, plus when it was last written.
# ============================================================
@app.get("/sync/settings")
def get_settings_sync(user=Depends(get_current_user)):
    with get_db() as db:
        row = db.execute("SELECT data, updated_at FROM settings WHERE user_id = ?", (user["id"],)).fetchone()
        if not row:
            return {"settings": {}, "updated_at": None}
        import json
        return {"settings": json.loads(row["data"]), "updated_at": row["updated_at"]}


@app.post("/sync/settings")
def save_settings_sync(req: SettingsSyncRequest, user=Depends(get_current_user)):
    import json
    now = int(time.time())
    with get_db() as db:
        db.execute(
            """
            INSERT INTO settings (user_id, data, updated_at) VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at
            """,
            (user["id"], json.dumps(req.settings), now),
        )
    return {"status": "synced", "count": len(req.settings), "updated_at": now}


# ============================================================
# TAB SYNC — one row per (user, device), so this device's open tabs
# get pushed under its own device_id and every OTHER device's tabs can
# be listed and opened selectively ("Tabs from other devices"), the
# same way Chrome/Firefox do it — never silently merged into whatever
# tabs are open right now on the device that's syncing.
# ============================================================
@app.post("/sync/tabs")
def save_tabs_sync(req: TabsSyncRequest, user=Depends(get_current_user)):
    import json
    if not req.device_id.strip():
        raise HTTPException(400, "device_id is required")
    with get_db() as db:
        db.execute(
            """
            INSERT INTO open_tabs (user_id, device_id, device_label, data, updated_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(user_id, device_id) DO UPDATE SET
                device_label = excluded.device_label,
                data = excluded.data,
                updated_at = excluded.updated_at
            """,
            (user["id"], req.device_id, req.device_label, json.dumps(req.tabs), int(time.time())),
        )
    return {"status": "synced", "count": len(req.tabs)}


@app.get("/sync/tabs")
def get_tabs_sync(user=Depends(get_current_user)):
    import json
    with get_db() as db:
        rows = db.execute(
            "SELECT device_id, device_label, data, updated_at FROM open_tabs WHERE user_id = ? ORDER BY updated_at DESC",
            (user["id"],),
        ).fetchall()

    return {"devices": [{
        "device_id": r["device_id"],
        "device_label": r["device_label"] or "Unknown device",
        "tabs": json.loads(r["data"]),
        "updated_at": r["updated_at"],
    } for r in rows]}


# ============================================================
# VAULT — one row PER USER in the `vault` table (was previously a
# single shared file on disk that every logged-in user read and wrote
# — a real cross-account data leak, now fixed). Every /vault/sync call
# reads THIS user's existing row first, MERGES the new data in (any
# field you send replaces that field; any field you leave out keeps
# its previous saved value — nothing gets wiped by accident), and
# writes it back under that user's own row. Every /vault/download call
# reads back only the authenticated user's own row — never anyone
# else's, no matter who else has synced.
# ============================================================
def _merge_vault_field(blob, existing, field_name, encrypted_value, plain_value):
    """Merge-safe logic for one vault field that may arrive either
    encrypted (current app builds, End-to-End Encrypted Vault #32) or
    plain (legacy client). Never lets a plain value silently overwrite an
    existing encrypted one — an old client can't downgrade the vault's
    security just by syncing."""
    enc_key = field_name + "_encrypted"
    if encrypted_value is not None:
        blob[enc_key] = encrypted_value
    elif enc_key in existing:
        blob[enc_key] = existing[enc_key]
        if plain_value is not None:
            blob[field_name] = plain_value
    else:
        blob[field_name] = plain_value if plain_value is not None else existing.get(field_name, [])


def _prune_vault_backups(db, user_id, keep=5):
    db.execute(
        """
        DELETE FROM vault_backups
        WHERE user_id = ? AND id NOT IN (
            SELECT id FROM vault_backups WHERE user_id = ? ORDER BY created_at DESC LIMIT ?
        )
        """,
        (user_id, user_id, keep),
    )


@app.post("/vault/sync")
def sync_vault(req: VaultSyncRequest, user=Depends(get_current_user)):
    import json
    import hashlib

    with get_db() as db:
        row = db.execute(
            "SELECT data, checksum, updated_at FROM vault WHERE user_id = ?", (user["id"],)
        ).fetchone()
        existing = json.loads(row["data"]) if row else {}

        blob = {
            "downloads": req.downloads if req.downloads is not None else existing.get("downloads", []),
            "tabs": req.tabs if req.tabs is not None else existing.get("tabs", []),
            "synced_by": user["email"],
            "exported_at": int(time.time()),
        }

        # End-to-End Encrypted Vault (#32): bookmarks/history/shortcuts/
        # passwords are all handled the same encrypted-preferred way now.
        _merge_vault_field(blob, existing, "bookmarks", req.bookmarks_encrypted, req.bookmarks)
        _merge_vault_field(blob, existing, "history", req.history_encrypted, req.history)
        _merge_vault_field(blob, existing, "shortcuts", req.shortcuts_encrypted, req.shortcuts)
        _merge_vault_field(blob, existing, "passwords", req.passwords_encrypted, req.passwords)

        if req.vault_salt is not None:
            blob["vault_salt"] = req.vault_salt
        elif "vault_salt" in existing:
            blob["vault_salt"] = existing["vault_salt"]

        new_data = json.dumps(blob)
        new_checksum = hashlib.sha256(new_data.encode()).hexdigest()

        # Secure Vault Backup (#36): archive the version being REPLACED
        # before overwriting it, so an accidental bad sync is recoverable
        # instead of the vault being a single row with no history. Only
        # archives when the content actually changed — repeated identical
        # syncs don't pile up useless backup rows.
        if row and row["data"] != new_data:
            db.execute(
                "INSERT INTO vault_backups (user_id, data, checksum, created_at) VALUES (?, ?, ?, ?)",
                (user["id"], row["data"], row["checksum"] or "", row["updated_at"]),
            )
            _prune_vault_backups(db, user["id"])

        db.execute(
            """
            INSERT INTO vault (user_id, data, checksum, updated_at) VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET data = excluded.data, checksum = excluded.checksum, updated_at = excluded.updated_at
            """,
            (user["id"], new_data, new_checksum, blob["exported_at"]),
        )
    return {"status": "synced", "updated_at": blob["exported_at"], "checksum": new_checksum}


# ============================================================
# MERGE-SAFE SYNC (#37) — a lightweight checksum check the app runs
# BEFORE pushing, so it can detect "another device changed this since I
# last synced" and ask the user rather than silently overwriting
# whatever changed elsewhere. Real conflict DETECTION, not automatic
# reconciliation — see the Android-side comment for why full three-way
# merging isn't attempted.
# ============================================================
@app.get("/vault/checksum")
def get_vault_checksum(user=Depends(get_current_user)):
    with get_db() as db:
        row = db.execute(
            "SELECT checksum, updated_at FROM vault WHERE user_id = ?", (user["id"],)
        ).fetchone()
    if not row:
        return {"checksum": None, "updated_at": None}
    return {"checksum": row["checksum"], "updated_at": row["updated_at"]}


@app.get("/vault/verify")
def verify_vault_integrity(user=Depends(get_current_user)):
    import hashlib
    with get_db() as db:
        row = db.execute("SELECT data, checksum FROM vault WHERE user_id = ?", (user["id"],)).fetchone()
    if not row:
        return {"status": "empty"}
    actual = hashlib.sha256(row["data"].encode()).hexdigest()
    return {"status": "ok" if actual == (row["checksum"] or "") else "corrupted", "checksum": row["checksum"]}


@app.get("/vault/backups")
def list_vault_backups(user=Depends(get_current_user)):
    with get_db() as db:
        rows = db.execute(
            "SELECT id, checksum, created_at FROM vault_backups WHERE user_id = ? ORDER BY created_at DESC",
            (user["id"],),
        ).fetchall()
    return {
        "backups": [
            {"backup_id": r["id"], "checksum": r["checksum"], "created_at": r["created_at"]}
            for r in rows
        ]
    }


@app.post("/vault/backups/{backup_id}/restore")
def restore_vault_backup(backup_id: int, user=Depends(get_current_user)):
    with get_db() as db:
        backup_row = db.execute(
            "SELECT data, checksum FROM vault_backups WHERE id = ? AND user_id = ?",
            (backup_id, user["id"]),
        ).fetchone()
        if not backup_row:
            raise HTTPException(404, "Backup not found")

        current_row = db.execute(
            "SELECT data, checksum, updated_at FROM vault WHERE user_id = ?", (user["id"],)
        ).fetchone()
        now = int(time.time())
        # Restoring an old backup is itself archived first — so restoring
        # can be undone too, same principle as every other overwrite here.
        if current_row:
            db.execute(
                "INSERT INTO vault_backups (user_id, data, checksum, created_at) VALUES (?, ?, ?, ?)",
                (user["id"], current_row["data"], current_row["checksum"] or "", current_row["updated_at"]),
            )

        db.execute(
            """
            INSERT INTO vault (user_id, data, checksum, updated_at) VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET data = excluded.data, checksum = excluded.checksum, updated_at = excluded.updated_at
            """,
            (user["id"], backup_row["data"], backup_row["checksum"], now),
        )
        _prune_vault_backups(db, user["id"])
    return {"status": "restored"}


@app.get("/vault/download")
def download_vault(user=Depends(get_current_user)):
    from fastapi.responses import Response

    with get_db() as db:
        row = db.execute("SELECT data FROM vault WHERE user_id = ?", (user["id"],)).fetchone()

    if not row:
        raise HTTPException(404, "No vault synced yet — save a password in the app first")

    return Response(
        content=row["data"],
        media_type="application/json",
        headers={"Content-Disposition": 'attachment; filename="vault.json"'},
    )


# ============================================================
# 3) AI SUMMARIZER — calls the Claude API. Requires
# ANTHROPIC_API_KEY to be set as an environment variable.
# ============================================================
@app.post("/summarize")
async def summarize(req: SummarizeRequest, user=Depends(get_ai_user)):
    if not ANTHROPIC_API_KEY:
        raise HTTPException(503, "Summarizer not configured — ANTHROPIC_API_KEY is not set on the server")

    text = req.text.strip()
    if len(text) < 50:
        raise HTTPException(400, "Not enough page text to summarize")

    # Keep the request small and cheap — trim very long pages
    trimmed = text[:12000]

    prompt = (
        "Summarize the following webpage content in 3-4 short bullet points. "
        "Be concise and factual, no preamble.\n\n"
        f"URL: {req.url or 'unknown'}\n\nContent:\n{trimmed}"
    )

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 300,
                "messages": [{"role": "user", "content": prompt}],
            },
        )

    if response.status_code != 200:
        raise HTTPException(502, f"Summarizer upstream error: {response.text[:200]}")

    data = response.json()
    summary_text = "".join(
        block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
    )
    return {"summary": summary_text.strip()}


# ============================================================
# 3b) AI-COMMAND MODE — address-bar "Ask AI" toggle (Blueprint
# section 4 / Design v2 section 13-14). Same Claude call pattern
# as /summarize just above, but takes a free-form user command
# instead of page text, and the current URL is only context, not
# content to be pulled apart — no page-text extraction happens
# here, that stays the Android side's job for /summarize.
# ============================================================
@app.post("/ai-command")
async def ai_command(req: AiCommandRequest, user=Depends(get_ai_user)):
    if not ANTHROPIC_API_KEY:
        raise HTTPException(503, "AI command mode not configured — ANTHROPIC_API_KEY is not set on the server")

    command = req.command.strip()
    if not command:
        raise HTTPException(400, "Empty command")

    prompt = (
        "You are the AI-command mode of a mobile web browser's address bar. "
        "The user typed this instead of a URL or search query — answer it "
        "directly and concisely, plain text, no markdown headers.\n\n"
        f"Current page (context only, may be irrelevant): {req.url or 'none'}\n\n"
        f"User command: {command}"
    )

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 400,
                "messages": [{"role": "user", "content": prompt}],
            },
        )

    if response.status_code != 200:
        raise HTTPException(502, f"AI command upstream error: {response.text[:200]}")

    data = response.json()
    reply_text = "".join(
        block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
    )
    return {"reply": reply_text.strip()}


@app.post("/reader/clean")
async def reader_clean(req: ReaderCleanRequest, user=Depends(get_ai_user)):
    """
    AI Reader Mode (#96) — Android extracts a candidate article block
    from the page's DOM using simple heuristics (largest text-dense
    <article>/<main>/content-like element) and shows it immediately;
    this endpoint is the "AI" upgrade pass, called right after, that
    cleans up whatever leftover navigation/ad fragments and broken
    paragraph breaks the heuristic extraction let through — WITHOUT
    summarizing or rephrasing, since Reader Mode's whole point is
    reading the real article, not a condensed version of it (that's
    what AI Summary is for).
    """
    if not ANTHROPIC_API_KEY:
        raise HTTPException(503, "Reader Mode cleanup not configured — ANTHROPIC_API_KEY is not set on the server")

    text = req.text.strip()
    if len(text) < 50:
        raise HTTPException(400, "Not enough page text to clean up")

    trimmed = text[:12000]

    prompt = (
        "The following text was extracted from a webpage's main content area using DOM "
        "heuristics, so it may still have leftover navigation labels, ad fragments, or "
        "broken paragraph breaks mixed in. Clean it up into a readable article: remove "
        "any leftover non-article fragments and fix paragraph breaks, but do NOT "
        "summarize, shorten, rephrase, or add anything — keep the actual article wording "
        "faithfully, word for word. Output ONLY the cleaned article body text as plain "
        "paragraphs separated by blank lines — no headers, no explanation, no markdown.\n\n"
        f"Page title: {req.title or 'unknown'}\nURL: {req.url or 'unknown'}\n\nExtracted content:\n{trimmed}"
    )

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 4000,
                "messages": [{"role": "user", "content": prompt}],
            },
        )

    if response.status_code != 200:
        raise HTTPException(502, f"Reader cleanup upstream error: {response.text[:200]}")

    data = response.json()
    cleaned = "".join(
        block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
    ).strip()
    return {"text": cleaned if cleaned else trimmed}


@app.post("/web/compare")
async def web_compare(req: WebCompareRequest, user=Depends(get_ai_user)):
    """
    AI Web Comparison (#97) — Android sends 2-5 open tabs' extracted
    article content (same Reader Mode #96 extraction), this produces a
    structured similarities/differences/per-source breakdown. Distinct
    from Contradiction Detector (#99), which is specifically about
    finding factual conflicts, and Source Reliability Engine (#98),
    which scores trustworthiness — this is a general-purpose content
    comparison, the "what's the same, what's different" question.
    """
    if not ANTHROPIC_API_KEY:
        raise HTTPException(503, "Web Comparison not configured — ANTHROPIC_API_KEY is not set on the server")

    pages = req.pages[:5]  # cap cost/latency — 5 sources is plenty for a readable comparison
    if len(pages) < 2:
        raise HTTPException(400, "Need at least 2 pages to compare")

    sections = []
    for i, p in enumerate(pages):
        if not isinstance(p, dict):
            continue
        title = str(p.get("title") or f"Page {i + 1}")
        url = str(p.get("url") or "")
        text = str(p.get("text") or "")[:4000]
        sections.append(f"--- Source {i + 1}: {title} ({url}) ---\n{text}")
    combined = "\n\n".join(sections)

    prompt = (
        "Compare the following web pages. Give a clear, structured comparison with three "
        "parts: (1) Key similarities, (2) Key differences, (3) one brief line per source "
        "summarizing what it uniquely covers. Be factual and concise, and base everything "
        "only on the content given — don't invent details that aren't there. Output as "
        "plain text with simple section labels, no markdown symbols.\n\n"
        f"{combined}"
    )

    async with httpx.AsyncClient(timeout=45) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 1200,
                "messages": [{"role": "user", "content": prompt}],
            },
        )

    if response.status_code != 200:
        raise HTTPException(502, f"Comparison upstream error: {response.text[:200]}")

    data = response.json()
    comparison = "".join(
        block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
    ).strip()
    return {"comparison": comparison}


@app.post("/web/reliability")
async def web_reliability(req: SourceReliabilityRequest, user=Depends(get_ai_user)):
    """
    Source Reliability Engine (#98) — a heuristic AI judgment call, NOT
    a lookup against any authoritative trust database (there isn't one
    built here) and NOT a fact-check of the page's claims (that's #100).
    Looks at signals like byline/authorship, citations, editorial tone
    vs sensationalism, and what's known generally about the domain, to
    give a rough High/Medium/Low/Unknown read — always framed as an
    estimate, never a verdict.
    """
    if not ANTHROPIC_API_KEY:
        raise HTTPException(503, "Source Reliability not configured — ANTHROPIC_API_KEY is not set on the server")

    text = req.text.strip()
    if len(text) < 50:
        raise HTTPException(400, "Not enough page text to assess")

    prompt = (
        "Assess this web source's likely reliability as an honest ESTIMATE, not a verdict "
        "— you're judging signals, not looking anything up. Consider: is there a named "
        "author/byline, are claims backed by citations or links, is the tone measured or "
        "sensational/clickbait-y, does the domain look like an established publisher, "
        "personal blog, forum, or something else, and anything you know generally about "
        "this domain's reputation. Output EXACTLY four lines, plain text, no markdown:\n"
        "Rating: <High, Medium, Low, or Unknown>\n"
        "Source type: <one short phrase>\n"
        "Signals: <one sentence on what supports or undermines trust here>\n"
        "Caveat: <one short sentence reminding this is an estimate, not a fact-check>\n\n"
        f"URL: {req.url}\nTitle: {req.title or 'unknown'}\n\nPage content sample:\n{text[:6000]}"
    )

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 300,
                "messages": [{"role": "user", "content": prompt}],
            },
        )
    if response.status_code != 200:
        raise HTTPException(502, f"Reliability check upstream error: {response.text[:200]}")

    data = response.json()
    result = "".join(
        block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
    ).strip()
    return {"result": result}


@app.post("/web/contradictions")
async def web_contradictions(req: ContradictionRequest, user=Depends(get_ai_user)):
    """
    Contradiction Detector (#99) — same multi-page extraction input as
    Web Comparison (#97), but a narrower question: not "what's similar/
    different overall" but specifically "where do these sources
    disagree on a fact". Distinct from Source Reliability (#98, judges
    ONE source's trustworthiness) and Fact-Checking (#100, checks ONE
    claim against general knowledge) — this only ever compares sources
    against EACH OTHER, never against outside truth.
    """
    if not ANTHROPIC_API_KEY:
        raise HTTPException(503, "Contradiction Detector not configured — ANTHROPIC_API_KEY is not set on the server")

    pages = req.pages[:5]
    if len(pages) < 2:
        raise HTTPException(400, "Need at least 2 pages to check for contradictions")

    sections = []
    for i, p in enumerate(pages):
        if not isinstance(p, dict):
            continue
        title = str(p.get("title") or f"Page {i + 1}")
        url = str(p.get("url") or "")
        text = str(p.get("text") or "")[:4000]
        sections.append(f"--- Source {i + 1}: {title} ({url}) ---\n{text}")
    combined = "\n\n".join(sections)

    prompt = (
        "Compare these sources and look SPECIFICALLY for factual contradictions — cases "
        "where two or more sources state conflicting facts, numbers, dates, quotes, or "
        "claims about the same thing. For each contradiction found, name which sources "
        "disagree and what each one says. If the sources don't actually conflict on "
        "anything (they may simply cover different things, or genuinely agree), say so "
        "plainly rather than inventing a contradiction. Base this only on what's in the "
        "text given. Output as plain text, no markdown.\n\n"
        f"{combined}"
    )

    async with httpx.AsyncClient(timeout=45) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 1200,
                "messages": [{"role": "user", "content": prompt}],
            },
        )
    if response.status_code != 200:
        raise HTTPException(502, f"Contradiction check upstream error: {response.text[:200]}")

    data = response.json()
    result = "".join(
        block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
    ).strip()
    return {"result": result}


@app.post("/web/factcheck")
async def web_factcheck(req: FactCheckRequest, user=Depends(get_ai_user)):
    """
    Fact-Checking Workflow (#100) — a structured multi-part check on ONE
    specific claim (not a whole page, not multiple sources), against the
    AI's general knowledge only (no live web access from this call) —
    honest about that limit, and always ends by suggesting concrete
    searches the user can run themselves rather than pretending to have
    verified anything definitively.
    """
    claim = req.claim.strip()
    if len(claim) < 5:
        raise HTTPException(400, "Claim is too short to check")
    if not ANTHROPIC_API_KEY:
        raise HTTPException(503, "Fact-Checking not configured — ANTHROPIC_API_KEY is not set on the server")

    context = ""
    if req.context_text:
        context = f"\n\nFound on this page (context only, not necessarily authoritative): {req.context_url or ''}\n{req.context_text.strip()[:2000]}"

    prompt = (
        "Fact-check this claim using only your general knowledge (you have no live web "
        "access in this call, so be upfront about that limit). Respond in EXACTLY this "
        "structure, plain text, no markdown:\n"
        "Claim: <restate it clearly and neutrally>\n"
        "Assessment: <Likely True, Likely False, Disputed/Mixed, or Cannot Determine>\n"
        "Reasoning: <2-3 sentences on why, based on what you know>\n"
        "Verify further: <2-3 short, specific search queries someone could run themselves "
        "to double-check this, one per line, prefixed with '- '>\n\n"
        f"Claim: {claim}{context}"
    )

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 600,
                "messages": [{"role": "user", "content": prompt}],
            },
        )
    if response.status_code != 200:
        raise HTTPException(502, f"Fact-check upstream error: {response.text[:200]}")

    data = response.json()
    result = "".join(
        block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
    ).strip()
    return {"result": result}


@app.post("/history/semantic-search")
async def history_semantic_search(req: HistorySemanticSearchRequest, user=Depends(get_ai_user)):
    """
    Semantic History Search (#102) — matches by MEANING, not just
    title/URL substring, using each entry's stored content snippet (AI
    Web Memory, #101, captured client-side when the page was visited).
    Entries with no stored content still get matched on title/URL alone.
    """
    query = req.query.strip()
    if not query:
        raise HTTPException(400, "Query is empty")
    if not ANTHROPIC_API_KEY:
        raise HTTPException(503, "Semantic History Search not configured — ANTHROPIC_API_KEY is not set on the server")

    entries = req.entries[:80]  # cap cost/latency
    if not entries:
        return {"matches": []}

    listing = []
    for i, e in enumerate(entries):
        if not isinstance(e, dict):
            continue
        title = str(e.get("title") or "")
        url = str(e.get("url") or "")
        content = str(e.get("content") or "")[:250]
        listing.append(f"[{i}] {title} — {url}" + (f"\n{content}" if content else ""))
    combined = "\n\n".join(listing)

    prompt = (
        f'The user is searching their browsing history for: "{query}"\n\n'
        "Below is a numbered list of history entries (title, URL, and a short content "
        "snippet where one was captured). Return ONLY a raw JSON array of the index "
        "numbers that genuinely match what the user means — best match first, at most "
        "15 entries. Match by MEANING, not just shared words. If nothing genuinely "
        "matches, return an empty array. Output raw JSON only, no markdown fences.\n\n"
        f"{combined}"
    )

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 300,
                "messages": [{"role": "user", "content": prompt}],
            },
        )
    if response.status_code != 200:
        raise HTTPException(502, f"Semantic search upstream error: {response.text[:200]}")

    data = response.json()
    text = "".join(
        block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
    ).strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
        text = text.strip()

    import json
    try:
        indices = json.loads(text)
        if not isinstance(indices, list):
            raise ValueError("not a list")
    except Exception:
        indices = []

    matches = []
    for idx in indices:
        try:
            i = int(idx)
            if 0 <= i < len(entries):
                matches.append(entries[i])
        except Exception:
            continue
    return {"matches": matches}


@app.post("/history/day-summary")
async def history_day_summary(req: DaySummaryRequest, user=Depends(get_ai_user)):
    """
    Browsing Timeline (#103)'s on-demand "summarize this day" — only
    called when the user taps it for a specific day, not automatically
    for every day shown, since that would be an AI call per day for
    data most people will just scroll past.
    """
    if not ANTHROPIC_API_KEY:
        raise HTTPException(503, "Day summary not configured — ANTHROPIC_API_KEY is not set on the server")

    entries = req.entries[:40]
    if not entries:
        raise HTTPException(400, "No entries to summarize")

    listing = []
    for e in entries:
        if not isinstance(e, dict):
            continue
        title = str(e.get("title") or "")
        content = str(e.get("content") or "")[:200]
        listing.append(f"- {title}" + (f": {content}" if content else ""))
    combined = "\n".join(listing)

    prompt = (
        "Here are the pages someone visited in one day, in a browser's history. Write a "
        "brief 1-3 sentence summary of what they seem to have been doing/researching "
        "that day. Be neutral and factual, don't guess at anything not suggested by the "
        "list. Output plain text only, no markdown.\n\n"
        f"{combined}"
    )

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 200,
                "messages": [{"role": "user", "content": prompt}],
            },
        )
    if response.status_code != 200:
        raise HTTPException(502, f"Day summary upstream error: {response.text[:200]}")

    data = response.json()
    summary = "".join(
        block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
    ).strip()
    return {"summary": summary}


# ============================================================
# WEB PAGE CHANGE MONITOR (#104) + SEMANTIC PAGE DIFF (#105)
# ============================================================
def _extract_text_from_html(html: str) -> str:
    """Crude tag-stripping text extraction for a raw HTTP fetch (the
    scheduler has no WebView/JS engine available server-side) — good
    enough to hash for change detection and to feed the diff summary,
    not meant to rival the DOM-heuristic extraction Android does with
    Reader Mode's own JS for pages actually open in the app."""
    import re
    text = re.sub(r"<script.*?</script>", " ", html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<style.*?</style>", " ", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


@app.post("/watch/add")
def watch_add(req: WatchPageRequest, user=Depends(get_current_user)):
    req.url = assert_public_http_url(req.url)
    now = int(time.time())
    with get_db() as db:
        db.execute(
            "INSERT INTO watched_pages (user_id, url, title, created_at) VALUES (?, ?, ?, ?)",
            (user["id"], req.url, req.title or req.url, now),
        )
    return {"status": "added"}


@app.get("/watch/list")
def watch_list(user=Depends(get_current_user)):
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM watched_pages WHERE user_id = ? ORDER BY id DESC", (user["id"],)
        ).fetchall()
    pages = []
    for r in rows:
        pages.append({
            "id": r["id"],
            "url": r["url"],
            "title": r["title"],
            "last_checked_at": r["last_checked_at"],
            "last_changed_at": r["last_changed_at"],
            "has_change": r["last_changed_at"] is not None and r["previous_content_snippet"] is not None,
        })
    return {"pages": pages}


@app.delete("/watch/{watch_id}")
def watch_delete(watch_id: int, user=Depends(get_current_user)):
    with get_db() as db:
        db.execute("DELETE FROM watched_pages WHERE id = ? AND user_id = ?", (watch_id, user["id"]))
    return {"status": "deleted"}


@app.post("/watch/{watch_id}/check-now")
def watch_check_now(watch_id: int, user=Depends(get_current_user)):
    """Manual, on-demand check — same logic _scheduler_loop uses
    periodically, just triggered immediately instead of waiting."""
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM watched_pages WHERE id = ? AND user_id = ?", (watch_id, user["id"])
        ).fetchone()
    if not row:
        raise HTTPException(404, "Watched page not found")
    changed = _check_watched_page(dict(row))
    return {"changed": changed}


@app.post("/watch/{watch_id}/diff-summary")
async def watch_diff_summary(watch_id: int, user=Depends(get_current_user)):
    """
    Semantic Page Diff (#105) — takes the OLD and NEW content snapshots
    Change Monitor (#104) already captured and asks AI what actually
    changed, in plain English, rather than showing a raw text diff.
    """
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM watched_pages WHERE id = ? AND user_id = ?", (watch_id, user["id"])
        ).fetchone()
    if not row:
        raise HTTPException(404, "Watched page not found")
    if not row["previous_content_snippet"] or not row["last_content_snippet"]:
        raise HTTPException(400, "No change has been recorded for this page yet")
    if not ANTHROPIC_API_KEY:
        raise HTTPException(503, "Page Diff not configured — ANTHROPIC_API_KEY is not set on the server")

    prompt = (
        "Here is the same webpage's content from two different points in time. Describe, "
        "in plain English, what actually changed — new information, updated numbers/"
        "prices/dates, removed content, etc. If nothing meaningful changed (e.g. only ads "
        "or unrelated boilerplate differ), say so. Be concise — 2-4 sentences. Output "
        "plain text, no markdown.\n\n"
        f"--- OLDER VERSION ---\n{row['previous_content_snippet'][:3000]}\n\n"
        f"--- NEWER VERSION ---\n{row['last_content_snippet'][:3000]}"
    )

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 400,
                "messages": [{"role": "user", "content": prompt}],
            },
        )
    if response.status_code != 200:
        raise HTTPException(502, f"Diff summary upstream error: {response.text[:200]}")

    data = response.json()
    summary = "".join(
        block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
    ).strip()
    return {"summary": summary}


def _check_watched_page(row: dict) -> bool:
    """Fetches the URL fresh, hashes its extracted text, and compares
    against what was stored last time. Returns True if a change was
    detected (and rotates last_content_snippet -> previous_content_snippet
    so Semantic Page Diff, #105, has both sides to compare)."""
    now = int(time.time())
    changed = False
    try:
        with httpx.Client(timeout=15, follow_redirects=False) as client:
            # follow redirects by hand (max 4) so every hop is SSRF-checked
            target = row["url"]
            for _hop in range(5):
                assert_public_http_url(target)
                resp = client.get(target, headers={"User-Agent": "Mozilla/5.0 (compatible; NexBrowserWatch/1.0)"})
                if resp.is_redirect and resp.headers.get("location"):
                    target = str(httpx.URL(target).join(resp.headers["location"]))
                    continue
                break
        text = _extract_text_from_html(resp.text)[:4000]
        new_hash = hashlib.sha256(text.encode("utf-8", errors="ignore")).hexdigest()

        with get_db() as db:
            if row["last_content_hash"] and row["last_content_hash"] != new_hash:
                changed = True
                db.execute(
                    "UPDATE watched_pages SET last_content_hash = ?, previous_content_snippet = ?, "
                    "last_content_snippet = ?, last_checked_at = ?, last_changed_at = ? WHERE id = ?",
                    (new_hash, row["last_content_snippet"], text, now, now, row["id"]),
                )
            elif not row["last_content_hash"]:
                # First-ever check — just establishes the baseline, not a "change"
                db.execute(
                    "UPDATE watched_pages SET last_content_hash = ?, last_content_snippet = ?, "
                    "last_checked_at = ? WHERE id = ?",
                    (new_hash, text, now, row["id"]),
                )
            else:
                db.execute("UPDATE watched_pages SET last_checked_at = ? WHERE id = ?", (now, row["id"]))
    except Exception as e:
        print(f"[watch] check failed for watched_pages id={row['id']}: {e}")
    return changed


# ============================================================
# AI RESEARCH WORKSPACE (#106)
# ============================================================
@app.post("/research/add")
def research_add(req: ResearchItemRequest, user=Depends(get_current_user)):
    now = int(time.time())
    with get_db() as db:
        db.execute(
            "INSERT INTO research_items (user_id, url, title, content, created_at, project_id) VALUES (?, ?, ?, ?, ?, ?)",
            (user["id"], req.url, req.title or req.url, req.content or "", now, req.project_id),
        )
    return {"status": "added"}


@app.get("/research/list")
def research_list(project_id: Optional[int] = None, user=Depends(get_current_user)):
    with get_db() as db:
        if project_id is not None:
            rows = db.execute(
                "SELECT * FROM research_items WHERE user_id = ? AND project_id = ? ORDER BY id DESC",
                (user["id"], project_id),
            ).fetchall()
        else:
            rows = db.execute(
                "SELECT * FROM research_items WHERE user_id = ? AND project_id IS NULL ORDER BY id DESC",
                (user["id"],),
            ).fetchall()
    return {"items": [
        {"id": r["id"], "url": r["url"], "title": r["title"], "content": r["content"], "project_id": r["project_id"]}
        for r in rows
    ]}


@app.delete("/research/{item_id}")
def research_delete(item_id: int, user=Depends(get_current_user)):
    with get_db() as db:
        db.execute("DELETE FROM research_items WHERE id = ? AND user_id = ?", (item_id, user["id"]))
    return {"status": "deleted"}


@app.post("/research/synthesize")
async def research_synthesize(project_id: Optional[int] = None, user=Depends(get_current_user)):
    """
    AI Research Workspace (#106) — combines every saved item's content
    into one coherent overview of the research collected so far. Not a
    comparison (#97) or a contradiction check (#99) — a SYNTHESIS: what
    the collected sources say TOGETHER about the topic. Scoped to one
    project (#107) when project_id is given, else the unsorted default.
    """
    with get_db() as db:
        if project_id is not None:
            rows = db.execute(
                "SELECT * FROM research_items WHERE user_id = ? AND project_id = ? ORDER BY id ASC",
                (user["id"], project_id),
            ).fetchall()
        else:
            rows = db.execute(
                "SELECT * FROM research_items WHERE user_id = ? AND project_id IS NULL ORDER BY id ASC",
                (user["id"],),
            ).fetchall()
    if len(rows) < 1:
        raise HTTPException(400, "Add at least one page to your research workspace first")
    if not ANTHROPIC_API_KEY:
        raise HTTPException(503, "Research synthesis not configured — ANTHROPIC_API_KEY is not set on the server")

    sections = []
    for i, r in enumerate(rows[:10]):
        sections.append(f"--- Source {i + 1}: {r['title']} ({r['url']}) ---\n{(r['content'] or '')[:3000]}")
    combined = "\n\n".join(sections)

    prompt = (
        "The user has been collecting these sources while researching a topic. Write a "
        "clear synthesis: what do these sources say, together, about the topic? Organize "
        "it into a few short thematic paragraphs rather than one-summary-per-source. Base "
        "this only on the content given. Output plain text, no markdown.\n\n"
        f"{combined}"
    )

    async with httpx.AsyncClient(timeout=45) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 1200,
                "messages": [{"role": "user", "content": prompt}],
            },
        )
    if response.status_code != 200:
        raise HTTPException(502, f"Synthesis upstream error: {response.text[:200]}")

    data = response.json()
    synthesis = "".join(
        block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
    ).strip()
    return {"synthesis": synthesis}


# ============================================================
# PERSISTENT RESEARCH PROJECTS (#107) + AI NOTES (#108) +
# SOURCE-TO-NOTE LINKING (#109)
# ============================================================
@app.post("/research/projects")
def research_create_project(req: ResearchProjectRequest, user=Depends(get_current_user)):
    name = req.name.strip()
    if not name:
        raise HTTPException(400, "Project name is empty")
    now = int(time.time())
    with get_db() as db:
        cursor = db.execute(
            "INSERT INTO research_projects (user_id, name, created_at) VALUES (?, ?, ?)",
            (user["id"], name, now),
        )
        project_id = cursor.lastrowid
    return {"id": project_id, "name": name}


@app.get("/research/projects")
def research_list_projects(user=Depends(get_current_user)):
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM research_projects WHERE user_id = ? ORDER BY id DESC", (user["id"],)
        ).fetchall()
    return {"projects": [{"id": r["id"], "name": r["name"]} for r in rows]}


@app.delete("/research/projects/{project_id}")
def research_delete_project(project_id: int, user=Depends(get_current_user)):
    """Deletes the project itself, plus any items/notes filed under it —
    an item/note with no project (project_id NULL) is untouched."""
    with get_db() as db:
        db.execute("DELETE FROM research_projects WHERE id = ? AND user_id = ?", (project_id, user["id"]))
        db.execute("DELETE FROM research_items WHERE project_id = ? AND user_id = ?", (project_id, user["id"]))
        db.execute("DELETE FROM research_notes WHERE project_id = ? AND user_id = ?", (project_id, user["id"]))
    return {"status": "deleted"}


@app.post("/research/notes")
def research_create_note(req: ResearchNoteRequest, user=Depends(get_current_user)):
    content = req.content.strip()
    if not content:
        raise HTTPException(400, "Note content is empty")
    now = int(time.time())
    with get_db() as db:
        if req.source_item_id is not None:
            source = db.execute(
                "SELECT id FROM research_items WHERE id = ? AND user_id = ?", (req.source_item_id, user["id"])
            ).fetchone()
            if not source:
                req.source_item_id = None  # silently drop a bad/foreign link rather than fail note creation
        cursor = db.execute(
            "INSERT INTO research_notes (user_id, project_id, source_item_id, title, content, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (user["id"], req.project_id, req.source_item_id, req.title or "", content, now, now),
        )
        note_id = cursor.lastrowid
    return {"id": note_id}


@app.get("/research/notes")
def research_list_notes(project_id: Optional[int] = None, user=Depends(get_current_user)):
    with get_db() as db:
        if project_id is not None:
            rows = db.execute(
                "SELECT n.*, i.title as source_title, i.url as source_url FROM research_notes n "
                "LEFT JOIN research_items i ON n.source_item_id = i.id "
                "WHERE n.user_id = ? AND n.project_id = ? ORDER BY n.id DESC",
                (user["id"], project_id),
            ).fetchall()
        else:
            rows = db.execute(
                "SELECT n.*, i.title as source_title, i.url as source_url FROM research_notes n "
                "LEFT JOIN research_items i ON n.source_item_id = i.id "
                "WHERE n.user_id = ? AND n.project_id IS NULL ORDER BY n.id DESC",
                (user["id"],),
            ).fetchall()
    return {"notes": [
        {
            "id": r["id"], "title": r["title"], "content": r["content"],
            "source_item_id": r["source_item_id"], "source_title": r["source_title"], "source_url": r["source_url"],
        } for r in rows
    ]}


@app.delete("/research/notes/{note_id}")
def research_delete_note(note_id: int, user=Depends(get_current_user)):
    with get_db() as db:
        db.execute("DELETE FROM research_notes WHERE id = ? AND user_id = ?", (note_id, user["id"]))
    return {"status": "deleted"}


# ============================================================
# AI FILE INTELLIGENCE (#111)
# ============================================================
@app.post("/files/analyze")
async def files_analyze(req: FileAnalyzeRequest, user=Depends(get_ai_user)):
    """
    AI File Intelligence (#111). Plain-text files are sent as text; images
    (png/jpg/gif/webp) and PDFs are sent as base64 and read by the model
    directly — which also covers scanned pages and photos of documents
    (OCR) without any extra server libraries. Gives a short "what is this
    file and what's notable in it" summary.
    """
    if not ANTHROPIC_API_KEY:
        raise HTTPException(503, "File analysis not configured — ANTHROPIC_API_KEY is not set on the server")

    instruction = (
        f'This is a downloaded file named "{req.filename}". Describe in 2-4 sentences what it is '
        "and what's notable in it (e.g. a scanned receipt with its total, an invoice, a chapter of a "
        "book, a photo of a whiteboard, a JSON config). If it contains printed or handwritten text, "
        "mention the key text. Be concise and factual — don't guess beyond what is shown. "
        "Output plain text, no markdown."
    )

    if req.content_base64:
        mime = (req.mime_type or "").lower().strip()
        allowed_images = {"image/png", "image/jpeg", "image/gif", "image/webp"}
        if mime not in allowed_images and mime != "application/pdf":
            raise HTTPException(400, "Only images (png, jpg, gif, webp) and PDFs can be analyzed this way")
        if len(req.content_base64) > 7_000_000:   # ~5 MB of raw bytes
            raise HTTPException(413, "That file is too large to analyze (limit about 5 MB)")
        import base64, binascii
        try:
            base64.b64decode(req.content_base64, validate=True)
        except (binascii.Error, ValueError):
            raise HTTPException(400, "File data isn't valid base64")
        block = ({"type": "document", "source": {"type": "base64", "media_type": mime, "data": req.content_base64}}
                 if mime == "application/pdf" else
                 {"type": "image", "source": {"type": "base64", "media_type": mime, "data": req.content_base64}})
        message_content = [block, {"type": "text", "text": instruction}]
    else:
        content = req.content.strip()
        if not content:
            raise HTTPException(400, "File appears to be empty")
        message_content = f"{instruction}\n\n{content[:6000]}"

    async with httpx.AsyncClient(timeout=60) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 400,
                "messages": [{"role": "user", "content": message_content}],
            },
        )
    if response.status_code != 200:
        raise HTTPException(502, f"File analysis upstream error: {response.text[:200]}")

    data = response.json()
    summary = "".join(
        block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
    ).strip()
    return {"summary": summary}


# ============================================================
# STRUCTURED DATA EXTRACTION (#112)
# ============================================================
MAX_TABLE_ROWS = 50
MAX_TABLE_COLS = 10


def parse_table_json(text_out: str):
    """Parses the model's {"columns":[...],"rows":[[...]]} reply. If the reply was cut
    off mid-row (token limit), keeps every COMPLETE row instead of throwing the whole
    table away. Returns (columns, rows, truncated)."""
    import json
    text_out = (text_out or "").strip()
    if text_out.startswith("```"):
        text_out = text_out.strip("`")
        if text_out.startswith("json"):
            text_out = text_out[4:]
        text_out = text_out.strip()
    truncated = False
    try:
        parsed = json.loads(text_out)
    except Exception:
        cut = text_out.rfind("],")
        if cut == -1:
            return [], [], False
        try:
            parsed = json.loads(text_out[:cut + 1] + "]}")
            truncated = True
        except Exception:
            return [], [], False
    if not isinstance(parsed, dict):
        return [], [], False
    columns = parsed.get("columns", [])
    rows = parsed.get("rows", [])
    if not isinstance(columns, list) or not isinstance(rows, list):
        return [], [], False
    columns = [str(c)[:80] for c in columns[:MAX_TABLE_COLS]]
    clean_rows = []
    for r in rows[:MAX_TABLE_ROWS]:
        if not isinstance(r, list):
            continue
        cells = [("" if v is None else str(v))[:300] for v in r[:len(columns)]]
        cells += [""] * (len(columns) - len(cells))   # pad short rows so every row lines up
        clean_rows.append(cells)
    if len(rows) > MAX_TABLE_ROWS:
        truncated = True
    return columns, clean_rows, truncated


@app.post("/web/extract-structured")
async def web_extract_structured(req: StructuredExtractRequest, user=Depends(get_ai_user)):
    """
    Structured Data Extraction (#112) — looks for anything table/list-
    shaped in a page's extracted text (prices, specs, contact info,
    schedules) and returns it as a simple {columns, rows} table Android
    can render and export (One-click Export, #113). Returns an empty
    table (not an error) when nothing structured is genuinely present —
    this is a "was there a table" detector, not a summarizer.
    """
    if not ANTHROPIC_API_KEY:
        raise HTTPException(503, "Structured extraction not configured — ANTHROPIC_API_KEY is not set on the server")

    text = req.text.strip()
    if len(text) < 30:
        raise HTTPException(400, "Not enough page text to extract from")

    prompt = (
        "Look at this webpage's extracted text for anything genuinely table- or list-"
        "shaped and structured — prices with product names, a schedule, contact details, "
        "specs, statistics, etc. Return ONLY a raw JSON object of the form "
        '{"columns": ["Col1", "Col2", ...], "rows": [["a","b"], ["c","d"], ...]}. '
        f"Keep it to at most {MAX_TABLE_ROWS} rows and {MAX_TABLE_COLS} columns (the most important ones first). If there's genuinely nothing "
        'structured here, return {"columns": [], "rows": []} — do not invent a table '
        "that isn't really there. Output raw JSON only, no markdown fences.\n\n"
        f"Title: {req.title or 'unknown'}\nURL: {req.url or 'unknown'}\n\n{text[:20000]}"
    )

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 3500,
                "messages": [{"role": "user", "content": prompt}],
            },
        )
    if response.status_code != 200:
        raise HTTPException(502, f"Structured extraction upstream error: {response.text[:200]}")

    data = response.json()
    text_out = "".join(
        block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
    ).strip()
    columns, rows, truncated = parse_table_json(text_out)
    return {"columns": columns, "rows": rows, "truncated": truncated}


# ============================================================
# 3b) AI TAB SEARCH — same Claude call pattern as the summarizer above.
# Takes the query plus every currently open tab's title + short page
# extract, and asks Claude which single tab (if any) actually matches —
# understands natural-language queries like "where I booked my flight",
# not just literal title/URL text matching. Requires ANTHROPIC_API_KEY,
# same as /summarize. Nothing here is stored server-side — it's a
# stateless one-shot lookup over whatever the app sent this request.
# ============================================================
@app.post("/ai/tab-search")
async def ai_tab_search(req: TabSearchRequest, user=Depends(get_ai_user)):
    if not ANTHROPIC_API_KEY:
        raise HTTPException(503, "AI Tab Search not configured — ANTHROPIC_API_KEY is not set on the server")

    if not req.tabs:
        return {"tab_id": None, "reason": "No open tabs to search"}

    tabs_listing = "\n".join(
        f"- id={t.id} | title=\"{t.title}\" | page_extract=\"{(t.extract or '')[:400]}\""
        for t in req.tabs
    )

    prompt = (
        "The user has these browser tabs open. Given their search query, pick the "
        "SINGLE tab id that best matches what they're looking for, understanding "
        "natural language (not just literal keyword matching) — e.g. \"where I "
        "booked my flight\" should match a tab about flight booking even if the "
        "title doesn't say those exact words. If nothing plausibly matches, "
        "return null.\n\n"
        f"Query: \"{req.query}\"\n\nOpen tabs:\n{tabs_listing}\n\n"
        "Respond with ONLY a JSON object, no other text: "
        '{"tab_id": <id or null>, "reason": "<one short sentence>"}'
    )

    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 150,
                "messages": [{"role": "user", "content": prompt}],
            },
        )

    if response.status_code != 200:
        raise HTTPException(502, f"AI Tab Search upstream error: {response.text[:200]}")

    data = response.json()
    reply_text = "".join(
        block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
    ).strip()

    import json
    import re

    # Claude is asked for pure JSON but models occasionally wrap it in
    # prose or a code fence anyway — pull out the first {...} block rather
    # than trusting the whole response is clean JSON.
    match = re.search(r"\{.*\}", reply_text, re.DOTALL)
    if not match:
        return {"tab_id": None, "reason": "Couldn't parse a match"}
    try:
        parsed = json.loads(match.group(0))
        return {"tab_id": parsed.get("tab_id"), "reason": parsed.get("reason", "")}
    except Exception:
        return {"tab_id": None, "reason": "Couldn't parse a match"}


# ============================================================
# 3c) AI TAB GROUPS — same Claude call pattern again. Takes every open
# tab's title + extract and asks Claude to sort them into a handful of
# short category names (e.g. "Trading", "Entertainment", "Shopping")
# so the app can section the Tab Switcher instead of one flat list.
# Stateless, same ANTHROPIC_API_KEY requirement as the two above.
# ============================================================
@app.post("/ai/tab-groups")
async def ai_tab_groups(req: TabGroupsRequest, user=Depends(get_ai_user)):
    if not ANTHROPIC_API_KEY:
        raise HTTPException(503, "AI Tab Groups not configured — ANTHROPIC_API_KEY is not set on the server")

    if not req.tabs:
        return {"assignments": []}

    tabs_listing = "\n".join(
        f"- id={t.id} | title=\"{t.title}\" | page_extract=\"{(t.extract or '')[:300]}\""
        for t in req.tabs
    )

    prompt = (
        "Group these browser tabs into short, sensible categories (2-4 words each, "
        'e.g. "Trading", "Entertainment", "Shopping", "Work", "Research"). Every '
        "single tab must be assigned exactly one group name. Use as FEW distinct "
        "groups as reasonably make sense — don't invent a separate group per tab.\n\n"
        f"Tabs:\n{tabs_listing}\n\n"
        "Respond with ONLY a JSON object, no other text: "
        '{"assignments": [{"tab_id": <id>, "group": "<short group name>"}, ...]}'
    )

    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 500,
                "messages": [{"role": "user", "content": prompt}],
            },
        )

    if response.status_code != 200:
        raise HTTPException(502, f"AI Tab Groups upstream error: {response.text[:200]}")

    data = response.json()
    reply_text = "".join(
        block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
    ).strip()

    import json
    import re

    match = re.search(r"\{.*\}", reply_text, re.DOTALL)
    if not match:
        return {"assignments": []}
    try:
        parsed = json.loads(match.group(0))
        return {"assignments": parsed.get("assignments", [])}
    except Exception:
        return {"assignments": []}


# ============================================================
# 4) PUSH NOTIFICATIONS — register a device's FCM token, and
# send a notification to it via FCM HTTP v1. Requires a Firebase
# service-account JSON (FCM_SERVICE_ACCOUNT_JSON / _FILE), and the
# Android app must have its own Firebase project +
# google-services.json (see backend/README.md).
# ============================================================
_fcm_cache = {"token": None, "exp": 0}


def _fcm_service_account() -> Optional[dict]:
    import json
    raw = FCM_SERVICE_ACCOUNT_JSON
    if not raw and FCM_SERVICE_ACCOUNT_FILE and os.path.exists(FCM_SERVICE_ACCOUNT_FILE):
        with open(FCM_SERVICE_ACCOUNT_FILE) as f:
            raw = f.read()
    if not raw:
        return None
    try:
        info = json.loads(raw)
        if not all(k in info for k in ("client_email", "private_key", "project_id")):
            return None
        return info
    except ValueError:
        return None


def _b64url(b: bytes) -> str:
    import base64
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


async def _fcm_access_token(sa: dict) -> str:
    """OAuth2 service-account flow (signed JWT -> access token), cached ~55 min."""
    import json
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding
    now = int(time.time())
    if _fcm_cache["token"] and _fcm_cache["exp"] - 60 > now:
        return _fcm_cache["token"]
    header = _b64url(json.dumps({"alg": "RS256", "typ": "JWT"}).encode())
    claims = _b64url(json.dumps({
        "iss": sa["client_email"],
        "scope": "https://www.googleapis.com/auth/firebase.messaging",
        "aud": "https://oauth2.googleapis.com/token",
        "iat": now, "exp": now + 3600,
    }).encode())
    signing_input = f"{header}.{claims}".encode()
    key = serialization.load_pem_private_key(sa["private_key"].encode(), password=None)
    sig = key.sign(signing_input, padding.PKCS1v15(), hashes.SHA256())
    assertion = f"{header}.{claims}.{_b64url(sig)}"
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.post("https://oauth2.googleapis.com/token", data={
            "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer", "assertion": assertion})
    if resp.status_code != 200:
        raise HTTPException(502, f"Could not get an FCM access token ({resp.status_code})")
    data = resp.json()
    _fcm_cache["token"] = data["access_token"]
    _fcm_cache["exp"] = now + int(data.get("expires_in", 3600))
    return _fcm_cache["token"]

@app.post("/notifications/register-token")
def register_token(req: RegisterTokenRequest, user=Depends(get_current_user)):
    with get_db() as db:
        existing = db.execute(
            "SELECT id FROM device_tokens WHERE user_id = ? AND fcm_token = ?",
            (user["id"], req.fcm_token),
        ).fetchone()
        if not existing:
            db.execute(
                "INSERT INTO device_tokens (user_id, fcm_token, created_at) VALUES (?, ?, ?)",
                (user["id"], req.fcm_token, int(time.time())),
            )
    return {"status": "registered"}


@app.post("/notifications/send")
async def send_notification(req: SendNotificationRequest, user=Depends(get_current_user)):
    sa = _fcm_service_account()
    if not sa:
        raise HTTPException(503, "Push notifications not configured — set FCM_SERVICE_ACCOUNT_JSON (or FCM_SERVICE_ACCOUNT_FILE) on the server")

    with get_db() as db:
        if req.fcm_token:
            # Even with an explicit token, only send to a device that's
            # actually registered under THIS user's own box — otherwise any
            # authenticated account could push a notification to a token
            # that isn't theirs.
            owned = db.execute(
                "SELECT id FROM device_tokens WHERE user_id = ? AND fcm_token = ?",
                (user["id"], req.fcm_token),
            ).fetchone()
            if not owned:
                raise HTTPException(403, "That device isn't registered to your account")
            tokens = [req.fcm_token]
        else:
            rows = db.execute(
                "SELECT fcm_token FROM device_tokens WHERE user_id = ?", (user["id"],)
            ).fetchall()
            tokens = [r["fcm_token"] for r in rows]

    if not tokens:
        raise HTTPException(404, "No registered devices for this account")

    sent = await _push_to_tokens(sa, tokens, req.title, req.body, user["id"])
    return {"status": "sent", "delivered_to": sent, "attempted": len(tokens)}


async def _push_to_tokens(sa: dict, tokens: list, title: str, body: str, user_id: int) -> int:
    """Sends one FCM v1 notification per token; prunes tokens Google says are dead."""
    sent = 0
    access_token = await _fcm_access_token(sa)
    stale_tokens = []
    async with httpx.AsyncClient(timeout=15) as client:
        for token in tokens:
            resp = await client.post(
                f"https://fcm.googleapis.com/v1/projects/{sa['project_id']}/messages:send",
                headers={
                    "Authorization": f"Bearer {access_token}",
                    "Content-Type": "application/json",
                },
                json={"message": {
                    "token": token,
                    "notification": {"title": title, "body": body},
                }},
            )
            if resp.status_code == 200:
                sent += 1
            elif resp.status_code in (404, 400) and "UNREGISTERED" in resp.text.upper():
                stale_tokens.append(token)  # app uninstalled / token rotated
    if stale_tokens:
        with get_db() as db:
            for t in stale_tokens:
                db.execute("DELETE FROM device_tokens WHERE user_id = ? AND fcm_token = ?", (user_id, t))
    return sent


def push_to_user_blocking(user_id: int, title: str, body: str) -> int:
    """For background threads (the scheduler): best-effort push to all of a user's
    devices. Never raises — a push problem must not stop the scheduler."""
    try:
        sa = _fcm_service_account()
        if not sa:
            return 0
        with get_db() as db:
            tokens = [r["fcm_token"] for r in db.execute(
                "SELECT fcm_token FROM device_tokens WHERE user_id = ?", (user_id,)).fetchall()]
        if not tokens:
            return 0
        import asyncio
        return asyncio.run(_push_to_tokens(sa, tokens, title, body, user_id))
    except Exception as e:
        print(f"[push] scheduler push failed: {e}")
        return 0


# ============================================================
# 5) AGENT AUTOMATION — you write an instruction in plain language
# ("search cats on youtube and get the first video's transcript"),
# Claude breaks it into a small sequence of browser steps from a
# FIXED action vocabulary, the Android app executes those steps for
# real inside its own WebView (using your logged-in session/cookies —
# nothing runs server-side), reports each step's result back here,
# and the final combined result is available both in the app AND via
# GET /agent/result/{job_id} — so you (or any script with your token)
# can fetch results through the API too.
#
# Fixed action vocabulary the planner is constrained to:
#   navigate(url)              — load a URL directly
#   search(query)               — search Google for query
#   extract_text()               — grab the visible text of the current page
#   get_youtube_transcript()     — best-effort scrape of YouTube's transcript panel
#   wait(ms)                     — pause before the next step
#   done(summary)                 — end the job with a final summary
# ============================================================
AGENT_SYSTEM_PROMPT = """You are a browser automation planner. Given a plain-language
instruction, output ONLY a JSON array of steps using EXACTLY this action vocabulary —
no other actions exist:

- {"action":"navigate","url":"..."}
- {"action":"search","query":"..."}
- {"action":"click","text":"..."}
- {"action":"type","text":"...","label":"..."}
- {"action":"scroll","direction":"down"}
- {"action":"inspect_dom"}
- {"action":"visual_understand","question":"..."}
- {"action":"fill_form","instructions":"..."}
- {"action":"read_screenshot_text"}
- {"action":"verify_screenshot","expectation":"..."}
- {"action":"extract_text"}
- {"action":"get_youtube_transcript"}
- {"action":"wait","ms":1500}
- {"action":"done","summary":"..."}

Notes on the newer actions — you cannot see the page's HTML, so target elements by
their likely VISIBLE TEXT, never by a guessed CSS selector or id:
- "click": clicks the first button/link/clickable element whose visible text contains
  the given "text" (case-insensitive substring match). Use short, distinctive text as
  it's likely to actually appear (e.g. "Sign in", "Add to cart", "Next"), not a
  description of the element.
- "type": types "text" into the first input/textarea whose placeholder, label, name,
  or id contains "label" (e.g. label:"email", label:"search", label:"message"). Never
  use "type" for passwords or other sensitive/private data.
- "scroll": "direction" is "down" or "up".
- "inspect_dom": lists the clickable elements and input fields currently visible on
  the page (their visible text/labels) — use this when the user's goal is literally
  to know what's on a page ("what are my options here", "list the buttons/fields on
  this page"), or right before a "click"/"type" step whose exact wording you're
  genuinely unsure of.
- "visual_understand": takes an actual screenshot of the page and asks an AI vision
  model your "question" about it — use this ONLY for things text/DOM inspection can't
  answer, like describing an image, reading a chart/graph, judging layout or visual
  state, or "what does this look like". If "question" is omitted, it just describes
  what's visible. Don't use this for anything inspect_dom or extract_text can already
  answer — it's slower and costs more than those.
- "fill_form": looks at every input/textarea field currently on the page and an AI
  decides a sensible value for each one relevant to "instructions" (e.g. "sign up
  with a test account", "search for wireless headphones under $50"), then fills them
  all in one step and verifies each one actually took. NEVER fills in real passwords,
  card numbers, or other sensitive personal data — it uses placeholder/test values or
  skips those fields instead. Use this instead of several separate "type" steps when
  there's more than one or two fields to fill.
- "read_screenshot_text": OCR-style — reads back every piece of readable text visible
  in a screenshot, INCLUDING text baked into images/banners/logos/photos that
  extract_text and inspect_dom cannot see (they only see real HTML text/DOM
  elements). Use this when the goal needs text that's part of a picture, not the
  page's markup — e.g. a coupon code shown as an image, text in a diagram or photo.
- "verify_screenshot": takes a screenshot and asks whether "expectation" is visibly
  true right now (e.g. "a success message is showing", "the shopping cart icon shows
  1 item", "the page looks like a login form"). Use this AFTER an action to confirm
  it visibly worked when there's no DOM signal to check instead — for things you
  could check by reading the DOM (a specific field's value, whether a button exists),
  inspect_dom or fill_form's own verification already covers that more cheaply.

Rules:
- Keep it to 8 steps or fewer.
- Always end with a "done" step.
- Prefer "search" followed by a "click" on the right-looking result over guessing a
  "navigate" URL you aren't sure of.
- After a "click" or "type" that might change or load the page, a short "wait" before
  the next step helps.
- Confidence Engine: add a "confidence" field (integer, 0-100) to EVERY step object —
  your own honest estimate of how likely THIS SPECIFIC step is to work as planned,
  given only the instruction (you haven't seen the real page yet, so a guessed
  "navigate" URL or a "click" on wording you're inferring should score lower than an
  "inspect_dom"/"search" step that can't really go wrong). Don't inflate this —
  it's shown to the user to flag steps worth watching, so a genuinely uncertain guess
  should say so (e.g. 40-60), not a confident-sounding 90.
- Output raw JSON only — no markdown fences, no explanation text.
- If the instruction is unclear or cannot be done with these actions, output a single
  "done" step explaining why in the summary.
"""


async def _plan_instruction_to_steps(instruction: str, user_provider: Optional[str] = None, user_api_key: Optional[str] = None, account_email: Optional[str] = None) -> list:
    """
    Shared by /agent/plan and /agent/plan/batch (#88) — turns one
    plain-language instruction into a browser-step plan. Prefers the
    user's OWN AI key (set once in Settings → AI — shared with Autopilot
    and Visual Page Understanding, see /account/ai-key) when they've set
    one; otherwise falls back to this server's own ANTHROPIC_API_KEY
    (Haiku) so planning still works out of the box with no setup.
    """
    email_context = ""
    if account_email:
        email_context = (
            "\n\nAccount context: the user selected/uses this email for this task: "
            + account_email
            + ". For forms/login, prefer an `autofill_login` step using this email "
              "instead of a generic password `type` step. Do not invent missing data."
        )
    planner_instruction = instruction + email_context
    if user_provider and user_api_key:
        plan_text = await _call_ai_model(
            user_provider, user_api_key, f"{AGENT_SYSTEM_PROMPT}\n\nInstruction: {planner_instruction}"
        )
    else:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": ANTHROPIC_API_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": "claude-haiku-4-5-20251001",
                    "max_tokens": 500,
                    "system": AGENT_SYSTEM_PROMPT,
                    "messages": [{"role": "user", "content": planner_instruction}],
                },
            )

        if response.status_code != 200:
            raise HTTPException(502, f"Planner upstream error: {response.text[:200]}")

        data = response.json()
        plan_text = "".join(
            block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
        ).strip()

    # Defensive parsing — strip markdown fences if the model added them anyway
    if plan_text.startswith("```"):
        plan_text = plan_text.strip("`")
        if plan_text.startswith("json"):
            plan_text = plan_text[4:]
        plan_text = plan_text.strip()

    import json
    try:
        steps = json.loads(plan_text)
        if not isinstance(steps, list):
            raise ValueError("not a list")
    except Exception:
        steps = [{"action": "done", "summary": "Couldn't turn that into browser steps — try rephrasing."}]

    return steps


def _create_agent_job(user_id: int, instruction: str, steps: list, depends_on: Optional[int] = None, mode: str = "plan", orchestration_id: Optional[int] = None, verify_result: bool = False, sandbox: bool = False, dry_run: bool = False, require_approval: bool = False, account_email: Optional[str] = None) -> int:
    import json
    now = int(time.time())
    with get_db() as db:
        if depends_on is not None:
            dep_row = db.execute(
                "SELECT id FROM agent_jobs WHERE id = ? AND user_id = ?", (depends_on, user_id)
            ).fetchone()
            if not dep_row:
                depends_on = None  # silently drop an invalid/foreign dependency rather than fail job creation

        max_priority_row = db.execute(
            "SELECT MAX(priority) as mx FROM agent_jobs WHERE user_id = ?", (user_id,)
        ).fetchone()
        next_priority = (max_priority_row["mx"] + 1) if max_priority_row and max_priority_row["mx"] is not None else 0

        cursor = db.execute(
            "INSERT INTO agent_jobs (user_id, instruction, plan_json, status, priority, result_json, created_at, updated_at, depends_on, mode, orchestration_id, verify_result, sandbox, dry_run, require_approval, account_email) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (user_id, instruction, json.dumps(steps), "queued", next_priority, None, now, now, depends_on, mode, orchestration_id, 1 if verify_result else 0, 1 if sandbox else 0, 1 if dry_run else 0, 1 if require_approval else 0, account_email),
        )
        return cursor.lastrowid


def _looks_like_login_task(instruction: str) -> bool:
    text = (instruction or "").lower()
    keywords = (
        "login", "log in", "sign in", "signin", "sign-in",
        "log into", "fill the form", "fill out the form",
        "complete the form", "submit the form"
    )
    return any(k in text for k in keywords)


@app.post("/agent/signal")
async def agent_signal(req: AgentSignalRequest, user=Depends(get_current_user)):
    """
    External signal entry point: an authorized caller can submit a natural-language
    task to Nex without using the Android UI. The signal is converted into the same
    agent job format used by /agent/plan, so it follows the normal permission,
    approval, retry and reporting pipeline.
    """
    user_provider, user_api_key = _get_user_ai_key_for_feature(user["id"], "planning")
    if not user_provider and not ANTHROPIC_API_KEY:
        raise HTTPException(503, "Agent not configured — set an AI key in Settings → AI, or ask the server admin to configure ANTHROPIC_API_KEY")

    instruction = req.instruction.strip()
    if len(instruction) < 3:
        raise HTTPException(400, "Instruction is too short")

    account_email = (req.account_email or user.get("email") or "").strip()
    steps = await _plan_instruction_to_steps(instruction, user_provider, user_api_key, account_email or None)
    # Defense-in-depth: if the task is clearly a login/form task and the
    # planner omitted the secure login action, insert it after navigation.
    if account_email and _looks_like_login_task(instruction):
        has_secure_login = any(
            isinstance(s, dict) and s.get("action") == "autofill_login"
            for s in steps
        )
        if not has_secure_login:
            login_step = {"action": "autofill_login", "email": account_email}
            insert_at = 1 if steps and isinstance(steps[0], dict) and steps[0].get("action") in ("navigate", "search") else 0
            steps.insert(insert_at, login_step)
    job_id = _create_agent_job(
        user["id"], instruction, steps,
        depends_on=req.depends_on,
        verify_result=req.verify_result,
        sandbox=req.sandbox,
        dry_run=req.dry_run,
        require_approval=req.require_approval,
        account_email=account_email or None,
    )
    return {"accepted": True, "job_id": job_id, "steps": steps, "account_email": account_email or None}


@app.post("/agent/plan")
async def agent_plan(req: AgentPlanRequest, user=Depends(get_current_user)):
    user_provider, user_api_key = _get_user_ai_key_for_feature(user["id"], "planning")
    if not user_provider and not ANTHROPIC_API_KEY:
        raise HTTPException(503, "Agent not configured — set an AI key in Settings → AI, or ask the server admin to configure ANTHROPIC_API_KEY")

    instruction = req.instruction.strip()
    if len(instruction) < 3:
        raise HTTPException(400, "Instruction is too short")

    account_email = (req.account_email or user.get("email") or "").strip()
    steps = await _plan_instruction_to_steps(instruction, user_provider, user_api_key, account_email or None)
    if account_email and _looks_like_login_task(instruction):
        has_secure_login = any(
            isinstance(s, dict) and s.get("action") == "autofill_login"
            for s in steps
        )
        if not has_secure_login:
            login_step = {"action": "autofill_login", "email": account_email}
            insert_at = 1 if steps and isinstance(steps[0], dict) and steps[0].get("action") in ("navigate", "search") else 0
            steps.insert(insert_at, login_step)
    job_id = _create_agent_job(
        user["id"], instruction, steps,
        depends_on=req.depends_on,
        verify_result=req.verify_result,
        sandbox=req.sandbox,
        dry_run=req.dry_run,
        require_approval=req.require_approval,
        account_email=account_email or None,
    )

    return {"job_id": job_id, "steps": steps, "account_email": account_email or None}


@app.post("/agent/plan/batch")
async def agent_plan_batch(req: BatchPlanRequest, user=Depends(get_current_user)):
    """
    Batch API (#88): plan + queue several instructions in one call
    instead of one /agent/plan round-trip per task. Each instruction
    gets its own independent agent_job (its own steps, its own status) —
    a batch is just a convenience wrapper around N single jobs, not a
    new kind of job. One bad instruction in the batch does not fail the
    others; its entry just comes back with an "error" field instead of
    a job_id.
    """
    user_provider, user_api_key = _get_user_ai_key_for_feature(user["id"], "planning")
    if not user_provider and not ANTHROPIC_API_KEY:
        raise HTTPException(503, "Agent not configured — set an AI key in Settings → AI, or ask the server admin to configure ANTHROPIC_API_KEY")

    if not req.instructions:
        raise HTTPException(400, "instructions must be a non-empty list")
    if len(req.instructions) > 20:
        raise HTTPException(400, "Max 20 instructions per batch")

    results = []
    previous_job_id = None
    for raw_instruction in req.instructions:
        instruction = (raw_instruction or "").strip()
        if len(instruction) < 3:
            results.append({"instruction": raw_instruction, "error": "Instruction is too short"})
            continue
        try:
            steps = await _plan_instruction_to_steps(instruction, user_provider, user_api_key)
            depends_on = previous_job_id if req.sequential else None
            job_id = _create_agent_job(user["id"], instruction, steps, depends_on=depends_on)
            results.append({"instruction": instruction, "job_id": job_id, "steps": steps, "depends_on": depends_on})
            if req.sequential:
                previous_job_id = job_id
        except HTTPException as e:
            results.append({"instruction": instruction, "error": e.detail})
        except Exception as e:
            results.append({"instruction": instruction, "error": str(e)})

    return {"jobs": results}


# Goal-Based Agent (#71) — distinct from the fixed-upfront-plan jobs
# above. There, the whole step list is decided ONCE before anything
# runs; here, only a GOAL is given, and the single next action is
# decided fresh each time, after seeing what actually happened on the
# page so far — because for open-ended goals you genuinely don't know
# what the pages along the way will look like until you get there.
# Deliberately text/DOM-based (not screenshot-based like Autopilot) so
# it shares "planning"'s AI-key toggle and server-key fallback and
# works out of the box with no user-supplied key, same as regular
# planning and unlike Autopilot (which always needs the user's own key).
GOAL_AGENT_SYSTEM_PROMPT = """You are controlling a mobile web browser, ONE STEP AT A
TIME, working toward a goal. You do not get to plan the whole task in advance because
you don't know yet what the pages along the way will look like — after every action
you'll be told what happened and asked to decide only the next one.

Respond with ONLY one raw JSON object — no markdown fences, no explanation — using
exactly one of these action shapes (same vocabulary as full task planning):
{"action":"navigate","url":"..."}
{"action":"search","query":"..."}
{"action":"click","text":"..."}
{"action":"type","text":"...","label":"..."}
{"action":"scroll","direction":"down"}
{"action":"inspect_dom"}
{"action":"visual_understand","question":"..."}
{"action":"fill_form","instructions":"..."}
{"action":"read_screenshot_text"}
{"action":"verify_screenshot","expectation":"..."}
{"action":"extract_text"}
{"action":"get_youtube_transcript"}
{"action":"wait","ms":1500}
{"action":"done","summary":"..."}

Target "click"/"type" elements by their likely VISIBLE text/label, never a guessed CSS
selector or id. Never use "type" for passwords or other sensitive personal data — use
"done" instead and explain why in the summary. If the goal already looks accomplished
based on what you've been told so far, or you're stuck repeating the same failed
attempt, respond with "done" and summarize what happened.

Confidence Engine: also include a "confidence" field (integer, 0-100) — your own
honest estimate of how likely THIS action is to succeed given the page elements
you were actually shown. An exact visible-text match should score high; a guess
made because nothing obviously matched should say so honestly, not sound more sure
than it is. Output raw JSON only.
"""

MAX_GOAL_STEPS = 25  # safety cap — a goal that isn't "done" by then stops on its own


@app.post("/agent/goal/plan")
async def agent_goal_plan(req: GoalPlanRequest, user=Depends(get_current_user)):
    """
    Creates a goal-mode job with an EMPTY plan_json — there is nothing
    to plan upfront, unlike /agent/plan. The step list is filled in one
    action at a time by /agent/goal/next as the job actually runs.
    """
    goal = req.goal.strip()
    if len(goal) < 3:
        raise HTTPException(400, "Goal is too short")

    job_id = _create_agent_job(user["id"], goal, [], depends_on=req.depends_on, mode="goal", verify_result=req.verify_result, sandbox=req.sandbox, dry_run=req.dry_run, require_approval=req.require_approval)
    return {"job_id": job_id, "steps": []}


@app.post("/agent/goal/next")
async def agent_goal_next(req: GoalNextRequest, user=Depends(get_current_user)):
    import json
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM agent_jobs WHERE id = ? AND user_id = ?", (req.job_id, user["id"])
        ).fetchone()
    if not row:
        raise HTTPException(404, "Job not found")
    if row["mode"] != "goal":
        raise HTTPException(400, "This job isn't a goal-mode job")
    if row["status"] in ("done", "cancelled"):
        raise HTTPException(400, f"Job is already {row['status']}")

    steps = json.loads(row["plan_json"])
    result = json.loads(row["result_json"]) if row["result_json"] else {}

    if len(steps) >= MAX_GOAL_STEPS:
        next_action = {"action": "done", "summary": f"Reached the {MAX_GOAL_STEPS}-step safety limit for goal mode."}
    else:
        history_lines = []
        for i, s in enumerate(steps):
            history_lines.append(f"{i + 1}. {s.get('action')} -> {result.get(str(i), '')}")
        history_text = "\n".join(history_lines) if history_lines else "(none yet)"

        prompt = f"""Goal: "{row['instruction']}"

Current page URL: {req.current_url}
Elements detected on the page (may be incomplete): {req.dom_summary[:2000]}

Steps already taken:
{history_text}

Decide the SINGLE next action."""

        user_provider, user_api_key = _get_user_ai_key_for_feature(user["id"], "planning")
        if user_provider and user_api_key:
            text = await _call_ai_model(user_provider, user_api_key, f"{GOAL_AGENT_SYSTEM_PROMPT}\n\n{prompt}")
        elif ANTHROPIC_API_KEY:
            async with httpx.AsyncClient(timeout=30) as client:
                response = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={
                        "x-api-key": ANTHROPIC_API_KEY,
                        "anthropic-version": "2023-06-01",
                        "content-type": "application/json",
                    },
                    json={
                        "model": "claude-haiku-4-5-20251001",
                        "max_tokens": 300,
                        "system": GOAL_AGENT_SYSTEM_PROMPT,
                        "messages": [{"role": "user", "content": prompt}],
                    },
                )
            if response.status_code != 200:
                raise HTTPException(502, f"Goal agent upstream error: {response.text[:200]}")
            data = response.json()
            text = "".join(
                block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
            ).strip()
        else:
            raise HTTPException(503, "Agent not configured — set an AI key in Settings → AI, or ask the server admin to configure ANTHROPIC_API_KEY")

        if text.startswith("```"):
            text = text.strip("`")
            if text.startswith("json"):
                text = text[4:]
            text = text.strip()

        try:
            next_action = json.loads(text)
            if not isinstance(next_action, dict) or "action" not in next_action:
                raise ValueError("not a valid action object")
        except Exception:
            next_action = {"action": "done", "summary": "Couldn't understand the AI's response — stopping."}

    # Persist the decided action into the job's plan right away, so a
    # crash/app-restart mid-goal-job resumes with everything decided so
    # far intact (Crash Recovery, #94) instead of losing the history.
    steps.append(next_action)
    now = int(time.time())
    with get_db() as db:
        db.execute(
            "UPDATE agent_jobs SET plan_json = ?, updated_at = ? WHERE id = ?",
            (json.dumps(steps), now, req.job_id),
        )

    return {"next_action": next_action, "step_index": len(steps) - 1}


# Multi-Agent Orchestrator (#72) — one goal, broken into an ordered list
# of smaller sub-tasks, each run as its own normal agent_job (reusing
# the existing planner + the existing parallel-lane queue + dependency
# machinery on the Android side — no new execution engine needed there).
# The chaining is what's new: sub-tasks are planned LAZILY, one at a
# time, only once the previous one finishes — never all upfront — so
# each sub-task's plan can be built with the actual RESULT of the one
# before it as context, not just "wait until it's done" like a plain
# depends_on chain (#91) gives you.
ORCHESTRATOR_SYSTEM_PROMPT = """You break one larger goal down into a short ordered
list of smaller, self-contained browser-automation sub-tasks, each of which will
later be planned and run on its own, one after another.

Output ONLY a raw JSON array of plain-language sub-task instruction strings — no
markdown fences, no explanation, no step-level detail (that gets planned separately,
later, for each sub-task individually).

Rules:
- 2 to 6 sub-tasks. If the goal is already a single simple task, output an array with
  just that ONE instruction — don't force it into more pieces than it needs.
- Each sub-task should read like a normal standalone task instruction (e.g. "search
  for flights from Delhi to Goa in December", "open the cheapest result and note the
  price"), not a meta-description of a step.
- Order matters — put them in the sequence they should actually run in. Each sub-task
  runs only after the previous one finishes, and is told the previous sub-task's
  outcome as context, so don't repeat information the next one will already be given.
- Output raw JSON array of strings only.
"""


async def _create_next_orchestrator_job(user_id: int, orch_id: int) -> Optional[int]:
    """
    Creates the agent_job for an orchestration's NEXT not-yet-created
    sub-task, enriching its instruction with the previous sub-job's
    result as context (if there is one). Called once when an
    orchestration is first created, and again from /agent/report each
    time an orchestrator sub-job finishes. Returns the new job_id, or
    None if every sub-task already has a job (orchestration complete).
    """
    import json
    with get_db() as db:
        orch = db.execute(
            "SELECT * FROM agent_orchestrations WHERE id = ? AND user_id = ?", (orch_id, user_id)
        ).fetchone()
    if not orch or orch["status"] != "running":
        return None

    sub_tasks = json.loads(orch["sub_tasks_json"])
    idx = orch["current_index"]
    if idx >= len(sub_tasks):
        return None

    instruction = sub_tasks[idx]
    if idx > 0:
        with get_db() as db:
            prev_job = db.execute(
                "SELECT result_json FROM agent_jobs WHERE orchestration_id = ? AND user_id = ? ORDER BY id DESC LIMIT 1",
                (orch_id, user_id),
            ).fetchone()
        prev_summary = ""
        if prev_job and prev_job["result_json"]:
            try:
                prev_summary = json.loads(prev_job["result_json"]).get("final", "") or ""
            except Exception:
                prev_summary = ""
        if prev_summary:
            instruction = f"{instruction}\n\n(Context — result of the previous step: {prev_summary[:500]})"

    user_provider, user_api_key = _get_user_ai_key_for_feature(user_id, "planning")
    steps = await _plan_instruction_to_steps(instruction, user_provider, user_api_key)
    job_id = _create_agent_job(user_id, instruction, steps, mode="plan", orchestration_id=orch_id)

    now = int(time.time())
    with get_db() as db:
        db.execute(
            "UPDATE agent_orchestrations SET current_index = ?, updated_at = ? WHERE id = ?",
            (idx + 1, now, orch_id),
        )
    return job_id


@app.post("/agent/orchestrate")
async def agent_orchestrate(req: OrchestratePlanRequest, user=Depends(get_current_user)):
    goal = req.goal.strip()
    if len(goal) < 3:
        raise HTTPException(400, "Goal is too short")

    user_provider, user_api_key = _get_user_ai_key_for_feature(user["id"], "planning")
    if not (user_provider and user_api_key) and not ANTHROPIC_API_KEY:
        raise HTTPException(503, "Agent not configured — set an AI key in Settings → AI, or ask the server admin to configure ANTHROPIC_API_KEY")

    if user_provider and user_api_key:
        text = await _call_ai_model(user_provider, user_api_key, f"{ORCHESTRATOR_SYSTEM_PROMPT}\n\nGoal: {goal}")
    else:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": ANTHROPIC_API_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": "claude-haiku-4-5-20251001",
                    "max_tokens": 400,
                    "system": ORCHESTRATOR_SYSTEM_PROMPT,
                    "messages": [{"role": "user", "content": f"Goal: {goal}"}],
                },
            )
        if response.status_code != 200:
            raise HTTPException(502, f"Orchestrator upstream error: {response.text[:200]}")
        data = response.json()
        text = "".join(
            block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
        ).strip()

    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
        text = text.strip()

    import json
    try:
        sub_tasks = json.loads(text)
        if not isinstance(sub_tasks, list) or not sub_tasks:
            raise ValueError("not a non-empty list")
        sub_tasks = [str(s).strip() for s in sub_tasks if str(s).strip()][:6]
        if not sub_tasks:
            raise ValueError("empty after cleanup")
    except Exception:
        sub_tasks = [goal]  # fall back to treating the whole goal as one sub-task

    now = int(time.time())
    with get_db() as db:
        cursor = db.execute(
            "INSERT INTO agent_orchestrations (user_id, goal, sub_tasks_json, current_index, status, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (user["id"], goal, json.dumps(sub_tasks), 0, "running", now, now),
        )
        orch_id = cursor.lastrowid

    first_job_id = await _create_next_orchestrator_job(user["id"], orch_id)

    return {"orchestration_id": orch_id, "sub_tasks": sub_tasks, "first_job_id": first_job_id}


@app.get("/agent/orchestrations")
def agent_orchestrations_list(user=Depends(get_current_user)):
    import json
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM agent_orchestrations WHERE user_id = ? ORDER BY id DESC LIMIT 50", (user["id"],)
        ).fetchall()
    orchestrations = []
    for row in rows:
        orchestrations.append({
            "orchestration_id": row["id"],
            "goal": row["goal"],
            "sub_tasks": json.loads(row["sub_tasks_json"]),
            "current_index": row["current_index"],
            "status": row["status"],
            "final_result": row["final_result"],
        })
    return {"orchestrations": orchestrations}


@app.get("/agent/firewall")
def agent_firewall_get(user=Depends(get_current_user)):
    """Agent Permission Firewall (#79) — the stored config only; Android
    fetches and enforces it locally, since navigation happens client-side."""
    import json
    with get_db() as db:
        row = db.execute("SELECT * FROM agent_firewall WHERE user_id = ?", (user["id"],)).fetchone()
    if not row:
        return {"mode": "off", "domains": []}
    return {"mode": row["mode"], "domains": json.loads(row["domains_json"])}


@app.post("/agent/firewall")
def agent_firewall_set(req: FirewallConfigRequest, user=Depends(get_current_user)):
    import json
    mode = req.mode if req.mode in ("off", "whitelist", "blacklist") else "off"
    domains = [str(d).strip().lower() for d in req.domains if str(d).strip()][:100]
    now = int(time.time())
    with get_db() as db:
        db.execute(
            "INSERT INTO agent_firewall (user_id, mode, domains_json, updated_at) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET mode = excluded.mode, domains_json = excluded.domains_json, updated_at = excluded.updated_at",
            (user["id"], mode, json.dumps(domains), now),
        )
    return {"mode": mode, "domains": domains}


@app.get("/agent/policy")
def agent_policy_get(user=Depends(get_current_user)):
    """Agent Policy Engine (#80) — generalizes Human Approval Layer
    (#78)'s hardcoded keyword list into something the user can extend,
    plus two global knobs enforced client-side across every job."""
    import json
    with get_db() as db:
        row = db.execute("SELECT * FROM agent_policy WHERE user_id = ?", (user["id"],)).fetchone()
    if not row:
        return {"custom_keywords": [], "always_require_approval": False, "max_steps_per_job": None}
    return {
        "custom_keywords": json.loads(row["custom_keywords_json"]),
        "always_require_approval": bool(row["always_require_approval"]),
        "max_steps_per_job": row["max_steps_per_job"],
    }


@app.post("/agent/policy")
def agent_policy_set(req: PolicyConfigRequest, user=Depends(get_current_user)):
    import json
    keywords = [str(k).strip().lower() for k in req.custom_keywords if str(k).strip()][:50]
    max_steps = req.max_steps_per_job if (req.max_steps_per_job is None or req.max_steps_per_job > 0) else None
    now = int(time.time())
    with get_db() as db:
        db.execute(
            "INSERT INTO agent_policy (user_id, custom_keywords_json, always_require_approval, max_steps_per_job, updated_at) "
            "VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET custom_keywords_json = excluded.custom_keywords_json, "
            "always_require_approval = excluded.always_require_approval, max_steps_per_job = excluded.max_steps_per_job, "
            "updated_at = excluded.updated_at",
            (user["id"], json.dumps(keywords), 1 if req.always_require_approval else 0, max_steps, now),
        )
    return {"custom_keywords": keywords, "always_require_approval": req.always_require_approval, "max_steps_per_job": max_steps}


@app.post("/agent/report")
async def agent_report(req: AgentReportRequest, user=Depends(get_current_user)):
    import json
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM agent_jobs WHERE id = ? AND user_id = ?", (req.job_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "Job not found")

        # Don't let a late progress report resurrect a job the user already cancelled
        if row["status"] == "cancelled":
            return {"status": "ignored (job was cancelled)"}

        result = {}
        if row["result_json"]:
            try:
                result = json.loads(row["result_json"])
            except Exception:
                result = {}

        result[str(req.step_index)] = req.step_result
        status = "needs_approval" if req.needs_approval else ("done" if req.done else "running")
        # A step that was already in flight when the user paused still reports
        # back: record its result and position, but the job stays paused (only
        # a finished/approval-needed report may change the status).
        if row["status"] == "paused" and status == "running":
            status = "paused"
        if req.done and req.final_result:
            result["final"] = req.final_result
        # Agent-to-Agent Verification (#73): a done report that failed
        # verification doesn't get to claim "done" — it parks for the
        # user to review instead, with the reviewer's own reasoning kept
        # alongside the worker's original claimed result (not replacing it).
        if req.done and req.verified is False:
            status = "needs_verification"
            if req.verification_reason:
                result["verification_reason"] = req.verification_reason

        # current_step/current_url let a job pick back up from where it left
        # off (rather than restarting from step 0) if execution is
        # interrupted — e.g. the app closes or the Automation page isn't
        # open when this device comes back. Only overwrite current_url when
        # the app actually sent one — a step that doesn't involve navigation
        # (like "wait") may not have a fresh URL to report.
        next_step = req.step_index + 1
        current_url = req.current_url if req.current_url else row["current_url"]

        # Error Reason Tracking (#69) / Last Successful Step (#68): a
        # step reporting in with no error is what actually succeeded —
        # record it, and clear any earlier error since a later success
        # supersedes it. A step reporting an error updates neither of
        # those, but still records what went wrong.
        last_successful_step = row["last_successful_step"]
        last_error = row["last_error"]
        if req.error:
            last_error = req.error
        else:
            last_successful_step = req.step_index
            last_error = None

        # Step timing for ETA: time since the previous step report, capped so a
        # long pause / closed app doesn't poison the average (resume resets
        # last_step_at to NULL, so paused time is never counted either).
        now_ts = int(time.time())
        steps_time_total = row["steps_time_total"] or 0
        steps_timed = row["steps_timed"] or 0
        if row["last_step_at"] and not req.error:
            steps_time_total += max(0, min(now_ts - row["last_step_at"], 300))
            steps_timed += 1

        db.execute(
            "UPDATE agent_jobs SET result_json = ?, status = ?, current_step = ?, current_url = ?, "
            "updated_at = ?, last_error = ?, last_successful_step = ?, "
            "last_step_at = ?, steps_time_total = ?, steps_timed = ? WHERE id = ?",
            (json.dumps(result), status, next_step, current_url, now_ts,
             last_error, last_successful_step, now_ts, steps_time_total, steps_timed, req.job_id),
        )

    # Multi-Agent Orchestrator (#72): a sub-job finishing is what
    # advances the chain. Only fires for jobs that actually belong to
    # an orchestration — an ordinary job's orchestration_id is NULL and
    # this is a no-op for it.
    # Don't advance an orchestrator chain (#72) on a result Verification
    # (#73) just flagged as unsupported — the next sub-task would be
    # planned using a possibly-false "final" result as its context.
    if req.done and req.verified is not False and row["orchestration_id"] is not None:
        orch_id = row["orchestration_id"]
        next_job_id = await _create_next_orchestrator_job(user["id"], orch_id)
        if next_job_id is None:
            final_summary = result.get("final", "") if req.final_result else req.step_result
            now = int(time.time())
            with get_db() as db:
                db.execute(
                    "UPDATE agent_orchestrations SET status = ?, final_result = ?, updated_at = ? WHERE id = ?",
                    ("done", final_summary, now, orch_id),
                )

    return {"status": "recorded"}


@app.get("/agent/result/{job_id}")
def agent_result(job_id: int, user=Depends(get_current_user)):
    import json
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM agent_jobs WHERE id = ? AND user_id = ?", (job_id, user["id"])
        ).fetchone()

    if not row:
        raise HTTPException(404, "Job not found")

    result = {}
    if row["result_json"]:
        try:
            result = json.loads(row["result_json"])
        except Exception:
            result = {}

    return {
        "job_id": row["id"],
        "instruction": row["instruction"],
        "status": row["status"],
        "priority": row["priority"],
        "steps": json.loads(row["plan_json"]),
        "result": result,
        "current_step": row["current_step"],
        "current_url": row["current_url"],
        "account_email": row["account_email"] if "account_email" in row.keys() else None,
        "mode": row["mode"],
        "orchestration_id": row["orchestration_id"],
        "verify_result": bool(row["verify_result"]),
        "sandbox": bool(row["sandbox"]),
        "dry_run": bool(row["dry_run"]),
        "require_approval": bool(row["require_approval"]),
    }


def _job_progress(row, total_steps: int) -> dict:
    """progress_pct + eta_seconds for the Automation screen (#66).
    ETA needs at least one measured step; goal-mode jobs grow their plan as
    they go, so their percentage/ETA is only a lower bound."""
    done_steps = min(row["current_step"] or 0, total_steps) if total_steps else 0
    status = row["status"]
    pct = 100 if status == "done" else (int(done_steps * 100 / total_steps) if total_steps else 0)
    eta = None
    timed = row["steps_timed"] or 0
    if status in ("running", "queued") and timed > 0 and total_steps > done_steps:
        avg = (row["steps_time_total"] or 0) / timed
        eta = int(avg * (total_steps - done_steps))
    return {"progress_pct": pct, "steps_total": total_steps, "steps_done": done_steps,
            "eta_seconds": eta, "avg_step_seconds": round((row["steps_time_total"] or 0) / timed, 1) if timed else None}


@app.get("/agent/jobs")
def agent_jobs(user=Depends(get_current_user)):
    import json
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM agent_jobs WHERE user_id = ? ORDER BY priority ASC",
            (user["id"],),
        ).fetchall()

    jobs = []
    for row in rows:
        result = {}
        if row["result_json"]:
            try:
                result = json.loads(row["result_json"])
            except Exception:
                result = {}
        jobs.append({
            "job_id": row["id"],
            "instruction": row["instruction"],
            "status": row["status"],
            "priority": row["priority"],
            "steps": json.loads(row["plan_json"]),
            "result": result,
            "current_step": row["current_step"],
            "current_url": row["current_url"],
            "created_at": row["created_at"],
            "depends_on": row["depends_on"],
            "last_error": row["last_error"],
            "last_successful_step": row["last_successful_step"],
            "mode": row["mode"],
            "orchestration_id": row["orchestration_id"],
            "verify_result": bool(row["verify_result"]),
            "sandbox": bool(row["sandbox"]),
            "dry_run": bool(row["dry_run"]),
            "require_approval": bool(row["require_approval"]),
            **_job_progress(row, len(json.loads(row["plan_json"]))),
        })

    return {"jobs": jobs}


@app.post("/agent/jobs/{job_id}/pause")
def agent_pause(job_id: int, user=Depends(get_current_user)):
    """Agent Pause (#62): durable, server-side. Survives app restarts and device
    switches — the old behaviour lived only in the phone's memory, so restarting
    the app silently resumed a job the user had paused."""
    with get_db() as db:
        row = db.execute("SELECT status FROM agent_jobs WHERE id = ? AND user_id = ?",
                         (job_id, user["id"])).fetchone()
        if not row:
            raise HTTPException(404, "Job not found")
        if row["status"] not in ("running", "queued"):
            raise HTTPException(409, f"A {row['status']} job can't be paused")
        db.execute("UPDATE agent_jobs SET status = 'paused', updated_at = ? WHERE id = ?",
                   (int(time.time()), job_id))
    return {"status": "paused"}


@app.post("/agent/jobs/{job_id}/resume")
def agent_resume(job_id: int, user=Depends(get_current_user)):
    """Agent Resume (#63): continues from current_step (not step 0). A job that
    already started goes back to 'running' so the phone's queue picks it up in
    preference to fresh work; one that never started returns to 'queued'."""
    with get_db() as db:
        row = db.execute("SELECT status, current_step FROM agent_jobs WHERE id = ? AND user_id = ?",
                         (job_id, user["id"])).fetchone()
        if not row:
            raise HTTPException(404, "Job not found")
        if row["status"] != "paused":
            raise HTTPException(409, "Job isn't paused")
        new_status = "running" if (row["current_step"] or 0) > 0 else "queued"
        db.execute("UPDATE agent_jobs SET status = ?, last_step_at = NULL, updated_at = ? WHERE id = ?",
                   (new_status, int(time.time()), job_id))
    return {"status": new_status}


@app.post("/agent/jobs/{job_id}/cancel")
def agent_cancel(job_id: int, user=Depends(get_current_user)):
    with get_db() as db:
        row = db.execute(
            "SELECT id FROM agent_jobs WHERE id = ? AND user_id = ?", (job_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "Job not found")
        now = int(time.time())
        db.execute(
            "UPDATE agent_jobs SET status = 'cancelled', updated_at = ? WHERE id = ?",
            (now, job_id),
        )

        # Job Dependencies (#91): any job waiting on this one can now
        # never become eligible to run, so cascade the cancellation
        # forward through the whole dependent chain instead of leaving
        # them stuck "queued" forever with no explanation.
        cancelled_ids = [job_id]
        while cancelled_ids:
            parent_id = cancelled_ids.pop()
            dependents = db.execute(
                "SELECT id FROM agent_jobs WHERE depends_on = ? AND user_id = ? AND status NOT IN ('done', 'cancelled')",
                (parent_id, user["id"]),
            ).fetchall()
            for dep in dependents:
                db.execute(
                    "UPDATE agent_jobs SET status = 'cancelled', updated_at = ? WHERE id = ?",
                    (now, dep["id"]),
                )
                cancelled_ids.append(dep["id"])

    return {"status": "cancelled"}


@app.delete("/agent/jobs/{job_id}")
def agent_delete(job_id: int, user=Depends(get_current_user)):
    with get_db() as db:
        row = db.execute(
            "SELECT id FROM agent_jobs WHERE id = ? AND user_id = ?", (job_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "Job not found")
        db.execute("DELETE FROM agent_jobs WHERE id = ?", (job_id,))
    return {"status": "deleted"}


@app.post("/agent/jobs/{job_id}/depend")
def agent_set_dependency(job_id: int, req: JobDependRequest, user=Depends(get_current_user)):
    with get_db() as db:
        row = db.execute(
            "SELECT id FROM agent_jobs WHERE id = ? AND user_id = ?", (job_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "Job not found")

        if req.depends_on is not None:
            if req.depends_on == job_id:
                raise HTTPException(400, "A job can't depend on itself")

            dep_row = db.execute(
                "SELECT id FROM agent_jobs WHERE id = ? AND user_id = ?", (req.depends_on, user["id"])
            ).fetchone()
            if not dep_row:
                raise HTTPException(404, "The job to depend on was not found")

            # Cycle check: walk depends_on backwards from the target —
            # if job_id shows up anywhere in that chain, linking it here
            # would create a loop that could never resolve.
            cursor_id = req.depends_on
            seen = set()
            while cursor_id is not None:
                if cursor_id == job_id:
                    raise HTTPException(400, "That would create a dependency cycle")
                if cursor_id in seen:
                    break  # already-broken chain elsewhere — stop rather than loop forever
                seen.add(cursor_id)
                next_row = db.execute(
                    "SELECT depends_on FROM agent_jobs WHERE id = ?", (cursor_id,)
                ).fetchone()
                cursor_id = next_row["depends_on"] if next_row else None

        db.execute(
            "UPDATE agent_jobs SET depends_on = ?, updated_at = ? WHERE id = ?",
            (req.depends_on, int(time.time()), job_id),
        )

    return {"job_id": job_id, "depends_on": req.depends_on}


@app.post("/agent/jobs/{job_id}/reorder")
def agent_reorder(job_id: int, req: AgentReorderRequest, user=Depends(get_current_user)):
    with get_db() as db:
        row = db.execute(
            "SELECT id FROM agent_jobs WHERE id = ? AND user_id = ?", (job_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "Job not found")

        if req.direction == "top":
            min_priority_row = db.execute(
                "SELECT MIN(priority) as mn FROM agent_jobs WHERE user_id = ?", (user["id"],)
            ).fetchone()
            new_priority = (min_priority_row["mn"] - 1) if min_priority_row and min_priority_row["mn"] is not None else 0
            db.execute(
                "UPDATE agent_jobs SET priority = ?, updated_at = ? WHERE id = ?",
                (new_priority, int(time.time()), job_id),
            )
        else:
            raise HTTPException(400, "Unsupported direction — only 'top' is implemented")

    return {"status": "reordered"}


# ============================================================
# Saved Workflows/Macros (#82) — persist a set of agent steps under a
# name so it can be replayed later without re-typing the instruction
# or re-planning it through the AI. Save/list/delete/run here; Edit
# (#83), Duplicate (#84) and Versioning (#86) follow further below —
# Scheduling (#87) is still separate/not built yet.
# ============================================================
@app.post("/workflows")
def save_workflow(req: WorkflowSaveRequest, user=Depends(get_current_user)):
    import json
    name = req.name.strip()
    if not name:
        raise HTTPException(400, "Workflow needs a name")
    if not req.steps:
        raise HTTPException(400, "Workflow needs at least one step")

    now = int(time.time())
    with get_db() as db:
        cursor = db.execute(
            "INSERT INTO workflows (user_id, name, steps_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
            (user["id"], name, json.dumps(req.steps), now, now),
        )
        workflow_id = cursor.lastrowid

    return {"workflow_id": workflow_id}


@app.get("/workflows")
def list_workflows(user=Depends(get_current_user)):
    import json
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM workflows WHERE user_id = ? ORDER BY updated_at DESC", (user["id"],)
        ).fetchall()
        schedule_rows = db.execute(
            "SELECT * FROM workflow_schedules WHERE user_id = ? AND enabled = 1", (user["id"],)
        ).fetchall()

    schedules_by_workflow = {}
    for s in schedule_rows:
        schedules_by_workflow[s["workflow_id"]] = {
            "schedule_id": s["id"],
            "recurrence": s["recurrence"],
            "daily_time": s["daily_time"],
            "next_run_at": s["next_run_at"],
            "last_run_at": s["last_run_at"],
        }

    workflows = []
    for row in rows:
        steps = json.loads(row["steps_json"])
        workflows.append({
            "workflow_id": row["id"],
            "name": row["name"],
            "step_count": len(steps),
            "steps": steps,
            "version": row["version"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
            "schedule": schedules_by_workflow.get(row["id"]),
        })

    return {"workflows": workflows}


@app.delete("/workflows/{workflow_id}")
def delete_workflow(workflow_id: int, user=Depends(get_current_user)):
    with get_db() as db:
        row = db.execute(
            "SELECT id FROM workflows WHERE id = ? AND user_id = ?", (workflow_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "Workflow not found")
        db.execute("DELETE FROM workflows WHERE id = ?", (workflow_id,))

    return {"status": "deleted"}


@app.post("/workflows/{workflow_id}/run")
def run_workflow(workflow_id: int, user=Depends(get_current_user)):
    import json
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM workflows WHERE id = ? AND user_id = ?", (workflow_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "Workflow not found")

        steps = json.loads(row["steps_json"])
        now = int(time.time())

        # Same job-creation shape as /agent/plan — this just skips the
        # Claude planning call because the steps are already known.
        max_priority_row = db.execute(
            "SELECT MAX(priority) as mx FROM agent_jobs WHERE user_id = ?", (user["id"],)
        ).fetchone()
        next_priority = (max_priority_row["mx"] + 1) if max_priority_row and max_priority_row["mx"] is not None else 0

        cursor = db.execute(
            "INSERT INTO agent_jobs (user_id, instruction, plan_json, status, priority, result_json, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (user["id"], f"Workflow: {row['name']}", json.dumps(steps), "queued", next_priority, None, now, now),
        )
        job_id = cursor.lastrowid

    return {"job_id": job_id, "steps": steps}


@app.post("/workflows/{workflow_id}/edit")
def edit_workflow(workflow_id: int, req: WorkflowEditRequest, user=Depends(get_current_user)):
    import json
    if req.name is None and req.steps is None:
        raise HTTPException(400, "Nothing to update — provide a name and/or steps")
    if req.name is not None and not req.name.strip():
        raise HTTPException(400, "Workflow needs a name")
    if req.steps is not None and not req.steps:
        raise HTTPException(400, "Workflow needs at least one step")

    with get_db() as db:
        row = db.execute(
            "SELECT * FROM workflows WHERE id = ? AND user_id = ?", (workflow_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "Workflow not found")

        now = int(time.time())

        # Workflow Versioning (#86): archive the version being replaced
        # BEFORE overwriting it, so every edit is reversible via
        # /workflows/{id}/versions/{version}/restore.
        db.execute(
            "INSERT INTO workflow_versions (workflow_id, user_id, version, name, steps_json, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (workflow_id, user["id"], row["version"], row["name"], row["steps_json"], now),
        )

        new_name = req.name.strip() if req.name is not None else row["name"]
        new_steps_json = json.dumps(req.steps) if req.steps is not None else row["steps_json"]
        new_version = row["version"] + 1

        db.execute(
            "UPDATE workflows SET name = ?, steps_json = ?, version = ?, updated_at = ? WHERE id = ?",
            (new_name, new_steps_json, new_version, now, workflow_id),
        )

    return {"workflow_id": workflow_id, "version": new_version}


@app.post("/workflows/{workflow_id}/duplicate")
def duplicate_workflow(workflow_id: int, req: WorkflowDuplicateRequest, user=Depends(get_current_user)):
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM workflows WHERE id = ? AND user_id = ?", (workflow_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "Workflow not found")

        new_name = (req.name.strip() if req and req.name else None) or (row["name"] + " (Copy)")
        now = int(time.time())

        # Fresh workflow, version 1 — the duplicate has its own independent
        # version history from here, separate from the original's.
        cursor = db.execute(
            "INSERT INTO workflows (user_id, name, steps_json, version, created_at, updated_at) "
            "VALUES (?, ?, ?, 1, ?, ?)",
            (user["id"], new_name, row["steps_json"], now, now),
        )
        new_workflow_id = cursor.lastrowid

    return {"workflow_id": new_workflow_id, "name": new_name}


@app.get("/workflows/{workflow_id}/versions")
def list_workflow_versions(workflow_id: int, user=Depends(get_current_user)):
    import json
    with get_db() as db:
        current = db.execute(
            "SELECT * FROM workflows WHERE id = ? AND user_id = ?", (workflow_id, user["id"])
        ).fetchone()
        if not current:
            raise HTTPException(404, "Workflow not found")

        rows = db.execute(
            "SELECT id, version, name, steps_json, created_at FROM workflow_versions "
            "WHERE workflow_id = ? AND user_id = ? ORDER BY version DESC",
            (workflow_id, user["id"]),
        ).fetchall()

    versions = [{
        "version": current["version"],
        "name": current["name"],
        "step_count": len(json.loads(current["steps_json"])),
        "updated_at": current["updated_at"],
        "is_current": True,
    }]
    for r in rows:
        versions.append({
            "version": r["version"],
            "name": r["name"],
            "step_count": len(json.loads(r["steps_json"])),
            "updated_at": r["created_at"],
            "is_current": False,
        })

    return {"versions": versions}


@app.post("/workflows/{workflow_id}/versions/{version}/restore")
def restore_workflow_version(workflow_id: int, version: int, user=Depends(get_current_user)):
    with get_db() as db:
        current = db.execute(
            "SELECT * FROM workflows WHERE id = ? AND user_id = ?", (workflow_id, user["id"])
        ).fetchone()
        if not current:
            raise HTTPException(404, "Workflow not found")

        old_version_row = db.execute(
            "SELECT * FROM workflow_versions WHERE workflow_id = ? AND user_id = ? AND version = ?",
            (workflow_id, user["id"], version),
        ).fetchone()
        if not old_version_row:
            raise HTTPException(404, "Version not found")

        now = int(time.time())

        # Archive the CURRENT live version too before overwriting it — so
        # restoring an old version never loses whatever was live just
        # before the restore.
        db.execute(
            "INSERT INTO workflow_versions (workflow_id, user_id, version, name, steps_json, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (workflow_id, user["id"], current["version"], current["name"], current["steps_json"], now),
        )

        new_version = current["version"] + 1
        db.execute(
            "UPDATE workflows SET name = ?, steps_json = ?, version = ?, updated_at = ? WHERE id = ?",
            (old_version_row["name"], old_version_row["steps_json"], new_version, now, workflow_id),
        )

    return {"workflow_id": workflow_id, "version": new_version, "restored_from_version": version}


# ============================================================
# Workflow Scheduling (#87) — run a saved workflow automatically at a
# future time ("once") or every day at a fixed time ("daily"), without
# the phone needing to be open. Scheduling lives entirely on the
# backend (see _scheduler_loop below) — the Android app only creates/
# views/cancels a schedule, it never has to be running for a scheduled
# workflow to fire.
# ============================================================
def _compute_next_daily_run(daily_time: str, after_ts: int) -> int:
    hh, mm = [int(p) for p in daily_time.split(":")]
    t = time.localtime(after_ts)
    candidate = time.mktime((t.tm_year, t.tm_mon, t.tm_mday, hh, mm, 0, 0, 0, -1))
    if candidate <= after_ts:
        candidate += 24 * 60 * 60
    return int(candidate)


@app.post("/workflows/{workflow_id}/schedule")
def schedule_workflow(workflow_id: int, req: WorkflowScheduleRequest, user=Depends(get_current_user)):
    if req.recurrence not in ("once", "daily"):
        raise HTTPException(400, "recurrence must be 'once' or 'daily'")

    with get_db() as db:
        row = db.execute(
            "SELECT id FROM workflows WHERE id = ? AND user_id = ?", (workflow_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "Workflow not found")

        now = int(time.time())

        if req.recurrence == "once":
            if not req.run_at:
                raise HTTPException(400, "run_at is required for a one-time schedule")
            if req.run_at <= now:
                raise HTTPException(400, "run_at must be in the future")
            next_run_at = req.run_at
            daily_time = None
        else:
            if not req.daily_time:
                raise HTTPException(400, "daily_time is required for a daily schedule")
            try:
                hh, mm = [int(p) for p in req.daily_time.split(":")]
                assert 0 <= hh <= 23 and 0 <= mm <= 59
            except Exception:
                raise HTTPException(400, "daily_time must be 'HH:MM' 24-hour")
            next_run_at = _compute_next_daily_run(req.daily_time, now)
            daily_time = req.daily_time

        # Only one active schedule per workflow — creating a new one
        # replaces whatever was there before.
        db.execute(
            "DELETE FROM workflow_schedules WHERE workflow_id = ? AND user_id = ?",
            (workflow_id, user["id"]),
        )
        cursor = db.execute(
            "INSERT INTO workflow_schedules (workflow_id, user_id, recurrence, daily_time, next_run_at, enabled, created_at) "
            "VALUES (?, ?, ?, ?, ?, 1, ?)",
            (workflow_id, user["id"], req.recurrence, daily_time, next_run_at, now),
        )
        schedule_id = cursor.lastrowid

    return {"schedule_id": schedule_id, "next_run_at": next_run_at}


@app.get("/workflows/{workflow_id}/schedule")
def get_workflow_schedule(workflow_id: int, user=Depends(get_current_user)):
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM workflow_schedules WHERE workflow_id = ? AND user_id = ? AND enabled = 1",
            (workflow_id, user["id"]),
        ).fetchone()

    if not row:
        return {"schedule": None}

    return {"schedule": {
        "schedule_id": row["id"],
        "recurrence": row["recurrence"],
        "daily_time": row["daily_time"],
        "next_run_at": row["next_run_at"],
        "last_run_at": row["last_run_at"],
    }}


@app.delete("/workflows/{workflow_id}/schedule")
def delete_workflow_schedule(workflow_id: int, user=Depends(get_current_user)):
    with get_db() as db:
        row = db.execute(
            "SELECT id FROM workflows WHERE id = ? AND user_id = ?", (workflow_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "Workflow not found")
        db.execute(
            "DELETE FROM workflow_schedules WHERE workflow_id = ? AND user_id = ?",
            (workflow_id, user["id"]),
        )

    return {"status": "deleted"}


@app.get("/schedules")
def list_all_schedules(user=Depends(get_current_user)):
    with get_db() as db:
        rows = db.execute(
            "SELECT ws.*, w.name as workflow_name FROM workflow_schedules ws "
            "JOIN workflows w ON w.id = ws.workflow_id "
            "WHERE ws.user_id = ? AND ws.enabled = 1 ORDER BY ws.next_run_at ASC",
            (user["id"],),
        ).fetchall()

    return {"schedules": [{
        "schedule_id": r["id"],
        "workflow_id": r["workflow_id"],
        "workflow_name": r["workflow_name"],
        "recurrence": r["recurrence"],
        "daily_time": r["daily_time"],
        "next_run_at": r["next_run_at"],
        "last_run_at": r["last_run_at"],
    } for r in rows]}


def _scheduler_loop():
    """
    Polls workflow_schedules every 30s and turns any due row into a
    normal agent_job — identical job shape to /workflows/{id}/run, so a
    scheduled run behaves exactly like a manual run once it's queued.

    Runs as a daemon thread inside this process. Each due schedule / watched
    page is claimed with a guarded UPDATE before any work is done, so running
    several workers against the same DB will NOT double-fire anything. (SQLite
    on one volume still means a single backend instance is the supported setup.)
    """
    while True:
        fired_notifications = []
        try:
            now = int(time.time())
            with get_db() as db:
                due = db.execute(
                    "SELECT * FROM workflow_schedules WHERE enabled = 1 AND next_run_at <= ?", (now,)
                ).fetchall()

                for sched in due:
                    workflow = db.execute(
                        "SELECT * FROM workflows WHERE id = ?", (sched["workflow_id"],)
                    ).fetchone()
                    if not workflow:
                        db.execute("UPDATE workflow_schedules SET enabled = 0 WHERE id = ?", (sched["id"],))
                        continue

                    # Atomic claim: advance/disable the schedule FIRST, guarded by the
                    # exact next_run_at we read. If another worker/tick already
                    # claimed this run, rowcount is 0 and we skip — so a schedule can
                    # never double-fire, even with several workers.
                    if sched["recurrence"] == "once":
                        claimed = db.execute(
                            "UPDATE workflow_schedules SET enabled = 0, last_run_at = ? "
                            "WHERE id = ? AND enabled = 1 AND next_run_at = ?",
                            (now, sched["id"], sched["next_run_at"]),
                        ).rowcount
                    else:
                        claimed = db.execute(
                            "UPDATE workflow_schedules SET last_run_at = ?, next_run_at = ? "
                            "WHERE id = ? AND enabled = 1 AND next_run_at = ?",
                            (now, _compute_next_daily_run(sched["daily_time"], now), sched["id"], sched["next_run_at"]),
                        ).rowcount
                    if not claimed:
                        continue

                    max_priority_row = db.execute(
                        "SELECT MAX(priority) as mx FROM agent_jobs WHERE user_id = ?", (sched["user_id"],)
                    ).fetchone()
                    next_priority = (max_priority_row["mx"] + 1) if max_priority_row and max_priority_row["mx"] is not None else 0

                    db.execute(
                        "INSERT INTO agent_jobs (user_id, instruction, plan_json, status, priority, result_json, created_at, updated_at) "
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                        (sched["user_id"], f"Scheduled: {workflow['name']}", workflow["steps_json"],
                         "queued", next_priority, None, now, now),
                    )
                    fired_notifications.append((sched["user_id"], workflow["name"]))
        except Exception as e:
            print(f"[scheduler] tick failed: {e}")

        # The browser itself runs on the phone, so a scheduled task can only start
        # when Nex is open. Tell the person it is waiting — a tap on the notification
        # opens the app, which picks the queued job up automatically.
        for uid, wf_name in fired_notifications:
            push_to_user_blocking(uid, "Scheduled task is ready", f"“{wf_name}” is waiting — open Nex to run it")

        # Web Page Change Monitor (#104): piggybacks on this same 30s
        # tick rather than running its own thread. Each watched page is
        # only actually re-fetched once its own 30-minute interval has
        # passed (checked via last_checked_at), so this doesn't hammer
        # watched sites every 30 seconds — it just LOOKS for due ones
        # that often.
        try:
            now2 = int(time.time())
            with get_db() as db:
                due_pages = db.execute(
                    "SELECT * FROM watched_pages WHERE last_checked_at IS NULL OR last_checked_at <= ?",
                    (now2 - 1800,),
                ).fetchall()
            for page in due_pages:
                with get_db() as db:
                    got = db.execute(
                        "UPDATE watched_pages SET last_checked_at = ? WHERE id = ? "
                        "AND (last_checked_at IS ? OR last_checked_at = ?)",
                        (now2, page["id"], page["last_checked_at"], page["last_checked_at"]),
                    ).rowcount
                if got:
                    _check_watched_page(dict(page))
        except Exception as e:
            print(f"[scheduler] watch tick failed: {e}")

        time.sleep(30)


# ============================================================
# Autopilot — user-provided Gemini API key (from Google AI Studio, free
# tier) drives a ReAct-style loop: Android sends a screenshot + page
# summary + goal + recent history, Gemini looks at all of it and
# returns the SINGLE next action, Android executes it and asks again.
# This is deliberately a separate, simpler path from the Haiku-based
# /agent/plan pipeline — Autopilot never pre-plans, it decides one step
# at a time with actual vision of the page.
# ============================================================
def _get_user_ai_key_for_feature(user_id: int, feature: str):
    """
    Shared by planning, visual understanding, and autopilot. feature is
    one of "planning"/"autopilot"/"visual" — returns the (provider,
    api_key) of whichever saved key has THAT feature's toggle on, or
    (None, None) if no key is assigned to it. Mutual exclusivity is
    enforced at write time (see set_ai_key_flags), so there's never more
    than one match to choose between here.
    """
    column = {
        "planning": "use_for_planning",
        "autopilot": "use_for_autopilot",
        "visual": "use_for_visual",
        "forms": "use_for_forms",
    }[feature]
    with get_db() as db:
        row = db.execute(
            f"SELECT provider, api_key FROM ai_keys WHERE user_id = ? AND {column} = 1 LIMIT 1",
            (user_id,),
        ).fetchone()
    if not row:
        return None, None
    return row["provider"], dec_secret(row["api_key"])


@app.post("/account/ai-keys")
def save_ai_key(req: AiKeyRequest, user=Depends(get_current_user)):
    provider = req.provider.strip().lower()
    if provider not in AUTOPILOT_MODELS:
        raise HTTPException(400, f"provider must be one of: {', '.join(AUTOPILOT_MODELS.keys())}")
    key = req.api_key.strip()
    if not key:
        raise HTTPException(400, "API key cannot be empty")

    now = int(time.time())
    with get_db() as db:
        db.execute(
            """
            INSERT INTO ai_keys (user_id, provider, api_key, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(user_id, provider) DO UPDATE SET api_key = excluded.api_key, updated_at = excluded.updated_at
            """,
            (user["id"], provider, enc_secret(key), now, now),
        )
    return {"status": "saved", "provider": provider}


@app.get("/account/ai-keys")
def list_ai_keys(user=Depends(get_current_user)):
    with get_db() as db:
        rows = db.execute(
            "SELECT provider, api_key, use_for_planning, use_for_autopilot, use_for_visual, use_for_forms "
            "FROM ai_keys WHERE user_id = ? ORDER BY provider",
            (user["id"],),
        ).fetchall()

    keys = []
    for r in rows:
        k = dec_secret(r["api_key"])
        masked = ("•" * max(0, len(k) - 4)) + k[-4:]
        keys.append({
            "provider": r["provider"],
            "masked": masked,
            "use_for_planning": bool(r["use_for_planning"]),
            "use_for_autopilot": bool(r["use_for_autopilot"]),
            "use_for_visual": bool(r["use_for_visual"]),
            "use_for_forms": bool(r["use_for_forms"]),
        })
    return {"keys": keys}


@app.delete("/account/ai-keys/{provider}")
def delete_ai_key(provider: str, user=Depends(get_current_user)):
    with get_db() as db:
        db.execute("DELETE FROM ai_keys WHERE user_id = ? AND provider = ?", (user["id"], provider))
    return {"status": "deleted"}


@app.post("/account/ai-keys/{provider}/flags")
def set_ai_key_flags(provider: str, req: AiKeyFlagsRequest, user=Depends(get_current_user)):
    with get_db() as db:
        row = db.execute(
            "SELECT id FROM ai_keys WHERE user_id = ? AND provider = ?", (user["id"], provider)
        ).fetchone()
        if not row:
            raise HTTPException(404, "No key saved for that provider")

        # Mutual exclusivity: switching a feature ON for this provider
        # switches that SAME feature OFF for every other provider this
        # user has — a feature always has at most one active key.
        if req.use_for_planning is True:
            db.execute("UPDATE ai_keys SET use_for_planning = 0 WHERE user_id = ?", (user["id"],))
        if req.use_for_autopilot is True:
            db.execute("UPDATE ai_keys SET use_for_autopilot = 0 WHERE user_id = ?", (user["id"],))
        if req.use_for_visual is True:
            db.execute("UPDATE ai_keys SET use_for_visual = 0 WHERE user_id = ?", (user["id"],))
        if req.use_for_forms is True:
            db.execute("UPDATE ai_keys SET use_for_forms = 0 WHERE user_id = ?", (user["id"],))

        updates, params = [], []
        if req.use_for_planning is not None:
            updates.append("use_for_planning = ?")
            params.append(1 if req.use_for_planning else 0)
        if req.use_for_autopilot is not None:
            updates.append("use_for_autopilot = ?")
            params.append(1 if req.use_for_autopilot else 0)
        if req.use_for_visual is not None:
            updates.append("use_for_visual = ?")
            params.append(1 if req.use_for_visual else 0)
        if req.use_for_forms is not None:
            updates.append("use_for_forms = ?")
            params.append(1 if req.use_for_forms else 0)

        if updates:
            updates.append("updated_at = ?")
            params.append(int(time.time()))
            params.extend([user["id"], provider])
            db.execute(f"UPDATE ai_keys SET {', '.join(updates)} WHERE user_id = ? AND provider = ?", params)

    return {"status": "updated"}


@app.post("/account/custom-apis")
def save_custom_api(req: CustomApiRequest, user=Depends(get_current_user)):
    name = req.name.strip()
    base_url = req.base_url.strip().rstrip("/")
    key = req.api_key.strip()
    if not name:
        raise HTTPException(400, "Name cannot be empty")
    if not base_url.startswith("http://") and not base_url.startswith("https://"):
        raise HTTPException(400, "Base URL must start with http:// or https://")
    assert_public_http_url(base_url)
    if not key:
        raise HTTPException(400, "API key cannot be empty")
    if req.auth_style not in ("header", "query"):
        raise HTTPException(400, "auth_style must be 'header' or 'query'")

    now = int(time.time())
    with get_db() as db:
        existing = db.execute(
            "SELECT id FROM custom_apis WHERE user_id = ? AND name = ?", (user["id"], name)
        ).fetchone()
        if existing:
            raise HTTPException(409, "You already have a saved API with that name — edit it instead")
        cur = db.execute(
            """
            INSERT INTO custom_apis
                (user_id, name, base_url, api_key, auth_style, header_name, header_prefix, query_param_name, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (user["id"], name, base_url, enc_secret(key), req.auth_style,
             req.header_name.strip() or "Authorization",
             req.header_prefix,
             req.query_param_name.strip() or "api_key",
             now, now),
        )
    return {"status": "saved", "id": cur.lastrowid, "name": name}


@app.get("/account/custom-apis")
def list_custom_apis(user=Depends(get_current_user)):
    with get_db() as db:
        rows = db.execute(
            "SELECT id, name, base_url, api_key, auth_style, header_name, header_prefix, query_param_name "
            "FROM custom_apis WHERE user_id = ? ORDER BY name COLLATE NOCASE",
            (user["id"],),
        ).fetchall()

    apis = []
    for r in rows:
        k = dec_secret(r["api_key"])
        masked = ("•" * max(0, len(k) - 4)) + k[-4:]
        apis.append({
            "id": r["id"],
            "name": r["name"],
            "base_url": r["base_url"],
            "masked": masked,
            "auth_style": r["auth_style"],
            "header_name": r["header_name"],
            "header_prefix": r["header_prefix"],
            "query_param_name": r["query_param_name"],
        })
    return {"apis": apis}


@app.put("/account/custom-apis/{api_id}")
def update_custom_api(api_id: int, req: CustomApiUpdateRequest, user=Depends(get_current_user)):
    with get_db() as db:
        row = db.execute(
            "SELECT id FROM custom_apis WHERE id = ? AND user_id = ?", (api_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "No saved API with that id")

        updates, params = [], []
        if req.name is not None:
            updates.append("name = ?"); params.append(req.name.strip())
        if req.base_url is not None:
            assert_public_http_url(req.base_url)
            updates.append("base_url = ?"); params.append(req.base_url.strip().rstrip("/"))
        if req.api_key is not None and req.api_key.strip():
            updates.append("api_key = ?"); params.append(enc_secret(req.api_key.strip()))
        if req.auth_style is not None:
            if req.auth_style not in ("header", "query"):
                raise HTTPException(400, "auth_style must be 'header' or 'query'")
            updates.append("auth_style = ?"); params.append(req.auth_style)
        if req.header_name is not None:
            updates.append("header_name = ?"); params.append(req.header_name.strip() or "Authorization")
        if req.header_prefix is not None:
            updates.append("header_prefix = ?"); params.append(req.header_prefix)
        if req.query_param_name is not None:
            updates.append("query_param_name = ?"); params.append(req.query_param_name.strip() or "api_key")

        if updates:
            updates.append("updated_at = ?")
            params.append(int(time.time()))
            params.extend([api_id, user["id"]])
            try:
                db.execute(f"UPDATE custom_apis SET {', '.join(updates)} WHERE id = ? AND user_id = ?", params)
            except sqlite3.IntegrityError:
                raise HTTPException(409, "You already have a saved API with that name")
    return {"status": "updated"}


@app.delete("/account/custom-apis/{api_id}")
def delete_custom_api(api_id: int, user=Depends(get_current_user)):
    with get_db() as db:
        db.execute("DELETE FROM custom_apis WHERE id = ? AND user_id = ?", (api_id, user["id"]))
    return {"status": "deleted"}


@app.post("/account/custom-apis/{api_id}/call")
async def call_custom_api(api_id: int, req: CustomApiCallRequest, user=Depends(get_current_user)):
    """
    This is the actual "browser uses the saved API" step: the app sends
    only path/method/query/body (never the key — the key never has to
    leave the server), the backend looks up that saved API's base_url +
    key + auth style, attaches the key the right way, forwards the
    request, and hands the response straight back to the app.
    """
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM custom_apis WHERE id = ? AND user_id = ?", (api_id, user["id"])
        ).fetchone()
    if not row:
        raise HTTPException(404, "No saved API with that id")

    method = (req.method or "GET").upper()
    if method not in ("GET", "POST", "PUT", "PATCH", "DELETE"):
        raise HTTPException(400, "Unsupported method")

    assert_public_http_url(row["base_url"])  # re-check at call time (DNS can change)
    url = row["base_url"] + ("/" + req.path.lstrip("/") if req.path else "")
    headers = dict(req.headers or {})
    params = dict(req.query or {})

    if row["auth_style"] == "query":
        params[row["query_param_name"]] = dec_secret(row["api_key"])
    else:
        headers[row["header_name"]] = f"{row['header_prefix']}{dec_secret(row['api_key'])}"

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.request(
                method, url, headers=headers, params=params,
                json=req.json_body if req.json_body is not None else None,
            )
    except httpx.RequestError as e:
        raise HTTPException(502, f"Couldn't reach {row['name']}: {e}")

    try:
        response_body = resp.json()
    except ValueError:
        response_body = resp.text

    return {
        "status_code": resp.status_code,
        "ok": resp.status_code < 400,
        "body": response_body,
    }


async def _call_ai_model(provider: str, api_key: str, prompt: str, image_b64: Optional[str] = None) -> str:
    """
    Sends one prompt (and optionally one screenshot) to whichever
    provider the key belongs to, using THAT key, and returns the raw
    text response. Isolates all three providers' very different
    request/response shapes behind one signature. image_b64=None means
    a text-only call (used for planning); a value means vision (used
    for Autopilot and Visual Page Understanding) — same models handle
    both fine, providers don't need a separate text-only endpoint.
    """
    model = AUTOPILOT_MODELS[provider]

    if provider == "gemini":
        parts = [{"text": prompt}]
        if image_b64:
            parts.append({"inline_data": {"mime_type": "image/jpeg", "data": image_b64}})
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                headers={"x-goog-api-key": api_key, "content-type": "application/json"},
                json={"contents": [{"parts": parts}]},
            )
        if response.status_code != 200:
            raise HTTPException(502, f"Gemini error ({response.status_code}): {response.text[:300]}")
        data = response.json()
        try:
            return data["candidates"][0]["content"]["parts"][0]["text"].strip()
        except Exception:
            raise HTTPException(502, "Gemini returned an unexpected response shape")

    elif provider == "openai":
        content = [{"type": "text", "text": prompt}]
        if image_b64:
            content.append({"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image_b64}"}})
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {api_key}", "content-type": "application/json"},
                json={"model": model, "max_tokens": 500, "messages": [{"role": "user", "content": content}]},
            )
        if response.status_code != 200:
            raise HTTPException(502, f"OpenAI error ({response.status_code}): {response.text[:300]}")
        data = response.json()
        try:
            return data["choices"][0]["message"]["content"].strip()
        except Exception:
            raise HTTPException(502, "OpenAI returned an unexpected response shape")

    else:  # anthropic
        content = [{"type": "text", "text": prompt}]
        if image_b64:
            content.insert(0, {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": image_b64}})
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={"model": model, "max_tokens": 500, "messages": [{"role": "user", "content": content}]},
            )
        if response.status_code != 200:
            raise HTTPException(502, f"Anthropic error ({response.status_code}): {response.text[:300]}")
        data = response.json()
        try:
            return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text").strip()
        except Exception:
            raise HTTPException(502, "Anthropic returned an unexpected response shape")


@app.post("/agent/visual-understand")
async def agent_visual_understand(req: VisualUnderstandRequest, user=Depends(get_current_user)):
    """
    Visual Page Understanding (#53) — a step INSIDE the normal plan-based
    job engine (agent_jobs). Prefers the user's OWN AI key (set once in
    Settings → AI, shared with Autopilot and Task Planning) if they've
    set one; otherwise falls back to this server's own ANTHROPIC_API_KEY
    so it still works out of the box for anyone who hasn't set a key.
    """
    if not req.screenshot_base64:
        raise HTTPException(400, "screenshot_base64 is required")

    provider, api_key = _get_user_ai_key_for_feature(user["id"], "visual")
    if not provider or not api_key:
        if not ANTHROPIC_API_KEY:
            raise HTTPException(503, "Visual understanding needs an AI key — set one in Settings → AI, or ask the server admin to configure ANTHROPIC_API_KEY")
        provider, api_key = "anthropic", ANTHROPIC_API_KEY

    question = (req.question or "Describe what's visible on this page.").strip()
    prompt = f"""Look at this screenshot of a web page and answer, in 2-4 concise
sentences, plain text, no markdown: {question}"""

    answer = await _call_ai_model(provider, api_key, prompt, req.screenshot_base64)
    return {"description": answer.strip()}


@app.post("/agent/fill-form")
async def agent_fill_form(req: FormFillRequest, user=Depends(get_current_user)):
    """
    Form Filling (#55), AI-assisted rather than plain label-matching:
    the caller sends the list of field labels/placeholders it found on
    the page (via inspect_dom), an AI decides a sensible VALUE for each
    relevant one given "instructions", and Android fills + verifies them
    all in one JS pass (see FORM_FILL_AND_VERIFY_JS on the Android side —
    that's where #56 Page Element Verification actually happens, by
    reading each field's value right back after setting it).

    Prefers the user's own "Form Filling" key (Settings → AI) if set,
    otherwise falls back to this server's own ANTHROPIC_API_KEY.
    """
    if not req.fields:
        raise HTTPException(400, "fields must be a non-empty list")

    provider, api_key = _get_user_ai_key_for_feature(user["id"], "forms")
    if not provider or not api_key:
        if not ANTHROPIC_API_KEY:
            raise HTTPException(503, "Form filling needs an AI key — set one in Settings → AI, or ask the server admin to configure ANTHROPIC_API_KEY")
        provider, api_key = "anthropic", ANTHROPIC_API_KEY

    fields_text = "\n".join(f"- {f}" for f in req.fields[:30])
    instructions = req.instructions.strip() or "Fill this form out with reasonable, realistic values."

    prompt = f"""A web page (URL: {req.current_url}) has these form fields, identified by
their placeholder/name/label text:
{fields_text}

Goal: {instructions}

Decide a value for each field that's actually relevant to the goal — skip fields that
aren't relevant (don't guess random values for them). Respond with ONLY a raw JSON
array, no markdown, no explanation, shaped exactly like:
[{{"label":"<the exact field text from the list above>","value":"..."}}]

NEVER put a real password, credit card number, SSN/national ID, or other sensitive
personal data in a "value" — use an obviously-fake placeholder instead (e.g.
"TestPass123!" for a password field) or omit that field entirely.
"""

    text = await _call_ai_model(provider, api_key, prompt)

    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
        text = text.strip()

    import json
    try:
        mapping = json.loads(text)
        if not isinstance(mapping, list):
            raise ValueError("not a list")
    except Exception:
        mapping = []

    return {"fields": mapping}


@app.post("/agent/screenshot-text")
async def agent_screenshot_text(req: ScreenshotTextRequest, user=Depends(get_current_user)):
    """
    Screenshot Understanding (#54) — OCR-style: reads back every piece
    of text actually visible in the screenshot, including text baked
    into images/banners/logos that extract_text/inspect_dom can't see
    (those only see real HTML text nodes). Shares the "visual" AI-key
    toggle with Visual Page Understanding (#53) and Screenshot
    Verification (#70) — all three are vision reasoning over a
    screenshot, just asked to do different things with it.
    """
    if not req.screenshot_base64:
        raise HTTPException(400, "screenshot_base64 is required")

    provider, api_key = _get_user_ai_key_for_feature(user["id"], "visual")
    if not provider or not api_key:
        if not ANTHROPIC_API_KEY:
            raise HTTPException(503, "Screenshot understanding needs an AI key — set one in Settings → AI, or ask the server admin to configure ANTHROPIC_API_KEY")
        provider, api_key = "anthropic", ANTHROPIC_API_KEY

    prompt = """Look at this screenshot and transcribe EVERY piece of readable text you
can see in it — including text that's part of an image, banner, logo, photo, or
graphic, not just normal page text. List each distinct piece of text on its own line,
in plain text, no markdown, no commentary. If there's no readable text at all, respond
with exactly: (no text found)"""

    text = await _call_ai_model(provider, api_key, prompt, req.screenshot_base64)
    return {"text": text.strip()}


@app.post("/files/analyze-image")
async def files_analyze_image(req: ImageUnderstandRequest, user=Depends(get_current_user)):
    """
    AI Screenshot Understanding for saved images (#115) — distinct from
    #54, which reads text from LIVE browser screenshots mid-automation:
    this looks at an image the user has downloaded/saved, describing
    what it shows AND reading back any text in it. Shares the "visual"
    AI-key toggle with #53/#54/#70.
    """
    if not req.image_base64:
        raise HTTPException(400, "image_base64 is required")

    provider, api_key = _get_user_ai_key_for_feature(user["id"], "visual")
    if not provider or not api_key:
        if not ANTHROPIC_API_KEY:
            raise HTTPException(503, "Image understanding needs an AI key — set one in Settings → AI, or ask the server admin to configure ANTHROPIC_API_KEY")
        provider, api_key = "anthropic", ANTHROPIC_API_KEY

    prompt = (
        "Describe this saved image in 2-4 sentences — what it shows, and if there's any "
        "readable text in it (a screenshot, a photo of a sign or document, a meme caption, "
        "etc.), include that text too. Be concise and factual — don't guess beyond what's "
        "actually visible. Output plain text, no markdown."
    )
    result = await _call_ai_model(provider, api_key, prompt, req.image_base64)
    return {"description": result.strip()}


@app.post("/agent/verify-screenshot")
async def agent_verify_screenshot(req: VerifyScreenshotRequest, user=Depends(get_current_user)):
    """
    Screenshot Verification (#70) — confirms an action's VISUAL effect
    actually happened, for things with no DOM signal to check instead
    (a toast/notification appearing, a modal closing, a visual state
    change). Page Element Verification (#56, inside fill_form) already
    covers the cheaper DOM-readback case — this is for when that isn't
    enough. Shares the "visual" AI-key toggle with #53/#54.
    """
    if not req.screenshot_base64:
        raise HTTPException(400, "screenshot_base64 is required")
    if not req.expectation.strip():
        raise HTTPException(400, "expectation is required")

    provider, api_key = _get_user_ai_key_for_feature(user["id"], "visual")
    if not provider or not api_key:
        if not ANTHROPIC_API_KEY:
            raise HTTPException(503, "Screenshot verification needs an AI key — set one in Settings → AI, or ask the server admin to configure ANTHROPIC_API_KEY")
        provider, api_key = "anthropic", ANTHROPIC_API_KEY

    prompt = f"""Look at this screenshot. Is the following currently, visibly true?
"{req.expectation.strip()}"

Respond with exactly one line: either "PASS: <one short sentence why>" or
"FAIL: <one short sentence why not>". Nothing else."""

    result = (await _call_ai_model(provider, api_key, prompt, req.screenshot_base64)).strip()
    passed = result.upper().startswith("PASS")
    return {"passed": passed, "result": result}


@app.post("/agent/verify")
async def agent_verify(req: VerifyResultRequest, user=Depends(get_current_user)):
    """
    Agent-to-Agent Verification (#73) — opt-in (agent_jobs.verify_result),
    checked by Android right before reporting a job as fully done. Unlike
    Screenshot Verification (#70), which checks ONE action's immediate
    visual effect mid-task, this is a SECOND, independent AI call — a
    reviewer persona that never did the work itself — sanity-checking the
    WORKER agent's own claimed final result against a real screenshot of
    where the task actually ended up, since a confidently-worded "done"
    summary isn't proof anything was actually accomplished. Shares the
    "visual" AI-key toggle with #53/#54/#57/#70.
    """
    if not req.screenshot_base64:
        raise HTTPException(400, "screenshot_base64 is required")
    if not req.final_result.strip():
        raise HTTPException(400, "final_result is required")

    provider, api_key = _get_user_ai_key_for_feature(user["id"], "visual")
    if not provider or not api_key:
        if not ANTHROPIC_API_KEY:
            raise HTTPException(503, "Verification needs an AI key — set one in Settings → AI, or ask the server admin to configure ANTHROPIC_API_KEY")
        provider, api_key = "anthropic", ANTHROPIC_API_KEY

    prompt = f"""You are an independent reviewer checking another AI agent's work —
you did not do this task yourself, so don't assume the claim below is correct just
because it's stated confidently.

Original task: "{req.instruction.strip()}"

The worker agent claims: "{req.final_result.strip()}"

Look at the attached screenshot of where the task actually ended up. Does it genuinely
support that claim?

Respond with exactly one line: either "PASS: <one short sentence why>" or
"FAIL: <one short sentence why the screenshot doesn't support the claim>". Nothing else."""

    result = (await _call_ai_model(provider, api_key, prompt, req.screenshot_base64)).strip()
    verified = result.upper().startswith("PASS")
    return {"verified": verified, "reason": result}


@app.post("/agent/jobs/{job_id}/accept-verification")
def agent_accept_verification(job_id: int, user=Depends(get_current_user)):
    """
    User override for a job that #73's verification flagged — accepts
    the worker agent's original result as good enough anyway, marking
    the job truly "done" without re-running anything.
    """
    with get_db() as db:
        row = db.execute(
            "SELECT id, status FROM agent_jobs WHERE id = ? AND user_id = ?", (job_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "Job not found")
        if row["status"] != "needs_verification":
            raise HTTPException(400, "Job isn't awaiting verification review")
        db.execute(
            "UPDATE agent_jobs SET status = 'done', updated_at = ? WHERE id = ?",
            (int(time.time()), job_id),
        )
    return {"status": "done"}


@app.post("/agent/jobs/{job_id}/confirm-run")
def agent_confirm_run(job_id: int, user=Depends(get_current_user)):
    """
    Dry Run Mode (#77): the user has reviewed a dry-run job's planned
    steps and wants it to actually execute now. Just clears the dry_run
    flag — the job was already fully planned and sitting in the normal
    'queued' state the whole time, so the existing queue picks it up on
    its own right after this (no separate re-planning needed).
    """
    with get_db() as db:
        row = db.execute(
            "SELECT id, dry_run FROM agent_jobs WHERE id = ? AND user_id = ?", (job_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "Job not found")
        if not row["dry_run"]:
            raise HTTPException(400, "Job isn't a dry run")
        db.execute(
            "UPDATE agent_jobs SET dry_run = 0, updated_at = ? WHERE id = ?",
            (int(time.time()), job_id),
        )
    return {"status": "confirmed"}


@app.post("/agent/jobs/{job_id}/retry")
def agent_retry_job(job_id: int, user=Depends(get_current_user)):
    """
    User-triggered full restart from step 0 — the manual counterpart to
    Automatic Retry (#58)'s own-initiative version. Used from a job
    flagged by Verification (#73), but generic enough for any job the
    user wants to re-run from scratch.
    """
    import json
    with get_db() as db:
        row = db.execute(
            "SELECT id, status, result_json FROM agent_jobs WHERE id = ? AND user_id = ?", (job_id, user["id"])
        ).fetchone()
        if not row:
            raise HTTPException(404, "Job not found")
        result = {}
        if row["result_json"]:
            try:
                result = json.loads(row["result_json"])
            except Exception:
                result = {}
        result.pop("final", None)
        result.pop("verification_reason", None)
        db.execute(
            "UPDATE agent_jobs SET status = 'queued', current_step = 0, current_url = '', "
            "result_json = ?, last_error = NULL, last_successful_step = -1, updated_at = ? WHERE id = ?",
            (json.dumps(result), int(time.time()), job_id),
        )
    return {"status": "queued"}

@app.post("/agent/self-heal")
async def agent_self_heal(req: SelfHealRequest, user=Depends(get_current_user)):
    """
    Self-Healing Agent (#57) — the last resort after Adaptive Retry (#59)
    has already retried the exact SAME action/target a couple of times
    and it's still not found. Rather than just give up, this asks the AI
    to look at what's actually on the page right now (the DOM summary
    from inspect_dom, plus a screenshot when one was captured) and
    suggest a different, semantically similar element to try instead —
    e.g. a bare download icon when the plan expected a "Download" button,
    because the page's wording or layout changed.

    Distinct from Adaptive Retry: that retries the exact same
    action/target hoping a transient issue clears on its own. This
    changes WHAT is targeted — and the Android caller only calls it once
    per step (self-heal isn't itself retried), since guessing repeatedly
    risks eventually clicking the wrong thing.

    Shares the "visual" AI-key toggle with #53 Visual Page Understanding,
    #54 Screenshot Understanding and #70 Screenshot Verification, since
    it reasons over a screenshot the same way those do.
    """
    import json
    try:
        parsed_dom = json.loads(req.dom_json) if req.dom_json else {}
    except Exception:
        parsed_dom = {}
    buttons = parsed_dom.get("buttons") or []
    fields = parsed_dom.get("fields") or []

    provider, api_key = _get_user_ai_key_for_feature(user["id"], "visual")
    if not provider or not api_key:
        if not ANTHROPIC_API_KEY:
            raise HTTPException(503, "Self-healing needs an AI key — set one in Settings → AI, or ask the server admin to configure ANTHROPIC_API_KEY")
        provider, api_key = "anthropic", ANTHROPIC_API_KEY

    buttons_text = ", ".join(str(b) for b in buttons[:25]) if buttons else "(none found)"
    fields_text = ", ".join(str(f) for f in fields[:25]) if fields else "(none found)"
    goal_line = f'\nOverall task goal: "{req.goal.strip()}"' if req.goal.strip() else ""

    prompt = f"""An automation agent tried to {req.action} an element described as:
"{req.target}"
on the current web page, but nothing matched that text/label exactly — the page
may have changed, or the wording may be slightly different than expected.{goal_line}

Currently clickable elements on the page: {buttons_text}
Currently fillable fields on the page: {fields_text}

Look at the screenshot (if provided) and these lists, and decide if one of them
is clearly the SAME thing the agent was trying to reach (e.g. an icon instead of
a labeled button, or slightly different wording for the same action).

Respond with ONLY raw JSON, no markdown, no explanation, shaped exactly like:
{{"found":true,"replacement":"<exact text from one of the lists above>","needs_approval":false,"reason":"<one short sentence>"}}

Set "found":false and "replacement":"" if nothing on the page plausibly matches.

Set "needs_approval":true whenever performing this specific action would be
sensitive, irreversible, or have a real-world consequence — payments, purchases,
placing/confirming an order, deleting or cancelling something, sending a message,
changing security/account settings, or similar — even if "found" is true. A human
should confirm those before they happen.
"""

    text = (await _call_ai_model(provider, api_key, prompt, req.screenshot_base64)).strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
        text = text.strip()

    try:
        parsed = json.loads(text)
        if not isinstance(parsed, dict):
            raise ValueError("not an object")
    except Exception:
        parsed = {}

    return {
        "found": bool(parsed.get("found", False)),
        "replacement": str(parsed.get("replacement", "") or ""),
        "needs_approval": bool(parsed.get("needs_approval", False)),
        "reason": str(parsed.get("reason", "") or ""),
    }


@app.post("/agent/autopilot/next")
async def autopilot_next(req: AutopilotNextRequest, user=Depends(get_current_user)):
    provider, api_key = _get_user_ai_key_for_feature(user["id"], "autopilot")
    if not provider or not api_key:
        raise HTTPException(400, "No AI key set — add one in Settings → AI first")

    if not req.goal.strip():
        raise HTTPException(400, "goal cannot be empty")
    if not req.screenshot_base64:
        raise HTTPException(400, "screenshot_base64 is required")

    history_lines = []
    for i, h in enumerate(req.history[-10:]):
        history_lines.append(f"{i + 1}. {h.get('action')} -> {h.get('result')}")
    history_text = "\n".join(history_lines) if history_lines else "(none yet)"

    prompt = f"""You are controlling a mobile web browser, one step at a time, to accomplish this goal:
"{req.goal}"

Current page URL: {req.current_url}
Elements detected on the page (may be incomplete): {req.dom_summary[:2000]}

Steps already taken:
{history_text}

Look at the attached screenshot of what the browser currently shows and decide the
SINGLE next action. Respond with ONLY one raw JSON object — no markdown fences, no
explanation — using exactly one of these shapes:
{{"action":"click","text":"..."}}
{{"action":"type","text":"...","label":"..."}}
{{"action":"scroll","direction":"down"}}
{{"action":"navigate","url":"..."}}
{{"action":"wait","ms":1000}}
{{"action":"done","summary":"..."}}

Target "click"/"type" elements by their likely VISIBLE text/label — you can see the
screenshot, use what's actually visible in it. If the goal already looks accomplished
in the screenshot, or you're stuck after repeated attempts at the same thing, respond
with "done". NEVER use "type" for passwords or other sensitive personal data — use
"done" instead and explain why in the summary.
"""

    text = await _call_ai_model(provider, api_key, prompt, req.screenshot_base64)

    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
        text = text.strip()

    import json
    try:
        next_action = json.loads(text)
        if not isinstance(next_action, dict) or "action" not in next_action:
            raise ValueError("not a valid action object")
    except Exception:
        next_action = {"action": "done", "summary": "Couldn't understand the AI's response — stopping."}

    return {"next_action": next_action}


threading.Thread(target=_scheduler_loop, daemon=True).start()
