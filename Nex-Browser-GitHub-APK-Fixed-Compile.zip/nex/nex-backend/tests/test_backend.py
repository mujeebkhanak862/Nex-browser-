import hashlib, json, sqlite3, time
import pytest


# ---------------- auth ----------------
def test_short_password_rejected(client):
    assert client.post("/auth/register", json={"email": "x@y.co", "password": "short"}).status_code == 400


def test_email_case_insensitive_and_hash_format(client, main, user):
    headers, email = user
    r = client.post("/auth/register", json={"email": email.upper(), "password": "password123"})
    assert r.status_code == 409
    db = sqlite3.connect(main.DB_PATH)
    h = db.execute("select password_hash from users where email = ?", (email,)).fetchone()[0]
    assert h.startswith("pbkdf2$600000$")


def test_legacy_hash_still_logs_in_and_is_upgraded(client, main, user):
    headers, email = user
    db = sqlite3.connect(main.DB_PATH)
    salt = db.execute("select salt from users where email = ?", (email,)).fetchone()[0]
    legacy = hashlib.pbkdf2_hmac("sha256", b"password123", salt.encode(), 100_000).hex()
    db.execute("update users set password_hash = ? where email = ?", (legacy, email)); db.commit()
    assert client.post("/auth/login", json={"email": email.upper(), "password": "password123"}).status_code == 200
    h = db.execute("select password_hash from users where email = ?", (email,)).fetchone()[0]
    assert h.startswith("pbkdf2$600000$")


def test_login_lockout(client, main, user):
    _, email = user
    main._rate_hits.clear()
    codes = [client.post("/auth/login", json={"email": email, "password": f"bad{i}"}).status_code for i in range(10)]
    assert 401 in codes and 429 in codes
    main._rate_hits.clear()


def test_google_signin_requires_client_id(client):
    r = client.post("/auth/google", json={"id_token": "x"})
    assert r.status_code in (401, 503)


# ---------------- AI endpoints need login ----------------
@pytest.mark.parametrize("ep", ["/summarize", "/ai-command", "/reader/clean", "/web/compare", "/web/reliability",
                                "/web/contradictions", "/web/factcheck", "/history/semantic-search",
                                "/history/day-summary", "/files/analyze", "/web/extract-structured",
                                "/ai/tab-search", "/ai/tab-groups"])
def test_ai_endpoints_require_auth(client, ep):
    assert client.post(ep, json={}).status_code == 401


# ---------------- SSRF ----------------
@pytest.mark.parametrize("url", ["http://127.0.0.1:8000/x", "http://169.254.169.254/latest", "http://10.0.0.5/",
                                 "file:///etc/passwd", "ftp://example.com/"])
def test_watch_blocks_internal_urls(client, user, url):
    assert client.post("/watch/add", json={"url": url}, headers=user[0]).status_code == 400


def test_custom_api_blocks_private_base_url(client, user):
    r = client.post("/account/custom-apis", json={"name": "x", "base_url": "http://192.168.1.1", "api_key": "k"},
                    headers=user[0])
    assert r.status_code == 400


# ---------------- secrets at rest ----------------
def test_ai_key_encrypted_in_db_but_masked_readable(client, main, user):
    headers, _ = user
    assert client.post("/account/ai-keys", json={"provider": "gemini", "api_key": "AIzaSECRETKEY1234"},
                       headers=headers).status_code == 200
    raw = sqlite3.connect(main.DB_PATH).execute("select api_key from ai_keys").fetchall()
    assert all(r[0].startswith("enc:v1:") and "SECRET" not in r[0] for r in raw)
    listed = client.get("/account/ai-keys", headers=headers).json()["keys"][0]
    assert listed["masked"].endswith("1234")


def test_cors_default_is_closed(main):
    assert main.ALLOWED_ORIGINS == []


# ---------------- push (FCM v1) ----------------
def test_fcm_v1_flow(client, main, user, monkeypatch):
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.hazmat.primitives import serialization
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                            serialization.NoEncryption()).decode()
    monkeypatch.setattr(main, "FCM_SERVICE_ACCOUNT_JSON", json.dumps(
        {"client_email": "x@p.iam.gserviceaccount.com", "private_key": pem, "project_id": "proj"}))
    main._fcm_cache.update(token=None, exp=0)
    calls = []

    class R:
        def __init__(s, code, js): s.status_code, s._j, s.text = code, js, ""
        def json(s): return s._j

    class Fake:
        def __init__(s, *a, **k): pass
        async def __aenter__(s): return s
        async def __aexit__(s, *a): pass
        async def post(s, url, **kw):
            calls.append((url, kw))
            return R(200, {"access_token": "AT", "expires_in": 3600}) if "oauth2" in url else R(200, {})

    monkeypatch.setattr(main.httpx, "AsyncClient", Fake)
    headers, _ = user
    client.post("/notifications/register-token", json={"fcm_token": "TKN"}, headers=headers)
    r = client.post("/notifications/send", json={"title": "t", "body": "b"}, headers=headers)
    assert r.status_code == 200 and r.json()["delivered_to"] == 1
    assert calls[-1][0] == "https://fcm.googleapis.com/v1/projects/proj/messages:send"
    assert calls[-1][1]["headers"]["Authorization"] == "Bearer AT"


# ---------------- scheduler: never double-fires ----------------
def test_scheduler_claims_are_atomic(client, main, user):
    headers, _ = user
    wf = client.post("/workflows", json={"name": "w", "steps": [{"action": "wait", "ms": 1}]}, headers=headers).json()["workflow_id"]
    db = sqlite3.connect(main.DB_PATH)
    uid = db.execute("select user_id from workflows where id = ?", (wf,)).fetchone()[0]
    now = int(time.time())
    db.execute("INSERT INTO workflow_schedules (workflow_id,user_id,recurrence,daily_time,next_run_at,enabled,created_at) "
               "VALUES (?,?,?,?,?,1,?)", (wf, uid, "once", None, now - 10, now)); db.commit()
    before = db.execute("select count(*) from agent_jobs").fetchone()[0]

    class Stop(Exception): pass
    real_sleep = main.time.sleep
    main.time.sleep = lambda _: (_ for _ in ()).throw(Stop())
    try:
        for _ in range(3):  # three "workers" tick over the same due row
            try: main._scheduler_loop()
            except Stop: pass
    finally:
        main.time.sleep = real_sleep
    after = db.execute("select count(*) from agent_jobs").fetchone()[0]
    assert after - before == 1


# ---------------- pause / resume / progress ----------------
def _make_job(client, main, headers, steps=4):
    import json as _j
    db = sqlite3.connect(main.DB_PATH)
    uid = db.execute("select id from users order by id desc limit 1").fetchone()[0]
    now = int(time.time())
    plan = _j.dumps([{"action": "wait", "ms": 1}] * steps)
    cur = db.execute("INSERT INTO agent_jobs (user_id,instruction,plan_json,status,priority,current_step,created_at,updated_at) "
                     "VALUES (?,?,?,?,?,?,?,?)", (uid, "t", plan, "running", 1, 0, now, now))
    db.commit()
    return cur.lastrowid


def test_pause_resume_and_progress(client, main, user):
    headers, _ = user
    jid = _make_job(client, main, headers, steps=4)
    r = client.post("/agent/report", json={"job_id": jid, "step_index": 0, "step_result": "ok"}, headers=headers)
    assert r.status_code == 200
    assert client.post(f"/agent/jobs/{jid}/pause", headers=headers).json()["status"] == "paused"
    # in-flight step reports back while paused: progress advances, status stays paused
    client.post("/agent/report", json={"job_id": jid, "step_index": 1, "step_result": "ok"}, headers=headers)
    job = [j for j in client.get("/agent/jobs", headers=headers).json()["jobs"] if j["job_id"] == jid][0]
    assert job["status"] == "paused" and job["current_step"] == 2 and job["progress_pct"] == 50
    assert client.post(f"/agent/jobs/{jid}/pause", headers=headers).status_code == 409
    assert client.post(f"/agent/jobs/{jid}/resume", headers=headers).json()["status"] == "running"
    assert client.post(f"/agent/jobs/{jid}/resume", headers=headers).status_code == 409


def test_eta_uses_measured_step_time(client, main, user):
    headers, _ = user
    jid = _make_job(client, main, headers, steps=5)
    db = sqlite3.connect(main.DB_PATH)
    db.execute("UPDATE agent_jobs SET current_step=2, last_step_at=?, steps_time_total=20, steps_timed=2 WHERE id=?",
               (int(time.time()) - 10, jid)); db.commit()
    client.post("/agent/report", json={"job_id": jid, "step_index": 2, "step_result": "ok"}, headers=headers)
    job = [j for j in client.get("/agent/jobs", headers=headers).json()["jobs"] if j["job_id"] == jid][0]
    # 3 timed steps, ~30s total => ~10s avg, 2 steps left => ETA ~20s
    assert job["steps_done"] == 3 and job["steps_total"] == 5
    assert 15 <= job["eta_seconds"] <= 25


def test_cannot_pause_someone_elses_job(client, main, user):
    headers, _ = user
    jid = _make_job(client, main, headers)
    import secrets
    other = client.post("/auth/register", json={"email": f"o{secrets.token_hex(3)}@example.com", "password": "password123"}).json()
    r = client.post(f"/agent/jobs/{jid}/pause", headers={"Authorization": "Bearer " + other["access_token"]})
    assert r.status_code == 404


# ---------------- file intelligence: images / PDFs ----------------
def _fake_anthropic(monkeypatch, main, sent):
    class R:
        status_code = 200
        text = ""
        def json(s): return {"content": [{"type": "text", "text": "A receipt."}]}

    class Fake:
        def __init__(s, *a, **k): pass
        async def __aenter__(s): return s
        async def __aexit__(s, *a): pass
        async def post(s, url, **kw):
            sent.append(kw["json"]); return R()

    monkeypatch.setattr(main.httpx, "AsyncClient", Fake)
    monkeypatch.setattr(main, "ANTHROPIC_API_KEY", "test-key")


def test_file_analyze_image_and_pdf_blocks(client, main, user, monkeypatch):
    import base64
    sent = []
    _fake_anthropic(monkeypatch, main, sent)
    data = base64.b64encode(b"\x89PNG fake").decode()
    r = client.post("/files/analyze", json={"filename": "r.png", "content_base64": data, "mime_type": "image/png"}, headers=user[0])
    assert r.status_code == 200 and r.json()["summary"] == "A receipt."
    assert sent[-1]["messages"][0]["content"][0]["type"] == "image"
    r = client.post("/files/analyze", json={"filename": "a.pdf", "content_base64": data, "mime_type": "application/pdf"}, headers=user[0])
    assert r.status_code == 200 and sent[-1]["messages"][0]["content"][0]["type"] == "document"


def test_file_analyze_rejects_bad_input(client, main, user, monkeypatch):
    import base64
    _fake_anthropic(monkeypatch, main, [])
    good = base64.b64encode(b"x").decode()
    h = user[0]
    assert client.post("/files/analyze", json={"filename": "a.exe", "content_base64": good, "mime_type": "application/x-msdownload"}, headers=h).status_code == 400
    assert client.post("/files/analyze", json={"filename": "a.png", "content_base64": "!!notb64!!", "mime_type": "image/png"}, headers=h).status_code == 400
    assert client.post("/files/analyze", json={"filename": "a.png", "content_base64": "A" * 7_000_001, "mime_type": "image/png"}, headers=h).status_code == 413
    assert client.post("/files/analyze", json={"filename": "t.txt", "content": "  "}, headers=h).status_code == 400


def test_file_analyze_text_still_works(client, main, user, monkeypatch):
    sent = []
    _fake_anthropic(monkeypatch, main, sent)
    r = client.post("/files/analyze", json={"filename": "n.txt", "content": "hello world"}, headers=user[0])
    assert r.status_code == 200 and isinstance(sent[-1]["messages"][0]["content"], str)


# ---------------- scheduled task -> push "ready" ----------------
def test_scheduler_sends_push_when_job_is_queued(client, main, user, monkeypatch):
    headers, _ = user
    wf = client.post("/workflows", json={"name": "Daily report", "steps": [{"action": "wait", "ms": 1}]}, headers=headers).json()["workflow_id"]
    db = sqlite3.connect(main.DB_PATH)
    uid = db.execute("select user_id from workflows where id = ?", (wf,)).fetchone()[0]
    now = int(time.time())
    db.execute("INSERT INTO workflow_schedules (workflow_id,user_id,recurrence,daily_time,next_run_at,enabled,created_at) "
               "VALUES (?,?,?,?,?,1,?)", (wf, uid, "once", None, now - 5, now)); db.commit()
    pushed = []
    monkeypatch.setattr(main, "push_to_user_blocking", lambda u, t, b: pushed.append((u, t, b)) or 1)

    class Stop(Exception): pass
    real_sleep = main.time.sleep
    main.time.sleep = lambda _: (_ for _ in ()).throw(Stop())
    try:
        try: main._scheduler_loop()
        except Stop: pass
    finally:
        main.time.sleep = real_sleep
    assert len(pushed) == 1 and pushed[0][0] == uid and "Daily report" in pushed[0][2]


def test_push_to_user_blocking_never_raises_when_unconfigured(main, monkeypatch):
    monkeypatch.setattr(main, "FCM_SERVICE_ACCOUNT_JSON", "")
    monkeypatch.setattr(main, "FCM_SERVICE_ACCOUNT_FILE", "")
    assert main.push_to_user_blocking(1, "t", "b") == 0


# ---------------- structured extraction ----------------
def test_table_parser_normalises_and_repairs(main):
    cols, rows, trunc = main.parse_table_json('{"columns":["a","b"],"rows":[["1","2"],["3"],["x","y","z"]]}')
    assert cols == ["a", "b"] and rows == [["1", "2"], ["3", ""], ["x", "y"]] and not trunc
    # reply cut off in the middle of the 3rd row -> keep the 2 complete rows
    cols, rows, trunc = main.parse_table_json('{"columns":["a","b"],"rows":[["1","2"],["3","4"],["5')
    assert rows == [["1", "2"], ["3", "4"]] and trunc
    # caps
    big = '{"columns":[%s],"rows":[%s]}' % (",".join('"c%d"' % i for i in range(15)),
                                           ",".join('[%s]' % ",".join(['"v"'] * 15) for _ in range(80)))
    cols, rows, trunc = main.parse_table_json(big)
    assert len(cols) == main.MAX_TABLE_COLS and len(rows) == main.MAX_TABLE_ROWS and trunc
    assert main.parse_table_json("not json at all") == ([], [], False)
    assert main.parse_table_json('```json\n{"columns":["a"],"rows":[["1"]]}\n```')[1] == [["1"]]
