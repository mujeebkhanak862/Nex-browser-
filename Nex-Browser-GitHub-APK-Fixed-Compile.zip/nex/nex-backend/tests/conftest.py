import os, sys, tempfile, importlib
import pytest

_tmp = tempfile.mkdtemp(prefix="nextest_")
os.environ["DB_PATH"] = os.path.join(_tmp, "nex.db")
os.environ["VAULT_FILE_PATH"] = os.path.join(_tmp, "vault.json")
os.environ.pop("GOOGLE_CLIENT_ID", None)
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))


@pytest.fixture(scope="session")
def main():
    return importlib.import_module("main")


@pytest.fixture(scope="session")
def client(main):
    from fastapi.testclient import TestClient
    return TestClient(main.app)


@pytest.fixture()
def user(client, main):
    """A fresh registered user; returns (headers, email)."""
    import secrets
    email = f"u{secrets.token_hex(4)}@example.com"
    r = client.post("/auth/register", json={"email": email, "password": "password123"})
    assert r.status_code == 200, r.text
    main._rate_hits.clear()
    return {"Authorization": "Bearer " + r.json()["access_token"]}, email
