# Nex Browser Backend

Ye backend sirf un **3 features** ke liye hai jo bina server ke ho hi nahi
sakte. Baaki sab kuch (Speed Dial, Ad Block, Bookmarks, History, Downloads,
Incognito, waghera) Android app ke andar hi chalta hai — unke liye ye
backend bilkul zaroori nahi hai.

## Ye 5 Cheezein Deta Hai

1. **AI Summarizer** (`POST /summarize`) — Claude API se page ka summary
2. **Cloud Sync** (`POST/GET /sync/bookmarks`) — account ke sath bookmarks sync
3. **Push Notifications** (`POST /notifications/send`) — Firebase Cloud Messaging se
4. **Vault Backup** (`POST /vault/sync`, `GET /vault/download`) — passwords +
   history + bookmarks + shortcuts, ek row **per account** `vault` table mein
   store hote hain (bookmarks table jaisa hi pattern). Har sync sirf usi
   account ki apni row ko **merge-update** karta hai (jo bhejo wo update
   hota hai, jo nahi bhejo wo **jaisa tha waisa hi rehta hai** — kuch bhi
   galti se mitta nahi), har download bhi sirf usi authenticated account ki
   apni row read karta hai — kisi doosre account ka data kabhi nahi.
   **End-to-end encrypted**: passwords/bookmarks/history/shortcuts sab app
   mein hi (Vault Passphrase se) encrypt hoke aate hain — server sirf
   ciphertext store karta hai, kabhi padh nahi sakta.
   - `GET /vault/checksum` — sirf ek hash lauta deta hai (poora data nahi),
     app isse use karta hai ye check karne ke liye ki kisi doosre device ne
     beech mein kuch badla to nahi (Merge-safe Sync).
   - `GET /vault/verify` — server-side integrity check, batata hai stored
     data corrupt hua ya nahi.
   - `GET /vault/backups`, `POST /vault/backups/{id}/restore` — har real
     change se pehle purani vault automatically archive ho jaati hai
     (last 5 rakhi jaati hain), yahan se koi bhi purani version wapas
     restore ki ja sakti hai (Secure Vault Backup).
5. **Automation (Agent)** — plain-language instruction se real browser
   automation. Task queue system:
   - `POST /agent/plan` — instruction bhejo, Claude usse browser-steps mein todta hai, naya task banta hai (queue mein add ho jata hai)
   - `POST /agent/report` — app apne execution ka progress yahan report karta hai (step-by-step)
   - `GET /agent/result/{job_id}` — kisi bhi task ka live status/result dekho
   - `GET /agent/jobs` — apne saare tasks (queue) dekho
   - `POST /agent/jobs/{id}/cancel` — task cancel karo
   - `DELETE /agent/jobs/{id}` — task delete karo
   - `POST /agent/jobs/{id}/reorder` — `{"direction":"top"}` bhejo, task ko queue mein sabse aage kar do ("pehle ye karo")

Account system (`/auth/register`, `/auth/login`) Cloud Sync, Push
Notifications, Vault Backup, aur Automation — chaaron ke liye chahiye,
kyunki sabko pata hona chahiye "ye kis user ka data hai".

⚠️ **Passwords is server pe bhi genuinely encrypted hote hain, plain text
kabhi nahi** — app ek alag "Vault Passphrase" (login password se bilkul
alag) se AES-256-GCM ka key banata hai phone pe hi, passwords ko wahin
encrypt karta hai, aur sirf ciphertext yahan bhejta hai. Ye backend/database
kabhi bhi asli password nahi dekh sakta. Trade-off ye hai: **Vault
Passphrase bhool gaye to backend pe backup hue passwords hamesha ke liye
unreadable ho jaate hain** — koi reset nahi hai, ye hi real end-to-end
encryption ka matlab hai. Phone pe saved passwords is se bilkul unaffected
rehte hain (wo alag se, Android Keystore se, encrypted hain).

---

## Deploy Karo (Railway — Free Tier)

### Step 1: GitHub Repo Banao
Is `nex-backend` folder ko GitHub repo mein push karo (web UI se drag-drop
bhi chalega, terminal zaroori nahi).

### Step 2: Railway Project Banao
1. [railway.app](https://railway.app) → New Project → Deploy from GitHub repo
2. Apna repo select karo
3. Railway khud detect kar lega ki ye Python app hai (Procfile se)

### Step 3: Environment Variables Set Karo
Railway dashboard → Variables tab mein ye add karo:

| Variable | Kya Hai | Zaroori? |
|---|---|---|
| `ANTHROPIC_API_KEY` | Claude API key ([console.anthropic.com](https://console.anthropic.com)) | Sirf AI Summarizer ke liye |
| `FCM_SERVICE_ACCOUNT_JSON` | Firebase service-account JSON (poora JSON paste karo; purani "server key" API Google ne band kar di hai) | Sirf Push Notifications ke liye |
| `ALLOWED_ORIGINS` | `*` (ya specific domain) | Optional, default `*` hai |
| `DB_PATH` | `/data/nex.db` | Volume mount karo to yahi rehne do |
| `VAULT_FILE_PATH` | `/data/vault.json` | Sirf ek-baar-chalne-wali legacy migration ke liye — agar purane single-file version se upgrade kar rahe ho to isse purana data uske asli owner account mein migrate ho jaata hai. Naye deployments ke liye zaroori nahi. |

**Agar tumhe sirf AI Summarizer chahiye, sirf `ANTHROPIC_API_KEY` set karo —
baaki cheezein automatically "not configured" error dengi, crash nahi
hongi.**

### Step 4: Persistent Storage (Accounts/Bookmarks Ke Liye)
Railway dashboard → apna service → "Volumes" tab → naya volume banao,
mount path: `/data`

Isके bina bhi app chalega, lekin Railway restart hone pe accounts/bookmarks
data **delete ho jayega** (SQLite file ephemeral storage mein hoga).

### Step 5: URL Copy Karo
Deploy hone ke baad Railway ek public URL dega, jaise:
`https://nex-backend-production.up.railway.app`

Ye URL Android app mein daalna hoga (agle section mein bataya hai).

---

## API Endpoints (Testing Ke Liye)

```bash
# Health check
curl https://your-app.up.railway.app/health

# Account banao
curl -X POST https://your-app.up.railway.app/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"test123","device_label":"My Phone"}'
# Response: {"access_token": "...", "refresh_token": "...", "expires_in": 1800,
#            "email": "...", "recovery_code": "XXXX-XXXX-XXXX"}
# access_token ek session (device) ke liye hai, 30 minute mein expire hota hai.
# refresh_token 30 din chalta hai — usse naya access_token milta hai bina dobara password daale.
# recovery_code SIRF is ek response mein aata hai — abhi save kar lo (isse hi password reset hota hai agar bhool jao).

# Login (naya login = naya session/device, purane devices logout nahi hote)
curl -X POST https://your-app.up.railway.app/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"test123","device_label":"My Phone"}'

# Access token expire ho jaaye to naya lo (refresh_token se, password nahi chahiye)
curl -X POST https://your-app.up.railway.app/auth/refresh \
  -H "Content-Type: application/json" \
  -d '{"refresh_token":"YOUR_REFRESH_TOKEN"}'
# Response: {"access_token": "...", "expires_in": 1800}

# Password bhool gaye? recovery_code se reset karo (koi email nahi bhejta ye backend)
curl -X POST https://your-app.up.railway.app/auth/reset-password \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","recovery_code":"XXXX-XXXX-XXXX","new_password":"newpass123"}'
# Sab existing sessions log out ho jaate hain (safety ke liye), aur ek naya recovery_code milta hai — purana ab kaam nahi karega.

# Recovery code kho gaya? already-logged-in device se naya bana lo
curl -X POST https://your-app.up.railway.app/auth/recovery-code/regenerate \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"

# Account ka security summary (Security Center screen isi se banti hai)
curl https://your-app.up.railway.app/auth/me \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"

# Sab devices dekho jo is account se login hain
curl https://your-app.up.railway.app/auth/sessions \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"

# Ek device ka naam badlo (session_id upar wali list se milega)
curl -X PATCH https://your-app.up.railway.app/auth/sessions/3 \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"device_label":"My Office Phone"}'

# Ek specific device ko logout karo
curl -X DELETE https://your-app.up.railway.app/auth/sessions/3 \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"

# Is device ke alawa har jagah se logout kar do
curl -X POST https://your-app.up.railway.app/auth/sign-out-everywhere \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"include_current_device": false}'

# Account permanently delete karo (bookmarks/history/vault/automation/sessions sab) —
# password ya recovery_code se confirm karna zaroori hai, kabhi undo nahi ho sakta
curl -X DELETE https://your-app.up.railway.app/auth/account \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"password":"test123"}'

# Bookmarks upload (access token chahiye)
curl -X POST https://your-app.up.railway.app/sync/bookmarks \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"bookmarks":[{"title":"Google","url":"https://google.com"}]}'

# Bookmarks download
curl https://your-app.up.railway.app/sync/bookmarks \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"

# AI Summary
curl -X POST https://your-app.up.railway.app/summarize \
  -H "Content-Type: application/json" \
  -d '{"text":"<page text here, at least 50 characters>","url":"https://example.com"}'

# Vault sync (upload passwords + history + bookmarks + shortcuts)
curl -X POST https://your-app.up.railway.app/vault/sync \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"passwords":[{"domain":"example.com","username":"me","password":"secret"}],"history":[],"bookmarks":[],"shortcuts":[]}'

# Vault download (returns a downloadable .json file)
curl -OJ https://your-app.up.railway.app/vault/download \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"

# Automation: create a new task
curl -X POST https://your-app.up.railway.app/agent/plan \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"instruction":"search cats on youtube and get the first video transcript"}'
# Response: {"job_id": 1, "steps": [...]}

# Automation: check a task's live progress/result
curl https://your-app.up.railway.app/agent/result/1 \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"

# Automation: see all your tasks (the queue)
curl https://your-app.up.railway.app/agent/jobs \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"

# Automation: move a task to the front of the queue
curl -X POST https://your-app.up.railway.app/agent/jobs/1/reorder \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"direction":"top"}'

# Automation: cancel or delete a task
curl -X POST https://your-app.up.railway.app/agent/jobs/1/cancel -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
curl -X DELETE https://your-app.up.railway.app/agent/jobs/1 -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

**Note:** creating tasks (`/agent/plan`) only sets up the plan — the actual
browsing happens on your **phone**, in the Nex Browser app, using your
logged-in session. The app needs to be open (or at least running in the
background) to pick up queued tasks and execute them. The API lets you
create tasks and check progress/results from anywhere, but execution
itself is on-device, not on this server.

---

## Push Notifications Setup (Extra Kaam Chahiye)

Push notifications ke liye **Firebase project** khud banana padega —
ye main tumhare liye nahi bana sakta kyunki ye tumhare Google account
se link hota hai:

1. [console.firebase.google.com](https://console.firebase.google.com) → naya project banao
2. Project Settings → Cloud Messaging tab → "Server key" copy karo →
   Railway mein `FCM_SERVICE_ACCOUNT_JSON` variable mein daalo (Firebase Console → Project settings → Service accounts → Generate new private key)
3. Same page se `google-services.json` download karo → Android app ke
   `app/` folder mein daalo (README-ANDROID mein steps hain)
4. App ka `build.gradle` mein Firebase Messaging dependency add karni
   hogi (agle section mein code diya hai)

**Bina is setup ke**, push notification button app mein "Push notifications
not configured" error dega — crash nahi karega.

---

## Security Notes

- Password hashing: PBKDF2-SHA256, 100,000 iterations (stdlib only, koi
  extra native dependency nahi)
- Tokens: 32-byte random hex, login pe rotate hote hain
- **Ye ek simple/personal-use backend hai** — production-grade rate
  limiting, email verification, password reset waghera nahi hai. Agar
  bahut zyada users honge to inko add karna padega.
- `ANTHROPIC_API_KEY` aur `FCM_SERVICE_ACCOUNT_JSON` kabhi bhi client-side code
  (Android app) mein mat daalna — sirf server (Railway env vars) mein
  rakho, warna koi bhi tumhari key nikal ke apne bill pe use kar sakta hai

---

## Cost Estimate

- Railway free tier: $5 credit/month — is chhote backend ke liye kaafi hai
  (halka SQLite, koi heavy compute nahi)
- Anthropic API: pay-per-use, Haiku model bahut sasta hai
  (summarization ke liye ~$0.001 per request ke aas-paas)
- Firebase Cloud Messaging: **completely free**, koi limit nahi

## Environment variables added in the security-hardening pass

| Variable | Required | Purpose |
|---|---|---|
| `GOOGLE_CLIENT_ID` | for Google Sign-In | Web Client ID that Google ID tokens must be issued for (`aud` check). Without it `/auth/google` returns 503. |
| `NEX_SECRET_KEY` | recommended | Fernet key that encrypts saved AI / custom-API keys in the DB. Generate: `python -c "from cryptography.fernet import Fernet;print(Fernet.generate_key().decode())"`. If unset, a key file is auto-created at `<DB dir>/secret.key` (keep it on the persistent volume). |
| `ALLOWED_ORIGINS` | optional | Comma-separated browser origins for CORS. Default is none (the Android app doesn't need CORS). |

Passwords are 8+ chars, hashed with PBKDF2-SHA256 (600k iterations); old 100k hashes are upgraded silently on next login. Login / register / reset endpoints are rate-limited per IP and per account.
