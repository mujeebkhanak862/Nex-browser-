# QR Scan — What Changed

Implements the "QR scan" item from the address-bar focused-state requirement
(Blueprint section 4, Design v2 section 13-14). Previously only a stale code
comment — not a real menu item, no button anywhere.

## Files changed
1. `DevilBrowser/app/build.gradle` — added `com.journeyapps:zxing-android-embedded:4.3.0`.
2. `DevilBrowser/app/src/main/res/drawable/ic_nav_qr.xml` (new).
3. `DevilBrowser/app/src/main/res/layout/activity_main.xml` — added `btnQr` in the omnibox pill.
4. `DevilBrowser/app/src/main/res/values/strings.xml` — added qr_scan strings.
5. `DevilBrowser/app/src/main/java/com/devil/browser/MainActivity.java` —
   `btnQr` field, `qrScanLauncher` (ZXing ScanContract/ScanOptions) +
   `qrPermissionLauncher` (CAMERA), `onQrScanClicked()` / `launchQrScanner()`.

## How it works
Requests CAMERA if needed, launches ZXing's scanner Activity (QR_CODE only),
decoded text goes through `submitOmnibox()` — URL navigates, anything else
falls back to search.

## Testing note
Static source edit — no Android SDK/emulator in this environment. Gradle
sync pulls the new dependency from Maven Central; test on a real device
before shipping.
