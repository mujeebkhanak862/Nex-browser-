# Nex Browser APK — GitHub Actions (Roman Urdu)

## APK banane ka tareeqa
1. ZIP extract karke is ke andar ke tamam files GitHub repository ke root mein upload/push karein. Root mein `.github/`, `DevilBrowser/`, aur `nex-backend/` hone chahiye.
2. GitHub repository ka naam `nex-browser` rakh sakte hain. Code ko `main` ya `master` branch par push karein.
3. Repository mein **Actions** tab kholein. **Build Nex Browser APK** workflow select karein.
4. Build complete hone ka intezar karein. Green check ka matlab workflow pass hua.
5. Run ke neeche **Artifacts** mein `nex-browser-debug-apk` download karein. ZIP ko phone par extract karke APK install karein.
6. Agar workflow fail ho, Actions run khol kar pehla laal error step aur error text dekhein. Build pass hona abhi app ke tamam features ke sahi chalne ki guarantee nahi; phone par test zaroor karein.

## Zaroori baatein
- Ye workflow debug APK banata hai, testing ke liye.
- Debug APK release/signing ke liye tayyar production build ka badal nahi.
- Firebase `google-services.json` optional hai; file na ho to push notification integration kaam nahi karegi, lekin project ki Gradle configuration ke mutabiq build phir bhi chalna chahiye.
- Keystore, passwords, API keys, ya `google-services.json` ko public repository mein upload na karein.
- Android Studio ki zaroorat GitHub-hosted runner par APK compile karne ke liye nahi hai.
