# Custom APIs (Settings → 🔌 Custom APIs) — kya add hua

Ye naya feature hai (report ke 116 features se alag, aapki nayi request par
banaya gaya): **Settings mein ek naya page** jahan aap **kisi bhi third-party
app/service ki API key** daal sakte hain — sirf AI providers (Gemini/OpenAI/
Anthropic) tak limited nahi, balki koi bhi API (weather, maps, aapka apna
server, koi bhi cheez jiska base URL + key ho).

## Kya-kya kaam karta hai

1. **Add** — Name, Base URL, API Key, aur key kaise bhejni hai (header ya
   query-param) — save hota hai.
2. **Edit** — Name/URL/Key update kar sakte hain, ya remove kar sakte hain.
3. **Test** — Har saved API ke saath ek "▶ Test" button hai jo actually us
   API ko call karta hai aur real response dikhata hai — yani browser
   waqai us API ko "istemal" kar raha hai, sirf store nahi kar raha.
4. **Cross-device** — Key server-side (aapke account ke saath) save hoti
   hai, bilkul AI Keys jaisa — matlab jahan bhi aap sign in karein, wahi
   saved APIs available hongi, sirf ek device tak limited nahi.

## Kahan implement hua

- **Backend** (`nex-backend/main.py`): naya `custom_apis` table +
  `POST/GET/PUT/DELETE /account/custom-apis` + generic
  `POST /account/custom-apis/{id}/call` jo asal request forward karta hai
  (key device par kabhi wapas nahi aati, sirf server par attach hoti hai).
- **App** (`MainActivity.java`): "🔌 Custom APIs" settings row + poora
  add/edit/test UI, `AI Keys` screen wale exact design pattern se.
- Ek generic `callCustomApi(id, method, path, body, callback)` helper bhi
  hai taake future mein Automation/Agent steps isi saved API ko reuse kar
  sakein, dobara se network code likhe bina.

## Zaroori: iske use hone ke liye

Backend ka naya code Railway (ya jahan bhi `nex-backend` deployed hai) par
**redeploy** karna hoga, warna app naye `/account/custom-apis` endpoints
call karega but purana backend unhe nahi jaanta (404 aayega). Redeploy ke
baad koi aur setup nahi chahiye — table apne aap ban jata hai
(`init_db()` pehle se automatic chalta hai).
