# Carousel Tab View — What Changed

Completes the Blueprint's "Tab UI modes — Grid / List / Carousel / Groups"
item. Grid, List, and Groups (the existing AI-tab-grouping/sectioning)
were already implemented before this session; only Carousel was missing.

## Files changed

**`app/src/main/java/com/devil/browser/MainActivity.java`** only.

1. `tabViewCarousel` boolean field, next to the existing `tabViewGrid`.
   Loaded from a new `tab_view_carousel` preference in `onCreate()`.

2. The "Tab View" settings row now cycles **List → Grid → Carousel →
   List** (previously just List ↔ Grid), saving both booleans each time
   so the two stay mutually exclusive.

3. Tab switcher rendering: added a new `if (tabViewCarousel) { ... }`
   branch **before** the existing `if (tabViewGrid) { ... } else { ... }`,
   which was left completely untouched. The Carousel branch builds a
   `HorizontalScrollView` containing one `buildTabSwitcherCarouselCard()`
   per tab in a horizontal strip.

4. `buildTabSwitcherCarouselCard()` — a new, self-contained card builder
   (deliberately *not* reusing `buildTabSwitcherGridCard()`, since that
   one returns a view with `GridLayout.LayoutParams`, which would throw a
   `ClassCastException` at runtime if added to a `LinearLayout` strip
   instead of a `GridLayout` — safer to duplicate the ~50 lines of visual
   setup than risk that). Same content/behavior as the Grid card: live
   thumbnail via the existing `captureTabThumbnail()`, private-tab chip,
   close button, parent-tab link, tap-to-switch — just wider (320dp) and
   laid out with `LinearLayout.LayoutParams`.

## Known limitation

Group section headers (shown in Grid/List when tabs have been AI-grouped)
are **not** shown in Carousel mode — a header card doesn't fit naturally
in a horizontal strip. Tabs from the same group still end up next to each
other though, since `displayOrder` is already sorted by group name before
any of the three branches run.

## Bug caught and fixed during this change

The first version of this edit accidentally deleted the method signature
line for the existing `buildTabSwitcherRow()` (the List View card
builder) while inserting the new Carousel card builder next to it in the
file — a copy-paste boundary mistake, not a logic error. Caught
immediately by the file's brace-balance check (`{` and `}` counts no
longer matched) before this was packaged; the signature line was restored
and the file re-verified balanced. Mentioned here so it's not a surprise
if anyone diffs this file against the previous zip and sees that method
touched twice.

## How it works

Settings → Tab View → tap through to "Carousel View" → the tab switcher
now shows a horizontally-scrollable strip of large tab cards instead of a
grid or list.

## Testing note

Static source edit only — no Android SDK/emulator in this environment.
Before shipping: build in Android Studio, cycle through all three Tab
View modes, confirm Grid and List still work exactly as before (the
bug above only ever affected List, and only until the fix), and check
the Carousel strip scrolls smoothly with several tabs open.
