# Universal Panel (Bookmarks / History / Tabs) — What Changed

Partial implementation of Design v2's "universal side panel" goal:
Bookmarks, History, and Tabs are now three tabs of **one** consolidated
screen instead of Tabs living only in the separate horizontal tab strip.

## Scope decision — why Tabs only, not AI/Agent/Privacy too

The app already had a working, fairly rich Bookmarks+History screen
(`buildBookmarksHistoryView`) — sign-in banner, edit mode, sync, semantic
search, timeline. Folding AI/Agent/Privacy into the *same* screen would
mean redesigning all of those (each is its own full feature surface) at
once, with no way to test any of it in this environment. Extending the
existing, working screen with a third **Tabs** tab was the bounded,
lower-risk slice that still moves toward "one panel, several sections"
instead of everything staying a separate full-page destination. AI/Agent/
Privacy remain separate screens, reachable the same way they were before
this change.

## Files changed

**`app/src/main/java/com/devil/browser/MainActivity.java`** only.

1. Replaced the `showingBookmarksTab` boolean field with
   `panelSection` (0 = Bookmarks, 1 = History, 2 = Tabs). Checked first
   that this field/its three read sites were only ever used inside this
   one method before removing it, so nothing else in the file was
   depending on it.

2. `buildBookmarksHistoryView(boolean startOnBookmarks)` is now a thin
   wrapper delegating to a new `buildBookmarksHistoryView(int section)` —
   kept on purpose so none of the ~10 existing call sites elsewhere in the
   file (Quick Access settings row, the bookmark star, etc.) needed to
   change at all.

3. Header tab strip: added a third "Tabs" `TextView` next to
   Bookmarks/History, same style, same active/inactive color logic keyed
   off `panelSection` instead of the old boolean.

4. The big `if (panelSection == 0) { ... } else if (panelSection == 1)
   { ... } else { ... }` — the third branch is new: lists `tabs` (the
   same `List<DevilTab>` the horizontal tab strip already uses), one row
   per tab with an icon (🕶 incognito / 🏠 home / 🌐 web), title, URL,
   and a close (✕) button. Tapping a row calls the existing
   `switchToTab(int)` and closes the panel; the close button calls the
   existing `closeTab(int)` and rebuilds the panel in place. A
   "+ New Tab" bottom-bar entry calls the existing `createNewTab(boolean)`.
   No new tab-management logic was written — this section is entirely a
   different *view* onto data/functions that already existed.

## How it works

Open Bookmarks/History from any of its existing entry points (Quick
Access, the bookmark star, etc.) — there's now a third "Tabs" label in
the header alongside Bookmarks/History. Tapping it lists every open tab;
tapping a tab switches to it, the ✕ closes it, "+ New Tab" opens one.

## Not yet done

- AI, Agent, and Privacy are **not** part of this panel — still separate
  full-page screens, unchanged.
- This is still presented as a full-page screen (via the app's existing
  `pageContainer`/`showFullPage()` mechanism, the same one every other
  screen in the app uses), not a true edge-anchored sliding drawer with
  the live page dimmed behind it. Building that would mean changing how
  `pageContainer` composites (it currently paints an opaque full-screen
  background for every page, by design, consistently across the whole
  app) — a bigger, riskier change than fits in this pass, so it wasn't
  attempted rather than being faked with a panel that doesn't actually
  show the page behind it.

## Testing note

Static source edit only — no Android SDK/emulator in this environment.
Before shipping: build in Android Studio, open the panel from more than
one of its entry points, switch between all three tabs, open/close/switch
tabs from the new Tabs section, and confirm closing the *current* tab
from this list doesn't leave the panel or the browser in a broken state.
