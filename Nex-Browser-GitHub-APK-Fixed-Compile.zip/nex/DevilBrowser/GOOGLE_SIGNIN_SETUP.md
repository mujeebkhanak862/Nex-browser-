# Google Sign-In Setup (Feature #20)

Nex Browser's Account screen now has a real **"Sign in with Google"** button
(Credential Manager API — Google's current, non-deprecated Sign-In library).
Code-side this is fully wired and requires **zero further code changes**.
What's left is entirely account/config setup on your side — the same kind
of one-time step as the Firebase project for push notifications.

## Why you have to do this part yourself
Google Sign-In needs an OAuth 2.0 Client ID that's tied to:
- your own Google Cloud project
- your app's package name (`com.devil.browser`)
- your app's signing certificate's SHA-1 fingerprint

None of that can be generated on your behalf — it has to come from your
own Google account.

## Steps

1. **Go to Google Cloud Console** → https://console.cloud.google.com
   Create a new project (or reuse the one you may have made for Firebase).

2. **Configure the OAuth consent screen**
   APIs & Services → OAuth consent screen → fill in app name, your email,
   External user type (unless you have Workspace) → save.

3. **Get your signing key's SHA-1**
   From a terminal, wherever your keystore is:
   ```
   keytool -list -v -keystore your-keystore.jks -alias your-key-alias
   ```
   For a debug build (testing only) you can use the auto-generated debug
   keystore instead:
   ```
   keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
   ```
   Copy the `SHA1:` fingerprint.

4. **Create TWO OAuth 2.0 Client IDs** (APIs & Services → Credentials →
   Create Credentials → OAuth client ID):
   - **Android** — package name `com.devil.browser`, paste the SHA-1 from
     step 3. This one Google uses internally to verify your app is really
     yours; you don't need to copy this ID anywhere in the app.
   - **Web application** — no extra fields needed. **This is the one that
     matters** — copy its Client ID (looks like
     `1234567890-abc123.apps.googleusercontent.com`).

5. **In Nex Browser**: Settings → Account → tap "Set Google Client ID first"
   → paste the **Web application** Client ID from step 4 → Save.

6. Make sure **Settings → Backend Server** is also set (the same Railway
   URL you already use) — Google sign-in calls your backend's
   `/auth/google`, which was already built and working server-side.

7. Tap **Account → Sign in with Google**. The system's real Google account
   picker will appear. Pick an account → the app gets a signed ID token →
   sends it to `/auth/google` → your backend verifies it directly against
   Google's servers → you're signed in, same session as email/password
   sign-in (bookmarks sync, push notifications, vault sync all work
   identically either way).

## Notes
- If you ever release a signed (non-debug) build, you'll need to add
  that build's SHA-1 as a second Android OAuth client (or update the
  existing one) — debug and release keys have different fingerprints.
- The Web Client ID is safe to store in SharedPreferences/paste into the
  app — it's a public identifier, not a secret (this is normal for OAuth
  "public clients" like mobile apps).
