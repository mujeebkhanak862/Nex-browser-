package com.devil.browser;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Only ever actually receives anything once a real google-services.json has
 * been dropped into app/ and the app rebuilt (see PUSH_NOTIFICATIONS_SETUP.md).
 * Without that file, Firebase never initializes and this class simply never
 * gets called — it does not crash or interfere with the rest of the app.
 */
public class NexFirebaseMessagingService extends FirebaseMessagingService {

    private static final String CHANNEL_ID = "nex_browser_notifications";
    private static final String PREFS_NAME = "nex_browser_prefs";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    public void onMessageReceived(RemoteMessage message) {
        super.onMessageReceived(message);

        String title = "Nex Browser";
        String body = "";
        if (message.getNotification() != null) {
            if (message.getNotification().getTitle() != null) title = message.getNotification().getTitle();
            if (message.getNotification().getBody() != null) body = message.getNotification().getBody();
        }

        showNotification(title, body);
    }

    private void showNotification(String title, String body) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Nex Browser", NotificationManager.IMPORTANCE_DEFAULT);
            nm.createNotificationChannel(channel);
        }

        Intent openApp = new Intent(this, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT
                | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, openApp, flags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        nm.notify((int) System.currentTimeMillis(), builder.build());
    }

    // ---- New FCM token: send it to the backend right away if the user is
    // already signed in and a backend URL is configured. If not, it's saved
    // locally and MainActivity picks it up and registers it after sign-in. ----
    @Override
    public void onNewToken(String token) {
        super.onNewToken(token);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString("fcm_token", token).apply();

        String backendUrl = prefs.getString("backend_url", "");
        String authToken = prefs.getString("auth_token", "");
        if (backendUrl.isEmpty() || authToken.isEmpty()) return; // registered later once both exist

        executor.execute(() -> registerTokenWithBackend(backendUrl, authToken, token));
    }

    private void registerTokenWithBackend(String backendUrl, String authToken, String fcmToken) {
        try {
            JSONObject body = new JSONObject();
            body.put("fcm_token", fcmToken);

            URL url = new URL(backendUrl + "/notifications/register-token");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + authToken);
            conn.setDoOutput(true);
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(15000);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            conn.getResponseCode(); // triggers the request; result isn't needed here
        } catch (Exception ignored) {
            // Best-effort — MainActivity will retry registration on next sign-in/app-open
        }
    }
}
