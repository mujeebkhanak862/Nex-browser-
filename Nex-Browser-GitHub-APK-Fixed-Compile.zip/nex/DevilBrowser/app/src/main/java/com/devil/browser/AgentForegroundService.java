package com.devil.browser;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

/**
 * Keeps the Nex process alive while an Agent job is running.
 *
 * The agent's browser lanes live inside MainActivity. When the person switches to
 * another app, Android is free to kill a "cached" background process — which silently
 * ends the job half-way. A foreground service (with its required, visible
 * notification) tells Android the process is doing user-visible work, so the job keeps
 * running. MainActivity starts this when the first lane becomes busy and stops it
 * when all lanes are idle (see reconcileAgentService).
 *
 * What happens when the person swipes Nex away from Recents: the agent's browser lanes live
 * inside MainActivity, so they stop with it — a job cannot keep executing with no app UI.
 * What is NOT lost: every finished step is already saved on the server, and on the next launch
 * the queue resumes a "running" job from its saved step (see maybeStartAutomationQueue). This
 * service's job at that moment is to tell the person, with a tap-to-continue notification,
 * instead of letting the task silently stall. Scheduled tasks are announced by a backend push.
 */
public class AgentForegroundService extends Service {

    private static final String CHANNEL_ID = "nex_agent_running";
    private static final String CHANNEL_PAUSED_ID = "nex_agent_paused";
    private static final int NOTIFICATION_ID = 4101;
    private static final int PAUSED_NOTIFICATION_ID = 4102;

    /** Sent by MainActivity.onDestroy when the app is being closed while a task runs. */
    static final String ACTION_APP_CLOSED = "com.devil.browser.action.APP_CLOSED";

    /** True while the service exists. MainActivity checks this instead of keeping its own flag,
     *  which a recreated Activity (rotation, theme change) would have forgotten. */
    static volatile boolean running = false;

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
    }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // The task was swiped away from Recents (Service.stopWithTask defaults to false, so we get this).
        announcePausedAndStop();
        super.onTaskRemoved(rootIntent);
    }

    private void announcePausedAndStop() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_PAUSED_ID, "Agent needs you", NotificationManager.IMPORTANCE_DEFAULT);
                channel.setDescription("Shown when a Nex agent task stopped because the app was closed");
                nm.createNotificationChannel(channel);
            }
            Intent openApp = new Intent(this, MainActivity.class);
            openApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            int piFlags = PendingIntent.FLAG_UPDATE_CURRENT
                    | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
            Notification n = new NotificationCompat.Builder(this, CHANNEL_PAUSED_ID)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle("Agent task paused")
                    .setContentText("Nex was closed. Tap to continue where it left off.")
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setContentIntent(PendingIntent.getActivity(this, 1, openApp, piFlags))
                    .build();
            try { nm.notify(PAUSED_NOTIFICATION_ID, n); } catch (SecurityException ignored) { /* notifications not permitted */ }
        }
        stopForeground(true);
        stopSelf();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_APP_CLOSED.equals(intent.getAction())) {
            announcePausedAndStop();
            return START_NOT_STICKY;
        }
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm != null) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Agent running", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shown while a Nex agent task is running in the background");
            nm.createNotificationChannel(channel);
        }

        Intent openApp = new Intent(this, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT
                | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent open = PendingIntent.getActivity(this, 0, openApp, piFlags);

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Nex agent is working")
                .setContentText("A task is running — tap to open")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        return START_NOT_STICKY; // if Android kills the process the job can't continue anyway
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
