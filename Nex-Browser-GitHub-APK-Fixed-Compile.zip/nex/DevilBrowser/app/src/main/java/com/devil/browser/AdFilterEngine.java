package com.devil.browser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Nex's ad / tracker filtering rules, pulled out of MainActivity (first step of splitting
 * that file) so the logic has no Android dependency and can be unit-tested on a plain JVM.
 *
 * Supported imported-list rule types, honestly:
 *   ||host^            block everything from that host (and its subdomains)
 *   ||host/path...     block that host only for URLs under that path
 *   @@||host^          exception: never block (or cosmetically hide on) that host
 *   ##.sel  ###id  site.com##.sel    cosmetic "hide this element" rules
 *   hosts-file lines and bare domains
 *   general patterns  /ads/*  -banner-  |http://x.com/ad|  with * (wildcard) ^ (separator) | (anchors)
 *   $options: third-party / ~third-party, script, image, stylesheet, xmlhttprequest, subdocument,
 *             media, font, other (each can be negated with ~), domain=a.com|~b.com, important
 * NOT supported (skipped whole, never guessed): regex rules (/.../), scriptlets (+js), procedural
 * cosmetics (:has-text, :xpath, ...), and options such as redirect=, removeparam=, csp=, popup,
 * badfilter, header=, replace=. That is a deliberately smaller subset than uBlock Origin, chosen so
 * it never blocks the wrong thing. Resource type and third-party status are inferred from the
 * request (extension, Accept header, registrable-domain comparison) — close, not perfect.
 *
 * Thread-safety: the rule set is an immutable snapshot swapped in one volatile write,
 * because WebView calls shouldInterceptRequest on background threads.
 */
final class AdFilterEngine {

    // Resource types (bit flags). TYPE_UNKNOWN: caller could not tell — rules that need a type then don't apply.
    static final int TYPE_UNKNOWN = 0;
    static final int TYPE_SCRIPT = 1, TYPE_IMAGE = 2, TYPE_STYLESHEET = 4, TYPE_XHR = 8,
            TYPE_SUBDOCUMENT = 16, TYPE_MEDIA = 32, TYPE_FONT = 64, TYPE_OTHER = 128;

    private static final String SEPARATOR = "(?:[^a-z0-9_.%-]|$)";
    private static final int MAX_NET_RULES = 60_000;

    /** One compiled network rule (pattern + options). */
    static final class NetRule {
        final String raw;                 // original line, for persistence
        final boolean allow;              // @@ exception
        final java.util.regex.Pattern regex;
        final String keyword;             // literal prefilter for un-indexed rules ("" if host-indexed)
        final int typeMask;               // 0 = any type
        final int notTypeMask;
        final int thirdParty;             // 1 = only third-party, -1 = only first-party, 0 = either
        final Set<String> domains;        // page must be on one of these (null = any)
        final Set<String> notDomains;
        final boolean important;

        NetRule(String raw, boolean allow, java.util.regex.Pattern regex, String keyword, int typeMask,
                int notTypeMask, int thirdParty, Set<String> domains, Set<String> notDomains, boolean important) {
            this.raw = raw; this.allow = allow; this.regex = regex; this.keyword = keyword;
            this.typeMask = typeMask; this.notTypeMask = notTypeMask; this.thirdParty = thirdParty;
            this.domains = domains; this.notDomains = notDomains; this.important = important;
        }

        boolean applies(String lowerUrl, String reqHost, String pageHost, int type) {
            if (typeMask != 0 && (type == TYPE_UNKNOWN || (typeMask & type) == 0)) return false;
            if (notTypeMask != 0 && type != TYPE_UNKNOWN && (notTypeMask & type) != 0) return false;
            if (thirdParty != 0) {
                if (pageHost == null) return false;                 // cannot tell → don't guess
                boolean third = isThirdParty(reqHost, pageHost);
                if ((thirdParty == 1) != third) return false;
            }
            if (domains != null || notDomains != null) {
                if (pageHost == null) return false;
                List<String> pageChain = hostAndParents(pageHost);
                if (notDomains != null) for (String h : pageChain) if (notDomains.contains(h)) return false;
                if (domains != null) {
                    boolean in = false;
                    for (String h : pageChain) if (domains.contains(h)) { in = true; break; }
                    if (!in) return false;
                }
            }
            return regex.matcher(lowerUrl).find();
        }
    }

    /** Immutable-after-parse rule set. */
    static final class Rules {
        final Map<String, List<NetRule>> hostNet = new HashMap<>();   // ||host-anchored rules, by host
        final List<NetRule> genericNet = new ArrayList<>();           // everything else (keyword-prefiltered)
        int netCount = 0;
        final Set<String> blockHosts = new HashSet<>();
        final Map<String, List<String>> pathRules = new HashMap<>();   // host -> lowercase path prefixes
        final Set<String> allowHosts = new HashSet<>();
        final List<String> genericCss = new ArrayList<>();
        final Map<String, List<String>> domainCss = new HashMap<>();   // host -> selectors

        int size() {
            return blockHosts.size() + allowHosts.size() + genericCss.size()
                    + pathRules.size() + domainCss.size() + netCount;
        }
    }

    static final int MAX_FILTER_RULES = 200_000;
    static final int MAX_GENERIC_COSMETIC = 2000;
    static final int MAX_DOMAIN_COSMETIC = 5000;

    private static final Pattern DOMAIN = Pattern.compile(
            "^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$");
    // Characters a plain CSS selector may contain. Anything fancier is a uBlock extension.
    private static final Pattern SAFE_SELECTOR = Pattern.compile(
            "^[A-Za-z0-9_\\-.#\\[\\]=\"'*^$~|:(),>+ ]{1,200}$");

    private final Map<String, String> builtinCategories; // built-in domain -> category
    private volatile Rules rules = new Rules();

    AdFilterEngine(Map<String, String> builtinCategories) {
        this.builtinCategories = builtinCategories;
    }

    // ------------------------------------------------------------------ URL helpers
    // Hand-rolled instead of java.net.URI/android.net.Uri: ad URLs are full of characters
    // those parsers reject ({}, |, spaces), and a parse failure must never mean "not blocked".

    /** Lowercase host of an http(s)/ws URL, or null. */
    static String hostOf(String url) {
        if (url == null) return null;
        int scheme = url.indexOf("://");
        int start = scheme >= 0 ? scheme + 3 : (url.startsWith("//") ? 2 : -1);
        if (start < 0) return null;
        int end = url.length();
        for (int i = start; i < url.length(); i++) {
            char c = url.charAt(i);
            if (c == '/' || c == '?' || c == '#') { end = i; break; }
        }
        String authority = url.substring(start, end);
        int at = authority.lastIndexOf('@');
        if (at >= 0) authority = authority.substring(at + 1);
        if (authority.startsWith("[")) return null;                // IPv6 literal: never an ad host
        int colon = authority.indexOf(':');
        if (colon >= 0) authority = authority.substring(0, colon);
        authority = authority.toLowerCase(Locale.US);
        while (authority.endsWith(".")) authority = authority.substring(0, authority.length() - 1);
        return authority.isEmpty() ? null : authority;
    }

    /** Lowercase path (no query/fragment), "" if none. */
    static String pathOf(String url) {
        int scheme = url.indexOf("://");
        int start = scheme >= 0 ? scheme + 3 : (url.startsWith("//") ? 2 : 0);
        int slash = url.indexOf('/', start);
        if (slash < 0) return "";
        int end = url.length();
        for (int i = slash; i < url.length(); i++) {
            char c = url.charAt(i);
            if (c == '?' || c == '#') { end = i; break; }
        }
        return url.substring(slash, end).toLowerCase(Locale.US);
    }

    /** host, then each parent domain, never a bare TLD. */
    static List<String> hostAndParents(String host) {
        List<String> out = new ArrayList<>();
        String candidate = host;
        while (true) {
            out.add(candidate);
            int dot = candidate.indexOf('.');
            if (dot < 0) break;
            candidate = candidate.substring(dot + 1);
            if (candidate.indexOf('.') < 0) break;
        }
        return out;
    }

    // ------------------------------------------------------------------ request context helpers

    private static final String[] TWO_LEVEL_SUFFIXES = {
            "co.uk", "org.uk", "ac.uk", "gov.uk", "com.au", "net.au", "org.au", "co.nz", "co.jp", "co.in",
            "co.za", "com.br", "com.mx", "com.ar", "com.tr", "com.cn", "com.hk", "com.sg", "com.pk",
            "com.bd", "com.ng", "com.eg", "co.kr", "co.id", "com.my", "com.ph", "com.vn", "co.il"};

    /** "a.b.example.co.uk" -> "example.co.uk" (small built-in suffix list, not the full PSL). */
    static String registrableDomain(String host) {
        String[] parts = host.split("\\.");
        if (parts.length <= 2) return host;
        String lastTwo = parts[parts.length - 2] + "." + parts[parts.length - 1];
        for (String s : TWO_LEVEL_SUFFIXES) {
            if (lastTwo.equals(s)) return parts[parts.length - 3] + "." + lastTwo;
        }
        return lastTwo;
    }

    static boolean isThirdParty(String requestHost, String pageHost) {
        if (requestHost == null || pageHost == null) return false;
        return !registrableDomain(requestHost).equals(registrableDomain(pageHost));
    }

    /** Best-effort resource type from what a WebView's shouldInterceptRequest gives us. */
    static int guessType(String url, String acceptHeader, String requestedWithHeader, boolean isSubFrameHtml) {
        if (requestedWithHeader != null && requestedWithHeader.equalsIgnoreCase("XMLHttpRequest")) return TYPE_XHR;
        String path = pathOf(url);
        if (path.endsWith(".js") || path.endsWith(".mjs")) return TYPE_SCRIPT;
        if (path.endsWith(".css")) return TYPE_STYLESHEET;
        if (path.matches(".*\\.(png|jpe?g|gif|webp|svg|ico|bmp|avif)$")) return TYPE_IMAGE;
        if (path.matches(".*\\.(woff2?|ttf|otf|eot)$")) return TYPE_FONT;
        if (path.matches(".*\\.(mp4|webm|mkv|mov|m3u8|mp3|m4a|ogg|wav|ts)$")) return TYPE_MEDIA;
        String accept = acceptHeader == null ? "" : acceptHeader.toLowerCase(Locale.US);
        if (isSubFrameHtml) return TYPE_SUBDOCUMENT;
        if (accept.startsWith("text/css")) return TYPE_STYLESHEET;
        if (accept.startsWith("image/")) return TYPE_IMAGE;
        if (accept.contains("text/html") && !accept.startsWith("*/*")) return TYPE_SUBDOCUMENT;
        return TYPE_OTHER;
    }

    // ------------------------------------------------------------------ matching

    /** The matched domain key if this request should be blocked, else null. Host-based on
     *  purpose: the old url.contains(domain) test also fired when an ad domain merely
     *  appeared inside a path or query string ("?ref=criteo.com"). */
    String match(String url) {
        return match(url, null, TYPE_UNKNOWN);
    }

    /**
     * Full match with request context. `pageUrl` = the page the request belongs to (for
     * third-party and domain= options; may be null), `type` = a TYPE_* flag (or TYPE_UNKNOWN).
     * Rules that need context the caller could not supply simply do not apply.
     */
    String match(String url, String pageUrl, int type) {
        String host = hostOf(url);
        if (host == null) return null;
        Rules f = rules;
        List<String> chain = hostAndParents(host);

        for (String h : chain) {
            if (f.allowHosts.contains(h)) return null;          // @@||host^ beats everything
        }
        String pageHost = hostOf(pageUrl);
        String lowerUrl = url.toLowerCase(Locale.US);

        String blockedBy = null;
        boolean important = false;
        for (String h : chain) {
            if (builtinCategories.containsKey(h) || f.blockHosts.contains(h)) { blockedBy = h; break; }
        }
        if (blockedBy == null && !f.pathRules.isEmpty()) {
            String path = pathOf(url);
            outer:
            for (String h : chain) {
                List<String> prefixes = f.pathRules.get(h);
                if (prefixes == null) continue;
                for (String prefix : prefixes) {
                    if (path.startsWith(prefix)) { blockedBy = h; break outer; }
                }
            }
        }
        if (f.netCount > 0) {
            // blocking pattern rules (and remember whether one of them is "important")
            for (String h : chain) {
                List<NetRule> rs = f.hostNet.get(h);
                if (rs == null) continue;
                for (NetRule r : rs) {
                    if (r.allow || !r.applies(lowerUrl, host, pageHost, type)) continue;
                    if (blockedBy == null) blockedBy = host;
                    if (r.important) important = true;
                }
            }
            for (NetRule r : f.genericNet) {
                if (r.allow || !lowerUrl.contains(r.keyword)) continue;
                if (!r.applies(lowerUrl, host, pageHost, type)) continue;
                if (blockedBy == null) blockedBy = host;
                if (r.important) important = true;
            }
        }
        if (blockedBy == null) return null;
        if (f.netCount > 0 && !important) {
            // @@ exception patterns (with or without options) unblock it
            for (String h : chain) {
                List<NetRule> rs = f.hostNet.get(h);
                if (rs == null) continue;
                for (NetRule r : rs) if (r.allow && r.applies(lowerUrl, host, pageHost, type)) return null;
            }
            for (NetRule r : f.genericNet) {
                if (r.allow && lowerUrl.contains(r.keyword) && r.applies(lowerUrl, host, pageHost, type)) return null;
            }
        }
        return blockedBy;
    }

    boolean isAd(String url) { return match(url) != null; }
    boolean isAd(String url, String pageUrl, int type) { return match(url, pageUrl, type) != null; }

    /** Category for the stats screen; imported-list domains have none, so count as banners. */
    /** Stats category for a domain key returned by match(). */
    String categoryForMatch(String matched) {
        String category = builtinCategories.get(matched);
        return category != null ? category : "Banners";   // imported-list match: no category info
    }

    String categoryOf(String url) { return categoryOf(url, null, TYPE_UNKNOWN); }

    String categoryOf(String url, String pageUrl, int type) {
        String matched = match(url, pageUrl, type);
        if (matched == null) return "Other";
        String category = builtinCategories.get(matched);
        return category != null ? category : "Banners";
    }

    int ruleCount() { return rules.size(); }
    Rules rules() { return rules; }
    void replace(Rules r) { rules = r; }
    void clear() { rules = new Rules(); }

    // ------------------------------------------------------------------ parsing

    static boolean isSafeCosmeticSelector(String sel) {
        if (!SAFE_SELECTOR.matcher(sel).matches()) return false;
        return !(sel.contains(":-abp") || sel.contains(":has-text") || sel.contains(":matches-css")
                || sel.contains(":xpath") || sel.contains(":contains") || sel.contains(":style")
                || sel.contains(":remove") || sel.contains(":upward") || sel.contains(":watch")
                || sel.contains(":not(:") || sel.contains("+js"));
    }

    /** First index of a character that ends the host part of an ||anchored rule. */
    private static int hostEnd(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '^' || c == '/' || c == '*' || c == ':' || c == '?') return i;
        }
        return s.length();
    }

    /** Running counters while parsing one list (caps are per import, not per line). */
    private static final class ParseState {
        int generic = 0, domainSpecific = 0;
    }

    Rules parse(BufferedReader reader) throws IOException {
        Rules out = new Rules();
        ParseState st = new ParseState();
        String line;
        while ((line = reader.readLine()) != null && out.size() < MAX_FILTER_RULES) {
            parseLine(line, out, st);
        }
        return out;
    }

    // option name -> type flag
    private static int typeFlag(String name) {
        switch (name) {
            case "script": return TYPE_SCRIPT;
            case "image": return TYPE_IMAGE;
            case "stylesheet": case "css": return TYPE_STYLESHEET;
            case "xmlhttprequest": case "xhr": return TYPE_XHR;
            case "subdocument": case "frame": return TYPE_SUBDOCUMENT;
            case "media": return TYPE_MEDIA;
            case "font": return TYPE_FONT;
            case "other": return TYPE_OTHER;
            default: return 0;
        }
    }

    /** Parses ONE filter line into `out`. Unsupported or unsafe lines are skipped silently. */
    private void parseLine(String line, Rules out, ParseState st) {
        line = line.trim();
        if (line.isEmpty() || line.startsWith("!") || line.startsWith("[")) return;
        if (line.startsWith("#") && !line.startsWith("##")) return;            // hosts-file comment
        if (line.contains("#@#") || line.contains("#?#") || line.contains("#$#")) return;

        // ---- cosmetic: [domain1,domain2]##selector ----
        int cos = line.indexOf("##");
        if (cos >= 0) {
            String domains = line.substring(0, cos).trim().toLowerCase(Locale.US);
            String selector = line.substring(cos + 2).trim();
            if (!isSafeCosmeticSelector(selector) || domains.contains("~")) return;
            if (domains.isEmpty()) {
                if (st.generic++ < MAX_GENERIC_COSMETIC) out.genericCss.add(selector);
            } else {
                for (String d : domains.split(",")) {
                    d = d.trim();
                    if (!DOMAIN.matcher(d).matches() || st.domainSpecific >= MAX_DOMAIN_COSMETIC) continue;
                    st.domainSpecific++;
                    out.domainCss.computeIfAbsent(d, k -> new ArrayList<>()).add(selector);
                }
            }
            return;
        }

        String lower = line.toLowerCase(Locale.US);
        boolean allow = lower.startsWith("@@");
        if (allow) lower = lower.substring(2);

        // ---- split "pattern$options" (the options part never contains '/' or '*') ----
        String optionText = null;
        int dollar = lower.lastIndexOf('$');
        if (dollar > 0) {
            String maybe = lower.substring(dollar + 1);
            if (!maybe.isEmpty() && maybe.indexOf('/') < 0 && maybe.indexOf('*') < 0) {
                optionText = maybe;
                lower = lower.substring(0, dollar);
            }
        }
        if (lower.isEmpty()) return;
        if (lower.startsWith("/") && lower.endsWith("/") && lower.length() > 2) return;   // regex rule: unsupported

        // ---- plain fast paths (no options) ----
        if (optionText == null) {
            if (lower.startsWith("||")) {
                String rest = lower.substring(2);
                int end = hostEnd(rest);
                String host = rest.substring(0, end);
                if (DOMAIN.matcher(host).matches()) {
                    if (end == rest.length() || (rest.charAt(end) == '^' && end + 1 == rest.length())) {
                        (allow ? out.allowHosts : out.blockHosts).add(host);       // ||host^
                        return;
                    }
                    if (!allow && rest.charAt(end) == '/') {
                        int pend = rest.length();
                        for (int i = end; i < rest.length(); i++) {
                            char c = rest.charAt(i);
                            if (c == '^' || c == '*' || c == '?' || c == '|') { pend = i; break; }
                        }
                        String path = rest.substring(end, pend);
                        // a plain "||host/path" with nothing after it → cheap path-prefix rule
                        if (pend == rest.length() || (rest.charAt(pend) == '^' && pend + 1 == rest.length())) {
                            if (path.length() >= 4) out.pathRules.computeIfAbsent(host, k -> new ArrayList<>()).add(path);
                            return;
                        }
                    }
                }
            } else if (!allow) {
                if (lower.startsWith("0.0.0.0 ") || lower.startsWith("127.0.0.1 ")) {      // hosts-file line
                    String candidate = lower.substring(lower.indexOf(' ') + 1).trim();
                    int hash = candidate.indexOf('#');
                    if (hash >= 0) candidate = candidate.substring(0, hash).trim();
                    if (DOMAIN.matcher(candidate).matches() && !candidate.equals("localhost")) out.blockHosts.add(candidate);
                    return;
                }
                // A bare token that IS a valid domain is a host rule; anything else ("-ad-banner-") is
                // a general URL pattern and falls through to the pattern compiler below.
                if (lower.indexOf(' ') < 0 && DOMAIN.matcher(lower).matches() && !lower.equals("localhost")) {
                    out.blockHosts.add(lower);
                    return;
                }
            }
        }

        // ---- general pattern rule (with or without options) ----
        NetRule rule = compileNetRule(line, lower, allow, optionText);
        if (rule != null && out.netCount < MAX_NET_RULES) {
            out.netCount++;
            String indexHost = rule.keyword.isEmpty() ? indexHostOf(lower) : null;
            if (indexHost != null) out.hostNet.computeIfAbsent(indexHost, k -> new ArrayList<>()).add(rule);
            else out.genericNet.add(rule);
        }
    }

    /** For "||host/..." patterns: the literal host used to index the rule; else null. */
    private static String indexHostOf(String pattern) {
        if (!pattern.startsWith("||")) return null;
        String rest = pattern.substring(2);
        String host = rest.substring(0, hostEnd(rest));
        return DOMAIN.matcher(host).matches() ? host : null;
    }

    private static final Pattern WORD_RUN = Pattern.compile("[a-z0-9]{3,}");

    /** Compiles pattern + options, or returns null if anything about it is unsupported/unsafe. */
    private NetRule compileNetRule(String raw, String pattern, boolean allow, String optionText) {
        int typeMask = 0, notTypeMask = 0, thirdParty = 0;
        Set<String> domains = null, notDomains = null;
        boolean important = false;
        if (optionText != null) {
            for (String opt : optionText.split(",")) {
                opt = opt.trim();
                if (opt.isEmpty()) return null;
                boolean neg = opt.startsWith("~");
                String name = neg ? opt.substring(1) : opt;
                if (name.startsWith("domain=")) {
                    for (String d : name.substring(7).split("\\|")) {
                        boolean dn = d.startsWith("~");
                        String dom = dn ? d.substring(1) : d;
                        if (!DOMAIN.matcher(dom).matches()) return null;
                        if (dn) { if (notDomains == null) notDomains = new HashSet<>(); notDomains.add(dom); }
                        else { if (domains == null) domains = new HashSet<>(); domains.add(dom); }
                    }
                    continue;
                }
                switch (name) {
                    case "third-party": case "3p": thirdParty = neg ? -1 : 1; continue;
                    case "first-party": case "1p": thirdParty = neg ? 1 : -1; continue;
                    case "important": important = true; continue;
                    default: break;
                }
                int flag = typeFlag(name);
                if (flag == 0) return null;           // unsupported option → skip the whole rule
                if (neg) notTypeMask |= flag; else typeMask |= flag;
            }
        }
        // ---- pattern → regex ----
        boolean anchorDomain = pattern.startsWith("||");
        boolean anchorStart = !anchorDomain && pattern.startsWith("|");
        String body = anchorDomain ? pattern.substring(2) : (anchorStart ? pattern.substring(1) : pattern);
        boolean anchorEnd = body.endsWith("|");
        if (anchorEnd) body = body.substring(0, body.length() - 1);
        if (body.isEmpty() || body.equals("*") || body.length() > 200) return null;
        int stars = 0;
        for (int i = 0; i < body.length(); i++) if (body.charAt(i) == '*') stars++;
        if (stars > 4) return null;                    // keeps regex matching linear-ish, no ReDoS surprises
        if (body.indexOf('|') >= 0) return null;       // '|' inside a pattern is not an anchor we support
        StringBuilder rx = new StringBuilder();
        if (anchorDomain) rx.append("^[a-z0-9+.-]+://(?:[^/?#]*\\.)?");
        else if (anchorStart) rx.append('^');
        for (int i = 0; i < body.length(); i++) {
            char c = body.charAt(i);
            if (c == '*') rx.append(".*");
            else if (c == '^') rx.append(SEPARATOR);
            else rx.append(Pattern.quote(String.valueOf(c)));
        }
        if (anchorEnd) rx.append('$');
        Pattern compiled;
        try { compiled = Pattern.compile(rx.toString()); } catch (Exception e) { return null; }

        // keyword prefilter for rules that cannot be indexed by host
        String keyword = "";
        if (indexHostOf(pattern) == null) {
            Matcher m = WORD_RUN.matcher(body);
            while (m.find()) if (m.group().length() > keyword.length()) keyword = m.group();
            if (keyword.isEmpty()) return null;        // no literal to prefilter on → too expensive/broad
        }
        return new NetRule(raw, allow, compiled, keyword, typeMask, notTypeMask, thirdParty, domains, notDomains, important);
    }

    // ------------------------------------------------------------------ persistence

    void save(File file) throws IOException {
        Rules f = rules;
        try (OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8)) {
            for (String h : f.blockHosts) w.write("B\t" + h + "\n");
            for (String h : f.allowHosts) w.write("A\t" + h + "\n");
            for (Map.Entry<String, List<String>> e : f.pathRules.entrySet())
                for (String path : e.getValue()) w.write("P\t" + e.getKey() + "\t" + path + "\n");
            for (List<NetRule> rs : f.hostNet.values()) for (NetRule r : rs) w.write("R\t" + r.raw + "\n");
            for (NetRule r : f.genericNet) w.write("R\t" + r.raw + "\n");
            for (String sel : f.genericCss) w.write("C\t" + sel + "\n");
            for (Map.Entry<String, List<String>> e : f.domainCss.entrySet())
                for (String sel : e.getValue()) w.write("D\t" + e.getKey() + "\t" + sel + "\n");
        }
    }

    /** Loads a file written by save(). A missing or corrupt file simply means "no custom rules". */
    void load(File file) {
        if (!file.exists()) return;
        Rules out = new Rules();
        ParseState st = new ParseState();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] parts = line.split("\t", 3);
                if (parts.length < 2) continue;
                switch (parts[0]) {
                    case "R": parseLine(line.substring(2), out, st); break;      // network pattern rule (raw line)
                    case "B": out.blockHosts.add(parts[1]); break;
                    case "A": out.allowHosts.add(parts[1]); break;
                    case "C": out.genericCss.add(parts[1]); break;
                    case "P":
                        if (parts.length == 3) out.pathRules.computeIfAbsent(parts[1], k -> new ArrayList<>()).add(parts[2]);
                        break;
                    case "D":
                        if (parts.length == 3) out.domainCss.computeIfAbsent(parts[1], k -> new ArrayList<>()).add(parts[2]);
                        break;
                    default: break;
                }
            }
            rules = out;
        } catch (Exception ignored) { /* keep whatever was loaded before */ }
    }

    // ------------------------------------------------------------------ cosmetic filtering

    /** JavaScript that hides the imported-list elements for this page, or null if there is
     *  nothing to hide. Every selector is inserted as its own CSS rule inside try/catch, so
     *  one selector the WebView does not understand cannot invalidate the others. */
    String cosmeticScript(String url) {
        Rules f = rules;
        if (f.genericCss.isEmpty() && f.domainCss.isEmpty()) return null;
        String host = hostOf(url);
        if (host == null) return null;
        List<String> chain = hostAndParents(host);
        for (String h : chain) {
            if (f.allowHosts.contains(h)) return null;   // @@ exception: leave this site alone
        }
        List<String> selectors = new ArrayList<>(f.genericCss);
        for (String h : chain) {
            List<String> specific = f.domainCss.get(h);
            if (specific != null) selectors.addAll(specific);
        }
        if (selectors.isEmpty()) return null;

        StringBuilder arr = new StringBuilder("[");
        for (int i = 0; i < selectors.size(); i++) {
            if (i > 0) arr.append(',');
            arr.append('"').append(jsEscape(selectors.get(i))).append('"');
        }
        arr.append(']');
        return "(function(){try{var s=" + arr
                + ";var st=document.createElement('style');st.setAttribute('data-nex-cosmetic','1');"
                + "(document.head||document.documentElement).appendChild(st);var sh=st.sheet;"
                + "for(var i=0;i<s.length;i++){try{sh.insertRule(s[i]+'{display:none !important}',sh.cssRules.length);}catch(e){}}"
                + "}catch(e){}})();";
    }

    private static String jsEscape(String s) {
        StringBuilder b = new StringBuilder(s.length() + 8);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\': b.append("\\\\"); break;
                case '"': b.append("\\\""); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '<': b.append("\\u003c"); break;   // can never close a surrounding <script>
                case '\u2028': b.append("\\u2028"); break;
                case '\u2029': b.append("\\u2029"); break;
                default: b.append(c);
            }
        }
        return b.toString();
    }
}
