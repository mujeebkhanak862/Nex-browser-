package com.devil.browser;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pure helpers for downloads / media detection / file names / formatting, split out of
 * MainActivity (no Android dependency, so they are unit-tested on a plain JVM).
 */
final class DownloadUtils {
    private DownloadUtils() {}

    // ---------------------------------------------------------------- media URL detection

    // Extension must END the token: ".ts" used to match inside "main.tsx" / "bundle.tsv" and ".mov"
    // inside "movie-reviews", offering a "Download video" for things that aren't one.
    private static final Pattern MEDIA_EXT = Pattern.compile(
            "\\.(mp4|webm|mkv|mov|m3u8|mp3|m4a|ts)(?![a-z0-9])");
    private static final String[] MEDIA_HOSTS = {
            "googlevideo.com", "tiktokcdn", "tiktokv.com", "fbcdn.net", "cdninstagram.com"};
    private static final String[] DIRECT_EXTS = {
            ".mp4", ".webm", ".mkv", ".mov", ".m3u8", ".mp3", ".m4a",
            ".jpg", ".jpeg", ".png", ".gif", ".pdf", ".zip", ".apk", ".rar", ".7z",
            ".doc", ".docx", ".xls", ".xlsx"};

    /** Path part of a URL (no query, no fragment), lowercase. */
    private static String lowerPath(String url) {
        String lower = url.toLowerCase(Locale.US);
        int q = lower.indexOf('?');
        if (q >= 0) lower = lower.substring(0, q);
        int h = lower.indexOf('#');
        if (h >= 0) lower = lower.substring(0, h);
        return lower;
    }

    static boolean isLikelyMediaUrl(String url) {
        if (url == null) return false;
        if (MEDIA_EXT.matcher(lowerPath(url)).find()) return true;
        String lower = url.toLowerCase(Locale.US);
        for (String h : MEDIA_HOSTS) if (lower.contains(h)) return true;
        return false;
    }

    static boolean isDirectMediaUrl(String url) {
        if (url == null) return false;
        String path = lowerPath(url);
        for (String ext : DIRECT_EXTS) if (path.endsWith(ext)) return true;
        return false;
    }

    // ---------------------------------------------------------------- HLS playlists

    private static final Pattern HLS_RESOLUTION = Pattern.compile("RESOLUTION=\\d+x(\\d+)");
    private static final Pattern HLS_BANDWIDTH = Pattern.compile("BANDWIDTH=(\\d+)");

    /** {label, absoluteUrl} per variant of an HLS master playlist. */
    static List<String[]> parseHlsMasterVariants(String playlistText, String baseUrl) throws MalformedURLException {
        List<String[]> variants = new ArrayList<>();
        String[] lines = playlistText.split("\n");
        URL base = new URL(baseUrl);
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            if (!line.startsWith("#EXT-X-STREAM-INF")) continue;
            String label = "Unknown quality";
            Matcher res = HLS_RESOLUTION.matcher(line);
            if (res.find()) {
                label = res.group(1) + "p";
            } else {
                Matcher bw = HLS_BANDWIDTH.matcher(line);
                if (bw.find()) label = "~" + (Long.parseLong(bw.group(1)) / 1000) + " kbps";
            }
            for (int j = i + 1; j < lines.length; j++) {
                String next = lines[j].trim();
                if (next.isEmpty() || next.startsWith("#")) continue;
                variants.add(new String[]{label, new URL(base, next).toString()});
                break;
            }
        }
        return variants;
    }

    static List<String> parseHlsSegments(String playlistText, String baseUrl) throws MalformedURLException {
        List<String> segs = new ArrayList<>();
        URL base = new URL(baseUrl);
        for (String raw : playlistText.split("\n")) {
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            segs.add(new URL(base, line).toString());
        }
        return segs;
    }

    /** "720p" -> 720, anything else -> 0 */
    static int extractQualityNumber(String label) {
        try {
            if (label.endsWith("p")) return Integer.parseInt(label.substring(0, label.length() - 1));
        } catch (Exception ignored) { /* not a "NNNp" label */ }
        return 0;
    }

    // ---------------------------------------------------------------- file names / types

    static String guessMimeFromFileName(String fileName) {
        String ext = "";
        int dot = fileName.lastIndexOf('.');
        if (dot >= 0) ext = fileName.substring(dot + 1).toLowerCase(Locale.US);
        switch (ext) {
            case "mp4": return "video/mp4";
            case "webm": return "video/webm";
            case "mkv": return "video/x-matroska";
            case "mov": return "video/quicktime";
            case "ts": return "video/mp2t";
            case "m3u8": return "application/vnd.apple.mpegurl";
            case "mp3": return "audio/mpeg";
            case "m4a": return "audio/mp4";
            case "jpg": case "jpeg": return "image/jpeg";
            case "png": return "image/png";
            case "gif": return "image/gif";
            case "pdf": return "application/pdf";
            case "zip": return "application/zip";
            case "apk": return "application/vnd.android.package-archive";
            default: return "application/octet-stream";
        }
    }

    /**
     * Makes a server/URL supplied name safe to use as a local file name:
     * no path separators or reserved characters, no control characters, never "." / "..",
     * and — when it has to be shortened — the extension is KEPT (the old code cut at 120 chars,
     * which chopped ".apk"/".pdf" off long names and defeated the risky-download check).
     */
    static String sanitizeFileName(String name, long nowMs) {
        String cleaned = name == null ? "" : name
                .replaceAll("[\\p{Cntrl}]", "")
                .replaceAll("[\\\\/:*?\"<>|]", "_")
                .trim();
        // names made only of dots/spaces ("..", ".", "...") are directory references, not names
        if (cleaned.replace(".", "").trim().isEmpty()) cleaned = "download_" + nowMs;
        while (cleaned.startsWith(".")) cleaned = cleaned.substring(1);   // no hidden / dot-leading names
        if (cleaned.isEmpty()) cleaned = "download_" + nowMs;
        final int max = 120;
        if (cleaned.length() > max) {
            int dot = cleaned.lastIndexOf('.');
            String ext = (dot > 0 && cleaned.length() - dot <= 12) ? cleaned.substring(dot) : "";
            cleaned = cleaned.substring(0, max - ext.length()) + ext;
        }
        return cleaned;
    }

    /**
     * Last path segment of a URL, percent-decoded exactly once. (The old code decoded twice,
     * so "C%2B%2B guide.pdf" became "C  guide.pdf" — '+' turned into a space — and a literal
     * "100%.pdf" threw and fell back to a timestamp name.)
     */
    static String guessFileNameFromUrl(String url, long nowMs) {
        try {
            String path = url;
            int scheme = path.indexOf("://");
            if (scheme >= 0) {
                int slash = path.indexOf('/', scheme + 3);
                path = slash >= 0 ? path.substring(slash) : "";
            }
            int cut = path.length();
            for (int i = 0; i < path.length(); i++) {
                char c = path.charAt(i);
                if (c == '?' || c == '#') { cut = i; break; }
            }
            path = path.substring(0, cut);
            int last = path.lastIndexOf('/');
            String segment = last >= 0 ? path.substring(last + 1) : path;
            if (!segment.isEmpty()) {
                // URLDecoder is for form data ('+' = space); in a URL PATH '+' is a literal plus.
                String decoded = URLDecoder.decode(segment.replace("+", "%2B"), "UTF-8");
                if (!decoded.trim().isEmpty()) return decoded;
            }
        } catch (UnsupportedEncodingException | IllegalArgumentException ignored) { /* bad %-escape: fall through */ }
        return "download_" + nowMs;
    }

    static boolean isImageDownloadExtension(String fileName) {
        String lower = fileName.toLowerCase(Locale.US);
        return lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png")
                || lower.endsWith(".webp") || lower.endsWith(".gif") || lower.endsWith(".bmp");
    }

    static boolean isRiskyDownloadExtension(String fileName) {
        String lower = fileName.toLowerCase(Locale.US);
        return lower.endsWith(".apk") || lower.endsWith(".exe") || lower.endsWith(".sh")
                || lower.endsWith(".bat") || lower.endsWith(".msi") || lower.endsWith(".dmg")
                || lower.endsWith(".scr") || lower.endsWith(".cmd");
    }

    static boolean isTextReadableExtension(String fileName) {
        String lower = fileName.toLowerCase(Locale.US);
        return lower.endsWith(".txt") || lower.endsWith(".md") || lower.endsWith(".csv")
                || lower.endsWith(".json") || lower.endsWith(".log") || lower.endsWith(".xml")
                || lower.endsWith(".html") || lower.endsWith(".htm") || lower.endsWith(".yaml")
                || lower.endsWith(".yml") || lower.endsWith(".ini") || lower.endsWith(".conf");
    }

    static boolean isPdfExtension(String fileName) {
        return fileName.toLowerCase(Locale.US).endsWith(".pdf");
    }

    /** Glob match ('*' any run, '?' one char) of a user-written pattern against a URL. */
    static boolean extensionMatches(String pattern, String url) {
        if (pattern == null || pattern.isEmpty() || pattern.equals("*")) return true;
        if (url == null) return false;
        StringBuilder regex = new StringBuilder();
        for (char c : pattern.toCharArray()) {
            if (c == '*') regex.append(".*");
            else if (c == '?') regex.append('.');
            else regex.append(Pattern.quote(String.valueOf(c)));
        }
        try {
            return url.matches(regex.toString());
        } catch (Exception e) {
            return false;
        }
    }

    // ---------------------------------------------------------------- formatting

    static String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024L * 1024) return (bytes / 1024) + " KB";
        if (bytes < 1024L * 1024 * 1024) return String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
        return String.format(Locale.US, "%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }

    static String formatDurationShort(long ms) {
        long totalSec = Math.max(0, ms / 1000);
        long m = totalSec / 60;
        long s = totalSec % 60;
        if (totalSec < 1) return "<1s";
        if (m == 0) return s + "s";
        if (s == 0) return m + "m";
        return m + "m " + s + "s";
    }

    static List<String> escapeCsvRow(List<String> cells) {
        List<String> escaped = new ArrayList<>();
        for (String cell : cells) {
            String safe = cell == null ? "" : cell.replace("\"", "\"\"");
            // Spreadsheet formula injection: a cell starting with = + - @ is executed by Excel/Sheets
            // when the CSV is opened. Prefix a quote so scraped web text can't run as a formula.
            if (!safe.isEmpty() && "=+-@\t\r".indexOf(safe.charAt(0)) >= 0 && !isPlainNumber(safe)) {
                safe = "'" + safe;
            }
            escaped.add("\"" + safe + "\"");
        }
        return escaped;
    }

    private static boolean isPlainNumber(String s) {
        return s.matches("[+-]?\\d+([.,]\\d+)?");
    }

    // ---------------------------------------------------------------- hosts

    private static final Pattern IPV4 = Pattern.compile("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$");

    /** localhost / emulator host / RFC1918 private IPv4 (a real IP, NOT a hostname like "10.example.com"). */
    static boolean isPrivateOrLocalHost(String host) {
        if (host == null) return false;
        host = host.toLowerCase(Locale.US);
        if (host.equals("localhost")) return true;
        Matcher m = IPV4.matcher(host);
        if (!m.matches()) return false;
        int a = Integer.parseInt(m.group(1)), b = Integer.parseInt(m.group(2));
        if (a > 255 || b > 255 || Integer.parseInt(m.group(3)) > 255 || Integer.parseInt(m.group(4)) > 255) return false;
        return a == 127 || a == 10 || (a == 192 && b == 168) || (a == 172 && b >= 16 && b <= 31);
    }
}
