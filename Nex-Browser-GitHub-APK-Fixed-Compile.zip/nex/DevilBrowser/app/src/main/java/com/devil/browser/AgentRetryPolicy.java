package com.devil.browser;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Agent step retry rules + the deterministic error classifier (#59 Adaptive Retry, #75 Error
 * Classification), split out of MainActivity so they are unit-testable on a plain JVM.
 * Retry counters are in memory only: a fresh app session resuming a job is a legitimate first
 * attempt again.
 */
final class AgentRetryPolicy {
    static final int MAX_STEP_RETRIES = 2; // 2 retries = 3 attempts total

    private final Map<String, Integer> counts = new HashMap<>();

    private static String key(int jobId, int index) { return jobId + ":" + index; }

    static String classifyError(String error) {
        if (error == null || error.isEmpty()) return "unknown";
        String r = error.toLowerCase(Locale.US);
        if (r.contains("captcha") || r.contains("verify you are human") || r.contains("i'm not a robot") || r.contains("i am not a robot")) return "captcha";
        if (r.contains("permission") || r.contains("denied") || r.contains("unauthorized") || r.contains(" 401") || r.contains(" 403")) return "permission_denied";
        if (r.contains("timed out") || r.contains("timeout")) return "timeout";
        if (r.contains("not found") || r.contains("couldn't find") || r.contains("could not find") || r.contains("no element") || r.contains("field not found")) return "element_not_found";
        if (r.contains("didn't check out") || r.contains("verification")) return "verification_failed";
        if (r.contains("network") || r.contains("unable to resolve host") || r.contains("failed to connect") || r.contains("connection") || r.contains("unreachable")) return "network";
        if (r.contains("redirected") || r.contains("navigated away") || r.contains("page changed")) return "page_changed";
        return "unknown";
    }

    static String categoryLabel(String category) {
        switch (category) {
            case "captcha": return "🤖 CAPTCHA";
            case "permission_denied": return "🔒 Permission";
            case "timeout": return "⏱ Timeout";
            case "element_not_found": return "🔍 Not found";
            case "verification_failed": return "🔍 Verification";
            case "network": return "🔌 Network";
            case "page_changed": return "↪ Page changed";
            default: return "⚠ Error";
        }
    }

    static long adaptiveDelayMs(String reason, int attemptNumber) {
        long base;
        switch (classifyError(reason)) {
            case "timeout": base = 1000; break;            // probably just a slow response
            case "element_not_found": base = 1800; break;  // page may still be rendering
            case "network": base = 1500; break;            // brief connectivity blip
            default: base = 1200;
        }
        return base * attemptNumber;
    }

    /** True (and reserves an attempt) if this step may be retried once more. A CAPTCHA or a
     *  permission wall gives up immediately: retrying cannot fix it, a human has to. */
    boolean shouldRetry(int jobId, int index, String reason) {
        String k = key(jobId, index);
        String category = classifyError(reason);
        if (category.equals("captcha") || category.equals("permission_denied")) {
            counts.remove(k);
            return false;
        }
        int attempts = counts.getOrDefault(k, 0);
        if (attempts >= MAX_STEP_RETRIES) {
            counts.remove(k);
            return false;
        }
        counts.put(k, attempts + 1);
        return true;
    }

    int attemptNumber(int jobId, int index) { return counts.getOrDefault(key(jobId, index), 0); }

    void clear(int jobId, int index) { counts.remove(key(jobId, index)); }

    /** Forget every step counter of a job (job restarted / cancelled). */
    void clearJob(int jobId) { counts.keySet().removeIf(k -> k.startsWith(jobId + ":")); }
}
