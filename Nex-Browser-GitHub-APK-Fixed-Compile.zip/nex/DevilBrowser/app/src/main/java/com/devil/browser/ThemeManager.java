package com.devil.browser;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatDelegate;

/**
 * Theme Center foundation (Blueprint section on Appearance / Design v2's
 * Theme/Customize Side Panel doc). This is Phase 1 + the "Appearance"
 * slice of Phase 2 from the gap-report build plan: Light/Dark/System mode
 * switching, backed by real day/night color resources
 * (values/colors.xml = Light, values-night/colors.xml = Dark overrides).
 *
 * Deliberately NOT covered here (left for a later phase, per the build
 * plan, so this doesn't turn into one giant unreviewable change):
 * built-in theme gallery, "My Themes", personal-image theme, custom
 * color picker, and the wider "universal side panel" that would also
 * host Bookmarks/History/AI/Agent. This class only owns the three-way
 * Light/Dark/System switch and where it's saved.
 */
public class ThemeManager {

    public static final String MODE_LIGHT = "light";
    public static final String MODE_DARK = "dark";
    public static final String MODE_SYSTEM = "system";

    private static final String PREFS_NAME = "theme_prefs";
    private static final String KEY_MODE = "mode";

    // The app shipped as dark-only before this change, so "dark" stays the
    // default for anyone who hasn't explicitly picked a mode yet — picking
    // Light or System is an opt-in, not a surprise re-theme on update.
    private static final String DEFAULT_MODE = MODE_DARK;

    private ThemeManager() {}

    public static String getSavedMode(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getString(KEY_MODE, DEFAULT_MODE);
    }

    /**
     * Applies the saved mode via AppCompatDelegate. Must be called before
     * super.onCreate()/setContentView() in every Activity that should honor
     * the chosen theme, so the correct color resource set (values vs
     * values-night) is already active on first layout inflation.
     */
    public static void apply(Context context) {
        applyMode(getSavedMode(context));
    }

    /**
     * Saves the new mode and applies it immediately. The caller is
     * responsible for recreating any visible Activity afterward
     * (AppCompatDelegate does not retroactively re-color an already
     * inflated screen).
     */
    public static void setMode(Context context, String mode) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_MODE, mode).apply();
        applyMode(mode);
    }

    private static void applyMode(String mode) {
        switch (mode) {
            case MODE_LIGHT:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                break;
            case MODE_SYSTEM:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
                break;
            case MODE_DARK:
            default:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                break;
        }
    }

    // ================================================================
    // CUSTOM ACCENT COLOR — first slice of the design docs' "built-in
    // theme gallery" beyond just the Home-background gradients (see
    // HOME-BACKGROUND-IMAGE-CHANGES.md for those). Each preset carries a
    // light-mode AND dark-mode value, same as the app's original "ember"
    // token did, so contrast stays correct in both modes rather than
    // picking one raw hex that might wash out on one background.
    //
    // SCOPE NOTE: this only repaints the ~20 spots in MainActivity.java
    // that read the accent color at runtime via getAccentColor() below
    // (icons, labels, progress fills, checkmarks). Five spots baked into
    // static XML — themes.xml's colorSecondary, the Go-button background,
    // and two card-border drawables — still use the fixed brand "Violet"
    // color regardless of the chosen preset. Making those dynamic too
    // would mean generating those drawables in code instead of XML; left
    // for a later pass rather than silently faked here.
    // ================================================================
    public static final class AccentPreset {
        public final String name;
        public final int lightColor;
        public final int darkColor;
        public AccentPreset(String name, int lightColor, int darkColor) {
            this.name = name;
            this.lightColor = lightColor;
            this.darkColor = darkColor;
        }
    }

    public static final AccentPreset[] ACCENT_PRESETS = {
            new AccentPreset("Violet", 0xFF7A4FE0, 0xFFB48CFF), // brand default — matches @color/ember
            new AccentPreset("Rose",   0xFFD6478A, 0xFFFF9ECF), // matches @color/gold
            new AccentPreset("Ocean",  0xFF1E88C7, 0xFF66C2FF),
            new AccentPreset("Forest", 0xFF2E8B57, 0xFF6FCF97),
            new AccentPreset("Amber",  0xFFC97A1B, 0xFFFFC266),
    };

    private static final String KEY_ACCENT_LIGHT = "accent_light";
    private static final String KEY_ACCENT_DARK = "accent_dark";
    private static final String KEY_ACCENT_NAME = "accent_name";

    /** Returns the accent color for whichever mode (light/dark) is
     *  currently active, based on the resolved night-mode configuration —
     *  not the saved Appearance preference, so this stays correct even
     *  under System mode where the OS decides. */
    public static int getAccentColor(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        boolean isNight = (context.getResources().getConfiguration().uiMode
                & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        int fallback = isNight ? ACCENT_PRESETS[0].darkColor : ACCENT_PRESETS[0].lightColor;
        return prefs.getInt(isNight ? KEY_ACCENT_DARK : KEY_ACCENT_LIGHT, fallback);
    }

    public static String getAccentPresetName(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getString(KEY_ACCENT_NAME, ACCENT_PRESETS[0].name);
    }

    public static void setAccentPreset(Context context, AccentPreset preset) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit()
                .putInt(KEY_ACCENT_LIGHT, preset.lightColor)
                .putInt(KEY_ACCENT_DARK, preset.darkColor)
                .putString(KEY_ACCENT_NAME, preset.name)
                .apply();
    }

    /**
     * Applies the ThemeOverlay matching the saved accent preset's *name*
     * (not its stored colors) when the name is one of the five built-in
     * presets. For anything else — most importantly Custom RGB, which by
     * definition has no compiled color resource of its own — this used to
     * silently fall back to Violet's overlay regardless of the actual
     * chosen color (report gap G: "the static colorSecondary overlay
     * itself is not custom-RGB-aware"). It still can't inject an arbitrary
     * runtime RGB value into a compiled theme attribute — Android theme
     * overlays need a resource id, not an int — but it CAN pick whichever
     * of the five compiled overlays is visually closest to the actual
     * custom color instead of defaulting to Violet regardless of what the
     * user picked. Every place that explicitly reads
     * ThemeManager.getAccentColor() (the ~22 spots in
     * ACCENT-COLOR-CHANGES.md, plus every explicitly-tinted Switch/
     * CheckBox already in this codebase) still shows the exact custom
     * color; this only narrows the fallback for the few Material widgets
     * that rely purely on the theme's colorSecondary attribute and were
     * never explicitly tinted.
     * <p>
     * Must be called on an Activity after super.onCreate() but before
     * setContentView(), same requirement Android documents for any
     * getTheme().applyStyle() call.
     */
    public static void applyAccentOverlay(android.app.Activity activity) {
        String name = getAccentPresetName(activity);
        int overlayRes;
        switch (name) {
            case "Rose":   overlayRes = R.style.ThemeOverlay_Nex_Accent_Rose;   break;
            case "Ocean":  overlayRes = R.style.ThemeOverlay_Nex_Accent_Ocean;  break;
            case "Forest": overlayRes = R.style.ThemeOverlay_Nex_Accent_Forest; break;
            case "Amber":  overlayRes = R.style.ThemeOverlay_Nex_Accent_Amber;  break;
            case "Violet": overlayRes = R.style.ThemeOverlay_Nex_Accent_Violet; break;
            default:       overlayRes = nearestPresetOverlay(getAccentColor(activity)); break;
        }
        activity.getTheme().applyStyle(overlayRes, true);
    }

    /** Simple Euclidean RGB distance to each built-in preset's light
     *  color, returning that preset's overlay resource — the closest
     *  visual match a compiled ThemeOverlay can give an arbitrary Custom
     *  RGB color, since no resource can be compiled for a runtime-chosen
     *  int. Only used as the colorSecondary theme-attribute fallback (see
     *  applyAccentOverlay above); it never affects the exact color used
     *  everywhere getAccentColor() is read directly. */
    private static int nearestPresetOverlay(int color) {
        int[] overlays = {
                R.style.ThemeOverlay_Nex_Accent_Violet,
                R.style.ThemeOverlay_Nex_Accent_Rose,
                R.style.ThemeOverlay_Nex_Accent_Ocean,
                R.style.ThemeOverlay_Nex_Accent_Forest,
                R.style.ThemeOverlay_Nex_Accent_Amber,
        };
        int bestOverlay = overlays[0];
        long bestDistance = Long.MAX_VALUE;
        for (int i = 0; i < ACCENT_PRESETS.length; i++) {
            int preset = ACCENT_PRESETS[i].lightColor;
            long dr = ((color >> 16) & 0xFF) - ((preset >> 16) & 0xFF);
            long dg = ((color >> 8) & 0xFF) - ((preset >> 8) & 0xFF);
            long db = (color & 0xFF) - (preset & 0xFF);
            long distance = dr * dr + dg * dg + db * db;
            if (distance < bestDistance) {
                bestDistance = distance;
                bestOverlay = overlays[i];
            }
        }
        return bestOverlay;
    }

    // ================================================================
    // Gap F (two sources of truth for the built-in accents): colors.xml
    // (values/ + values-night/) is the source of truth; see
    // syncAccentPresetsFromResources() below.
    // ================================================================
    private static boolean accentPresetsSynced = false;

    /** A Context whose resources are resolved for light (nightMode=false) or dark mode,
     *  regardless of what the device/activity is currently showing. */
    private static Context contextForMode(Context base, boolean night) {
        android.content.res.Configuration cfg = new android.content.res.Configuration(base.getResources().getConfiguration());
        int nightBits = night ? android.content.res.Configuration.UI_MODE_NIGHT_YES
                              : android.content.res.Configuration.UI_MODE_NIGHT_NO;
        cfg.uiMode = (cfg.uiMode & ~android.content.res.Configuration.UI_MODE_NIGHT_MASK) | nightBits;
        return base.createConfigurationContext(cfg);
    }

    /**
     * Makes colors.xml (values/ = light, values-night/ = dark) the single source of
     * truth for BOTH sides of every built-in accent preset: the Java constants above are
     * only a fallback if a resource can't be read. (Previously only the light side was
     * synced, and it was read through the CURRENT configuration — so on a phone that
     * happened to be in dark mode at startup the "light" accent was overwritten with the
     * dark value.)
     */
    public static void syncAccentPresetsFromResources(Context context) {
        if (accentPresetsSynced) return;
        int[] resIds = {
                R.color.accent_violet, R.color.accent_rose,
                R.color.accent_ocean, R.color.accent_forest, R.color.accent_amber,
        };
        try {
            Context light = contextForMode(context, false);
            Context dark = contextForMode(context, true);
            for (int i = 0; i < ACCENT_PRESETS.length && i < resIds.length; i++) {
                int lightRes = light.getColor(resIds[i]);
                int darkRes = dark.getColor(resIds[i]);
                if (lightRes != ACCENT_PRESETS[i].lightColor || darkRes != ACCENT_PRESETS[i].darkColor) {
                    ACCENT_PRESETS[i] = new AccentPreset(ACCENT_PRESETS[i].name, lightRes, darkRes);
                }
            }
        } catch (Exception ignored) {
            // Resource missing/unreadable — keep the Java literals as a safe fallback
            // rather than crash theme setup over this.
        }
        accentPresetsSynced = true;
    }

    // ================================================================
    // Closing the scope gap flagged in ACCENT-COLOR-CHANGES.md: the Go
    // button and two card-border drawables were left on the fixed brand
    // "Violet" because they were static XML <shape> resources rather than
    // something read at runtime. These three builders recreate the same
    // shapes in code instead, using the live accent color, and are called
    // from MainActivity right after each view is found/created — the
    // original bg_go_button.xml / bg_home_add_card.xml /
    // bg_new_tab_prominent.xml drawables are left in place unused rather
    // than deleted, in case a future pass wants them as a reference or a
    // fallback.
    // ================================================================

    /** Darkens (factor<1) or lightens (factor>1) a color's HSV value
     *  channel, preserving hue/saturation/alpha. Used to synthesize a
     *  second gradient stop from a single accent color, the same way the
     *  original ember->gold gradients paired two related hues. */
    /**
     * Gap G (custom RGB accent): a compiled ThemeOverlay can only point at a fixed colour
     * resource, so widgets that take their colour purely from the theme (check boxes, seek bars,
     * progress bars, text cursors, switches) used to show the NEAREST PRESET instead of the exact
     * custom colour. Walking a finished view tree and tinting those widgets directly closes that
     * gap for every screen and dialog without touching the ~90 places that build them.
     * Safe to call repeatedly. Never changes backgrounds, so custom-drawn boxes keep their look.
     */
    public static void tintViewTree(android.view.View root, int accent) {
        if (root == null) return;
        if (root instanceof android.widget.Switch) {
            android.widget.Switch sw = (android.widget.Switch) root;
            sw.setThumbTintList(new android.content.res.ColorStateList(
                    new int[][]{{android.R.attr.state_checked}, {}},
                    new int[]{accent, 0xFF8A8A93}));
            sw.setTrackTintList(new android.content.res.ColorStateList(
                    new int[][]{{android.R.attr.state_checked}, {}},
                    new int[]{shade(accent, 0.6f), 0xFF3A3A44}));
        } else if (root instanceof android.widget.CompoundButton) {            // CheckBox, RadioButton
            ((android.widget.CompoundButton) root).setButtonTintList(
                    new android.content.res.ColorStateList(
                            new int[][]{{android.R.attr.state_checked}, {}},
                            new int[]{accent, 0xFF8A8A93}));
        } else if (root instanceof android.widget.SeekBar) {
            android.widget.SeekBar sb = (android.widget.SeekBar) root;
            android.content.res.ColorStateList c = android.content.res.ColorStateList.valueOf(accent);
            sb.setThumbTintList(c);
            sb.setProgressTintList(c);
        } else if (root instanceof android.widget.ProgressBar) {
            android.widget.ProgressBar pb = (android.widget.ProgressBar) root;
            android.content.res.ColorStateList c = android.content.res.ColorStateList.valueOf(accent);
            pb.setIndeterminateTintList(c);
            pb.setProgressTintList(c);
        } else if (root instanceof android.widget.EditText) {
            android.widget.EditText et = (android.widget.EditText) root;
            et.setHighlightColor((accent & 0x00FFFFFF) | 0x55000000);          // text-selection background
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                android.graphics.drawable.Drawable cursor = et.getTextCursorDrawable();
                if (cursor != null) {
                    cursor = cursor.mutate();
                    cursor.setTint(accent);
                    et.setTextCursorDrawable(cursor);
                }
            }
        }
        if (root instanceof android.view.ViewGroup) {
            android.view.ViewGroup g = (android.view.ViewGroup) root;
            for (int i = 0; i < g.getChildCount(); i++) tintViewTree(g.getChildAt(i), accent);
        }
    }

    public static int shade(int color, float factor) {
        float[] hsv = new float[3];
        android.graphics.Color.colorToHSV(color, hsv);
        hsv[2] = Math.max(0f, Math.min(1f, hsv[2] * factor));
        return android.graphics.Color.HSVToColor(android.graphics.Color.alpha(color), hsv);
    }

    /** Oval gradient, replaces bg_go_button.xml (ember -> gold, 135°). */
    public static android.graphics.drawable.GradientDrawable buildGoButtonDrawable(Context context) {
        int accent = getAccentColor(context);
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.BR_TL,
                new int[]{accent, shade(accent, 0.8f)});
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        return d;
    }

    /** Rounded-rect gradient, replaces bg_new_tab_prominent.xml (ember -> gold, 0°). */
    public static android.graphics.drawable.GradientDrawable buildProminentCardDrawable(Context context, float cornerRadiusPx) {
        int accent = getAccentColor(context);
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{accent, shade(accent, 0.8f)});
        d.setCornerRadius(cornerRadiusPx);
        return d;
    }

    /** Dashed-stroke rounded rect, replaces bg_home_add_card.xml. */
    public static android.graphics.drawable.GradientDrawable buildAddCardDrawable(Context context, float cornerRadiusPx, float strokeWidthPx, float dashWidthPx, float dashGapPx) {
        int accent = getAccentColor(context);
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        d.setColor(android.graphics.Color.TRANSPARENT);
        d.setCornerRadius(cornerRadiusPx);
        d.setStroke((int) strokeWidthPx, accent, dashWidthPx, dashGapPx);
        return d;
    }
}
