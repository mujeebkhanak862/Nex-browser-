package com.devil.browser;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class AgentRetryPolicyTest {

    @Test
    public void classification() {
        assertEquals("captcha", AgentRetryPolicy.classifyError("Please verify you are human"));
        assertEquals("permission_denied", AgentRetryPolicy.classifyError("HTTP 403 Forbidden"));
        assertEquals("timeout", AgentRetryPolicy.classifyError("Step timed out after 20s"));
        assertEquals("element_not_found", AgentRetryPolicy.classifyError("Couldn't find the Login button"));
        assertEquals("network", AgentRetryPolicy.classifyError("Unable to resolve host x.com"));
        assertEquals("page_changed", AgentRetryPolicy.classifyError("Page redirected unexpectedly"));
        assertEquals("unknown", AgentRetryPolicy.classifyError(null));
        assertEquals("unknown", AgentRetryPolicy.classifyError("something odd"));
        assertEquals("🤖 CAPTCHA", AgentRetryPolicy.categoryLabel("captcha"));
        assertEquals("⚠ Error", AgentRetryPolicy.categoryLabel("unknown"));
    }

    @Test
    public void delaysGrowWithAttemptAndDependOnCategory() {
        assertEquals(1000, AgentRetryPolicy.adaptiveDelayMs("timeout", 1));
        assertEquals(3600, AgentRetryPolicy.adaptiveDelayMs("element not found", 2));
        assertEquals(1500, AgentRetryPolicy.adaptiveDelayMs("network down", 1));
        assertEquals(1200, AgentRetryPolicy.adaptiveDelayMs("weird", 1));
    }

    @Test
    public void retriesAreCappedAndCaptchaGivesUpImmediately() {
        AgentRetryPolicy p = new AgentRetryPolicy();
        assertTrue(p.shouldRetry(1, 0, "timeout"));
        assertEquals(1, p.attemptNumber(1, 0));
        assertTrue(p.shouldRetry(1, 0, "timeout"));
        assertFalse("third retry refused (2 retries = 3 attempts)", p.shouldRetry(1, 0, "timeout"));
        assertEquals("counter cleared after exhaustion", 0, p.attemptNumber(1, 0));
        assertFalse("captcha never retried", p.shouldRetry(1, 1, "Captcha challenge"));
        assertFalse("permission wall never retried", p.shouldRetry(1, 2, "Access denied"));
        assertEquals(0, p.attemptNumber(1, 1));
    }

    @Test
    public void clearingAJobOnlyClearsThatJob() {
        AgentRetryPolicy p = new AgentRetryPolicy();
        p.shouldRetry(1, 0, "x"); p.shouldRetry(1, 3, "x"); p.shouldRetry(12, 0, "x");
        p.clearJob(1);
        assertEquals(0, p.attemptNumber(1, 0));
        assertEquals(0, p.attemptNumber(1, 3));
        assertEquals("job 12 untouched even though '12' starts with '1'", 1, p.attemptNumber(12, 0));
        p.clear(12, 0);
        assertEquals(0, p.attemptNumber(12, 0));
    }
}
