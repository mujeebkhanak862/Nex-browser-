package com.devil.browser;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

public class DownloadUtilsTest {

    @Test
    public void mediaDetectionDoesNotMatchLookalikeExtensions() {
        assertTrue(DownloadUtils.isLikelyMediaUrl("https://x.com/a/clip.mp4?token=1"));
        assertTrue(DownloadUtils.isLikelyMediaUrl("https://x.com/live/seg001.ts"));
        assertTrue(DownloadUtils.isLikelyMediaUrl("https://x.com/stream/playlist.m3u8#t=3"));
        assertTrue(DownloadUtils.isLikelyMediaUrl("https://rr1---sn.googlevideo.com/videoplayback?id=1"));
        assertFalse("tsx source file is not video", DownloadUtils.isLikelyMediaUrl("https://x.com/src/main.tsx"));
        assertFalse("tsv is not video", DownloadUtils.isLikelyMediaUrl("https://x.com/data/export.tsv"));
        assertFalse("'.mov' inside a word", DownloadUtils.isLikelyMediaUrl("https://x.com/movie.movies-list"));
        assertFalse("extension only in query", DownloadUtils.isLikelyMediaUrl("https://x.com/page?file=a.mp4"));
        assertTrue(DownloadUtils.isDirectMediaUrl("https://x.com/report.PDF?dl=1"));
        assertFalse(DownloadUtils.isDirectMediaUrl("https://x.com/report.pdf.html"));
    }

    @Test
    public void hlsParsing() throws Exception {
        String master = "#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=800000,RESOLUTION=640x360\nlow/index.m3u8\n"
                + "#EXT-X-STREAM-INF:BANDWIDTH=2400000,RESOLUTION=1280x720\n/abs/hd.m3u8\n"
                + "#EXT-X-STREAM-INF:BANDWIDTH=128000\n\n# comment\naudio.m3u8\n";
        List<String[]> v = DownloadUtils.parseHlsMasterVariants(master, "https://cdn.x.com/v/master.m3u8");
        assertEquals(3, v.size());
        assertEquals("360p", v.get(0)[0]);
        assertEquals("https://cdn.x.com/v/low/index.m3u8", v.get(0)[1]);
        assertEquals("https://cdn.x.com/abs/hd.m3u8", v.get(1)[1]);
        assertEquals("~128 kbps", v.get(2)[0]);
        assertEquals("https://cdn.x.com/v/audio.m3u8", v.get(2)[1]);
        List<String> segs = DownloadUtils.parseHlsSegments("#EXTM3U\n#EXTINF:4,\nseg1.ts\n\nseg2.ts\n#EXT-X-ENDLIST\n", "https://cdn.x.com/v/low/index.m3u8");
        assertEquals(Arrays.asList("https://cdn.x.com/v/low/seg1.ts", "https://cdn.x.com/v/low/seg2.ts"), segs);
        assertEquals(720, DownloadUtils.extractQualityNumber("720p"));
        assertEquals(0, DownloadUtils.extractQualityNumber("~128 kbps"));
    }

    @Test
    public void fileNamesFromUrlAreDecodedExactlyOnce() {
        assertEquals("C++ guide.pdf", DownloadUtils.guessFileNameFromUrl("https://x.com/files/C%2B%2B%20guide.pdf?dl=1", 1));
        assertEquals("a+b.pdf", DownloadUtils.guessFileNameFromUrl("https://x.com/a+b.pdf", 1));
        assertEquals("100%.pdf", DownloadUtils.guessFileNameFromUrl("https://x.com/100%25.pdf", 1));
        assertEquals("download_7", DownloadUtils.guessFileNameFromUrl("https://x.com/", 7));
        assertEquals("download_7", DownloadUtils.guessFileNameFromUrl("https://x.com/bad%zz", 7));
        assertEquals("résumé.pdf", DownloadUtils.guessFileNameFromUrl("https://x.com/r%C3%A9sum%C3%A9.pdf#top", 1));
    }

    @Test
    public void sanitizedNamesAreSafeAndKeepTheirExtension() {
        assertEquals("a_b_c.txt", DownloadUtils.sanitizeFileName("a/b\\c.txt", 5));
        assertEquals("download_5", DownloadUtils.sanitizeFileName("..", 5));
        assertEquals("download_5", DownloadUtils.sanitizeFileName(".", 5));
        assertEquals("download_5", DownloadUtils.sanitizeFileName("   ", 5));
        assertEquals("download_5", DownloadUtils.sanitizeFileName(null, 5));
        assertEquals("bashrc", DownloadUtils.sanitizeFileName(".bashrc", 5));
        assertEquals("evilname.apk", DownloadUtils.sanitizeFileName("evil\nname\u0000.apk", 5));
        assertEquals(".._.._etc_passwd".replaceAll("^\\.+", ""), DownloadUtils.sanitizeFileName("../../etc/passwd", 5));
        StringBuilder longName = new StringBuilder();
        for (int i = 0; i < 200; i++) longName.append('x');
        String s = DownloadUtils.sanitizeFileName(longName + ".apk", 5);
        assertTrue("length capped", s.length() <= 120);
        assertTrue("extension survived truncation: " + s, s.endsWith(".apk"));
        assertTrue("risky extension still detected", DownloadUtils.isRiskyDownloadExtension(s));
    }

    @Test
    public void typesAndMime() {
        assertEquals("video/mp4", DownloadUtils.guessMimeFromFileName("a.MP4"));
        assertEquals("application/octet-stream", DownloadUtils.guessMimeFromFileName("noext"));
        assertTrue(DownloadUtils.isRiskyDownloadExtension("setup.EXE"));
        assertFalse(DownloadUtils.isRiskyDownloadExtension("setup.exe.txt"));
        assertTrue(DownloadUtils.isPdfExtension("A.PdF"));
        assertTrue(DownloadUtils.isTextReadableExtension("notes.md"));
        assertTrue(DownloadUtils.isImageDownloadExtension("p.WEBP"));
        assertTrue(DownloadUtils.extensionMatches("*.pdf", "https://x.com/a.pdf"));
        assertFalse(DownloadUtils.extensionMatches("*.pdf", "https://x.com/a.pdf.exe"));
        assertTrue(DownloadUtils.extensionMatches("*", "anything"));
        assertTrue("regex metacharacters are literal", DownloadUtils.extensionMatches("a(b).txt", "a(b).txt"));
    }

    @Test
    public void formatting() {
        assertEquals("0 B", DownloadUtils.formatBytes(0));
        assertEquals("1 KB", DownloadUtils.formatBytes(1536));
        assertEquals("1.5 MB", DownloadUtils.formatBytes(1536 * 1024));
        assertEquals("5.0 GB", DownloadUtils.formatBytes(5L * 1024 * 1024 * 1024));
        assertEquals("<1s", DownloadUtils.formatDurationShort(400));
        assertEquals("45s", DownloadUtils.formatDurationShort(45_000));
        assertEquals("2m", DownloadUtils.formatDurationShort(120_000));
        assertEquals("2m 5s", DownloadUtils.formatDurationShort(125_000));
        assertEquals("<1s", DownloadUtils.formatDurationShort(-5));
    }

    @Test
    public void csvEscapingStopsFormulaInjection() {
        List<String> out = DownloadUtils.escapeCsvRow(Arrays.asList("plain", "say \"hi\"", null, "=HYPERLINK(\"http://evil\")", "@SUM(A1)", "-5", "+1,5", "-cmd|' /C calc'!A0"));
        assertEquals("\"plain\"", out.get(0));
        assertEquals("\"say \"\"hi\"\"\"", out.get(1));
        assertEquals("\"\"", out.get(2));
        assertTrue(out.get(3).startsWith("\"'="));
        assertTrue(out.get(4).startsWith("\"'@"));
        assertEquals("numbers stay numbers", "\"-5\"", out.get(5));
        assertEquals("\"+1,5\"", out.get(6));
        assertTrue(out.get(7).startsWith("\"'-"));
    }

    @Test
    public void privateHosts() {
        assertTrue(DownloadUtils.isPrivateOrLocalHost("localhost"));
        assertTrue(DownloadUtils.isPrivateOrLocalHost("127.0.0.1"));
        assertTrue(DownloadUtils.isPrivateOrLocalHost("10.0.2.2"));
        assertTrue(DownloadUtils.isPrivateOrLocalHost("192.168.1.20"));
        assertTrue(DownloadUtils.isPrivateOrLocalHost("172.16.0.1"));
        assertTrue(DownloadUtils.isPrivateOrLocalHost("172.31.255.255"));
        assertFalse(DownloadUtils.isPrivateOrLocalHost("172.32.0.1"));
        assertFalse("hostname that merely starts with 10.", DownloadUtils.isPrivateOrLocalHost("10.example.com"));
        assertFalse(DownloadUtils.isPrivateOrLocalHost("192.168.example.com"));
        assertFalse(DownloadUtils.isPrivateOrLocalHost("8.8.8.8"));
        assertFalse(DownloadUtils.isPrivateOrLocalHost("999.1.1.1"));
        assertFalse(DownloadUtils.isPrivateOrLocalHost(null));
    }
}
