package com.devil.browser;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.io.*;
import java.util.*;

public class AdFilterEngineTest {
    private static void check(String name, boolean ok) { assertTrue(name, ok); }
    private static void eq(String name, Object actual, Object expected) { assertEquals(name, expected, actual); }

    @Test
    public void engineBehaviour() throws Exception {
        Map<String, String> builtin = new HashMap<>();
        builtin.put("criteo.com", "Banners"); builtin.put("adservice.google.com", "Banners");
        AdFilterEngine e = new AdFilterEngine(builtin);

        // --- host helpers
        eq("hostOf plain", AdFilterEngine.hostOf("https://Static.Criteo.com/x.js?a=b"), "static.criteo.com");
        eq("hostOf port+userinfo", AdFilterEngine.hostOf("http://user:pw@ads.example.com:8080/p"), "ads.example.com");
        eq("hostOf weird chars survive", AdFilterEngine.hostOf("https://ads.example.com/a|b{c}?x=1 2"), "ads.example.com");
        eq("hostOf no scheme", AdFilterEngine.hostOf("not a url"), null);
        eq("pathOf", AdFilterEngine.pathOf("https://h.com/Ads/Banner.js?x=1#f"), "/ads/banner.js");
        eq("pathOf none", AdFilterEngine.pathOf("https://h.com"), "");

        // --- builtin matching
        eq("builtin subdomain blocked", e.match("https://static.criteo.com/a.js"), "criteo.com");
        eq("builtin exact blocked", e.match("https://adservice.google.com/x"), "adservice.google.com");
        eq("parent google.com NOT blocked", e.match("https://www.google.com/search"), null);
        eq("domain only in query not blocked", e.match("https://news.com/a?ref=criteo.com"), null);
        eq("domain only in path not blocked", e.match("https://news.com/criteo.com/story"), null);
        eq("lookalike host not blocked", e.match("https://criteo.com.evil.org/x"), null);
        eq("category builtin", e.categoryOf("https://criteo.com/x"), "Banners");
        eq("category none", e.categoryOf("https://example.org/"), "Other");

        // --- parsing
        String list = String.join("\n",
            "! Title", "[Adblock Plus 2.0]", "||ads.example.com^", "||tracker.net^$third-party",
            "||news.site/ads/banner^", "||news.site/a/", "@@||good.com^", "@@||shop.com/ok/path",
            "##.ad-banner", "###sponsored-box", "example.com##.sidebar-ad", "a.com,b.com##div[class^=\"promo-\"]",
            "c.com##div:has-text(Sponsored)", "c.com##+js(aopr, x)", "~d.com##.x", "0.0.0.0 evil-ads.io",
            "127.0.0.1 localhost", "# hosts comment", "plain-domain.xyz", "/ads/banner.gif", "x.com#@#.ad",
            "||good.com/tracking/", "||BIG.Mixed.Case.net^");
        AdFilterEngine.Rules r = e.parse(new BufferedReader(new StringReader(list)));
        eq("blockHosts", new TreeSet<>(r.blockHosts), new TreeSet<>(Arrays.asList("ads.example.com", "evil-ads.io", "plain-domain.xyz", "big.mixed.case.net")));
        eq("allowHosts", r.allowHosts, new HashSet<>(Collections.singleton("good.com")));
        eq("short path /a/ rejected, long accepted", r.pathRules.get("news.site"), Arrays.asList("/ads/banner"));
        eq("generic cosmetic", r.genericCss, Arrays.asList(".ad-banner", "#sponsored-box"));
        eq("domain cosmetic keys", new TreeSet<>(r.domainCss.keySet()), new TreeSet<>(Arrays.asList("example.com", "a.com", "b.com")));
        check("has-text / +js / negated skipped", !r.domainCss.containsKey("c.com") && !r.domainCss.containsKey("d.com"));
        e.replace(r);

        // --- matching with imported rules
        eq("imported host blocked", e.match("https://x.ads.example.com/p"), "ads.example.com");
        eq("path rule blocks under path", e.match("https://news.site/ads/banner.js"), "news.site");
        eq("path rule leaves rest of site", e.match("https://news.site/article/1"), null);
        eq("path rule applies to subdomain", e.match("https://img.news.site/ads/banner/x"), "news.site");
        eq("exception wins", e.match("https://good.com/tracking/pixel"), null);
        AdFilterEngine withBuiltinGood = new AdFilterEngine(new HashMap<>(Collections.singletonMap("good.com", "Banners")));
        withBuiltinGood.replace(r);
        eq("exception beats builtin", withBuiltinGood.match("https://good.com/x"), null);
        eq("imported category defaults", e.categoryOf("https://evil-ads.io/x"), "Banners");

        // --- cosmetic script
        String js = e.cosmeticScript("https://example.com/page");
        check("cosmetic has generic + domain selectors", js != null && js.contains(".ad-banner") && js.contains(".sidebar-ad"));
        check("cosmetic script escapes quotes", e.cosmeticScript("https://a.com/").contains("div[class^=\\\"promo-\\\"]"));
        eq("no domain rules for other site -> generic only", e.cosmeticScript("https://other.org/").contains(".sidebar-ad"), false);
        eq("exception host not hidden", e.cosmeticScript("https://good.com/"), null);
        check("selector safety", !AdFilterEngine.isSafeCosmeticSelector("div:has-text(x)") && !AdFilterEngine.isSafeCosmeticSelector("a{color:red}")
              && AdFilterEngine.isSafeCosmeticSelector("div[id^=\"ad-\"] > .x"));

        // --- persistence round trip
        File tmp = File.createTempFile("filters", ".txt");
        e.save(tmp);
        AdFilterEngine e2 = new AdFilterEngine(builtin);
        e2.load(tmp);
        eq("round-trip size", e2.ruleCount(), e.ruleCount());
        eq("round-trip path rule", e2.match("https://news.site/ads/banner.js"), "news.site");
        eq("round-trip exception", e2.match("https://good.com/tracking/x"), null);
        tmp.delete();
        AdFilterEngine e3 = new AdFilterEngine(builtin); e3.load(new File("/nonexistent/file")); eq("missing file ok", e3.ruleCount(), 0);

        e.clear(); eq("clear", e.ruleCount(), 0);
        eq("builtin still works after clear", e.match("https://criteo.com/x"), "criteo.com");
    }

    // ---------------------------------------------------------------- $options / patterns

    private static AdFilterEngine engineWith(String... lines) throws Exception {
        AdFilterEngine e = new AdFilterEngine(new HashMap<>());
        e.replace(e.parse(new BufferedReader(new StringReader(String.join("\n", lines)))));
        return e;
    }

    @Test
    public void thirdPartyAndTypeOptions() throws Exception {
        AdFilterEngine e = engineWith("||ads.net^$third-party", "||cdn.com/lib.js$script", "/banner/*$image");
        int S = AdFilterEngine.TYPE_SCRIPT, I = AdFilterEngine.TYPE_IMAGE, U = AdFilterEngine.TYPE_UNKNOWN;
        eq("third-party blocked", e.match("https://ads.net/x.js", "https://news.com/a", S), "ads.net");
        eq("first-party not blocked", e.match("https://ads.net/x.js", "https://www.ads.net/", S), null);
        eq("no page context -> don't guess", e.match("https://ads.net/x.js", null, S), null);
        eq("script rule blocks script", e.match("https://cdn.com/lib.js", "https://a.com/", S), "cdn.com");
        eq("script rule ignores image", e.match("https://cdn.com/lib.js", "https://a.com/", I), null);
        eq("type unknown -> typed rule does not apply", e.match("https://cdn.com/lib.js", "https://a.com/", U), null);
        eq("pattern rule + image type", e.match("https://x.com/banner/1.png", "https://a.com/", I), "x.com");
        eq("pattern rule wrong type", e.match("https://x.com/banner/1.png", "https://a.com/", S), null);
    }

    @Test
    public void domainOptionAndExceptions() throws Exception {
        AdFilterEngine e = engineWith("||promo.net^$domain=a.com|~sub.a.com", "||trk.net^", "@@||trk.net/ok.js$script",
                "||big.net^$important", "@@||big.net^$script");
        int S = AdFilterEngine.TYPE_SCRIPT;
        eq("on listed domain", e.match("https://promo.net/x", "https://a.com/p", S), "promo.net");
        eq("on subdomain of listed", e.match("https://promo.net/x", "https://www.a.com/p", S), "promo.net");
        eq("on excluded subdomain", e.match("https://promo.net/x", "https://sub.a.com/p", S), null);
        eq("on other domain", e.match("https://promo.net/x", "https://b.com/p", S), null);
        eq("blocked normally", e.match("https://trk.net/other.js", "https://b.com/", S), "trk.net");
        eq("exception with option unblocks", e.match("https://trk.net/ok.js", "https://b.com/", S), null);
        eq("exception does not apply to other types", e.match("https://trk.net/ok.js", "https://b.com/", AdFilterEngine.TYPE_IMAGE), "trk.net");
        eq("important rule beats exception", e.match("https://big.net/x.js", "https://b.com/", S), "big.net");
    }

    @Test
    public void patternAnchorsWildcardsAndSeparator() throws Exception {
        AdFilterEngine e = engineWith("-ad-banner-", "|https://x.com/pixel|", "/ads^", "||s.com/a*b/track^");
        int O = AdFilterEngine.TYPE_OTHER;
        eq("substring", e.match("https://y.com/img-ad-banner-1.png", null, O), "y.com");
        eq("start+end anchors match exact", e.match("https://x.com/pixel", null, O), "x.com");
        eq("end anchor rejects longer", e.match("https://x.com/pixel2", null, O), null);
        eq("start anchor rejects other scheme", e.match("http://x.com/pixel", null, O), null);
        eq("separator matches slash", e.match("https://q.com/ads/1", null, O), "q.com");
        eq("separator matches end", e.match("https://q.com/ads", null, O), "q.com");
        eq("separator matches ?", e.match("https://q.com/ads?x=1", null, O), "q.com");
        eq("separator rejects letters (adsense)", e.match("https://q.com/adsense/1", null, O), null);
        eq("wildcard host rule", e.match("https://s.com/aXXXb/track?z", null, O), "s.com");
        eq("wildcard host rule miss", e.match("https://s.com/aXXXb/other", null, O), null);
    }

    @Test
    public void unsupportedRulesAreSkippedNotGuessed() throws Exception {
        AdFilterEngine e = engineWith("||a.com^$redirect=noop.js", "||b.com^$popup", "/ad\\d+/", "||c.com^$removeparam=x",
                "||d.com^$csp=script-src", "*", "||e.com^$badfilter", "ads$script,unknownopt");
        eq("nothing compiled", e.ruleCount(), 0);
        eq("no accidental match", e.match("https://a.com/x", "https://p.com/", AdFilterEngine.TYPE_SCRIPT), null);
    }

    @Test
    public void requestContextHelpers() {
        eq("registrable simple", AdFilterEngine.registrableDomain("a.b.example.com"), "example.com");
        eq("registrable co.uk", AdFilterEngine.registrableDomain("www.bbc.co.uk"), "bbc.co.uk");
        eq("registrable bare", AdFilterEngine.registrableDomain("example.com"), "example.com");
        check("same site", !AdFilterEngine.isThirdParty("cdn.example.com", "www.example.com"));
        check("different site", AdFilterEngine.isThirdParty("ads.net", "www.example.com"));
        check("co.uk siblings are different sites", AdFilterEngine.isThirdParty("a.co.uk", "b.co.uk"));
        eq("js", AdFilterEngine.guessType("https://x.com/a.js?v=1", null, null, false), AdFilterEngine.TYPE_SCRIPT);
        eq("css", AdFilterEngine.guessType("https://x.com/a.css", null, null, false), AdFilterEngine.TYPE_STYLESHEET);
        eq("image by ext", AdFilterEngine.guessType("https://x.com/a.PNG", null, null, false), AdFilterEngine.TYPE_IMAGE);
        eq("font", AdFilterEngine.guessType("https://x.com/a.woff2", null, null, false), AdFilterEngine.TYPE_FONT);
        eq("media", AdFilterEngine.guessType("https://x.com/a.mp4", null, null, false), AdFilterEngine.TYPE_MEDIA);
        eq("xhr header", AdFilterEngine.guessType("https://x.com/api", "*/*", "XMLHttpRequest", false), AdFilterEngine.TYPE_XHR);
        eq("iframe", AdFilterEngine.guessType("https://x.com/embed", "text/html", null, true), AdFilterEngine.TYPE_SUBDOCUMENT);
        eq("image by accept", AdFilterEngine.guessType("https://x.com/pic", "image/webp,*/*", null, false), AdFilterEngine.TYPE_IMAGE);
        eq("fallback", AdFilterEngine.guessType("https://x.com/api", "*/*", null, false), AdFilterEngine.TYPE_OTHER);
    }

    @Test
    public void patternRulesSurvivePersistence() throws Exception {
        AdFilterEngine e = engineWith("||ads.net^$third-party", "-ad-banner-", "@@||cdn.com/ok.js$script", "||x.com/promo/");
        File tmp = File.createTempFile("filters2", ".txt");
        e.save(tmp);
        AdFilterEngine e2 = new AdFilterEngine(new HashMap<>());
        e2.load(tmp);
        tmp.delete();
        eq("rule count", e2.ruleCount(), e.ruleCount());
        eq("third-party survives", e2.match("https://ads.net/a", "https://n.com/", AdFilterEngine.TYPE_SCRIPT), "ads.net");
        eq("pattern survives", e2.match("https://y.com/q-ad-banner-1", null, AdFilterEngine.TYPE_OTHER), "y.com");
        eq("path rule survives", e2.match("https://x.com/promo/q", null, AdFilterEngine.TYPE_OTHER), "x.com");
    }

    @Test
    public void largeListsStayFast() throws Exception {
        StringBuilder sb = new StringBuilder();
        java.util.Random rnd = new java.util.Random(7);
        for (int i = 0; i < 30000; i++) sb.append("/ad").append(Integer.toHexString(rnd.nextInt())).append("track*.js$script\n");
        for (int i = 0; i < 20000; i++) sb.append("||host").append(i).append(".com/x/*$third-party\n");
        AdFilterEngine e = new AdFilterEngine(new HashMap<>());
        e.replace(e.parse(new BufferedReader(new StringReader(sb.toString()))));
        check("rules parsed", e.ruleCount() > 40000);
        long t0 = System.nanoTime();
        int hits = 0;
        for (int i = 0; i < 2000; i++) {
            if (e.match("https://site" + i + ".com/assets/app.bundle.js?v=" + i, "https://www.example.org/", AdFilterEngine.TYPE_SCRIPT) != null) hits++;
        }
        long ms = (System.nanoTime() - t0) / 1_000_000;
        assertEquals("no false positives", 0, hits);
        check("2000 lookups against 50k rules took " + ms + "ms (limit 3000)", ms < 3000);
        eq("indexed host rule still hits", e.match("https://host777.com/x/y", "https://www.example.org/", AdFilterEngine.TYPE_OTHER), "host777.com");
    }
}
