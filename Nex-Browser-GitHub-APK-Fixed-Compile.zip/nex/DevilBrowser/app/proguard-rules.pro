# Nex Browser — ProGuard/R8 rules.
# Release currently ships with minifyEnabled=false (see app/build.gradle), so these
# rules are a safety net: they make turning minification on later a one-line change.

# JS bridge: methods annotated @JavascriptInterface are called by name from web pages.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface,Signature,*Annotation*,SourceFile,LineNumberTable

# Firebase Messaging service is instantiated by the framework via the manifest.
-keep class com.devil.browser.NexFirebaseMessagingService { *; }

# Credential Manager / Google ID
-keep class com.google.android.libraries.identity.googleid.** { *; }
-keep class androidx.credentials.** { *; }

# ZXing embedded scanner
-keep class com.journeyapps.barcodescanner.** { *; }
-dontwarn com.google.zxing.**

# EncryptedSharedPreferences / Tink
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-keep class com.google.crypto.tink.** { *; }
