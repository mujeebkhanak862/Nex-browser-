# ⚡ Nex Browser — Real Android App

Ye ek **asli Android browser app** hai — UC Browser/Chrome ki tarah. Iske andar
har tab ek **real WebView** hai (webpage ke andar webpage/iframe nahi), isliye
Quotex, Pocket Option, banking sites, ya koi bhi "X-Frame-Options" wali site
**bina kisi rukavat ke khulti hai** — bilkul waise jaise UC Browser mein khulti hai.

---

## Iframe wala PWA vs Ye Real App — Kya Farak Hai

| | PWA Browser (pehle wala) | Ye App (Real Android) |
|---|---|---|
| Har tab kya hai | `<iframe>` (webpage ke andar webpage) | Asli WebView (top-level) |
| Quotex/Pocket khulega? | ❌ Block ho sakta hai | ✅ Hamesha khulega |
| Install kaise | Netlify + "Add to Home Screen" | APK file (direct install) |
| Google Play chahiye? | Nahi | Nahi (sideload) |

---

## 🖥️ Backend-Powered Features (Server Chahiye)

Ye 3 features **backend ke bina kaam nahi karte** — pehle `nex-backend`
deploy karo (README wahan hai), phir app ke **Settings → Backend Server**
mein apna Railway URL daalo:

- ✅ **AI Summarizer** — Main Menu → ✨ AI Summary. Page ka text nikaal ke
  backend ke through Claude API se summary laata hai (3-4 bullet points)
- ✅ **Cloud Sync (Bookmarks)** — Settings → Account se sign in/register
  karo, phir Bookmarks screen mein "Sync" — tumhare bookmarks server pe
  save ho jaate hain, doosre device pe bhi login karke wahi mil jaate hain
- ⚡ **Push Notifications** — App ke andar Firebase SDK **ab fully wire hai** (build.gradle, manifest, messaging service, backend registration — sab code se ban chuka hai). **Bas ek cheez baki hai**: apna khud ka Firebase project banana (Google account se link hota hai, wo main nahi bana sakta). Jab tak wo nahi karoge, app **normally chalega**, sirf ye feature dormant rahega — koi crash nahi. `PUSH_NOTIFICATIONS_SETUP.md` mein steps hain.

**In teeno ke bina bhi app 100% chalega** — sirf ye 3 buttons non-functional
rahenge jab tak backend URL set nahi karte.

---

## Features (Abhi Ke Liye)

- ✅ **Speed Dial Homepage** — naya tab khulte hi 15 default shortcuts (Google, Facebook, YouTube, Gmail, etc.), "Most Visited" (real visit-count tracking se), aur "Manage Cards" (shortcuts add/remove) — sab kuch on-device save hota hai
- ✅ **Tab Switcher (list view)** — bottom sheet mein har tab ek row (icon+title+URL+close), "+ New Tab", incognito icon (abhi placeholder, real incognito baad mein aayega)
- ✅ **Main Menu (☰)** — Speed Mode (data saver — images block karta hai), Facebook shortcut, Share (Android share sheet), Save Page (local .mht archive), Full Screen (immersive mode, back button se exit), Find in Page (text search + highlight); Ad Block aur QR Scanner abhi placeholder hain (aage ke batches mein)
- ✅ **Profile/Tools Menu** — Main Menu ke andar "⋯ More Tools" tile se khulta hai: **Downloads** (real list, Android Download Manager se), **Night** (real screen-dim toggle), History & Bookmarks/My Videos/Incognito/Tools abhi placeholder; neeche row mein Settings/Collapse/Power (Power = confirm karke app close)
- ✅ **Settings Screen** — poora page: Add-ons → Ad Block, "Set as Default Browser" (Android system settings kholta hai), Clear Records (real cache/cookies/history wipe), About (real app version), Reset to Default (sab kuch factory-reset karta hai); Browsing/Download/Notification Settings aur Language abhi placeholder
- ✅ **Ad Block — REAL, dikhawa nahi** — actual ad-serving domains (doubleclick, googlesyndication, taboola, outbrain, popads, etc.) ko network level pe block karta hai. Live dashboard: total ads blocked, saved data estimate, load-time saved, 10-day bar chart, **Banners/Popups/Native Ads/Trackers** ka real breakdown (domain ke hisaab se sahi categorize hota hai, ab sirf "image vs hidden" guess nahi), on/off toggle, share button, reset stats button
- ✅ **Bookmarks & History** — omnibox ke paas ☆ star button (tap karke current page bookmark/unbookmark karo, gold ho jata hai jab saved ho). Tabbed screen (Bookmarks | History) — real CRUD, Edit mode se delete, real Clear History
- ✅ **Browsing Settings** — 8 real options: Text-Only (images block), Tab View (List/Grid — Tab Switcher isi ke hisaab se badalta hai), Reopen Tabs on Startup (session save/restore), Brightness (real slider), Animation (menu transitions on/off), Typing Assistant (autocomplete on/off), Open Link (Current/New Tab), Website Preferences (Desktop/Mobile User-Agent)
- ✅ **Language Screen** — 6 languages (English, Tiếng Việt, Bahasa Indonesia, Português, Español, हिन्दी), selection save hoti hai — **honest note**: abhi sirf selection save hoti hai, poori app translate nahi hoti (uske liye har text ko strings.xml mein le jana padega, alag hi bada kaam hai)
- ✅ **Notification Settings** — Push Notification (**real**, download-alert notifications se linked), Facebook toggle (save hota hai lekin **honest note**: koi push backend nahi hai is browser mein, isliye ye kaam nahi karta abhi), Quick Access (**real** — tumhare bookmarks khol deta hai)
- ✅ **Custom Error Page** — jab koi site load na ho (no internet, DNS fail, etc.), ab WebView ka default ugly error nahi dikhta — apna khud ka dark-themed error page dikhta hai: URL, tips, **Retry** button (real reload) aur **Go Home** button (Speed Dial pe wapas)
- ✅ **Files Manager** — category grid (Music/Video/Photo/Apps/Archive/Docs/Webpage/Others) **real counts** tumhare actual downloads se; **real storage bar** (device ka available/total space, StatFs se); **Send** (real Android share sheet se koi bhi downloaded file bhejo); **Receive** (real! local Wi-Fi network pe ek simple socket kholta hai, IP:Port dikhata hai, doosra Nex Browser wahan file bhej sakta hai)
- ✅ **My Videos** — tumhare downloaded videos ki real list (Download Manager se filter), tap karo to default video player mein khulta hai; kuch na ho to proper empty state dikhta hai
- ✅ **Incognito Mode** — Tab Switcher ya Profile menu se 🕶 tap karo, naya private tab khulta hai. **Real**: is tab ki browsing history kabhi save nahi hoti; jab aakhri incognito tab band ho, cookies clear ho jaate hain. Tab bar mein 🕶 icon dikhta hai pehchan ke liye. **Honest note**: cookies open rehne tak normal tabs ke saath shared hain (poora alag cookie-jar nahi bana — wo bahut bada refactor hai)
- ✅ **Omnibox History Dropdown** — jab tum type karo, tumhari **apni pehle ki typed cheezein** (URLs/searches) turant dikhti hain (live Google suggestions ke saath), aur agar history hai to neeche **"🗑 Delete all input history"** option bhi aata hai — tap karo to sab clear ho jata hai
- ✅ **Password Manager & Autofill — REAL, encrypted** — kisi bhi site pe login form submit karo, "Save password?" poochega. Save karne ke baad, agli baar us site pe jaate hi **automatically fill** ho jata hai (username + password dono). Passwords **AES-256 encrypted** on-device hain (Android Keystore se, Jetpack Security library). Settings → Passwords mein poori list dikhti hai (show/hide toggle, delete per entry, master on/off switch). Incognito tabs mein na save hota hai na autofill
- ✅ **Cloud Vault Backup** — agar signed in ho aur Backend Server set hai, to **har baar password save karte hi** poora vault (passwords + history + bookmarks + shortcuts) **automatically backend pe sync** ho jata hai — ek hi combined file mein. Settings → Passwords se **"☁ Sync Now"** (manual sync) aur **"⇩ Download Vault File"** (poori file `.json` mein phone pe download) — dono real hain. ⚠️ **Security tradeoff jo tumne khud chuna**: ye on-device-only se zyada risky hai — agar backend account compromise ho, passwords bhi expose ho sakte hain. Bina sign-in/backend URL set kiye, sab kuch phone pe hi rehta hai jaisa pehle tha
- ✅ **Automation (AI Agent)** — Profile/Tools Menu → 🧰 Automation. Plain language mein task likho (jaise "search cats on youtube and get the first video's transcript") — backend ka Claude usse **browser steps** mein todta hai (navigate/search/extract_text/get_youtube_transcript/wait/done), phir **app khud** apne WebView mein (tumhare login session ke sath) wo steps **real mein execute** karta hai. Features:
  - **Multiple tasks queue mein** — ek ke baad ek automatically chalte hain
  - Har task ek **card** mein dikhta hai: naam upar, neeche **green stepper** (chhote circles, jo step ho chuka hai wo green ✓ ho jata hai, line bhi green ho jati hai)
  - Har card ka **⋮ menu**: View Result, **Create API** (curl command milta hai, copy kar sakte ho — kahin se bhi us task ka result mangwa sakte ho), **Do This First** (queue mein aage badhao), Cancel, Delete
  - **Poora kaam API se bhi control hota hai**: `/agent/plan` (naya task), `/agent/jobs` (sab dekho), `/agent/result/{id}` (progress/result), `/agent/jobs/{id}/cancel`, `/agent/jobs/{id}` DELETE, `/agent/jobs/{id}/reorder`
  - ⚠️ YouTube transcript scraping **best-effort hai** — YouTube apna page design badalta rehta hai, kabhi kaam na kare to "Transcript not found" dikhega

---

## 🖥️ Backend Server (Optional — sirf 3 features ke liye chahiye)

Ek separate `nex-backend` folder hai (Python/FastAPI) jo sirf in cheezon ke liye zaroori hai:
- **AI Summarizer** — page ka quick summary (Claude API se)
- **Cloud Sync** — bookmarks account ke saath sync (dusre phone pe bhi wahi bookmarks)
- **Push Notifications** — backend ready hai, app ka Firebase code bhi wire hai, sirf tumhara khud ka Firebase project chahiye (niche dekho)

**Baaki sab kuch (Speed Dial, Ad Block, History, Downloads, Incognito — sab 16 batches) is backend ke bina bhi 100% kaam karta hai.**

### Setup:
1. `nex-backend` folder deploy karo Railway pe (poora README uske andar hai)
2. App mein: **Settings → Backend Server** → apna Railway URL daalo
3. **Settings → Account** → sign in/register karo (Cloud Sync ke liye)
4. Ab **Main Menu → ✨ AI Summary** aur **Bookmarks → Sync** kaam karenge

### Push Notifications — Ek Extra Step Baki Hai:
Backend ka `/notifications/send` endpoint ready hai, **aur Android app ke
andar Firebase SDK bhi ab poora wire ho chuka hai** (dependencies, manifest
service, message-receiving code, backend token registration — sab ban
chuka hai code mein). Isko "activate" karne ke liye sirf ek cheez chahiye:

1. Apna khud ka Firebase project banao (tumhare Google account se link
   hota hai, isliye main khud ye nahi bana sakta)
2. Us project se `google-services.json` download karke `app/` folder mein
   daal do
3. Rebuild karo — **bas itna hi**, koi aur code change nahi karna
4. Firebase console mein Server Key copy karke Railway ke `FCM_SERVICE_ACCOUNT_JSON`
   variable mein daal do

Poore steps `PUSH_NOTIFICATIONS_SETUP.md` mein hain. Jab tak ye nahi
karoge, `google-services.json` file wahan nahi hogi to Gradle plugin apply
hi nahi hoga (maine build.gradle mein `if (file(...).exists())` check
lagaya hai) — **build fail nahi hoga**, sirf push notifications dormant
rahenge. Settings → Notification Settings mein real status dikhta hai
("Active" ya "Not set up") aur configured hone pe ek "Send Test" button
bhi hai turant check karne ke liye.



Sab **16 features** ban chuke hain jo UC Mini reference se banaye the — batch #1 se #16 tak, ek-ek karke. Har feature real hai (dikhawe ka nahi), jahan honest limitation thi (Language translation, Facebook push notifications) wahan clearly bataya gaya hai.
- ✅ **Download Settings** — Default Path (info, fixed to public Downloads folder), Max Downloads (persisted preference), New Task (Always Ask/Auto Start — **real**, download se pehle confirm dialog aata hai), Auto Reconnect (toggle), Notification (**real** — Android download notification on/off karta hai)

- ✅ **Real Multi-Tab System** — har tab apna independent WebView hai
- ✅ **Smart Omnibox** — URL detect karta hai vs search query
- ✅ **Autocomplete Suggestions** — type karte hi Google ke free suggest endpoint se dropdown suggestions (koi API key ya limit nahi, alag se unlimited service hai)
- ✅ **Fullscreen Video (YouTube etc.)** — video ka fullscreen button ab kaam karta hai, real fullscreen player khulta hai
- ✅ **Real File Downloads** — images, videos, APKs, documents — Android ke System Download Manager se, phone ke normal "Downloads" folder mein jaate hain, notification ke sath
- ✅ **Cookies enabled** (first-party + third-party) — login sessions properly persist hote hain
- ✅ **Back/Forward** navigation
- ✅ **Progress bar** — page load hote waqt
- ✅ **Tab counter + tab chips** — top mein saare open tabs dikhte hain, tap karke switch karo
- ✅ **Close tab** — chip ke ✕ pe tap karo
- ✅ **Dark red theme**
- ✅ **Custom logo launcher icon** — already generated, sab density sizes mein

---

## Android Studio Mein Kholna Aur APK Banana (Step-by-Step)

### Step 1: Android Studio Install Karo
Agar nahi hai, [developer.android.com/studio](https://developer.android.com/studio) se download karo.

### Step 2: Project Kholo
```
Android Studio → Open →
  DevilBrowser folder select karo (jisme build.gradle hai) → OK
```
Pehli baar Gradle sync hone mein 2-5 minute lag sakte hain (internet chahiye).

### Step 3: APK Banao
```
Menu bar → Build → Build Bundle(s) / APK(s) → Build APK(s)
```
Build complete hone ke baad, neeche-right corner mein "locate" link click karo
— wahan `app-debug.apk` milega.

Path usually: `app/build/outputs/apk/debug/app-debug.apk`

### Step 4: Phone Mein Install Karo
```
1. app-debug.apk ko phone mein copy karo (USB, ya khud ko email/WhatsApp kar do)
2. Phone mein file open karo
3. "Install from unknown sources" allow karo (pehli baar puchega)
4. Install → Open
```

Bas! **Nex Browser** ab tumhare phone mein ek real app hai, home screen
pe icon ke sath. Isse Quotex, Pocket Option, koi bhi site normally khulegi.

---

## Kyun Ye Iframe Wali Problem Fix Karta Hai

Jab koi website (Quotex jaisi) `X-Frame-Options` ya `Content-Security-Policy:
frame-ancestors` header bhejti hai, wo sirf **iframe ke andar embed hone** se
rokti hai. Is app mein har tab **apna khud ka top-level WebView** hai — bilkul
waise jaise tum phone ke normal Chrome mein URL type karke site kholte ho.
Koi embedding nahi ho rahi, isliye wo security check trigger hi nahi hota.

Yahi wajah hai ki UC Browser, Chrome, Firefox — sab real apps mein trading
sites, banking sites, sab normally khulti hain, lekin website-based (PWA)
browsers mein iframe restriction ka saamna karna padta hai.

---

## Next Steps (Jo Add Kar Sakte Hain)

- [ ] Bookmarks + History (SharedPreferences mein save)
- [ ] Settings panel (search engine choice, dark mode toggle)
- [ ] Downloads manager (real file downloads, `DownloadManager` API se)
- [ ] Incognito tabs (separate WebView data directory)
- [ ] QR Scanner (CameraX + ML Kit)
- [ ] Homepage with speed dial shortcuts (jaisa PWA version mein tha)
- [ ] Pull-to-refresh
- [ ] Find in page
- [ ] Desktop site toggle

Bata do inme se konsa pehle chahiye — agli iteration mein add kar dunga.

---

## File Structure

```
DevilBrowser/
├── build.gradle                    (project-level)
├── settings.gradle
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle                 (app-level, dependencies)
    └── src/main/
        ├── AndroidManifest.xml      (permissions, activity)
        ├── java/com/devil/browser/
        │   └── MainActivity.java     (all browser logic)
        └── res/
            ├── layout/activity_main.xml
            ├── values/ (colors, strings, themes)
            ├── drawable/ (button/tab backgrounds)
            └── mipmap-*/ (devil logo launcher icons)
```

Enjoy your real browser! ⚡🔥
