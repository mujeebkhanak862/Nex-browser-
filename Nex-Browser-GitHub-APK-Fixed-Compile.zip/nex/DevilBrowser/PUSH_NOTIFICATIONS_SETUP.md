# Push Notifications — Setup Guide

**Update: Firebase SDK ab poori tarah code mein wire ho chuka hai.** Pehle
ye guide manual code paste karne ke liye tha — ab **sirf apna Firebase
project banana hai aur ek file daalni hai**. Baaki sab automatic hai.

## Kaise Kaam Karta Hai

- `build.gradle` mein Firebase Messaging dependency already hai
- `NexFirebaseMessagingService.java` already bana hua hai — push message
  receive karta hai, notification dikhata hai, naya token backend ko bhejta hai
- `AndroidManifest.xml` mein service already registered hai
- Google-services Gradle plugin **sirf tab apply hota hai jab
  `app/google-services.json` file exist karti hai** — is check ki wajah
  se, tumhare apni Firebase file daalne se pehle bhi **build fail nahi
  hota**, bas push notifications dormant rehti hain

**Matlab tumhe koi code nahi likhna** — sirf neeche wale 4 steps follow karo.

---

## Step 1: Firebase Project Banao

1. [console.firebase.google.com](https://console.firebase.google.com) → **Add project**
2. Naam do (jaise "Nex Browser"), baaki defaults rakho, Create karo

## Step 2: Android App Add Karo

1. Firebase console → apne project ke andar → **Add app** → Android icon
2. Package name daalo: `com.devil.browser` (ye app ka internal/technical
   naam hai — app khud "Nex Browser" ke naam se dikhta hai phone pe)
3. **`google-services.json`** download karo

## Step 3: File Ko Project Mein Daalo

Download ki hui file ko copy karo yahan:
```
DevilBrowser/app/google-services.json
```
(same folder jahan `app/build.gradle` hai)

## Step 4: Backend Mein Service-Account JSON Daalo

(Purani "Server key" wali API Google ne band kar di hai — ab FCM HTTP v1 use hota hai.)

1. Firebase console → Project Settings (⚙) → **Service accounts** tab
2. **Generate new private key** dabao — ek `.json` file download hogi
3. Us file ka poora content copy karo
4. Railway dashboard → apna `nex-backend` service → Variables →
   `FCM_SERVICE_ACCOUNT_JSON` mein paste karo
   (ya file volume pe rakh ke `FCM_SERVICE_ACCOUNT_FILE=/data/fcm.json` set karo)
5. Is JSON ko kabhi GitHub par commit mat karna

---

## Rebuild Aur Test Karo

1. Android Studio mein project reopen/sync karo (ya rebuild)
2. App install karo phone mein
3. **Settings → Account** → sign in/register karo
4. **Settings → Notification Settings** — ab yahan "Server Push (Firebase):
   Active" dikhega, aur ek **"Send Test"** button
5. Test button dabao — turant ek real push notification aani chahiye 🎉

Agar `google-services.json` nahi daali, to yahi screen "Not set up" dikhayegi
— app crash nahi karega, bas ye ek feature use nahi hoga.

---

**Ye sab optional hai** — agar push notifications nahi chahiye, kuch mat
karo, app bilkul normal chalega baaki sab 16+ features ke saath.
