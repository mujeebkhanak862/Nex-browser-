package androidx.core.app;
public class NotificationCompat { public static final int PRIORITY_LOW=-1, PRIORITY_DEFAULT=0, PRIORITY_HIGH=1;
  public static class Builder { public Builder(android.content.Context c, String ch){}
    public Builder setSmallIcon(int i){return this;} public Builder setContentTitle(CharSequence t){return this;} public Builder setContentText(CharSequence t){return this;}
    public Builder setOngoing(boolean b){return this;} public Builder setOnlyAlertOnce(boolean b){return this;} public Builder setAutoCancel(boolean b){return this;}
    public Builder setPriority(int p){return this;} public Builder setContentIntent(android.app.PendingIntent p){return this;} public android.app.Notification build(){return null;} } }