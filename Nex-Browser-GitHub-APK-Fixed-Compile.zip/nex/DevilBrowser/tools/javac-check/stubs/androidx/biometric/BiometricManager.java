package androidx.biometric;
public class BiometricManager { public static final int BIOMETRIC_SUCCESS=0;
  public interface Authenticators { int BIOMETRIC_STRONG=0xF, BIOMETRIC_WEAK=0xFF, DEVICE_CREDENTIAL=0x8000; }
  public static BiometricManager from(android.content.Context c){return null;} public int canAuthenticate(int a){return 0;} }