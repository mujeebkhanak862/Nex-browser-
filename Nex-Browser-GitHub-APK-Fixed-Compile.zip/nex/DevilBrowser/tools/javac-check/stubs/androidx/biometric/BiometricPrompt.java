package androidx.biometric;
public class BiometricPrompt {
  public BiometricPrompt(androidx.fragment.app.FragmentActivity a, java.util.concurrent.Executor e, AuthenticationCallback cb){}
  public void authenticate(PromptInfo p){}
  public static abstract class AuthenticationCallback { public void onAuthenticationError(int c, CharSequence s){} public void onAuthenticationSucceeded(AuthenticationResult r){} public void onAuthenticationFailed(){} }
  public static class AuthenticationResult {}
  public static class PromptInfo { public static class Builder { public Builder setTitle(CharSequence s){return this;} public Builder setSubtitle(CharSequence s){return this;} public Builder setDescription(CharSequence s){return this;} public Builder setNegativeButtonText(CharSequence s){return this;} public Builder setAllowedAuthenticators(int a){return this;} public PromptInfo build(){return null;} } }
}