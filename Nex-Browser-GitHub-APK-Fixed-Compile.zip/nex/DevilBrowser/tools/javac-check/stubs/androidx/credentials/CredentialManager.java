package androidx.credentials;
import androidx.credentials.exceptions.GetCredentialException;
public interface CredentialManager { static CredentialManager create(android.content.Context c){return null;}
  void getCredentialAsync(android.content.Context c, GetCredentialRequest r, android.os.CancellationSignal s, java.util.concurrent.Executor e, CredentialManagerCallback<GetCredentialResponse, GetCredentialException> cb); }