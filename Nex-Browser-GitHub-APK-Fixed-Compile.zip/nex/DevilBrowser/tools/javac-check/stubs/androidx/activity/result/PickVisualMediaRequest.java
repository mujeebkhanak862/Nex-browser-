package androidx.activity.result;
import androidx.activity.result.contract.ActivityResultContracts;
public final class PickVisualMediaRequest { public static final class Builder { public Builder setMediaType(ActivityResultContracts.PickVisualMedia.VisualMediaType t){return this;} public PickVisualMediaRequest build(){return null;} } }