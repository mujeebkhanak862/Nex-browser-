package androidx.activity.result.contract;
import androidx.activity.result.*; import android.content.*; import android.net.Uri; import java.util.Map;
public final class ActivityResultContracts {
  public static class StartActivityForResult extends ActivityResultContract<Intent, ActivityResult> { public Intent createIntent(Context c, Intent i){return i;} public ActivityResult parseResult(int r, Intent i){return null;} }
  public static class RequestPermission extends ActivityResultContract<String, Boolean> { public Intent createIntent(Context c, String i){return null;} public Boolean parseResult(int r, Intent i){return null;} }
  public static class RequestMultiplePermissions extends ActivityResultContract<String[], Map<String,Boolean>> { public Intent createIntent(Context c, String[] i){return null;} public Map<String,Boolean> parseResult(int r, Intent i){return null;} }
  public static class GetContent extends ActivityResultContract<String, Uri> { public Intent createIntent(Context c, String i){return null;} public Uri parseResult(int r, Intent i){return null;} }
  public static class OpenDocument extends ActivityResultContract<String[], Uri> { public Intent createIntent(Context c, String[] i){return null;} public Uri parseResult(int r, Intent i){return null;} }
  public static class CreateDocument extends ActivityResultContract<String, Uri> { public Intent createIntent(Context c, String i){return null;} public Uri parseResult(int r, Intent i){return null;} }
  public static class PickVisualMedia extends ActivityResultContract<PickVisualMediaRequest, Uri> {
    public interface VisualMediaType {}
    public static final class ImageOnly implements VisualMediaType { public static final ImageOnly INSTANCE = new ImageOnly(); }
    public Intent createIntent(Context c, PickVisualMediaRequest i){return null;} public Uri parseResult(int r, Intent i){return null;} }
}