package androidx.activity;
public class OnBackPressedDispatcher { public void addCallback(androidx.lifecycle.LifecycleOwner o, OnBackPressedCallback c){} public void onBackPressed(){} }