package androidx.webkit;
public interface Profile { android.webkit.CookieManager getCookieManager(); android.webkit.WebStorage getWebStorage(); String getName(); }