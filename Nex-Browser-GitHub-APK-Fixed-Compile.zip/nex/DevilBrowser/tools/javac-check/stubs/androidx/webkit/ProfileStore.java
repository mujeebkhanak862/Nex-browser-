package androidx.webkit;
public interface ProfileStore { static ProfileStore getInstance(){return null;} Profile getOrCreateProfile(String name); boolean deleteProfile(String name); }