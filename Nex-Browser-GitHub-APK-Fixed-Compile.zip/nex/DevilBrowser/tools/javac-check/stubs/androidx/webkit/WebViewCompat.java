package androidx.webkit;
import android.webkit.WebView; import java.util.Set;
public class WebViewCompat {
  public interface WebMessageListener { void onPostMessage(WebView view, WebMessageCompat message, android.net.Uri sourceOrigin, boolean isMainFrame, JavaScriptReplyProxy replyProxy); }
  public static void setProfile(WebView w, String name){}
  public static void addWebMessageListener(WebView w, String js, Set<String> origins, WebMessageListener l){}
}