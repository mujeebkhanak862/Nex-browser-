#!/usr/bin/env bash
# Fast "does it compile?" check with a REAL javac, without Gradle or the Android SDK.
#   - compiles every app source against android.jar (API 34, downloaded once from GitHub)
#   - androidx / Firebase / Google classes are replaced by small hand-written stubs in ./stubs
#   - R.java is generated from res/
# Limits: stubs are written from memory of the real APIs, so a PASS here is strong evidence but not
# proof for androidx/Firebase calls — ./gradlew assembleDebug is the final authority.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
APP="$HERE/../../app/src/main"
WORK="${TMPDIR:-/tmp}/nex-javac-check"
mkdir -p "$WORK"
JAVAC=(javac)
command -v javac >/dev/null || JAVAC=(java -m jdk.compiler/com.sun.tools.javac.Main)

if [ ! -f "$WORK/android-34.jar" ]; then
  curl -sSL -o "$WORK/android-34.jar" https://raw.githubusercontent.com/Sable/android-platforms/master/android-34/android.jar
fi
rm -rf "$WORK/stubs_out" "$WORK/src" "$WORK/out"; mkdir -p "$WORK/stubs_out" "$WORK/src/com/devil/browser" "$WORK/out"
"${JAVAC[@]}" -proc:none -cp "$WORK/android-34.jar" -d "$WORK/stubs_out" $(find "$HERE/stubs" -name '*.java')
cp "$APP"/java/com/devil/browser/*.java "$WORK/src/com/devil/browser/"
python3 "$HERE/gen_r.py" "$APP/res" "$WORK/src/com/devil/browser/R.java"
"${JAVAC[@]}" -proc:none -Xmaxerrs 1000 -cp "$WORK/android-34.jar:$WORK/stubs_out" -d "$WORK/out" "$WORK"/src/com/devil/browser/*.java
echo "javac-check: OK (0 errors)"
