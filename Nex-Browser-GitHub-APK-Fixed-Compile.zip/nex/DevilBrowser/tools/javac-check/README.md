# javac-check
Quick compile check without Gradle/Android SDK: `./tools/javac-check/run.sh` (needs a JDK 17+ and python3).
`stubs/` are hand-written approximations of the few androidx / Firebase / Google classes the app imports.
If you add a new androidx call and this fails with "cannot find symbol" on an androidx class, extend the stub —
if it fails anywhere else, it is a real bug in the app code.
