import re,glob,os,sys
res=sys.argv[1]; out=sys.argv[2]
defined={k:set() for k in ['drawable','string','color','layout','mipmap','style','xml','id','dimen','anim','array','raw','integer','bool','attr']}
for f in glob.glob(res+'/**/*',recursive=True):
    if os.path.isfile(f):
        d=os.path.basename(os.path.dirname(f)); n=os.path.splitext(os.path.basename(f))[0]; base=d.split('-')[0]
        if base in defined: defined[base].add(n)
for f in glob.glob(res+'/values*/*.xml'):
    t=open(f,encoding='utf-8').read()
    for m in re.finditer(r'<(string|color|style|dimen|string-array|array|integer|bool|attr)\s+name="([^"]+)"',t):
        k={'string-array':'array'}.get(m.group(1),m.group(1)); defined[k].add(m.group(2).replace('.','_'))
allxml=''.join(open(f,encoding='utf-8').read() for f in glob.glob(res+'/**/*.xml',recursive=True))
for m in re.finditer(r'android:id="@\+id/([A-Za-z0-9_]+)"',allxml): defined['id'].add(m.group(1))
o=["package com.devil.browser;","public final class R {"]
for k,v in defined.items():
    o.append(f"  public static final class {k} {{")
    for i,n in enumerate(sorted(v)): o.append(f"    public static final int {n} = {0x7f000000+i};")
    o.append("  }")
o.append("}")
open(out,'w').write('\n'.join(o))
