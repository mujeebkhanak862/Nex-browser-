# AI Answer Cache (Settings → 🧠 AI Answer Cache)

Aapki request: agar ek sawal **baar-baar** poocha jaye, to browser use
dobara AI ko na bheje — pehle wala jawab **seedha** de de, taake AI ka
"khana" (API call/cost) na lage.

## Kya kaam karta hai

- **AI Command Mode** (omnibox mein ✨ toggle karke koi bhi sawal/command
  type karna) — ab jab bhi koi command aata hai, pehle local cache check
  hoti hai:
  - Agar wahi sawal (same page ke liye, agar page-aware command hai) pehle
    kabhi poocha ja chuka hai aur jawab **7 din** ke andar hai → **turant**
    wahi jawab dikha diya jata hai, koi network/AI call hoti hi nahi
    (title mein "🧠 cached" likh kar batata hai ke ye cached jawab hai).
  - Agar naya sawal hai ya cache expire ho chuka hai → normal tareeqe se
    AI ko call karta hai, jawab milte hi cache mein save kar leta hai
    taake agli baar wahi sawal instant ho.
- **Settings → 🧠 AI Answer Cache** — kitne jawab abhi saved hain dikhata
  hai, aur "Clear Cache" se sab mita sakte hain.

## Zaroori design faisle

- **Same sawal, alag page = alag cache entry.** "summarize this" do alag
  articles par poocha jaye to dono ka jawab alag rehta hai (page URL
  cache-key ka hissa hai) — warna galat purana jawab dikh jata.
- **7 din ki expiry** — page-based jawab hamesha ke liye sahi nahi rehte
  (page badal sakta hai), isliye purana ho to dobara fresh poocha jata hai.
- **Max 200 saved answers** — is se zyada ho to sabse purana khud-ba-khud
  hat jata hai, storage bina limit ke nahi badhta.

## Kahan implement hua

`MainActivity.java` mein — `runAiCommand()` (jo AI Command Mode chalata
hai) cache-aware bana diya, aur naye helper methods
(`getCachedAiReply`, `putAiCacheReply`, wagera) add kiye jo koi bhi
future "AI se sawal poocho" feature bhi reuse kar sakta hai.

## Note

- Ye sirf **AI Command Mode** (omnibox se poocha gaya sawal) par laga hai
  abhi. Autopilot/Task Planning jaise features cache nahi karte kyunki
  wo har baar live webpage ki state par depend karte hain — wahan "same
  sawal" ka concept fit nahi baithta.
- Testing note: sandbox mein Android build/run nahi ho sakta — Android
  Studio mein test karna: ek hi command 2 baar type karo (same page par),
  doosri baar turant "🧠 cached" wala jawab aana chahiye bina wait/loading
  ke.
