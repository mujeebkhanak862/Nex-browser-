# Accent Color Picker — What Changed

Adds a preset-based accent color picker to Theme Center — the next slice
of the design docs' "built-in theme gallery" beyond the Home-background
gradients already covered in HOME-BACKGROUND-IMAGE-CHANGES.md.

## Files changed

1. **`app/src/main/java/com/devil/browser/ThemeManager.java`**
   - `AccentPreset` inner class (name + light-mode color + dark-mode color
     — each preset carries both so contrast stays correct in either
     Appearance mode, the same way the original single "ember" token did).
   - `ACCENT_PRESETS` array: Violet (brand default, identical to the
     original `ember`/`gold` values), Rose, Ocean, Forest, Amber.
   - `getAccentColor(Context)` — returns the right preset color for
     whichever mode is *currently rendering* (reads the live night-mode
     configuration, not just the saved Appearance preference, so it's
     correct under System mode too).
   - `getAccentPresetName(Context)` / `setAccentPreset(Context, preset)` —
     persistence, same `theme_prefs` SharedPreferences file as the
     Light/Dark/System setting.

2. **`app/src/main/java/com/devil/browser/MainActivity.java`**
   - All ~22 call sites that did `getColor(R.color.ember)` now call
     `ThemeManager.getAccentColor(this)` instead (labels, checkmarks,
     progress-bar fills, warning text, etc.) — found and replaced as a
     batch, not by hand one at a time, so every one of them stayed
     consistent.
   - The one call site that picked between accent and dim text with a
     ternary (`isAiCommandMode ? R.color.ember : R.color.text_dim`, from
     the AI-command mode toggle) was updated the same way, just written
     out explicitly since it's a mixed expression.
   - `showThemeCenter()` — added an "Accent Color" row of five tappable
     swatches. Tapping a different one saves it and calls `recreate()`,
     same pattern as the mode switch.

## SCOPE NOTE — what this does NOT reach

Five spots are still the fixed brand "Violet" color regardless of which
preset is chosen, because they're baked into static XML rather than read
at runtime in Java:
- `themes.xml`'s `colorSecondary` (affects default Material component
  tinting, e.g. switches/checkboxes that don't have explicit colors set)
- the Go button's background drawable
- two card-border drawables (`bg_home_add_card`, `bg_new_tab_prominent`)

Making these dynamic too would mean generating those drawables
programmatically instead of via XML `<shape>`/`<selector>` resources —
a real change, not a two-line fix, so it's left for a later pass rather
than silently leaving them mismatched with no explanation. The Theme
Center sheet's "coming soon" note says this directly rather than
implying the picker is 100% complete.

## How it works

Customize → Accent Color → tap a swatch → `recreate()` repaints every
screen built after that point using the new color at the ~22 call sites
above.

## Testing note

Static source edit only — no Android SDK/emulator in this environment.
Before shipping: build in Android Studio, cycle through all 5 presets in
both Light and Dark mode, and check the 5 known-unreached spots listed
above still look intentional (brand violet) rather than broken.
