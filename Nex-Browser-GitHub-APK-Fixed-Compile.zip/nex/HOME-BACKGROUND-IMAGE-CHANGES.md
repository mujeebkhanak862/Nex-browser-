# Personal Image Home Background — What Changed

Extends Theme Center with the "personal image" piece of the design docs'
Customize Side Panel. Builds on the app's existing "Home Style" gradient
picker (which already existed before any of this session's changes — see
the note in THEME-CENTER-CHANGES.md correcting the earlier gap-report entry
that called the built-in gallery fully "Missing": a small gradient gallery
was already there, just not linked from a place called "Customize").

## Files changed

1. **`app/build.gradle`**
   - Pinned `androidx.activity:activity:1.8.0` explicitly (appcompat 1.6.1
     pulls in a compatible version transitively already, but this
     guarantees `PickVisualMedia`, which needs 1.6.0+).

2. **`app/src/main/java/com/devil/browser/MainActivity.java`**
   - `HOME_WALLPAPER_CUSTOM_IMAGE_INDEX` (-1) and
     `HOME_WALLPAPER_IMAGE_FILENAME` constants next to `HOME_WALLPAPERS`.
   - `homeImagePickerLauncher` — `ActivityResultLauncher` using
     `ActivityResultContracts.PickVisualMedia()` (the modern system Photo
     Picker; no storage permission needed on any supported API level).
   - `copyImageToInternalStorage(Uri)` — copies the picked image into
     app-internal storage immediately, since the Photo Picker's read grant
     on its returned `Uri` is only guaranteed for the current process, not
     persisted across restarts.
   - `applyHomeWallpaper()` extended: when the saved index is the
     custom-image sentinel, decodes the internal file, lays it in as a
     `CENTER_CROP` `ImageView`, and adds a semi-transparent scrim on top
     (the design doc's "readability overlay" requirement) so shortcut/
     search-pill text stays legible over any photo. Falls back to the
     Default gradient if the file is missing/unreadable.
   - `showHomeStyleDialog()` — added a "Personal Image" row below the
     gradient presets that launches the picker.
   - `showThemeCenter()` — added a "Home Background" section linking to
     the (now-extended) Home Style dialog, so Customize doesn't feel
     disconnected from a feature that already existed elsewhere. Updated
     the "coming soon" note to only mention what's genuinely still
     missing: a full built-in *theme* gallery (beyond Home gradients), My
     Themes, and a custom accent-color picker.

## How it works

Tap Customize → Home Background → Personal Image → pick a photo. The image
is copied into the app's private storage, and Home's background switches
to that photo with a dark scrim over it. Choosing any gradient preset
afterward switches back cleanly (the stored file isn't deleted, so
switching back to Personal Image later doesn't require re-picking).

## Not yet done

- A real built-in **theme gallery** — presets that also change accent
  color / component styling app-wide, not just the Home background.
- **My Themes** (save/duplicate/apply/export a user-made theme).
- A **custom accent-color picker** — the app's accent (`ember`) is
  currently a single fixed value per Light/Dark mode, not user-editable.
  Making it truly editable at runtime would need the accent to be read
  from a preference everywhere it's used instead of a static color
  resource — a larger refactor than fits in this pass.
- The **universal side panel** consolidating Bookmarks/History/AI/Agent
  alongside this Theme Center into one panel (Design v2's stated end
  goal) — Customize is still its own sheet, not merged with those yet.

## Testing note

Static source edit only — no Android SDK/emulator in this environment.
Before shipping: build in Android Studio, test the Photo Picker on both an
Android 13+ device (native picker) and an older one (Google Play Services
backport), and confirm the image survives an app restart / force-stop.
