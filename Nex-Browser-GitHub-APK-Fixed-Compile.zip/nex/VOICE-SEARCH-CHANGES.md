# Voice Search — What Changed

Implements the "voice input" item from the address-bar focused-state
requirement in both design docs (Blueprint section 4, Design v2 section 13-14).

## Files changed
1. `DevilBrowser/app/src/main/AndroidManifest.xml` — added RECORD_AUDIO permission.
2. `DevilBrowser/app/src/main/res/drawable/ic_nav_mic.xml` (new) — mic icon.
3. `DevilBrowser/app/src/main/res/layout/activity_main.xml` — added `btnVoice` in the omnibox pill.
4. `DevilBrowser/app/src/main/res/values/strings.xml` — added voice_search strings.
5. `DevilBrowser/app/src/main/java/com/devil/browser/MainActivity.java` —
   `btnVoice` field, `voiceSearchLauncher` + `voicePermissionLauncher`
   ActivityResultLaunchers, `onVoiceSearchClicked()` / `launchVoiceRecognizer()`.

## How it works
Delegates to `RecognizerIntent.ACTION_RECOGNIZE_SPEECH` (system speech picker,
same as Chrome) — Nex never records audio itself. Recognized text goes into
the address bar and through the existing `submitOmnibox()` path.

## Testing note
Static source edit — no Android SDK/emulator in this environment. Build in
Android Studio and test on a real device before shipping.
