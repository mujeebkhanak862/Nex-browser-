# Extensions (Settings → 🧩 Extensions)

## Pehle ek zaroori sach baat

Aap ne "extension istemal kar sake" poocha — lekin ek technical sach
samajhna zaroori hai: **Android WebView** (jis par yeh poora browser bana
hai) mein Chrome/Firefox jaisa **real extension system hai hi nahin** —
koi background page, koi browserAction, koi .crx/.xpi loader, kuch nahi.
Yeh koi is app ki kami nahi — **koi bhi** WebView-based Android browser
asli Chrome Web Store extension nahi chala sakta, chahe koi bhi developer
banaye. Agar main yahan "real Chrome extensions chalte hain" bol deta to
yeh jhooth hota.

Jo WebView mein **waqai kaam karta hai** wo hai **injected JavaScript** —
isi tareeqe se Tampermonkey/Greasemonkey jaise mashhoor "userscript"
managers kaam karte hain. Toh maine wahi genuine, kaam karne wala system
banaya hai — honestly usi naam se.

## Kya banaya

- **Settings → 🧩 Extensions** — installed extensions ki list, har ek ke
  saath ON/OFF switch aur ✕ remove
- **"+ Install from URL"** — koi URL do jahan ek chhota `.js` script ho,
  ya ek JSON manifest `{"name","match","script"}` — install ho jata hai
  aur **agli hi matching page** par khud-ba-khud chal jata hai
- Har extension ek "match pattern" rakhta hai (jaise `*` = sab sites, ya
  `*://*.reddit.com/*` = sirf Reddit par) — sirf sahi pages par chalta hai
- Ek se zyada extensions ho to sab chalte hain, ek TOOT jaye (error de) to
  baaki par asar nahi padta
- Incognito tabs mein extensions **kabhi nahi chalte** — history/passwords
  jaisi hi boundary

## "Khud install kare, khud chalaye" — Agent wala hissa

Aap ne yeh bhi bola: agar Agent ko kisi kaam ke liye extension chahiye ho
to woh khud install kare, khud chalaye — bina poochhe. Isliye Autopilot
Agent ke actions mein ek naya `install_extension` action add kiya hai:
agent jab decide kare ke usse ek chhota script chahiye, woh khud
`installExtensionFromUrl()` ko call kar sakta hai (bilkul wahi method jo
Settings ka "Install from URL" button use karta hai) — extension install
ho jata hai aur agli page se chalna shuru ho jata hai, koi user se
confirmation maange bina.

## Kahan implement hua

Sab kuch `MainActivity.java` ke andar:
- Extension storage/matching/install methods
- `onPageFinished` mein ek line add hui jo har page load par matching
  extensions chalati hai
- Autopilot Agent ke action-switch mein `install_extension` case

## Testing note

Sandbox mein Android build/run nahi ho sakta. Android Studio mein test
karna:
- Ek simple `.js` file kisi bhi URL par daal kar (jaise
  `console.log("hello from extension")` ya page ka background color
  badalne wala script) "Install from URL" se install karo, phir koi bhi
  page kholo aur confirm karo script chal raha hai
- Extension OFF karke confirm karo woh ab nahi chalta
- Incognito tab mein confirm karo extension nahi chalta
