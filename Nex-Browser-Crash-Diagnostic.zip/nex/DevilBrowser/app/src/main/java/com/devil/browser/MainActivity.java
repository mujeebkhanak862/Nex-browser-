package com.devil.browser;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.provider.Settings;
import android.util.Patterns;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.JavascriptInterface;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListPopupWindow;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.HorizontalScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private FrameLayout webViewContainer;
    private FrameLayout fullscreenContainer; // for YouTube-style fullscreen video
    private FrameLayout pageContainer; // for full "pages" like Settings, Add-ons, Ad Block
    private boolean isPageShown = false;

    // Universal Panel drawer overlay — separate from pageContainer, see the
    // comment where these are created in onCreate() for why.
    private FrameLayout universalPanelContainer; // full-screen dim scrim, tap to close
    private FrameLayout universalPanelDrawer;    // the actual sliding edge panel
    private boolean isUniversalPanelShown = false;
    private View topBar, omniboxWrap, tabBarScroll; // hidden together for Full Screen mode
    private LinearLayout tabBarContainer;
    private EditText omniInput;
    private ImageButton btnGo, btnBack, btnForward, btnHome, btnRefresh, btnTabs, btnMenu, btnVoice, btnQr, btnAiMode;
    // Address-bar AI-command mode (Blueprint section 4 / Design v2 section
    // 13-14: a distinct focused-address-bar state, separate from normal
    // search/URL entry). Toggled by btnAiMode; submitOmnibox() branches on
    // this instead of resolving the input as a URL/search when it's on.
    private boolean isAiCommandMode = false;
    private TextView btnBookmarkStar;
    private TextView tabCounter;
    private ProgressBar progressBar;
    private ListPopupWindow suggestPopup;
    private ArrayAdapter<SmartSearchResult> suggestAdapter;
    private boolean isFullScreenMode = false;
    private boolean isDataSaverOn = false;

    // Voice search (address-bar mic, AI Universal Browser blueprint section 4:
    // "focused state ... voice input"). Launcher fields must be registered
    // unconditionally before the Activity reaches STARTED, so they live here
    // as instance fields rather than being created on demand inside a click
    // listener.
    private final androidx.activity.result.ActivityResultLauncher<android.content.Intent> voiceSearchLauncher =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
                        ArrayList<String> matches = result.getData()
                                .getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS);
                        if (matches != null && !matches.isEmpty()) {
                            String spoken = matches.get(0);
                            omniInput.requestFocus();
                            omniInput.setText(spoken);
                            omniInput.setSelection(spoken.length());
                            // Mirrors how a typed+Enter search behaves; the user still sees
                            // what was heard in the address bar for a moment before navigation.
                            submitOmnibox();
                        }
                    });

    private final androidx.activity.result.ActivityResultLauncher<String> voicePermissionLauncher =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.RequestPermission(),
                    granted -> {
                        if (granted) launchVoiceRecognizer();
                        else Toast.makeText(this, R.string.voice_search_not_available, Toast.LENGTH_SHORT).show();
                    });

    // QR scan (address-bar camera icon, same blueprint section as voice
    // input above). ZXing's embedded ScanContract launches its own camera
    // Activity and hands back the decoded text directly.
    private final androidx.activity.result.ActivityResultLauncher<com.journeyapps.barcodescanner.ScanOptions> qrScanLauncher =
            registerForActivityResult(new com.journeyapps.barcodescanner.ScanContract(),
                    result -> {
                        if (result == null || result.getContents() == null) return; // user cancelled
                        String scanned = result.getContents();
                        omniInput.requestFocus();
                        omniInput.setText(scanned);
                        omniInput.setSelection(scanned.length());
                        submitOmnibox();
                    });

    private final androidx.activity.result.ActivityResultLauncher<String> qrPermissionLauncher =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.RequestPermission(),
                    granted -> {
                        if (granted) launchQrScanner();
                        else Toast.makeText(this, R.string.qr_scan_not_available, Toast.LENGTH_SHORT).show();
                    });

    // Website <input type="file"> uploads. WebChromeClient.onShowFileChooser hands
    // us a callback that MUST be answered exactly once (null = cancelled), or the
    // page's upload button stays dead until the tab is reloaded.
    private android.webkit.ValueCallback<Uri[]> pendingFileChooserCallback;
    private final androidx.activity.result.ActivityResultLauncher<android.content.Intent> fileChooserLauncher =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        android.webkit.ValueCallback<Uri[]> cb = pendingFileChooserCallback;
                        pendingFileChooserCallback = null;
                        if (cb == null) return;
                        Uri[] uris = null;
                        if (result.getResultCode() == RESULT_OK) {
                            uris = WebChromeClient.FileChooserParams.parseResult(result.getResultCode(), result.getData());
                        }
                        cb.onReceiveValue(uris);
                    });

    // Website camera / microphone (getUserMedia, WebRTC video calls, voice
    // recorders). The page asks via WebChromeClient.onPermissionRequest; we ask
    // the person first, then the Android runtime permission, then answer the page.
    private android.webkit.PermissionRequest pendingWebPermissionRequest;
    private final androidx.activity.result.ActivityResultLauncher<String[]> webPermissionLauncher =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions(),
                    grants -> {
                        android.webkit.PermissionRequest req = pendingWebPermissionRequest;
                        pendingWebPermissionRequest = null;
                        if (req == null) return;
                        answerWebPermissionRequest(req);
                    });

    // Ad Block → "Import filter list" file picker
    private final androidx.activity.result.ActivityResultLauncher<String> adFilterPickerLauncher =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.GetContent(),
                    uri -> { if (uri != null) importAdFilterList(uri); });

    // Website geolocation (navigator.geolocation). Same pattern as camera/mic:
    // ask the person, then the Android runtime permission, then answer the page
    // exactly once.
    private String pendingGeoOrigin;
    private android.webkit.GeolocationPermissions.Callback pendingGeoCallback;
    private final androidx.activity.result.ActivityResultLauncher<String[]> geoPermissionLauncher =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions(),
                    grants -> {
                        android.webkit.GeolocationPermissions.Callback cb = pendingGeoCallback;
                        String origin = pendingGeoOrigin;
                        pendingGeoCallback = null;
                        pendingGeoOrigin = null;
                        if (cb == null) return;
                        boolean ok = Boolean.TRUE.equals(grants.get(android.Manifest.permission.ACCESS_FINE_LOCATION))
                                || Boolean.TRUE.equals(grants.get(android.Manifest.permission.ACCESS_COARSE_LOCATION));
                        cb.invoke(origin, ok, false);
                    });

    // Personal Image Home background (Blueprint/Design v2's Theme Center
    // "personal image" section). Uses the system Photo Picker — no storage
    // permission needed at all on any supported API level, which is the
    // whole point of PickVisualMedia over the older ACTION_GET_CONTENT/
    // READ_EXTERNAL_STORAGE approach. The returned Uri's read grant is only
    // guaranteed for the current process though, so the picked image is
    // copied into app-internal storage immediately (see
    // copyImageToInternalStorage()) rather than kept as a Uri reference.
    private final androidx.activity.result.ActivityResultLauncher<androidx.activity.result.PickVisualMediaRequest> homeImagePickerLauncher =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia(),
                    uri -> {
                        if (uri == null) return; // user backed out of the picker
                        // `this.` is required: these fields are declared further down the class, and
                        // Java rejects a simple-name use of a not-yet-declared field inside a field
                        // initializer's lambda ("illegal forward reference").
                        this.networkExecutor.execute(() -> {
                            boolean ok = copyImageToInternalStorage(uri);
                            this.mainHandler.post(() -> {
                                if (ok) {
                                    this.prefs.edit()
                                            .putInt("home_wallpaper_index", HOME_WALLPAPER_CUSTOM_IMAGE_INDEX)
                                            .apply();
                                    refreshHomeIfShown();
                                } else {
                                    Toast.makeText(this, "Couldn't load that image", Toast.LENGTH_SHORT).show();
                                }
                            });
                        });
                    });

    // My Themes import (Blueprint/Design v2 item #16: "Export/Import
    // themes — versioned JSON package"). GetContent needs no storage
    // permission, same reasoning as PickVisualMedia above.
    private final androidx.activity.result.ActivityResultLauncher<String> importThemeLauncher =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.GetContent(),
                    uri -> {
                        if (uri == null) return;
                        try (java.io.InputStream in = getContentResolver().openInputStream(uri)) {
                            if (in == null) throw new Exception("empty file");
                            java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
                            byte[] chunk = new byte[4096];
                            int n;
                            while ((n = in.read(chunk)) != -1) buffer.write(chunk, 0, n);
                            JSONObject theme = new JSONObject(buffer.toString("UTF-8"));
                            importMyTheme(theme);
                        } catch (Exception e) {
                            Toast.makeText(this, "Couldn't read that theme file", Toast.LENGTH_SHORT).show();
                        }
                    });

    private List<DevilTab> tabs = new ArrayList<>();
    private int currentTabIndex = 0;
    private int tabIdCounter = 0;

    private SharedPreferences prefs;
    private List<Shortcut> shortcuts = new ArrayList<>();

    // ---- Ad Block state ----
    private boolean isAdBlockOn = true;

    // ---- Browsing Settings state ----
    private boolean isTextOnlyOn = false;
    private boolean tabViewGrid = false;
    // Third Tab View mode (Blueprint's "Grid / List / Carousel / Groups").
    // Checked before tabViewGrid in the switcher, so precedence is
    // Carousel > Grid > List; Groups isn't a separate mode here, it's
    // the existing anyGroupedAlready sectioning that already applies on
    // top of whichever of these three is active.
    private boolean tabViewCarousel = false;
    private boolean reopenTabsOnStartup = false;
    private boolean isAnimationOn = true;
    private boolean isTypingAssistantOn = true;
    private boolean openLinkInNewTab = false;
    private boolean isDesktopUA = false;
    private static final String DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

    // ---- Download Settings state ----
    private int maxDownloads = 3;
    private boolean newTaskAlwaysAsk = true;
    private boolean autoReconnect = true;
    private boolean downloadNotificationOn = true;

    // ---- Backend (server) state — for AI Summarizer + Cloud Sync ----
    private String backendUrl = "";
    private String authToken = "";
    private String refreshToken = "";
    private long accessTokenExpiresAt = 0; // epoch seconds
    private String authEmail = "";

    // ---- Password Manager & Autofill state ----
    private SharedPreferences securePrefs;
    private boolean passwordManagerEnabled = true;
    // Biometric Vault Lock (#34) + Vault Auto-Lock (#35): whether opening
    // Passwords requires a fingerprint/face/PIN prompt, and how "unlocked"
    // resets to locked again after leaving the app or after a while idle.
    private boolean biometricLockEnabled = false;
    private long vaultUnlockedAt = 0; // 0 = locked; session-only, never persisted
    private static final long VAULT_AUTO_LOCK_MS = 2 * 60 * 1000; // 2 minutes

    static class SavedCredential {
        String domain;
        String username;
        String password;
        SavedCredential(String domain, String username, String password) {
            this.domain = domain;
            this.username = username;
            this.password = password;
        }
    }

    // ---- Automation (Agent) state ----
    // Parallel Agent Execution (#90): each lane is a fully independent
    // WebView with its own navigation/cookie state, so N jobs can run
    // truly at the same time instead of queueing one-at-a-time behind
    // a single shared WebView. currentAutomationJobIds[lane] == null
    // means that lane is free.
    private static final int MAX_PARALLEL_AUTOMATION_JOBS = 2;
    private final WebView[] automationWebViews = new WebView[MAX_PARALLEL_AUTOMATION_JOBS];
    private final Runnable[] pendingAutomationContinuations = new Runnable[MAX_PARALLEL_AUTOMATION_JOBS];
    private final Integer[] currentAutomationJobIds = new Integer[MAX_PARALLEL_AUTOMATION_JOBS];
    // Step Timeout (#60) / faster network-error detection: what's
    // currently in flight per lane, so a timeout or a WebView load error
    // can report a real, specific failure instead of just hanging.
    private static final long AUTOMATION_STEP_TIMEOUT_MS = 30_000;
    private final Runnable[] automationStepTimeouts = new Runnable[MAX_PARALLEL_AUTOMATION_JOBS];
    private final StepContext[] activeStepContexts = new StepContext[MAX_PARALLEL_AUTOMATION_JOBS];

    private static class StepContext {
        final int jobId;
        final JSONArray steps;
        final int index;
        final String action;
        StepContext(int jobId, JSONArray steps, int index, String action) {
            this.jobId = jobId;
            this.steps = steps;
            this.index = index;
            this.action = action;
        }
    }

    // Adaptive Retry (#59) — distinct from Step Timeout (#60, one attempt
    // + a hard cutoff) and Error Reason Tracking (#69, just records why):
    // this actually RETRIES a failed step in place (same index, not
    // skipped to index+1) up to MAX_STEP_STRETCHES times, and adapts the
    // wait before retrying based on WHY it failed — a "not found" element
    // gets a longer wait (the page is plausibly still loading/rendering)
    // than a network timeout does (a blip that usually clears fast).
    // In-memory only (keyed by "jobId:index") — deliberately not
    // persisted, since a fresh app session starting a resumed job is a
    // legitimate first attempt again, not a continuation of an old count.
    private final AgentRetryPolicy retryPolicy = new AgentRetryPolicy(); // 2 retries = 3 attempts total

    // Automatic Error Classification (#75) — a single, deterministic
    // keyword classifier shared by retry timing, retry gating, and the
    // job card's error display. Formalizes what Adaptive Retry (#59)
    // was already doing ad hoc with its own inline keyword checks — now
    // one shared taxonomy other things can key off of too. Deliberately
    // rule-based, not an AI call: this runs on every single step
    // failure and needs to be instant and free.
    private String classifyError(String error) {
        return AgentRetryPolicy.classifyError(error);
    }

    private String errorCategoryLabel(String category) {
        return AgentRetryPolicy.categoryLabel(category);
    }

    private long adaptiveRetryDelayMs(String reason, int attemptNumber) {
        return AgentRetryPolicy.adaptiveDelayMs(reason, attemptNumber);
    }

    // Returns true (and reserves an attempt) if this step is allowed one
    // more retry; returns false (and clears the counter) once exhausted.
    private boolean shouldRetryStep(int jobId, int index) {
        return shouldRetryStep(jobId, index, null);
    }

    // Automatic Error Classification (#75): a category retrying can't
    // possibly fix — a CAPTCHA challenge, a permission/auth wall — gives
    // up on the FIRST attempt instead of burning all of MAX_STEP_RETRIES
    // on something that will fail identically every time. Those need a
    // human, not another try.
    private boolean shouldRetryStep(int jobId, int index, String reason) {
        return retryPolicy.shouldRetry(jobId, index, reason);
    }

    private int retryAttemptNumber(int jobId, int index) {
        return retryPolicy.attemptNumber(jobId, index);
    }

    private void clearStepRetryCount(int jobId, int index) {
        retryPolicy.clear(jobId, index);
    }

    // Self-Healing Agent (#57) — kicks in only once Adaptive Retry (#59)
    // has exhausted its retries on the exact same click/type target and
    // it's genuinely not there. Rather than fail the step outright, the
    // AI is shown a fresh DOM summary + screenshot and asked whether
    // something else on the page is clearly the same thing (e.g. an icon
    // instead of a labeled button). Attempted at most ONCE per step —
    // tracked here — since repeated guessing risks eventually acting on
    // the wrong element. A healed match the AI flags as sensitive
    // (payments, deletions, sending something, etc.) is never clicked
    // automatically; it's parked in automationPendingHeals and the job's
    // lane is deliberately left occupied (not freed back to the queue)
    // until the user approves or skips it from the job's "⋮" menu, so
    // the WebView is still on the right page when they do.
    private final Set<String> automationSelfHealAttempted = new HashSet<>();
    private final Map<Integer, JSONObject> automationPendingHeals = new HashMap<>();
    // Human Approval Layer (#78): same "park it, don't free the lane,
    // wait for the ⋮ menu" shape as automationPendingHeals above, but
    // for a PROACTIVE pause before a consequential-looking click/
    // fill_form step — the entry just needs {lane, index} since the
    // step to run is the unmodified original one, not a self-heal
    // replacement guess.
    private final Map<Integer, JSONObject> automationPendingApprovals = new HashMap<>();

    // Agent Permission Firewall (#79): fetched once per session (see
    // fetchAgentFirewallConfig, called lazily from buildAutomationView)
    // and cached here. mode: "off" | "whitelist" | "blacklist".
    private boolean agentFirewallLoaded = false;
    private String agentFirewallMode = "off";
    private final List<String> agentFirewallDomains = new ArrayList<>();

    // Agent Policy Engine (#80): same lazy-fetch-once-per-session shape
    // as the firewall config above. customKeywords extends (doesn't
    // replace) Human Approval Layer (#78)'s hardcoded keyword list;
    // alwaysRequireApproval and maxStepsPerJob are global overrides that
    // apply across every job regardless of that job's own checkboxes.
    private boolean agentPolicyLoaded = false;
    private final List<String> agentPolicyCustomKeywords = new ArrayList<>();
    private boolean agentPolicyAlwaysRequireApproval = false;
    private int agentPolicyMaxStepsPerJob = 0; // 0 = no cap

    private void fetchAgentFirewallConfig() {
        if (backendUrl.isEmpty() || authToken.isEmpty()) return;
        networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(backendUrl + "/agent/firewall", authToken);
                String mode = resp.optString("mode", "off");
                JSONArray domainsArr = resp.optJSONArray("domains");
                List<String> domains = new ArrayList<>();
                if (domainsArr != null) {
                    for (int i = 0; i < domainsArr.length(); i++) domains.add(domainsArr.optString(i, ""));
                }
                mainHandler.post(() -> {
                    agentFirewallMode = mode;
                    agentFirewallDomains.clear();
                    agentFirewallDomains.addAll(domains);
                });
            } catch (Exception ignored) {}
        });
    }

    private void fetchAgentPolicyConfig() {
        if (backendUrl.isEmpty() || authToken.isEmpty()) return;
        networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(backendUrl + "/agent/policy", authToken);
                JSONArray kwArr = resp.optJSONArray("custom_keywords");
                List<String> keywords = new ArrayList<>();
                if (kwArr != null) {
                    for (int i = 0; i < kwArr.length(); i++) keywords.add(kwArr.optString(i, ""));
                }
                boolean alwaysApprove = resp.optBoolean("always_require_approval", false);
                int maxSteps = resp.isNull("max_steps_per_job") ? 0 : resp.optInt("max_steps_per_job", 0);
                mainHandler.post(() -> {
                    agentPolicyCustomKeywords.clear();
                    agentPolicyCustomKeywords.addAll(keywords);
                    agentPolicyAlwaysRequireApproval = alwaysApprove;
                    agentPolicyMaxStepsPerJob = maxSteps;
                });
            } catch (Exception ignored) {}
        });
    }

    // Agent Permission Firewall (#79): "off" or an empty domain list
    // means no restriction. Subdomains of an allowed/blocked domain
    // match too (host.equals(d) || host.endsWith("." + d)).
    private boolean isDomainAllowed(String url) {
        if (!"whitelist".equals(agentFirewallMode) && !"blacklist".equals(agentFirewallMode)) return true;
        if (agentFirewallDomains.isEmpty()) return true;
        String host = safeUrlHost(url);
        if (host == null) return true; // can't tell — fail open rather than break normal navigation
        boolean matches = false;
        for (String d : agentFirewallDomains) {
            if (!d.isEmpty() && (host.equals(d) || host.endsWith("." + d))) { matches = true; break; }
        }
        return "whitelist".equals(agentFirewallMode) ? matches : !matches;
    }

    private String safeUrlHost(String url) {
        try {
            String host = android.net.Uri.parse(url).getHost();
            return host != null ? host.toLowerCase(java.util.Locale.US) : null;
        } catch (Exception e) {
            return null;
        }
    }

    private final Map<Integer, JSONObject> automationJobsCache = new LinkedHashMap<>();
    private final Map<Integer, Boolean> automationCancelFlags = new HashMap<>();

    // Agent Pause (#62) — distinct from Cancel (irreversible) and from the
    // crash/app-restart resume that Agent Resume (#63) already provides:
    // this is a user-triggered "stop for now, continue exactly here
    // later" within the same app session. Checked at the top of
    // executeAutomationStep, so a pause only ever takes effect right
    // before the NEXT step starts — it never interrupts a step that's
    // already in-flight. The job's lane is deliberately left occupied
    // while paused (same reasoning as a parked self-heal approval) so
    // its WebView is still on the right page whenever Resume is tapped.
    private final Map<Integer, Boolean> automationPauseFlags = new HashMap<>();
    private final Map<Integer, Integer> automationPausedAtIndex = new HashMap<>();

    // Automatic Retry (#58) — distinct from per-step Adaptive Retry (#59),
    // which only ever retries ONE step against the same target. This
    // operates at the JOB level: if the task is about to end — either it
    // ran out of steps, or the AI's own "done" step fired — while an
    // earlier step's error is still unresolved (nothing after it
    // succeeded to clear it, see Error Reason Tracking #69), a single bad
    // step likely left the page in a state later steps couldn't recover
    // from no matter how many times that one step alone got retried. So
    // the whole task gets one automatic full re-run from step 0 (with
    // fresh per-step retry/self-heal budgets) before it's allowed to
    // actually finish in an error state. Capped at MAX_JOB_RETRIES so a
    // genuinely broken task doesn't loop forever.
    private static final int MAX_JOB_RETRIES = 1;
    // Confidence Engine (#74): a step whose own self-reported confidence
    // (from the planner or goal agent, see AGENT_SYSTEM_PROMPT/
    // GOAL_AGENT_SYSTEM_PROMPT server-side) falls below this is flagged
    // amber in the stepper even if it succeeded — "it worked, but the AI
    // wasn't very sure going in" is worth seeing, not just pass/fail.
    private static final int LOW_CONFIDENCE_THRESHOLD = 50;
    private final Map<Integer, Integer> automationJobRetryCounts = new HashMap<>();

    // ---- Saved Workflows (#82) state ----
    private final Map<Integer, JSONObject> workflowsCache = new LinkedHashMap<>();

    // ---- Autopilot state ----
    // Drives the CURRENT VISIBLE TAB directly (not a hidden automation
    // lane) — the whole point is the user watches their own browser get
    // driven live, one AI-decided step at a time.
    private boolean autopilotRunning = false;
    private int autopilotStepCount = 0;
    private static final int AUTOPILOT_MAX_STEPS = 20;
    private String autopilotGoal = "";
    private final List<JSONObject> autopilotHistory = new ArrayList<>();
    private AlertDialog autopilotDialog;
    private final StringBuilder autopilotLog = new StringBuilder();
    private TextView autopilotLogView;


    private static final String[] AVAILABLE_LANGUAGES = {
            "English", "Tiếng Việt", "Bahasa Indonesia", "Português", "Español", "हिन्दी"
    };
    // Domain -> ad category. This single map is now the source of truth for
    // both "is this an ad request" (any key match) AND the breakdown shown
    // on the dashboard (Banners/Popups/Native Ads/Trackers), replacing the
    // old crude "Image vs Hidden" guess-by-file-extension approach.
    private static final Map<String, String> AD_DOMAIN_CATEGORIES = buildAdDomainCategories();

    private static Map<String, String> buildAdDomainCategories() {
        Map<String, String> m = new HashMap<>();
        // Banners — classic display/banner ad servers
        m.put("doubleclick.net", "Banners");
        m.put("googlesyndication.com", "Banners");
        m.put("googleadservices.com", "Banners");
        m.put("adservice.google.com", "Banners");
        m.put("adnxs.com", "Banners");
        m.put("smartadserver.com", "Banners");
        m.put("adtechus.com", "Banners");
        // Native Ads — "recommended content" / sponsored-article widgets
        m.put("taboola.com", "Native Ads");
        m.put("outbrain.com", "Native Ads");
        // Popups — redirect/popup/popunder ad networks
        m.put("popads.net", "Popups");
        m.put("propellerads.com", "Popups");
        m.put("popcash.net", "Popups");
        m.put("adcash.com", "Popups");
        m.put("exoclick.com", "Popups");
        m.put("juicyads.com", "Popups");
        // Trackers — analytics/audience-measurement, not visible ads themselves
        m.put("moatads.com", "Trackers");
        m.put("criteo.com", "Trackers");
        m.put("pubmatic.com", "Trackers");
        m.put("rubiconproject.com", "Trackers");
        m.put("scorecardresearch.com", "Trackers");

        // ---- Expanded built-in list (host-suffix matched, see matchAdDomain) ----
        String[] banners = {
                "adsrvr.org", "advertising.com", "adform.net", "openx.net", "casalemedia.com", "indexww.com",
                "sharethrough.com", "33across.com", "bidswitch.net", "contextweb.com", "yieldmo.com",
                "media.net", "adsafeprotected.com", "serving-sys.com", "amazon-adsystem.com", "lijit.com",
                "sovrn.com", "triplelift.com", "gumgum.com", "teads.tv", "smaato.net", "inmobi.com",
                "mopub.com", "adcolony.com", "vungle.com", "chartboost.com", "2mdn.net", "adition.com",
                "adscale.de", "yldbt.com", "adroll.com", "bidtheatre.com", "smartadserver.com", "stickyadstv.com",
                "tremorhub.com", "spotxchange.com", "springserve.com", "freewheel.tv", "ad.gt", "adkernel.com"
        };
        for (String d : banners) m.put(d, "Banners");
        String[] nativeAds = { "revcontent.com", "mgid.com", "zergnet.com", "content.ad", "nativeads.com", "adblade.com" };
        for (String d : nativeAds) m.put(d, "Native Ads");
        String[] popups = {
                "hilltopads.net", "clickadu.com", "adsterra.com", "trafficjunky.net", "plugrush.com",
                "richads.com", "onclickads.net", "popunderjs.com", "trafficstars.com", "tsyndicate.com"
        };
        for (String d : popups) m.put(d, "Popups");
        String[] trackers = {
                "google-analytics.com", "hotjar.com", "quantserve.com", "chartbeat.net", "krxd.net",
                "bluekai.com", "demdex.net", "everesttech.net", "mathtag.com", "tapad.com", "rlcdn.com",
                "agkn.com", "crwdcntrl.net", "2o7.net", "omtrdc.net", "imrworldwide.com", "exelator.com",
                "eyeota.net", "adsymptotic.com", "rfihub.com", "mxpnl.com", "fullstory.com", "mouseflow.com",
                "crazyegg.com", "optimizely.com", "branch.io", "adjust.com", "kochava.com", "app-measurement.com"
        };
        for (String d : trackers) m.put(d, "Trackers");
        return m;
    }

    private static final String[] AD_CATEGORY_ORDER = {"Banners", "Popups", "Native Ads", "Trackers"};

    // A small subset flagged as more aggressive/malvertising-associated networks,
    // tracked separately as "Averted Threats" in the dashboard
    private static final String[] THREAT_DOMAINS = { "popads.net", "adcash.com", "popcash.net" };

    // ---- Speed Dial shortcut model ----
    static class Shortcut {
        String name;
        String url;
        int color;
        Shortcut(String name, String url, int color) {
            this.name = name;
            this.url = url;
            this.color = color;
        }
    }

    // Sensible default set (mainstream, legitimate sites only — not copying every
    // entry from third-party reference screenshots, e.g. skipped unrelated
    // download-aggregator sites some browsers ship by default)
    private static final Object[][] DEFAULT_SHORTCUTS = {
            {"Google", "https://www.google.com", "#4285F4"},
            {"Facebook", "https://www.facebook.com", "#1877F2"},
            {"X", "https://www.twitter.com", "#14171A"},
            {"YouTube", "https://www.youtube.com", "#FF0000"},
            {"Gmail", "https://www.gmail.com", "#EA4335"},
            {"Wikipedia", "https://www.wikipedia.org", "#636466"},
            {"WhatsApp", "https://web.whatsapp.com", "#25D366"},
            {"Instagram", "https://www.instagram.com", "#C13584"},
            {"Netflix", "https://www.netflix.com", "#E50914"},
            {"Amazon", "https://www.amazon.com", "#FF9900"},
            {"Pinterest", "https://www.pinterest.com", "#E60023"},
            {"Weather", "https://weather.com", "#4A90D9"},
            {"PayPal", "https://www.paypal.com", "#003087"},
            {"Reddit", "https://www.reddit.com", "#FF4500"},
            {"LinkedIn", "https://www.linkedin.com", "#0077B5"},
    };

    // ---- Home screen wallpaper presets (redesign, Sep 2026) ----
    // Each entry: {display name, start color res, end color res}. index 0
    // is the original plain look; others are gradients, kept subtle so
    // shortcut/card text stays readable over any of them.
    private static final Object[][] HOME_WALLPAPERS = {
            {"Default", R.color.wallpaper_default_start, R.color.wallpaper_default_end},
            {"Violet", R.color.wallpaper_violet_start, R.color.wallpaper_violet_end},
            {"Rose", R.color.wallpaper_rose_start, R.color.wallpaper_rose_end},
            {"Midnight", R.color.wallpaper_midnight_start, R.color.wallpaper_midnight_end},
            {"Solid", R.color.wallpaper_solid, R.color.wallpaper_solid},
    };

    // Sentinel stored in "home_wallpaper_index" when the user picked a
    // Personal Image instead of one of the gradient presets above — kept
    // out of the HOME_WALLPAPERS array itself since a photo has no
    // start/end color pair to show.
    private static final int HOME_WALLPAPER_CUSTOM_IMAGE_INDEX = -1;
    private static final String HOME_WALLPAPER_IMAGE_FILENAME = "home_wallpaper_custom.jpg";

    // Security fix (Sep 2026 audit): hosts the user has explicitly clicked
    // "Proceed anyway" for on a cert warning, this app session only — never
    // persisted, never silently pre-populated.
    private final Set<String> sslTrustedHostsThisSession = new HashSet<>();

    private WebChromeClient.CustomViewCallback fullscreenCallback;
    private View currentFullscreenView;

    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    // External Agent Signal polling: picks up authorized /agent/signal jobs while the app is active.
    // ---- Background agent: keep running when the person leaves the app ----
    private boolean activityResumed = false;

    /** Starts/stops AgentForegroundService to match whether any agent lane (or Autopilot) is busy. */
    private void reconcileAgentService() {
        boolean busy = autopilotRunning;
        for (Integer id : currentAutomationJobIds) if (id != null) busy = true;
        Intent svc = new Intent(this, AgentForegroundService.class);
        // Ask the service itself (not a field on this Activity): a recreated Activity — after a
        // rotation, say — would not remember it had started one, and a stale notification would stick.
        boolean serviceUp = AgentForegroundService.running;
        if (busy && !serviceUp) {
            try {
                ContextCompat.startForegroundService(this, svc);
            } catch (Exception e) {
                // Android 12+ refuses to start a foreground service from the background.
                // The job still runs while the app is visible; it just isn't protected.
            }
        } else if (!busy && serviceUp) {
            stopService(svc);
            // Nothing left to do in the background → stop the 5-second job poll too.
            if (!activityResumed) mainHandler.removeCallbacks(agentSignalPoller);
        }
    }

    private final Runnable agentServiceReconciler = new Runnable() {
        @Override public void run() {
            if (isFinishing() || isDestroyed()) return;
            reconcileAgentService();
            mainHandler.postDelayed(this, 3000);
        }
    };

    private final Runnable agentSignalPoller = new Runnable() {
        @Override public void run() {
            if (isFinishing() || isDestroyed()) return;
            if (!authToken.isEmpty() && !backendUrl.isEmpty()) {
                networkExecutor.execute(() -> {
                    try {
                        refreshAutomationJobsSync();
                        mainHandler.post(() -> maybeStartAutomationQueue());
                    } catch (Exception ignored) {}
                });
            }
            mainHandler.postDelayed(this, 5000);
        }
    };

    // ---- Sync Retry Engine / Offline-first Sync Queue ----
    // A failed sync (bookmarks/history/settings/tabs) is never just
    // dropped — it's recorded here with an exponential backoff, retried
    // automatically on a timer AND the moment connectivity comes back,
    // and cleared the moment it actually succeeds.
    private static final String[] SYNC_TYPES = {"bookmarks", "history", "settings", "tabs"};
    private android.net.ConnectivityManager connectivityManager;
    private android.net.ConnectivityManager.NetworkCallback syncNetworkCallback;
    private final Handler debounceHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingSuggestFetch;

    // ---- Tab model: each tab owns its own real WebView ----
    static class DevilTab {
        int id;
        WebView webView;
        String title = "New Tab";
        View chipView;
        String type = "home"; // "home" (Speed Dial shown) or "web" (webView shown)
        volatile boolean blockedThisLoad = false;   // written by WebView's request thread, read on the UI thread
        volatile String filterPageUrl = "";          // top-level page URL, for ad-filter third-party / domain= rules
        boolean hasError = false;
        String errorMessage = "";
        String failedUrl = "";
        boolean isIncognito = false;
        // Media resource URLs (video/audio) spotted while this tab loaded/played
        // content — powers "Download Video" from whatever's currently open,
        // capped so it can't grow unbounded on long browsing sessions.
        // filled from WebView's request thread, read on the UI thread → must be synchronized
        final Set<String> detectedMediaUrls = java.util.Collections.synchronizedSet(new LinkedHashSet<>());
        // Smart Tab Suspension: tracks when this tab was last the active
        // (foreground) one, so idle BACKGROUND tabs can be discarded to
        // free memory — same idea as Chrome/Edge "tab discarding". When
        // suspended, webView is set to null and its real WebView/renderer
        // is destroyed (not just hidden) — that's what actually frees the
        // RAM. A fresh WebView is recreated only if the user taps back
        // into this tab, loading suspendedUrl.
        long lastActiveTime = System.currentTimeMillis();
        boolean isSuspended = false;
        String suspendedUrl = "";
        long lastRendererGoneAt = 0; // crash-loop guard for onRenderProcessGone recovery
        // AI Tab Search: a short text extract of the page's content
        // (~600 chars), refreshed on every page load — lets search match
        // what a tab is actually ABOUT, not just its title. Never
        // populated for incognito tabs.
        String pageExtract = "";
        // AI Tab Groups: set by performAiTabGroups(), used to sort/section
        // the Tab Switcher into categories. Empty = ungrouped.
        String groupName = "";
        // Tab Relationship Graph: which tab (by id) this one was opened
        // FROM — set only when opened via a link/"open in new tab", never
        // for deliberate new tabs (toolbar +, incognito button, session
        // restore). -1 = no parent (a "root" tab).
        int parentTabId = -1;
    }

    /** Shows the last captured uncaught exception after a previous failed launch. */
    private void showPreviousStartupCrashIfPresent() {
        java.io.File log = new java.io.File(getFilesDir(), "nex_last_crash.txt");
        if (!log.isFile()) return;
        try {
            java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.FileReader(log));
            StringBuilder details = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                if (details.length() > 16000) { details.append("\n...log truncated..."); break; }
                details.append(line).append('\n');
            }
            reader.close();
            final String crashDetails = details.toString();
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Nex Browser: Previous crash log")
                    .setMessage(crashDetails)
                    .setPositiveButton("Copy log", (dialog, which) -> {
                        android.content.ClipboardManager clipboard = (android.content.ClipboardManager)
                                getSystemService(CLIPBOARD_SERVICE);
                        if (clipboard != null) clipboard.setPrimaryClip(
                                android.content.ClipData.newPlainText("Nex Browser crash log", crashDetails));
                        android.widget.Toast.makeText(this, "Crash log copied. Paste it into ChatGPT.",
                                android.widget.Toast.LENGTH_LONG).show();
                    })
                    .setNegativeButton("Close", null)
                    .show();
            // Keep the file until the user copies it, so a second launch can still show it.
        } catch (Exception ignored) { }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.syncAccentPresetsFromResources(this);
        ThemeManager.apply(this);
        super.onCreate(savedInstanceState);
        showPreviousStartupCrashIfPresent();
        ThemeManager.applyAccentOverlay(this);
        setContentView(R.layout.activity_main);
        // Initialize preferences before toolbar setup; applyToolbarPosition() reads them.
        prefs = getSharedPreferences("nex_browser_prefs", MODE_PRIVATE);
        // exact custom accent on the widgets the theme overlay can only approximate (cursor, progress bar...)
        getWindow().getDecorView().post(() -> ThemeManager.tintViewTree(getWindow().getDecorView(), ThemeManager.getAccentColor(this)));

        webViewContainer = findViewById(R.id.webViewContainer);
        tabBarContainer = findViewById(R.id.tabBarContainer);
        topBar = findViewById(R.id.topBar);
        omniboxWrap = findViewById(R.id.omniboxWrap);
        tabBarScroll = findViewById(R.id.tabBarScroll);
        omniInput = findViewById(R.id.omniInput);
        btnGo = findViewById(R.id.btnGo);
        btnGo.setBackground(ThemeManager.buildGoButtonDrawable(this));
        btnBack = findViewById(R.id.btnBack);
        btnForward = findViewById(R.id.btnForward);
        btnHome = findViewById(R.id.btnHome);
        btnRefresh = findViewById(R.id.btnRefresh);
        btnTabs = findViewById(R.id.btnTabs);
        btnMenu = findViewById(R.id.btnMenu);
        applyToolbarCustomization();
        applyToolbarPosition();
        tabCounter = findViewById(R.id.tabCounter);
        progressBar = findViewById(R.id.progressBar);
        btnBookmarkStar = findViewById(R.id.btnBookmarkStar);
        btnBookmarkStar.setOnClickListener(v -> toggleBookmarkCurrentPage());
        btnVoice = findViewById(R.id.btnVoice);
        btnVoice.setOnClickListener(v -> onVoiceSearchClicked());
        btnQr = findViewById(R.id.btnQr);
        btnQr.setOnClickListener(v -> onQrScanClicked());
        btnAiMode = findViewById(R.id.btnAiMode);
        btnAiMode.setOnClickListener(v -> toggleAiCommandMode());

        // Overlay container used only while a video is fullscreen (YouTube etc.)
        fullscreenContainer = new FrameLayout(this);
        fullscreenContainer.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        fullscreenContainer.setBackgroundColor(getColor(R.color.black));
        fullscreenContainer.setVisibility(View.GONE);
        ((ViewGroup) getWindow().getDecorView()).addView(fullscreenContainer);

        // Overlay container used for full "pages" — Settings, Add-ons, Ad Block
        pageContainer = new FrameLayout(this);
        pageContainer.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pageContainer.setBackgroundColor(getColor(R.color.bg_primary));
        pageContainer.setVisibility(View.GONE);
        ((ViewGroup) getWindow().getDecorView()).addView(pageContainer);

        // Universal Panel drawer (Bookmarks/History/Tabs + quick access to
        // AI/Vault/Ad Block/Customize) — a SEPARATE overlay from
        // pageContainer above, added after it so it always sits on top.
        // Unlike pageContainer (opaque full-screen background, used by
        // every other screen in the app on purpose), this one is a true
        // edge-anchored sliding drawer: a dim scrim over the live page,
        // with the drawer content sliding in from the right and the page
        // still visible/dimmed behind it, closer to Design v2's "universal
        // side panel" than a full-page destination. See
        // showUniversalPanel()/hideUniversalPanel() below for the animation.
        universalPanelContainer = new FrameLayout(this);
        universalPanelContainer.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        universalPanelContainer.setBackgroundColor(0x00000000);
        universalPanelContainer.setVisibility(View.GONE);
        universalPanelContainer.setOnClickListener(v -> hideUniversalPanel()); // tap the dimmed scrim to close
        ((ViewGroup) getWindow().getDecorView()).addView(universalPanelContainer);

        universalPanelDrawer = new FrameLayout(this);
        int drawerWidth = Math.min(
                (int) (getResources().getDisplayMetrics().widthPixels * 0.86f),
                (int) (420 * getResources().getDisplayMetrics().density));
        FrameLayout.LayoutParams drawerParams = new FrameLayout.LayoutParams(
                drawerWidth, ViewGroup.LayoutParams.MATCH_PARENT);
        drawerParams.gravity = android.view.Gravity.END;
        universalPanelDrawer.setLayoutParams(drawerParams);
        universalPanelDrawer.setBackgroundColor(getColor(R.color.bg_primary));
        universalPanelDrawer.setElevation(24f);
        universalPanelDrawer.setClickable(true); // swallow taps so they don't fall through to the scrim
        universalPanelContainer.addView(universalPanelDrawer);

        setupSuggestions();

        prefs = getSharedPreferences("nex_browser_prefs", MODE_PRIVATE);
        loadShortcuts();
        isAdBlockOn = prefs.getBoolean("adblock_enabled", true);
        networkExecutor.execute(this::loadCustomAdFilters);
        // If the app was killed with Private tabs open, their profile is still on disk — remove it
        // before any WebView exists (so it isn't "in use").
        if (prefs.getBoolean("incognito_profile_dirty", false)) wipeIncognitoData();
        isTextOnlyOn = prefs.getBoolean("text_only", false);
        tabViewGrid = prefs.getBoolean("tab_view_grid", false);
        tabViewCarousel = prefs.getBoolean("tab_view_carousel", false);
        reopenTabsOnStartup = prefs.getBoolean("reopen_tabs_on_startup", false);
        isAnimationOn = prefs.getBoolean("animation_on", true);
        isTypingAssistantOn = prefs.getBoolean("typing_assistant", true);
        openLinkInNewTab = prefs.getBoolean("open_link_new_tab", false);
        isDesktopUA = prefs.getBoolean("desktop_ua", false);
        maxDownloads = prefs.getInt("max_downloads", 3);
        newTaskAlwaysAsk = prefs.getBoolean("new_task_always_ask", true);
        autoReconnect = prefs.getBoolean("auto_reconnect", true);
        downloadNotificationOn = prefs.getBoolean("download_notification", true);
        backendUrl = prefs.getString("backend_url", "");
        securePrefs = createSecurePrefs();
        authToken = securePrefs.getString("auth_token", "");
        refreshToken = securePrefs.getString("refresh_token", "");
        accessTokenExpiresAt = securePrefs.getLong("auth_access_expires_at", 0);
        authEmail = securePrefs.getString("auth_email", "");
        passwordManagerEnabled = prefs.getBoolean("password_manager_enabled", true);
        biometricLockEnabled = prefs.getBoolean("biometric_lock_enabled", false);

        startSyncRetryTicker();
        registerSyncConnectivityCallback();
        mainHandler.postDelayed(agentSignalPoller, 5000);

        float savedBrightness = prefs.getFloat("brightness", -1f);
        if (savedBrightness >= 0f) {
            android.view.WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.screenBrightness = savedBrightness;
            getWindow().setAttributes(lp);
        }

        // First tab(s) on launch — restore previous session if "Reopen Tabs on
        // Startup" is on and there's a saved session, otherwise a fresh Speed Dial tab.
        // Session Reconstruction (#14): restores exact tab order + which tab was
        // active, not just a bag of URLs — and this saved state is kept fresh
        // continuously (every navigation/tab change), not only on a clean app
        // close, so a real crash still has something recent to recover from.
        List<SavedTabState> savedSession = reopenTabsOnStartup ? loadSavedSession() : new ArrayList<>();
        if (!savedSession.isEmpty()) {
            int restoreActiveIndex = 0;
            for (int i = 0; i < savedSession.size(); i++) {
                SavedTabState st = savedSession.get(i);
                createNewTab();
                navigate(st.url);
                if (st.wasActive) restoreActiveIndex = i;
            }
            switchToTab(restoreActiveIndex);
        } else {
            createNewTab();
        }

        // Smart Tab Suspension: starts the periodic idle-tab check now that
        // at least one tab exists.
        scheduleTabSuspensionCheck();
        mainHandler.post(agentServiceReconciler);

        // Android 13+ requires runtime permission to show notifications at all —
        // harmless to request even if Firebase (push) was never set up, since
        // download-complete notifications (batch 10) also need this.
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1001);
            }
        }

        // If a push token arrived (from Firebase) before the user signed in,
        // register it now that we know the account + backend URL.
        registerPendingFcmTokenIfReady();

        omniInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                submitOmnibox();
                return true;
            }
            return false;
        });

        btnGo.setOnClickListener(v -> submitOmnibox());

        btnBack.setOnClickListener(v -> {
            WebView wv = currentWebView();
            if (wv != null && wv.canGoBack()) wv.goBack();
        });

        btnForward.setOnClickListener(v -> {
            WebView wv = currentWebView();
            if (wv != null && wv.canGoForward()) wv.goForward();
        });

        btnHome.setOnClickListener(v -> {
            DevilTab tab = currentTab();
            if (tab != null) {
                tab.type = "home";
                tab.title = "New Tab";
                updateTabChip(tab);
                switchToTab(currentTabIndex);
            }
        });

        btnRefresh.setOnClickListener(v -> {
            WebView wv = currentWebView();
            if (wv != null) wv.reload();
        });

        // Opens the tab grid switcher (was previously wired to instantly create
        // a new tab, which isn't what a "Tabs" button should do)
        btnTabs.setOnClickListener(v -> showTabSwitcher());

        btnMenu.setOnClickListener(v -> showMainMenu());
    }

    // ================================================================
    // MAIN MENU (☰) — Speed Mode, Facebook, Ad Block, QR Scanner, Share,
    // Save Page, Full Screen, Find in Page. Matches the UC Mini reference
    // grid layout. Items not yet built (Ad Block, QR Scanner) show a
    // clear "coming later" message rather than silently doing nothing.
    // ================================================================
    private void showMainMenu() {
        BottomSheetDialog dialog = newBottomSheet();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(getColor(R.color.bg_secondary));
        root.setPadding(16, 24, 16, 24);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        root.addView(grid);

        // Redesign pass 3 (Sep 2026): trimmed from 19 flat items down to the
        // items people tap most on an actual page. Agent OS, Research, Watch
        // List, Source Reliability, Fact-Check and Extract Data all moved
        // into the "Tools" hub below (per the UC-style audit's "move advanced
        // AI Agent OS / Research / Watch List / Policy / Security into a
        // second-level Tools hub" recommendation). The old "Facebook" quick
        // shortcut is dropped from here — it's one tap away as a Speed Dial
        // card on Home now that custom shortcuts exist (redesign pass 1).
        Object[][] items = {
                {R.drawable.ic_menu_ai_summary, "AI Summary"},
                {R.drawable.ic_menu_reader, "Reader Mode"},
                {R.drawable.ic_menu_speed, "Speed Mode"},
                {R.drawable.ic_nav_search, "Find in Page"},
                {R.drawable.ic_menu_share, "Share"},
                {R.drawable.ic_menu_save, "Save Page"},
                {R.drawable.ic_menu_video, "Download Video"},
                {R.drawable.ic_menu_fullscreen, "Full Screen"},
                {R.drawable.ic_menu_adblock, "Ad Block"},
                {R.drawable.ic_menu_customize, "Customize"},
                {R.drawable.ic_menu_tools, "Tools"},
                {R.drawable.ic_menu_more, "More"},
        };

        for (Object[] item : items) {
            grid.addView(buildMenuGridItem((int) item[0], (String) item[1], dialog));
        }

        TextView cancel = new TextView(this);
        cancel.setText("Cancel");
        cancel.setTextColor(getColor(R.color.text_primary));
        cancel.setTextSize(12);
        cancel.setGravity(android.view.Gravity.CENTER);
        cancel.setPadding(20, 28, 20, 12);
        cancel.setOnClickListener(v -> dialog.dismiss());
        root.addView(cancel);

        dialog.setContentView(root);
        dialog.show();
    }

    // Redesign pass 4 (Sep 2026): main menu items now use a real vector
    // icon system (single fill color, tinted to match theme) instead of
    // emoji glyphs — matches the audit's "consistent icon system, not
    // emoji-based labels in primary navigation" recommendation. Compact
    // rounded-card look ties this into the same visual language as the
    // Home speed-dial cards (pass 1) and Tab Switcher cards (pass 2).
    private View buildMenuGridItem(int iconRes, String label, BottomSheetDialog dialog) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(android.view.Gravity.CENTER);
        item.setPadding(8, 18, 8, 14);
        item.setBackgroundResource(R.drawable.bg_home_card);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        params.setMargins(5, 5, 5, 5);
        item.setLayoutParams(params);

        ImageView iconView = new ImageView(this);
        iconView.setImageResource(iconRes);
        iconView.setColorFilter(getColor(R.color.text_primary));
        iconView.setLayoutParams(new LinearLayout.LayoutParams(26, 26));
        item.addView(iconView);

        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextColor(getColor(R.color.text_dim));
        labelView.setTextSize(9);
        labelView.setGravity(android.view.Gravity.CENTER);
        labelView.setMaxLines(1);
        labelView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        labelParams.topMargin = 10;
        labelView.setLayoutParams(labelParams);
        item.addView(labelView);

        item.setOnClickListener(v -> {
            dialog.dismiss();
            handleMenuAction(label);
        });

        return item;
    }

    private void handleMenuAction(String label) {
        switch (label) {
            case "AI Summary":
                summarizeCurrentPage();
                break;
            case "Reader Mode":
                showReaderMode();
                break;
            case "Speed Mode":
                toggleDataSaver();
                break;
            case "Find in Page":
                showFindInPage();
                break;
            case "Share":
                sharePage();
                break;
            case "Save Page":
                savePage();
                break;
            case "Download Video":
                showDownloadVideoForCurrentTab();
                break;
            case "Full Screen":
                toggleFullScreen();
                break;
            case "Ad Block":
                showFullPage(buildAdBlockDashboard());
                break;
            case "Customize":
                showThemeCenter();
                break;
            case "Tools":
                showFullPage(buildAgentOsHubView());
                break;
            case "More":
                showProfileToolsMenu();
                break;
        }
    }

    // ================================================================
    // THEME CENTER — Appearance section only (Blueprint/Design v2's
    // Theme/Customize Side Panel). Build-plan Phase 1 + first slice of
    // Phase 2: a real, working Light/Dark/System switch. Built-in theme
    // gallery, My Themes, personal-image backgrounds and custom color
    // pickers are intentionally NOT here yet — each is its own later
    // phase in the build plan, not stubbed with fake buttons here.
    // ================================================================
    // ================================================================
    // TOOLBAR CUSTOMIZATION — Blueprint's "toolbar customization
    // (reorder/enable/disable)" item. Scoped to the four navigation
    // buttons (Back/Forward/Home/Refresh); Tabs and Menu stay fixed since
    // they're structural (Tabs is paired with the tab counter, Menu is
    // the only way to reach most other screens) rather than optional.
    // ================================================================
    private static final String[] TOOLBAR_BUTTON_IDS = {"back", "forward", "home", "refresh"};

    private JSONArray loadToolbarAllOrder() {
        try {
            JSONArray saved = new JSONArray(prefs.getString("toolbar_all_order", "[]"));
            if (saved.length() == TOOLBAR_BUTTON_IDS.length) return saved;
        } catch (Exception ignored) {}
        JSONArray def = new JSONArray();
        for (String id : TOOLBAR_BUTTON_IDS) def.put(id);
        return def;
    }

    private JSONArray loadToolbarHidden() {
        try {
            return new JSONArray(prefs.getString("toolbar_hidden", "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private void saveToolbarAllOrder(JSONArray order) {
        prefs.edit().putString("toolbar_all_order", order.toString()).apply();
    }

    private void saveToolbarHidden(JSONArray hidden) {
        prefs.edit().putString("toolbar_hidden", hidden.toString()).apply();
    }

    private boolean isToolbarIdHidden(JSONArray hidden, String id) {
        for (int i = 0; i < hidden.length(); i++) {
            if (id.equals(hidden.optString(i))) return true;
        }
        return false;
    }

    /** Reorders/hides the four nav buttons inside topBar to match the
     *  saved preference. Called once from onCreate (right after the four
     *  buttons are found) and again immediately after any change made in
     *  showToolbarCustomizer(), so no activity recreate() is needed for
     *  this particular setting. */
    private void applyToolbarCustomization() {
        java.util.Map<String, ImageButton> byId = new java.util.LinkedHashMap<>();
        byId.put("back", btnBack);
        byId.put("forward", btnForward);
        byId.put("home", btnHome);
        byId.put("refresh", btnRefresh);

        for (ImageButton b : byId.values()) {
            if (b.getParent() == topBar) ((ViewGroup) topBar).removeView(b);
        }

        JSONArray order = loadToolbarAllOrder();
        JSONArray hidden = loadToolbarHidden();
        int insertIndex = 0;
        for (int i = 0; i < order.length(); i++) {
            String id = order.optString(i);
            if (isToolbarIdHidden(hidden, id)) continue;
            ImageButton b = byId.get(id);
            if (b != null) {
                ((ViewGroup) topBar).addView(b, insertIndex);
                insertIndex++;
            }
        }
    }

    /**
     * Report gap E: "Moving the entire toolbar from top to bottom is not
     * implemented." Reparents the whole topBar (nav buttons + Tabs/Menu)
     * to either the very first or very last child of the root vertical
     * LinearLayout — everything else (omnibox, tab strip, progress bar,
     * WebView) keeps its existing relative order either way, only the nav
     * bar itself moves, matching how Chrome/Firefox's own top/bottom
     * toolbar toggle behaves.
     */
    private void applyToolbarPosition() {
        ViewGroup root = (ViewGroup) topBar.getParent();
        if (root == null) return;
        boolean atBottom = "bottom".equals(prefs.getString("toolbar_position", "top"));
        int currentIndex = root.indexOfChild(topBar);
        int targetIndex = atBottom ? root.getChildCount() - 1 : 0;
        if (currentIndex == targetIndex) return; // already where it should be
        root.removeView(topBar);
        root.addView(topBar, atBottom ? root.getChildCount() : 0);
    }

    private void setToolbarPosition(String position) {
        prefs.edit().putString("toolbar_position", position).apply();
        applyToolbarPosition();
    }

    private View buildToolbarPositionToggle(BottomSheetDialog dialog) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 4;
        row.setLayoutParams(rowParams);

        String current = prefs.getString("toolbar_position", "top");
        String[] positions = {"top", "bottom"};
        String[] labels = {"⬆ Top", "⬇ Bottom"};
        for (int i = 0; i < positions.length; i++) {
            String pos = positions[i];
            TextView chip = new TextView(this);
            chip.setText(labels[i]);
            chip.setTextSize(12);
            chip.setGravity(android.view.Gravity.CENTER);
            chip.setPadding(16, 16, 16, 16);
            boolean selected = pos.equals(current);
            chip.setTextColor(getColor(selected ? R.color.black : R.color.text_primary));
            chip.setBackgroundColor(selected ? ThemeManager.getAccentColor(this) : getColor(R.color.bg_secondary));
            LinearLayout.LayoutParams chipParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            chipParams.rightMargin = i == 0 ? 6 : 0;
            chip.setLayoutParams(chipParams);
            chip.setOnClickListener(v -> {
                setToolbarPosition(pos);
                dialog.dismiss();
                showToolbarCustomizer();
            });
            row.addView(chip);
        }
        return row;
    }

    private String toolbarButtonLabel(String id) {
        switch (id) {
            case "back": return "◀  Back";
            case "forward": return "▶  Forward";
            case "home": return "🏠  Home";
            case "refresh": return "⟳  Refresh";
            default: return id;
        }
    }

    private void showToolbarCustomizer() {
        BottomSheetDialog dialog = newBottomSheet();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 32, 36, 40);

        TextView title = new TextView(this);
        title.setText("Toolbar");
        title.setTextColor(getColor(R.color.text_primary));
        title.setTextSize(17);
        title.setPadding(8, 0, 0, 4);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Show, hide, and reorder the navigation buttons. Tabs and Menu are always shown.");
        subtitle.setTextColor(getColor(R.color.text_dim));
        subtitle.setTextSize(11.5f);
        subtitle.setPadding(8, 0, 0, 20);
        root.addView(subtitle);

        root.addView(buildToolbarPositionToggle(dialog));

        TextView dragHint = new TextView(this);
        dragHint.setText("Long-press a row below to drag it into a new position, or use ▲▼.");
        dragHint.setTextColor(getColor(R.color.text_dim));
        dragHint.setTextSize(10.5f);
        LinearLayout.LayoutParams dragHintParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        dragHintParams.topMargin = 16;
        dragHintParams.bottomMargin = 8;
        dragHint.setLayoutParams(dragHintParams);
        root.addView(dragHint);

        JSONArray order = loadToolbarAllOrder();
        JSONArray hidden = loadToolbarHidden();
        int count = order.length();
        for (int i = 0; i < count; i++) {
            String id = order.optString(i);
            boolean visible = !isToolbarIdHidden(hidden, id);
            root.addView(buildToolbarRow(id, visible, i, count, dialog));
        }

        dialog.setContentView(root);
        dialog.show();
    }

    private View buildToolbarRow(String id, boolean visible, int index, int count, BottomSheetDialog dialog) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(20, 18, 12, 18);
        row.setBackground(getDrawable(R.drawable.bg_toolbar_btn));
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 8;
        row.setLayoutParams(rowParams);

        // Drag handle — report gap E's other half ("drag-and-drop
        // reordering is not implemented"). Uses Android's real View
        // drag-and-drop framework (startDragAndDrop + OnDragListener),
        // which works on any ViewGroup, not just RecyclerView — no need
        // to rebuild this plain LinearLayout list as a RecyclerView just
        // to get genuine drag support. ▲▼ stay as-is alongside it, since
        // they're more reliable/accessible than a drag gesture.
        TextView dragHandle = new TextView(this);
        dragHandle.setText("⠿");
        dragHandle.setTextSize(15);
        dragHandle.setTextColor(getColor(R.color.text_dim));
        dragHandle.setPadding(0, 8, 20, 8);
        dragHandle.setOnLongClickListener(v -> {
            android.content.ClipData dragData = android.content.ClipData.newPlainText("toolbar_row", id);
            View.DragShadowBuilder shadow = new View.DragShadowBuilder(row);
            row.startDragAndDrop(dragData, shadow, index, 0);
            return true;
        });
        row.addView(dragHandle);

        row.setOnDragListener((v, event) -> {
            switch (event.getAction()) {
                case android.view.DragEvent.ACTION_DRAG_ENTERED:
                    row.setAlpha(0.6f);
                    return true;
                case android.view.DragEvent.ACTION_DRAG_EXITED:
                    row.setAlpha(1f);
                    return true;
                case android.view.DragEvent.ACTION_DROP: {
                    row.setAlpha(1f);
                    Object localState = event.getLocalState();
                    if (localState instanceof Integer) {
                        int fromIndex = (Integer) localState;
                        if (fromIndex != index) {
                            moveToolbarButton(fromIndex, index);
                            dialog.dismiss();
                            showToolbarCustomizer();
                        }
                    }
                    return true;
                }
                case android.view.DragEvent.ACTION_DRAG_ENDED:
                    row.setAlpha(1f);
                    return true;
                default:
                    return true;
            }
        });

        CheckBox checkBox = new CheckBox(this);
        checkBox.setChecked(visible);
        checkBox.setButtonTintList(android.content.res.ColorStateList.valueOf(ThemeManager.getAccentColor(this)));
        checkBox.setOnCheckedChangeListener((btn, isChecked) -> {
            JSONArray hidden = loadToolbarHidden();
            JSONArray updated = new JSONArray();
            boolean already = false;
            for (int i = 0; i < hidden.length(); i++) {
                String hid = hidden.optString(i);
                if (hid.equals(id)) already = true;
                if (!hid.equals(id)) updated.put(hid);
            }
            if (!isChecked && !already) updated.put(id);
            saveToolbarHidden(updated);
            applyToolbarCustomization();
        });
        row.addView(checkBox);

        TextView label = new TextView(this);
        label.setText(toolbarButtonLabel(id));
        label.setTextColor(getColor(R.color.text_primary));
        label.setTextSize(14);
        label.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(label);

        TextView upBtn = new TextView(this);
        upBtn.setText("▲");
        upBtn.setTextSize(13);
        upBtn.setPadding(20, 8, 20, 8);
        upBtn.setTextColor(getColor(index == 0 ? R.color.line_color : R.color.text_dim));
        if (index > 0) {
            upBtn.setOnClickListener(v -> {
                moveToolbarButton(index, index - 1);
                dialog.dismiss();
                showToolbarCustomizer();
            });
        }
        row.addView(upBtn);

        TextView downBtn = new TextView(this);
        downBtn.setText("▼");
        downBtn.setTextSize(13);
        downBtn.setPadding(12, 8, 8, 8);
        downBtn.setTextColor(getColor(index == count - 1 ? R.color.line_color : R.color.text_dim));
        if (index < count - 1) {
            downBtn.setOnClickListener(v -> {
                moveToolbarButton(index, index + 1);
                dialog.dismiss();
                showToolbarCustomizer();
            });
        }
        row.addView(downBtn);

        return row;
    }

    private void moveToolbarButton(int fromIndex, int toIndex) {
        JSONArray order = loadToolbarAllOrder();
        java.util.List<String> list = new java.util.ArrayList<>();
        for (int i = 0; i < order.length(); i++) list.add(order.optString(i));
        if (fromIndex < 0 || fromIndex >= list.size() || toIndex < 0 || toIndex >= list.size()) return;
        String moved = list.remove(fromIndex);
        list.add(toIndex, moved);
        JSONArray updated = new JSONArray();
        for (String id : list) updated.put(id);
        saveToolbarAllOrder(updated);
        applyToolbarCustomization();
    }

    // ---- Built-in Theme Gallery (report gap B: "a full built-in theme
    // gallery... bundles accent/component styling" beyond just picking
    // mode/accent/background separately). Each entry bundles all three at
    // once into one named, curated look — tap once, get a complete themed
    // result — rather than mixing the three pickers above by hand. Reuses
    // applyMyTheme() to actually apply the bundle, so gallery themes go
    // through the exact same, already-tested apply path as a saved My
    // Theme; they just aren't user-editable/deletable the way a saved one
    // is (they're presented directly from this array, not from storage).
    private static final Object[][] THEME_GALLERY = {
            // {label, mode, accent preset name, home wallpaper index}
            {"Midnight Violet", ThemeManager.MODE_DARK,  "Violet",  1},
            {"Rose Dusk",        ThemeManager.MODE_DARK,  "Rose",    2},
            {"Ocean Breeze",     ThemeManager.MODE_LIGHT, "Ocean",   0},
            {"Forest Morning",   ThemeManager.MODE_LIGHT, "Forest",  0},
            {"Amber Night",      ThemeManager.MODE_DARK,  "Amber",   3},
            {"Minimal Noir",     ThemeManager.MODE_DARK,  "Violet",  4},
    };

    private void applyGalleryTheme(Object[] entry) {
        try {
            String mode = (String) entry[1];
            String accentName = (String) entry[2];
            int wallpaperIndex = (Integer) entry[3];

            ThemeManager.AccentPreset preset = ThemeManager.ACCENT_PRESETS[0];
            for (ThemeManager.AccentPreset p : ThemeManager.ACCENT_PRESETS) {
                if (p.name.equals(accentName)) { preset = p; break; }
            }

            JSONObject bundle = new JSONObject();
            bundle.put("mode", mode);
            bundle.put("accentName", preset.name);
            bundle.put("accentLight", preset.lightColor);
            bundle.put("accentDark", preset.darkColor);
            bundle.put("homeWallpaperIndex", wallpaperIndex);
            applyMyTheme(bundle); // same apply path a saved My Theme uses
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't apply theme: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private View buildThemeGalleryRow(BottomSheetDialog dialog) {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        scroll.addView(row);

        String currentMode = ThemeManager.getSavedMode(this);
        String currentAccent = ThemeManager.getAccentPresetName(this);
        int currentWallpaper = prefs.getInt("home_wallpaper_index", 0);

        for (Object[] entry : THEME_GALLERY) {
            String label = (String) entry[0];
            String mode = (String) entry[1];
            String accentName = (String) entry[2];
            int wallpaperIndex = (Integer) entry[3];
            boolean isActive = mode.equals(currentMode) && accentName.equals(currentAccent) && wallpaperIndex == currentWallpaper;

            int darkColor = ThemeManager.ACCENT_PRESETS[0].darkColor;
            for (ThemeManager.AccentPreset p : ThemeManager.ACCENT_PRESETS) {
                if (p.name.equals(accentName)) { darkColor = p.darkColor; break; }
            }

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(180, LinearLayout.LayoutParams.WRAP_CONTENT);
            cardParams.rightMargin = 16;
            card.setLayoutParams(cardParams);

            // Mini preview: this theme's home-background gradient with an
            // accent-colored dot on top, so the card reads at a glance
            // without needing to actually switch to it first.
            FrameLayout preview = new FrameLayout(this);
            preview.setLayoutParams(new LinearLayout.LayoutParams(180, 110));
            android.graphics.drawable.GradientDrawable previewBg = new android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                    new int[]{getColor((int) HOME_WALLPAPERS[wallpaperIndex][1]), getColor((int) HOME_WALLPAPERS[wallpaperIndex][2])});
            previewBg.setCornerRadius(18f);
            if (isActive) previewBg.setStroke(5, darkColor);
            preview.setBackground(previewBg);

            View dot = new View(this);
            FrameLayout.LayoutParams dotParams = new FrameLayout.LayoutParams(28, 28);
            dotParams.gravity = android.view.Gravity.BOTTOM | android.view.Gravity.START;
            dotParams.setMargins(14, 0, 0, 14);
            dot.setLayoutParams(dotParams);
            android.graphics.drawable.GradientDrawable dotBg = new android.graphics.drawable.GradientDrawable();
            dotBg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            dotBg.setColor(darkColor);
            dot.setBackground(dotBg);
            preview.addView(dot);

            if (isActive) {
                TextView check = new TextView(this);
                check.setText("✓");
                check.setTextColor(android.graphics.Color.WHITE);
                check.setTextSize(13);
                FrameLayout.LayoutParams checkParams = new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
                checkParams.gravity = android.view.Gravity.TOP | android.view.Gravity.END;
                checkParams.setMargins(0, 10, 12, 0);
                check.setLayoutParams(checkParams);
                preview.addView(check);
            }

            card.addView(preview);

            TextView nameView = new TextView(this);
            nameView.setText(label);
            nameView.setTextColor(getColor(isActive ? R.color.text_primary : R.color.text_dim));
            nameView.setTextSize(10.5f);
            nameView.setGravity(android.view.Gravity.CENTER);
            nameView.setPadding(0, 8, 0, 0);
            card.addView(nameView);

            card.setOnClickListener(v -> {
                dialog.dismiss();
                if (!isActive) applyGalleryTheme(entry);
            });
            row.addView(card);
        }
        return scroll;
    }

    private void showThemeCenter() {
        BottomSheetDialog dialog = newBottomSheet();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 32, 36, 40);

        TextView title = new TextView(this);
        title.setText("🎨 Customize");
        title.setTextColor(getColor(R.color.text_primary));
        title.setTextSize(17);
        title.setPadding(8, 0, 0, 4);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Appearance");
        subtitle.setTextColor(getColor(R.color.text_dim));
        subtitle.setTextSize(12);
        subtitle.setPadding(8, 0, 0, 20);
        root.addView(subtitle);

        String current = ThemeManager.getSavedMode(this);
        root.addView(buildThemeModeRow("☀️", "Light", ThemeManager.MODE_LIGHT, current, dialog));
        root.addView(buildThemeModeRow("🌙", "Dark", ThemeManager.MODE_DARK, current, dialog));
        root.addView(buildThemeModeRow("⚙️", "System", ThemeManager.MODE_SYSTEM, current, dialog));

        TextView subtitle2 = new TextView(this);
        subtitle2.setText("Home Background");
        subtitle2.setTextColor(getColor(R.color.text_dim));
        subtitle2.setTextSize(12);
        subtitle2.setPadding(8, 20, 0, 12);
        root.addView(subtitle2);

        LinearLayout homeBgRow = new LinearLayout(this);
        homeBgRow.setOrientation(LinearLayout.HORIZONTAL);
        homeBgRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        homeBgRow.setPadding(28, 24, 28, 24);
        homeBgRow.setBackground(getDrawable(R.drawable.bg_toolbar_btn));
        TextView homeBgIcon = new TextView(this);
        homeBgIcon.setText("🖼️");
        homeBgIcon.setTextSize(17);
        LinearLayout.LayoutParams homeBgIconParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        homeBgIconParams.rightMargin = 24;
        homeBgIcon.setLayoutParams(homeBgIconParams);
        homeBgRow.addView(homeBgIcon);
        TextView homeBgLabel = new TextView(this);
        homeBgLabel.setText("Gradients & Personal Image…");
        homeBgLabel.setTextColor(getColor(R.color.text_primary));
        homeBgLabel.setTextSize(14);
        homeBgRow.addView(homeBgLabel);
        homeBgRow.setOnClickListener(v -> {
            dialog.dismiss();
            showHomeStyleDialog();
        });
        root.addView(homeBgRow);

        LinearLayout toolbarRow = new LinearLayout(this);
        toolbarRow.setOrientation(LinearLayout.HORIZONTAL);
        toolbarRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        toolbarRow.setPadding(28, 24, 28, 24);
        toolbarRow.setBackground(getDrawable(R.drawable.bg_toolbar_btn));
        LinearLayout.LayoutParams toolbarRowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        toolbarRowParams.topMargin = 8;
        toolbarRow.setLayoutParams(toolbarRowParams);
        TextView toolbarIcon = new TextView(this);
        toolbarIcon.setText("🧭");
        toolbarIcon.setTextSize(17);
        LinearLayout.LayoutParams toolbarIconParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        toolbarIconParams.rightMargin = 24;
        toolbarIcon.setLayoutParams(toolbarIconParams);
        toolbarRow.addView(toolbarIcon);
        TextView toolbarLabel = new TextView(this);
        toolbarLabel.setText("Toolbar buttons…");
        toolbarLabel.setTextColor(getColor(R.color.text_primary));
        toolbarLabel.setTextSize(14);
        toolbarRow.addView(toolbarLabel);
        toolbarRow.setOnClickListener(v -> {
            dialog.dismiss();
            showToolbarCustomizer();
        });
        root.addView(toolbarRow);

        TextView subtitle3 = new TextView(this);
        subtitle3.setText("Accent Color");
        subtitle3.setTextColor(getColor(R.color.text_dim));
        subtitle3.setTextSize(12);
        subtitle3.setPadding(8, 20, 0, 12);
        root.addView(subtitle3);

        LinearLayout swatchRow = new LinearLayout(this);
        swatchRow.setOrientation(LinearLayout.HORIZONTAL);
        swatchRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        String currentAccentName = ThemeManager.getAccentPresetName(this);
        for (ThemeManager.AccentPreset preset : ThemeManager.ACCENT_PRESETS) {
            boolean isSelected = preset.name.equals(currentAccentName);
            LinearLayout swatchCol = new LinearLayout(this);
            swatchCol.setOrientation(LinearLayout.VERTICAL);
            swatchCol.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
            LinearLayout.LayoutParams colParams = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            swatchCol.setLayoutParams(colParams);

            View dot = new View(this);
            dot.setLayoutParams(new LinearLayout.LayoutParams(40, 40));
            android.graphics.drawable.GradientDrawable dotBg = new android.graphics.drawable.GradientDrawable();
            dotBg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            // Preview swatch always shows the dark-mode value — it reads
            // consistently as a "chip of color" regardless of which mode
            // the sheet itself happens to be rendered in right now.
            dotBg.setColor(preset.darkColor);
            if (isSelected) {
                dotBg.setStroke(4, getColor(R.color.text_primary));
            }
            dot.setBackground(dotBg);
            swatchCol.addView(dot);

            TextView dotLabel = new TextView(this);
            dotLabel.setText((isSelected ? "✓ " : "") + preset.name);
            dotLabel.setTextColor(getColor(isSelected ? R.color.text_primary : R.color.text_dim));
            dotLabel.setTextSize(10);
            dotLabel.setGravity(android.view.Gravity.CENTER);
            dotLabel.setPadding(0, 8, 0, 0);
            swatchCol.addView(dotLabel);

            swatchCol.setOnClickListener(v -> {
                dialog.dismiss();
                if (!preset.name.equals(currentAccentName)) {
                    ThemeManager.setAccentPreset(this, preset);
                    recreate();
                }
            });
            swatchRow.addView(swatchCol);
        }

        boolean isCustomSelected = "Custom".equals(currentAccentName);
        LinearLayout customCol = new LinearLayout(this);
        customCol.setOrientation(LinearLayout.VERTICAL);
        customCol.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        customCol.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        View customDot = new View(this);
        customDot.setLayoutParams(new LinearLayout.LayoutParams(40, 40));
        android.graphics.drawable.GradientDrawable customDotBg = new android.graphics.drawable.GradientDrawable();
        customDotBg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        if (isCustomSelected) {
            customDotBg.setColor(ThemeManager.getAccentColor(this));
            customDotBg.setStroke(4, getColor(R.color.text_primary));
        } else {
            customDotBg.setColor(android.graphics.Color.TRANSPARENT);
            customDotBg.setStroke(3, getColor(R.color.text_dim));
        }
        customDot.setBackground(customDotBg);
        customCol.addView(customDot);

        TextView customLabel = new TextView(this);
        customLabel.setText((isCustomSelected ? "✓ " : "+ ") + "Custom");
        customLabel.setTextColor(getColor(isCustomSelected ? R.color.text_primary : R.color.text_dim));
        customLabel.setTextSize(10);
        customLabel.setGravity(android.view.Gravity.CENTER);
        customLabel.setPadding(0, 8, 0, 0);
        customCol.addView(customLabel);

        customCol.setOnClickListener(v -> {
            dialog.dismiss();
            showCustomAccentPicker();
        });
        swatchRow.addView(customCol);
        root.addView(swatchRow);

        TextView subtitleGallery = new TextView(this);
        subtitleGallery.setText("Theme Gallery");
        subtitleGallery.setTextColor(getColor(R.color.text_dim));
        subtitleGallery.setTextSize(12);
        subtitleGallery.setPadding(8, 20, 0, 12);
        root.addView(subtitleGallery);

        TextView gallerySubtext = new TextView(this);
        gallerySubtext.setText("Complete looks — mode, accent and background bundled together in one tap.");
        gallerySubtext.setTextColor(getColor(R.color.text_dim));
        gallerySubtext.setTextSize(10);
        gallerySubtext.setPadding(8, 0, 0, 12);
        root.addView(gallerySubtext);

        root.addView(buildThemeGalleryRow(dialog));

        TextView subtitle4 = new TextView(this);
        subtitle4.setText("My Themes");
        subtitle4.setTextColor(getColor(R.color.text_dim));
        subtitle4.setTextSize(12);
        subtitle4.setPadding(8, 20, 0, 12);
        root.addView(subtitle4);

        JSONArray myThemes = loadMyThemes();
        for (int i = 0; i < myThemes.length(); i++) {
            JSONObject theme = myThemes.optJSONObject(i);
            if (theme != null) root.addView(buildMyThemeRow(theme, dialog));
        }

        LinearLayout saveRow = new LinearLayout(this);
        saveRow.setOrientation(LinearLayout.HORIZONTAL);
        saveRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        saveRow.setPadding(28, 24, 28, 24);
        saveRow.setBackground(getDrawable(R.drawable.bg_toolbar_btn));
        TextView saveIcon = new TextView(this);
        saveIcon.setText("➕");
        saveIcon.setTextSize(15);
        LinearLayout.LayoutParams saveIconParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        saveIconParams.rightMargin = 24;
        saveIcon.setLayoutParams(saveIconParams);
        saveRow.addView(saveIcon);
        TextView saveLabel = new TextView(this);
        saveLabel.setText("Save current as theme…");
        saveLabel.setTextColor(getColor(R.color.text_primary));
        saveLabel.setTextSize(14);
        saveRow.addView(saveLabel);
        saveRow.setOnClickListener(v -> {
            dialog.dismiss();
            promptSaveCurrentAsTheme();
        });
        root.addView(saveRow);

        LinearLayout importRow = new LinearLayout(this);
        importRow.setOrientation(LinearLayout.HORIZONTAL);
        importRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        importRow.setPadding(28, 20, 28, 8);
        TextView importIcon = new TextView(this);
        importIcon.setText("📥");
        importIcon.setTextSize(14);
        LinearLayout.LayoutParams importIconParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        importIconParams.rightMargin = 24;
        importIcon.setLayoutParams(importIconParams);
        importRow.addView(importIcon);
        TextView importLabel = new TextView(this);
        importLabel.setText("Import theme file…");
        importLabel.setTextColor(getColor(R.color.text_dim));
        importLabel.setTextSize(12.5f);
        importRow.addView(importLabel);
        importRow.setOnClickListener(v -> {
            dialog.dismiss();
            importThemeLauncher.launch("application/json");
        });
        root.addView(importRow);

        TextView comingSoon = new TextView(this);
        comingSoon.setText("Personal-image themes now travel with export/import — the photo is bundled into the file. The Theme Gallery above bundles complete looks; My Themes below is for your own saved combinations.");
        comingSoon.setTextColor(getColor(R.color.text_dim));
        comingSoon.setTextSize(11);
        comingSoon.setPadding(8, 24, 8, 0);
        root.addView(comingSoon);

        dialog.setContentView(root);
        dialog.show();
    }

    // ================================================================
    // CUSTOM ACCENT COLOR (RGB) — the "custom color picker" item still
    // open in ACCENT-COLOR-CHANGES.md. Simple three-slider RGB picker
    // (no external color-picker library in this project) rather than a
    // hex-text field, so every possible slider position is always a
    // valid color — nothing to parse or reject.
    //
    // SCOPE NOTE: a custom color reaches the same ~22+3 runtime spots the
    // 5 built-in presets do (see ACCENT-COLOR-CHANGES.md and
    // ACCENT-COLOR-FULL-COVERAGE-CHANGES.md), but NOT the colorSecondary
    // ThemeOverlay — that mechanism needs a precompiled XML color
    // resource per preset, which isn't possible for an arbitrary RGB
    // value chosen at runtime. applyAccentOverlay()'s existing default
    // case already falls back to the Violet overlay for any unrecognized
    // preset name ("Custom" included), so this isn't a crash risk, just
    // a visual inconsistency in that one small set of Material defaults
    // — stated in the picker dialog itself, not hidden.
    // ================================================================
    private void showCustomAccentPicker() {
        int startColor = "Custom".equals(ThemeManager.getAccentPresetName(this))
                ? ThemeManager.getAccentColor(this)
                : ThemeManager.ACCENT_PRESETS[0].darkColor;
        int[] rgb = {
                android.graphics.Color.red(startColor),
                android.graphics.Color.green(startColor),
                android.graphics.Color.blue(startColor)
        };

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 24, 48, 8);

        View preview = new View(this);
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 100);
        previewParams.bottomMargin = 20;
        preview.setLayoutParams(previewParams);
        android.graphics.drawable.GradientDrawable previewBg = new android.graphics.drawable.GradientDrawable();
        previewBg.setCornerRadius(16);
        previewBg.setColor(android.graphics.Color.rgb(rgb[0], rgb[1], rgb[2]));
        preview.setBackground(previewBg);
        root.addView(preview);

        TextView noteText = new TextView(this);
        noteText.setText("Reaches most accent-colored elements. A few default-tinted controls (like standard switches) keep the Violet accent instead — see the Theme Center note.");
        noteText.setTextColor(getColor(R.color.text_dim));
        noteText.setTextSize(10.5f);
        noteText.setPadding(0, 0, 0, 12);
        root.addView(noteText);

        String[] channelNames = {"Red", "Green", "Blue"};
        for (int c = 0; c < 3; c++) {
            final int channel = c;
            TextView channelLabel = new TextView(this);
            channelLabel.setText(channelNames[c] + ": " + rgb[c]);
            channelLabel.setTextColor(getColor(R.color.text_primary));
            channelLabel.setTextSize(12);
            root.addView(channelLabel);

            SeekBar seekBar = new SeekBar(this);
            seekBar.setMax(255);
            seekBar.setProgress(rgb[c]);
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                    rgb[channel] = progress;
                    channelLabel.setText(channelNames[channel] + ": " + progress);
                    previewBg.setColor(android.graphics.Color.rgb(rgb[0], rgb[1], rgb[2]));
                }
                @Override public void onStartTrackingTouch(SeekBar sb) {}
                @Override public void onStopTrackingTouch(SeekBar sb) {}
            });
            root.addView(seekBar);
        }

        ScrollView scrollWrap = new ScrollView(this);
        scrollWrap.addView(root);

        new AccentDialogBuilder(this)
                .setTitle("Custom Accent Color")
                .setView(scrollWrap)
                .setPositiveButton("Apply", (d, w) -> {
                    int base = android.graphics.Color.rgb(rgb[0], rgb[1], rgb[2]);
                    int lightVariant = ThemeManager.shade(base, 0.75f);
                    int darkVariant = ThemeManager.shade(base, 1.15f);
                    ThemeManager.setAccentPreset(this, new ThemeManager.AccentPreset("Custom", lightVariant, darkVariant));
                    recreate();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private View buildThemeModeRow(String emoji, String label, String mode, String currentMode, BottomSheetDialog dialog) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(28, 24, 28, 24);
        row.setBackground(getDrawable(R.drawable.bg_toolbar_btn));
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 8;
        row.setLayoutParams(rowParams);

        TextView icon = new TextView(this);
        icon.setText(emoji);
        icon.setTextSize(17);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        iconParams.rightMargin = 24;
        icon.setLayoutParams(iconParams);
        row.addView(icon);

        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextColor(getColor(R.color.text_primary));
        labelView.setTextSize(14);
        labelView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(labelView);

        if (mode.equals(currentMode)) {
            TextView check = new TextView(this);
            check.setText("✓");
            check.setTextColor(ThemeManager.getAccentColor(this));
            check.setTextSize(16);
            row.addView(check);
        }

        row.setOnClickListener(v -> {
            dialog.dismiss();
            if (!mode.equals(currentMode)) {
                ThemeManager.setMode(this, mode);
                recreate();
            }
        });
        return row;
    }

    // ================================================================
    // MY THEMES — save/apply/delete/export/import a named snapshot of
    // {Appearance mode, Accent preset, Home Background choice}. Design
    // v2 item #16: "Export/Import themes — versioned JSON package".
    // Stored as a JSON array under one SharedPreferences key, same file
    // ThemeManager already uses, so everything Theme-Center-related
    // lives in one place.
    // ================================================================
    private static final String KEY_MY_THEMES = "my_themes";
    private static final int MY_THEME_SCHEMA_VERSION = 1;

    private JSONArray loadMyThemes() {
        SharedPreferences themePrefs = getSharedPreferences("theme_prefs", MODE_PRIVATE);
        try {
            return new JSONArray(themePrefs.getString(KEY_MY_THEMES, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private void saveMyThemesArray(JSONArray arr) {
        getSharedPreferences("theme_prefs", MODE_PRIVATE)
                .edit().putString(KEY_MY_THEMES, arr.toString()).apply();
    }

    private void promptSaveCurrentAsTheme() {
        EditText input = new EditText(this);
        input.setHint("Theme name");
        input.setPadding(40, 24, 40, 24);
        new AccentDialogBuilder(this)
                .setTitle("Save current as theme")
                .setView(input)
                .setPositiveButton("Save", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) name = "My Theme";
                    saveCurrentAsTheme(name);
                    Toast.makeText(this, "Theme saved", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveCurrentAsTheme(String name) {
        try {
            JSONObject theme = new JSONObject();
            theme.put("schema", MY_THEME_SCHEMA_VERSION);
            theme.put("id", String.valueOf(System.currentTimeMillis()));
            theme.put("name", name);
            theme.put("mode", ThemeManager.getSavedMode(this));
            String accentName = ThemeManager.getAccentPresetName(this);
            theme.put("accentName", accentName);
            for (ThemeManager.AccentPreset p : ThemeManager.ACCENT_PRESETS) {
                if (p.name.equals(accentName)) {
                    theme.put("accentLight", p.lightColor);
                    theme.put("accentDark", p.darkColor);
                    break;
                }
            }
            theme.put("homeWallpaperIndex", prefs.getInt("home_wallpaper_index", 0));

            JSONArray all = loadMyThemes();
            all.put(theme);
            saveMyThemesArray(all);
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't save theme: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void applyMyTheme(JSONObject theme) {
        try {
            String mode = theme.optString("mode", ThemeManager.MODE_DARK);
            ThemeManager.setMode(this, mode);

            String accentName = theme.optString("accentName", "Violet");
            int lightColor = theme.optInt("accentLight", ThemeManager.ACCENT_PRESETS[0].lightColor);
            int darkColor = theme.optInt("accentDark", ThemeManager.ACCENT_PRESETS[0].darkColor);
            ThemeManager.setAccentPreset(this, new ThemeManager.AccentPreset(accentName, lightColor, darkColor));

            int wallpaperIndex = theme.optInt("homeWallpaperIndex", 0);
            if (wallpaperIndex == HOME_WALLPAPER_CUSTOM_IMAGE_INDEX
                    && !new File(getFilesDir(), HOME_WALLPAPER_IMAGE_FILENAME).exists()) {
                // Imported from another device/export with no matching photo
                // on this one — fall back rather than show a blank Home.
                wallpaperIndex = 0;
            }
            prefs.edit().putInt("home_wallpaper_index", wallpaperIndex).apply();

            recreate();
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't apply theme: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteMyTheme(String id) {
        JSONArray all = loadMyThemes();
        JSONArray kept = new JSONArray();
        for (int i = 0; i < all.length(); i++) {
            JSONObject t = all.optJSONObject(i);
            if (t != null && !id.equals(t.optString("id"))) kept.put(t);
        }
        saveMyThemesArray(kept);
    }

    // Closes the "Duplicate/rename an existing saved theme" gap noted in
    // MY-THEMES-CHANGES.md — previously the only way to get a variant of a
    // saved theme was save-a-new-one-then-delete-the-old-one.

    private void duplicateMyTheme(JSONObject theme) {
        try {
            JSONObject copy = new JSONObject(theme.toString()); // deep copy via JSON round-trip
            copy.put("id", String.valueOf(System.currentTimeMillis())); // never reuse the id, or it'd collide with the original
            copy.put("name", theme.optString("name", "My Theme") + " (Copy)");
            JSONArray all = loadMyThemes();
            all.put(copy);
            saveMyThemesArray(all);
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't duplicate theme: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void renameMyTheme(String id, String newName) {
        JSONArray all = loadMyThemes();
        for (int i = 0; i < all.length(); i++) {
            JSONObject t = all.optJSONObject(i);
            if (t != null && id.equals(t.optString("id"))) {
                try { t.put("name", newName); } catch (Exception ignored) {}
                break;
            }
        }
        saveMyThemesArray(all);
    }

    private void promptRenameMyTheme(JSONObject theme) {
        EditText input = new EditText(this);
        input.setHint("Theme name");
        input.setText(theme.optString("name", ""));
        input.setSelection(input.getText().length());
        input.setPadding(40, 24, 40, 24);
        new AccentDialogBuilder(this)
                .setTitle("Rename theme")
                .setView(input)
                .setPositiveButton("Save", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) name = theme.optString("name", "My Theme");
                    renameMyTheme(theme.optString("id"), name);
                    showThemeCenter(); // rebuild so the new name shows
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Personal-image theme portability (report gap D: "the exported
    // .nextheme JSON does not contain the actual photo... falls back to
    // the default gradient" on another device). Downscaled + JPEG-
    // compressed rather than embedding the original file byte-for-byte,
    // since a raw picked photo can be several MB and this same JSON also
    // gets kept around in SharedPreferences via saveMyThemesArray() —
    // a multi-MB SharedPreferences value is a real reliability risk
    // (slow writes, ANR risk), not just a size inconvenience.
    private static final int THEME_EXPORT_IMAGE_MAX_DIM = 1080;
    private static final int THEME_EXPORT_IMAGE_QUALITY = 80;

    private String compressImageFileToBase64(File imgFile) {
        try {
            android.graphics.BitmapFactory.Options bounds = new android.graphics.BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            android.graphics.BitmapFactory.decodeFile(imgFile.getAbsolutePath(), bounds);
            int sample = 1;
            while ((bounds.outWidth / sample) > THEME_EXPORT_IMAGE_MAX_DIM
                    || (bounds.outHeight / sample) > THEME_EXPORT_IMAGE_MAX_DIM) {
                sample *= 2;
            }
            android.graphics.BitmapFactory.Options opts = new android.graphics.BitmapFactory.Options();
            opts.inSampleSize = sample;
            android.graphics.Bitmap bitmap = android.graphics.BitmapFactory.decodeFile(imgFile.getAbsolutePath(), opts);
            if (bitmap == null) return null;

            java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
            bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, THEME_EXPORT_IMAGE_QUALITY, baos);
            bitmap.recycle();
            return android.util.Base64.encodeToString(baos.toByteArray(), android.util.Base64.NO_WRAP);
        } catch (Exception e) {
            return null;
        }
    }

    private void exportMyTheme(JSONObject theme) {
        try {
            // Work on a copy for export — a personal-image photo gets
            // embedded into the EXPORTED file only, never written back into
            // the on-device My Themes list (which stays lightweight, since
            // the real photo file already lives locally at
            // HOME_WALLPAPER_IMAGE_FILENAME for this device's own use).
            JSONObject exportTheme = new JSONObject(theme.toString());
            if (theme.optInt("homeWallpaperIndex", 0) == HOME_WALLPAPER_CUSTOM_IMAGE_INDEX) {
                File imgFile = new File(getFilesDir(), HOME_WALLPAPER_IMAGE_FILENAME);
                if (imgFile.exists()) {
                    String base64 = compressImageFileToBase64(imgFile);
                    if (base64 != null) {
                        exportTheme.put("homeWallpaperImageBase64", base64);
                    } else {
                        Toast.makeText(this, "Couldn't include the photo — exporting theme colors only", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            String safeName = theme.optString("name", "theme").replaceAll("[^a-zA-Z0-9 _-]", "").trim();
            if (safeName.isEmpty()) safeName = "theme";
            File exportDir = new File(getCacheDir(), "theme_exports");
            if (!exportDir.exists()) exportDir.mkdirs();
            File outFile = new File(exportDir, safeName + ".nextheme.json");
            try (FileOutputStream out = new FileOutputStream(outFile)) {
                out.write(exportTheme.toString(2).getBytes("UTF-8"));
            }
            Uri uri = androidx.core.content.FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", outFile);
            android.content.Intent shareIntent = new android.content.Intent(android.content.Intent.ACTION_SEND);
            shareIntent.setType("application/json");
            shareIntent.putExtra(android.content.Intent.EXTRA_STREAM, uri);
            shareIntent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(android.content.Intent.createChooser(shareIntent, "Share theme"));
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't export theme: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void importMyTheme(JSONObject theme) {
        try {
            // Re-stamp with a fresh id/name-safety rather than trusting the
            // file blindly — it may have come from another device/export.
            theme.put("id", String.valueOf(System.currentTimeMillis()));
            if (!theme.has("name") || theme.optString("name").trim().isEmpty()) {
                theme.put("name", "Imported Theme");
            }

            // If the export carried an embedded personal-image photo,
            // write it into THIS device's own wallpaper file now — that's
            // what actually closes gap D, rather than just accepting the
            // gradient fallback when the photo doesn't already exist here.
            String embeddedImage = theme.optString("homeWallpaperImageBase64", "");
            if (!embeddedImage.isEmpty()) {
                try {
                    byte[] bytes = android.util.Base64.decode(embeddedImage, android.util.Base64.NO_WRAP);
                    try (FileOutputStream out = new FileOutputStream(new File(getFilesDir(), HOME_WALLPAPER_IMAGE_FILENAME))) {
                        out.write(bytes);
                    }
                    Toast.makeText(this, "Theme's personal image restored on this device", Toast.LENGTH_SHORT).show();
                } catch (Exception imgErr) {
                    Toast.makeText(this, "Theme imported, but its photo couldn't be restored — using the gradient instead", Toast.LENGTH_LONG).show();
                }
                // The photo now lives on disk like any other local wallpaper —
                // no need to keep duplicating a large base64 blob inside the
                // SharedPreferences-backed My Themes list too.
                theme.remove("homeWallpaperImageBase64");
            }

            JSONArray all = loadMyThemes();
            all.put(theme);
            saveMyThemesArray(all);
            Toast.makeText(this, "Theme imported — open Customize to apply it", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't import theme: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private View buildMyThemeRow(JSONObject theme, BottomSheetDialog dialog) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(28, 20, 20, 20);
        row.setBackground(getDrawable(R.drawable.bg_toolbar_btn));
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 8;
        row.setLayoutParams(rowParams);

        View swatch = new View(this);
        LinearLayout.LayoutParams swatchParams = new LinearLayout.LayoutParams(28, 28);
        swatchParams.rightMargin = 20;
        swatch.setLayoutParams(swatchParams);
        android.graphics.drawable.GradientDrawable swatchBg = new android.graphics.drawable.GradientDrawable();
        swatchBg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        swatchBg.setColor(theme.optInt("accentDark", ThemeManager.ACCENT_PRESETS[0].darkColor));
        swatch.setBackground(swatchBg);
        row.addView(swatch);

        TextView name = new TextView(this);
        name.setText(theme.optString("name", "My Theme"));
        name.setTextColor(getColor(R.color.text_primary));
        name.setTextSize(14);
        name.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        name.setOnClickListener(v -> {
            dialog.dismiss();
            applyMyTheme(theme);
        });
        row.addView(name);

        TextView renameBtn = new TextView(this);
        renameBtn.setText("✎");
        renameBtn.setTextColor(getColor(R.color.text_dim));
        renameBtn.setTextSize(15);
        renameBtn.setPadding(16, 8, 16, 8);
        renameBtn.setOnClickListener(v -> {
            dialog.dismiss();
            promptRenameMyTheme(theme);
        });
        row.addView(renameBtn);

        TextView duplicateBtn = new TextView(this);
        duplicateBtn.setText("⎘");
        duplicateBtn.setTextColor(getColor(R.color.text_dim));
        duplicateBtn.setTextSize(15);
        duplicateBtn.setPadding(16, 8, 16, 8);
        duplicateBtn.setOnClickListener(v -> {
            duplicateMyTheme(theme);
            dialog.dismiss();
            showThemeCenter(); // rebuild the sheet so the new copy appears
        });
        row.addView(duplicateBtn);

        TextView exportBtn = new TextView(this);
        exportBtn.setText("📤");
        exportBtn.setTextSize(15);
        exportBtn.setPadding(16, 8, 16, 8);
        exportBtn.setOnClickListener(v -> {
            dialog.dismiss();
            exportMyTheme(theme);
        });
        row.addView(exportBtn);

        TextView deleteBtn = new TextView(this);
        deleteBtn.setText("✕");
        deleteBtn.setTextColor(getColor(R.color.text_dim));
        deleteBtn.setTextSize(15);
        deleteBtn.setPadding(16, 8, 8, 8);
        deleteBtn.setOnClickListener(v -> {
            deleteMyTheme(theme.optString("id"));
            dialog.dismiss();
            showThemeCenter(); // rebuild the sheet so the deleted row disappears
        });
        row.addView(deleteBtn);

        return row;
    }

    // ================================================================
    // PROFILE / TOOLS MENU — History & Bookmarks, My Videos, Downloads,
    // Night, Incognito, Tools, plus a bottom row (Settings, Collapse,
    // Power). Reached via "More" in the Main Menu.
    // ================================================================
    private boolean isNightDimOn = false;

    private void showProfileToolsMenu() {
        BottomSheetDialog dialog = newBottomSheet();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(getColor(R.color.bg_secondary));
        root.setPadding(16, 24, 16, 16);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        root.addView(grid);

        grid.addView(buildProfileToolTile("📜", "History & Bookmarks", () -> {
            dialog.dismiss();
            showUniversalPanel(buildBookmarksHistoryView(true));
        }));
        grid.addView(buildProfileToolTile("▶", "My Videos", () -> {
            dialog.dismiss();
            showFullPage(buildMyVideosView());
        }));
        grid.addView(buildProfileToolTile("⇩", "Downloads", () -> {
            dialog.dismiss();
            showFullPage(buildDownloadsManagerView());
        }));
        grid.addView(buildProfileToolTile("📦", "Files", () -> {
            dialog.dismiss();
            showFullPage(buildFilesManagerView());
        }));
        grid.addView(buildProfileToolTile("🌙", "Night", () -> {
            dialog.dismiss();
            toggleNightDim();
        }));
        grid.addView(buildProfileToolTile("🕶", "Incognito", () -> {
            dialog.dismiss();
            createIncognitoTab();
        }));
        // Automation / Workflows tiles removed from here (redesign pass 3,
        // Sep 2026) — they now live inside the "🧰 Tools" hub alongside the
        // rest of the AI/agent surface, instead of being duplicated in both
        // menus.

        // Bottom row: Settings / Collapse / Power
        LinearLayout bottomRow = new LinearLayout(this);
        bottomRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams bottomRowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bottomRowParams.topMargin = 24;
        bottomRow.setLayoutParams(bottomRowParams);

        bottomRow.addView(buildBottomRowIcon("⚙", () -> {
            dialog.dismiss();
            showFullPage(buildSettingsView());
        }));
        bottomRow.addView(buildBottomRowIcon("⌄", dialog::dismiss));
        bottomRow.addView(buildBottomRowIcon("⏻", () -> {
            dialog.dismiss();
            confirmExitApp();
        }));

        root.addView(bottomRow);

        dialog.setContentView(root);
        dialog.show();
    }

    private View buildProfileToolTile(String icon, String label, Runnable action) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(android.view.Gravity.CENTER);
        item.setPadding(12, 20, 12, 20);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        item.setLayoutParams(params);

        TextView iconView = new TextView(this);
        iconView.setText(icon);
        iconView.setTextSize(20);
        iconView.setGravity(android.view.Gravity.CENTER);
        item.addView(iconView);

        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextColor(getColor(R.color.text_dim));
        labelView.setTextSize(9);
        labelView.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        labelParams.topMargin = 10;
        labelView.setLayoutParams(labelParams);
        item.addView(labelView);

        item.setOnClickListener(v -> action.run());
        return item;
    }

    private View buildBottomRowIcon(String icon, Runnable action) {
        TextView view = new TextView(this);
        view.setText(icon);
        view.setTextSize(16);
        view.setTextColor(getColor(R.color.text_primary));
        view.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.weight = 1;
        view.setLayoutParams(params);
        view.setPadding(16, 16, 16, 16);
        view.setOnClickListener(v -> action.run());
        return view;
    }

    // ================================================================
    // DOWNLOAD MANAGER (real, custom) — its own queue with pause/resume
    // (HTTP Range), retry, progress %, and duplicate-URL detection —
    // wrapping raw HttpURLConnection rather than Android's system
    // DownloadManager (which has no manual pause/resume API). Also the
    // engine behind the Universal Downloader: paste any link, or grab
    // whatever video/audio a page is currently playing — YouTube, TikTok,
    // Instagram, or anywhere else — and queue it here.
    // ================================================================
    static class NexDownload {
        String id;
        String url;
        String fileName;
        String mimeType;
        String status; // queued, downloading, paused, done, failed
        long totalBytes = -1;
        long downloadedBytes = 0;
        int retryCount = 0;
        String error = "";
        long createdAt;
        String savedUri = ""; // content:// URI of the finished file, set once done
        boolean isHls = false; // true = downloaded segment-by-segment from an HLS stream
    }

    private final ExecutorService downloadExecutor = Executors.newFixedThreadPool(2);
    private final Map<String, Boolean> downloadPauseFlags = new HashMap<>();

    private List<NexDownload> loadNexDownloads() {
        List<NexDownload> list = new ArrayList<>();
        try {
            String raw = prefs.getString("nex_downloads_v1", "[]");
            JSONArray arr = new JSONArray(new JSONTokener(raw));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                NexDownload d = new NexDownload();
                d.id = o.getString("id");
                d.url = o.getString("url");
                d.fileName = o.getString("fileName");
                d.mimeType = o.optString("mimeType", "application/octet-stream");
                d.status = o.getString("status");
                d.totalBytes = o.optLong("totalBytes", -1);
                d.downloadedBytes = o.optLong("downloadedBytes", 0);
                d.retryCount = o.optInt("retryCount", 0);
                d.error = o.optString("error", "");
                d.createdAt = o.optLong("createdAt", 0);
                d.savedUri = o.optString("savedUri", "");
                d.isHls = o.optBoolean("isHls", false);
                list.add(d);
            }
        } catch (Exception ignored) {}
        return list;
    }

    private synchronized void saveNexDownloads(List<NexDownload> list) {
        JSONArray arr = new JSONArray();
        try {
            for (NexDownload d : list) {
                JSONObject o = new JSONObject();
                o.put("id", d.id);
                o.put("url", d.url);
                o.put("fileName", d.fileName);
                o.put("mimeType", d.mimeType);
                o.put("status", d.status);
                o.put("totalBytes", d.totalBytes);
                o.put("downloadedBytes", d.downloadedBytes);
                o.put("retryCount", d.retryCount);
                o.put("error", d.error);
                o.put("createdAt", d.createdAt);
                o.put("savedUri", d.savedUri);
                o.put("isHls", d.isHls);
                arr.put(o);
            }
        } catch (Exception ignored) {}
        prefs.edit().putString("nex_downloads_v1", arr.toString()).apply();
    }

    private NexDownload findNexDownload(String id) {
        for (NexDownload d : loadNexDownloads()) if (d.id.equals(id)) return d;
        return null;
    }

    private synchronized void updateNexDownload(NexDownload updated) {
        List<NexDownload> list = loadNexDownloads();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(updated.id)) {
                list.set(i, updated);
                saveNexDownloads(list);
                return;
            }
        }
    }

    // ---- Duplicate detection: same URL already downloaded successfully.
    // (Scoped simpler than a full content-hash check — matching on the
    // source URL is enough to catch the common case of re-adding the same
    // link, without needing to read back finished files to hash them.) ----
    private NexDownload findCompletedDownloadForUrl(String url) {
        for (NexDownload d : loadNexDownloads()) {
            if (d.url.equals(url) && "done".equals(d.status)) return d;
        }
        return null;
    }

    private void enqueueNexDownload(String url, String suggestedFileName, String mimeType) {
        NexDownload existing = findCompletedDownloadForUrl(url);
        if (existing != null) {
            new AccentDialogBuilder(this)
                    .setTitle("Already downloaded")
                    .setMessage(existing.fileName + " was already downloaded from this link. Download again?")
                    .setPositiveButton("Download Again", (d, w) -> startNewNexDownload(url, suggestedFileName, mimeType))
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }
        startNewNexDownload(url, suggestedFileName, mimeType);
    }

    // ---- Lightweight sync: only the "downloads" field, so this doesn't
    // touch/resync passwords, bookmarks, history, or shortcuts every time a
    // download starts or finishes. Metadata only (filename/url/status/
    // timestamp) — the actual downloaded file itself never leaves the
    // device it was downloaded on. Same account-box rule as everything
    // else: silently no-ops if backend/account aren't set up. ----
    private void syncDownloadsMetadataToBackend() {
        if (backendUrl.isEmpty() || authToken.isEmpty()) return;
        networkExecutor.execute(() -> {
            try {
                JSONArray downloadsArr = new JSONArray();
                for (NexDownload d : loadNexDownloads()) {
                    JSONObject o = new JSONObject();
                    o.put("id", d.id);
                    o.put("fileName", d.fileName);
                    o.put("url", d.url);
                    o.put("status", d.status);
                    o.put("createdAt", d.createdAt);
                    downloadsArr.put(o);
                }
                JSONObject body = new JSONObject();
                body.put("downloads", downloadsArr);
                httpPostJson(backendUrl + "/vault/sync", body, authToken);
            } catch (Exception ignored) {
                // best-effort — download itself already succeeded/failed locally either way
            }
        });
    }

    private void startNewNexDownload(String url, String suggestedFileName, String mimeType) {
        NexDownload d = new NexDownload();
        d.id = UUID.randomUUID().toString();
        d.url = url;
        d.fileName = sanitizeFileName(suggestedFileName);
        d.mimeType = mimeType;
        d.status = "queued";
        d.createdAt = System.currentTimeMillis();
        List<NexDownload> list = loadNexDownloads();
        list.add(0, d);
        saveNexDownloads(list);
        startNexDownload(d.id);
        Toast.makeText(this, "Added to Downloads", Toast.LENGTH_SHORT).show();
        syncDownloadsMetadataToBackend();
        if (isPageShown) showFullPage(buildDownloadsManagerView());
    }

    private void startNexDownload(String id) {
        downloadPauseFlags.put(id, false);
        downloadExecutor.execute(() -> runNexDownload(id));
    }

    private void pauseNexDownload(String id) {
        downloadPauseFlags.put(id, true);
    }

    private void resumeNexDownload(String id) {
        startNexDownload(id);
    }

    private void retryNexDownload(String id) {
        NexDownload d = findNexDownload(id);
        if (d == null) return;
        d.status = "queued";
        d.error = "";
        updateNexDownload(d);
        startNexDownload(id);
    }

    private void deleteNexDownload(String id) {
        downloadPauseFlags.put(id, true);
        List<NexDownload> list = loadNexDownloads();
        list.removeIf(d -> d.id.equals(id));
        saveNexDownloads(list);
        new File(new File(getExternalFilesDir(null), "downloads_tmp"), id + ".part").delete();
        syncDownloadsMetadataToBackend();
        if (isPageShown) showFullPage(buildDownloadsManagerView());
    }

    // ---- The actual transfer: raw HttpURLConnection with a Range header
    // so a paused/failed download can resume from where it left off
    // instead of restarting. Partial bytes live in a private app-cache
    // file; once fully downloaded, the finished file is copied into the
    // public Downloads folder (MediaStore on Android 10+, legacy path
    // below) so it shows up like any normal browser download. ----
    private void runNexDownload(String id) {
        NexDownload d = findNexDownload(id);
        if (d == null) return;
        if (d.isHls) {
            runHlsDownload(d);
            return;
        }
        d.status = "downloading";
        d.error = "";
        updateNexDownload(d);

        File tmpDir = new File(getExternalFilesDir(null), "downloads_tmp");
        if (!tmpDir.exists()) tmpDir.mkdirs();
        File partFile = new File(tmpDir, d.id + ".part");

        HttpURLConnection conn = null;
        try {
            long existingBytes = partFile.exists() ? partFile.length() : 0;
            URL u = new URL(d.url);
            conn = (HttpURLConnection) u.openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(15000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10) NexBrowser/1.0");
            if (existingBytes > 0) {
                conn.setRequestProperty("Range", "bytes=" + existingBytes + "-");
            }
            conn.connect();

            int code = conn.getResponseCode();
            if (code != HttpURLConnection.HTTP_OK && code != HttpURLConnection.HTTP_PARTIAL) {
                throw new Exception("Server returned HTTP " + code);
            }
            boolean resumedOk = (code == HttpURLConnection.HTTP_PARTIAL);
            if (existingBytes > 0 && !resumedOk) {
                // Server ignored our Range request — start over cleanly.
                existingBytes = 0;
                partFile.delete();
            }
            d.downloadedBytes = existingBytes;

            long contentLength = conn.getContentLengthLong();
            d.totalBytes = contentLength >= 0 ? (existingBytes + contentLength) : -1;
            updateNexDownload(d);

            try (InputStream in = conn.getInputStream();
                 RandomAccessFile out = new RandomAccessFile(partFile, "rw")) {
                out.seek(existingBytes);
                byte[] buffer = new byte[8192];
                int read;
                long lastSave = System.currentTimeMillis();
                while ((read = in.read(buffer)) != -1) {
                    if (Boolean.TRUE.equals(downloadPauseFlags.get(id))) {
                        d.status = "paused";
                        updateNexDownload(d);
                        return;
                    }
                    out.write(buffer, 0, read);
                    d.downloadedBytes += read;
                    long now = System.currentTimeMillis();
                    if (now - lastSave > 400) {
                        updateNexDownload(d);
                        lastSave = now;
                    }
                }
            }

            moveToPublicDownloads(partFile, d);
            d.status = "done";
            if (d.totalBytes > 0) d.downloadedBytes = d.totalBytes;
            updateNexDownload(d);
            syncDownloadsMetadataToBackend();
            mainHandler.post(() -> Toast.makeText(this, d.fileName + " downloaded", Toast.LENGTH_SHORT).show());

        } catch (Exception e) {
            NexDownload latest = findNexDownload(id);
            if (latest != null) {
                latest.status = "failed";
                latest.error = e.getMessage() != null ? e.getMessage() : "Download failed";
                latest.retryCount++;
                updateNexDownload(latest);
                syncDownloadsMetadataToBackend();
            }
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private void moveToPublicDownloads(File srcFile, NexDownload d) throws Exception {
        String mime = (d.mimeType != null && !d.mimeType.isEmpty()) ? d.mimeType : guessMimeFromFileName(d.fileName);
        if (Build.VERSION.SDK_INT >= 29) {
            android.content.ContentValues values = new android.content.ContentValues();
            values.put(android.provider.MediaStore.Downloads.DISPLAY_NAME, d.fileName);
            values.put(android.provider.MediaStore.Downloads.MIME_TYPE, mime);
            values.put(android.provider.MediaStore.Downloads.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("Could not create a Downloads entry");
            try (InputStream in = new java.io.FileInputStream(srcFile);
                 OutputStream out = getContentResolver().openOutputStream(uri)) {
                byte[] buf = new byte[8192];
                int r;
                while ((r = in.read(buf)) != -1) out.write(buf, 0, r);
            }
            android.content.ContentValues done = new android.content.ContentValues();
            done.put(android.provider.MediaStore.Downloads.IS_PENDING, 0);
            getContentResolver().update(uri, done, null, null);
            d.savedUri = uri.toString();
        } else {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists()) dir.mkdirs();
            File destFile = new File(dir, d.fileName);
            try (InputStream in = new java.io.FileInputStream(srcFile);
                 OutputStream out = new FileOutputStream(destFile)) {
                byte[] buf = new byte[8192];
                int r;
                while ((r = in.read(buf)) != -1) out.write(buf, 0, r);
            }
            android.media.MediaScannerConnection.scanFile(this, new String[]{destFile.getAbsolutePath()}, null, null);
            Uri contentUri = androidx.core.content.FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", destFile);
            d.savedUri = contentUri.toString();
        }
        srcFile.delete();
    }

    // ================================================================
    // HLS (adaptive-stream) downloader — this is what actually answers
    // "360 ya 480 kaunsa chahiye": most sites (YouTube included, for many
    // videos) serve video as an HLS master playlist listing several
    // quality variants. We fetch that master playlist, list the real
    // qualities it advertises, download the chosen variant's video
    // segments one by one, and concatenate them into a single .ts file
    // (raw MPEG-TS segments concatenate cleanly — VLC/MX Player and most
    // non-stock players open the result directly; the built-in Android
    // Gallery player is less reliable with .ts, which is an honest
    // limitation, not a bug). Encrypted/DRM-protected streams are
    // detected and refused rather than producing a broken file. If the
    // stream keeps its audio in a separate track (common on some
    // sites), the downloaded file may be video-only — a known limit of
    // this lightweight approach vs. a full ffmpeg mux, which isn't
    // included here.
    // ================================================================

    private String fetchTextUrl(String url) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10) NexBrowser/1.0");
        try (InputStream in = conn.getInputStream()) {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int r;
            while ((r = in.read(buf)) != -1) bos.write(buf, 0, r);
            return bos.toString("UTF-8");
        } finally {
            conn.disconnect();
        }
    }

    private byte[] fetchBytesUrl(String url) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10) NexBrowser/1.0");
        try (InputStream in = conn.getInputStream()) {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) != -1) bos.write(buf, 0, r);
            return bos.toByteArray();
        } finally {
            conn.disconnect();
        }
    }

    private String readSmallFile(File f) throws Exception {
        try (java.io.FileInputStream fis = new java.io.FileInputStream(f)) {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[512];
            int r;
            while ((r = fis.read(buf)) != -1) bos.write(buf, 0, r);
            return bos.toString("UTF-8");
        }
    }

    private void writeSmallFile(File f, String content) throws Exception {
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write(content.getBytes(StandardCharsets.UTF_8));
        }
    }

    // Parses an HLS MASTER playlist: one entry per available quality.
    // Prefers the RESOLUTION attribute (gives a clean "480p" label); falls
    // back to BANDWIDTH when a variant doesn't advertise a resolution.
    private List<String[]> parseHlsMasterVariants(String playlistText, String baseUrl) throws Exception {
        return DownloadUtils.parseHlsMasterVariants(playlistText, baseUrl);
    }

    // Parses an HLS MEDIA playlist (one specific quality): the ordered
    // list of video segment URLs that make up the actual video.
    private List<String> parseHlsSegments(String playlistText, String baseUrl) throws Exception {
        return DownloadUtils.parseHlsSegments(playlistText, baseUrl);
    }

    private int extractQualityNumber(String label) {
        return DownloadUtils.extractQualityNumber(label);
    }

    // Fetches the master playlist and, if it lists multiple qualities,
    // shows the picker — otherwise the URL was already a single-quality
    // stream, so it starts downloading directly.
    private void resolveHlsQuality(String masterUrl) {
        Toast.makeText(this, "Checking available qualities…", Toast.LENGTH_SHORT).show();
        networkExecutor.execute(() -> {
            try {
                String text = fetchTextUrl(masterUrl);
                if (text.contains("#EXT-X-KEY") && !text.contains("METHOD=NONE")) {
                    mainHandler.post(() -> Toast.makeText(this, "This stream is encrypted (DRM-protected) — can't be downloaded.", Toast.LENGTH_LONG).show());
                    return;
                }
                List<String[]> variants = parseHlsMasterVariants(text, masterUrl);
                mainHandler.post(() -> {
                    if (variants.isEmpty()) {
                        startHlsDownload(masterUrl, sanitizeFileName("video_" + System.currentTimeMillis()) + ".ts");
                    } else {
                        showQualityPickerDialog(variants);
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() -> Toast.makeText(this, "Couldn't read stream: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private void showQualityPickerDialog(List<String[]> variants) {
        variants.sort((a, b) -> extractQualityNumber(b[0]) - extractQualityNumber(a[0]));
        String[] labels = new String[variants.size()];
        for (int i = 0; i < variants.size(); i++) labels[i] = variants.get(i)[0];

        new AccentDialogBuilder(this)
                .setTitle("Choose quality")
                .setItems(labels, (d, which) -> {
                    String[] chosen = variants.get(which);
                    String fileName = sanitizeFileName("video_" + chosen[0] + "_" + System.currentTimeMillis()) + ".ts";
                    startHlsDownload(chosen[1], fileName);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void startHlsDownload(String variantPlaylistUrl, String fileName) {
        NexDownload existing = findCompletedDownloadForUrl(variantPlaylistUrl);
        if (existing != null) {
            new AccentDialogBuilder(this)
                    .setTitle("Already downloaded")
                    .setMessage(existing.fileName + " was already downloaded from this stream. Download again?")
                    .setPositiveButton("Download Again", (d, w) -> enqueueHlsDownload(variantPlaylistUrl, fileName))
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }
        enqueueHlsDownload(variantPlaylistUrl, fileName);
    }

    private void enqueueHlsDownload(String variantPlaylistUrl, String fileName) {
        NexDownload d = new NexDownload();
        d.id = UUID.randomUUID().toString();
        d.url = variantPlaylistUrl;
        d.fileName = sanitizeFileName(fileName);
        d.mimeType = "video/mp2t";
        d.status = "queued";
        d.isHls = true;
        d.createdAt = System.currentTimeMillis();
        List<NexDownload> list = loadNexDownloads();
        list.add(0, d);
        saveNexDownloads(list);
        startNexDownload(d.id);
        Toast.makeText(this, "Added to Downloads — stream downloads take a bit longer", Toast.LENGTH_LONG).show();
        syncDownloadsMetadataToBackend();
        if (isPageShown) showFullPage(buildDownloadsManagerView());
    }

    // Downloads every segment of the chosen quality in order and
    // concatenates them into one file. Resumable: how many segments were
    // already written is tracked in a small sidecar file next to the
    // partial download, so pausing/resuming picks up mid-stream instead
    // of re-fetching segments already saved.
    private void runHlsDownload(NexDownload d) {
        d.status = "downloading";
        d.error = "";
        updateNexDownload(d);

        File tmpDir = new File(getExternalFilesDir(null), "downloads_tmp");
        if (!tmpDir.exists()) tmpDir.mkdirs();
        File partFile = new File(tmpDir, d.id + ".part");
        File progressFile = new File(tmpDir, d.id + ".segprogress");

        try {
            int startSegment = 0;
            if (progressFile.exists()) {
                try {
                    startSegment = Integer.parseInt(readSmallFile(progressFile).trim());
                } catch (Exception ignored) {}
            }

            String playlistText = fetchTextUrl(d.url);
            if (playlistText.contains("#EXT-X-KEY") && !playlistText.contains("METHOD=NONE")) {
                throw new Exception("This stream is encrypted (DRM) — can't be downloaded");
            }
            List<String> segmentUrls = parseHlsSegments(playlistText, d.url);
            if (segmentUrls.isEmpty()) throw new Exception("No video segments found in this stream");
            if (startSegment >= segmentUrls.size()) startSegment = 0;

            try (RandomAccessFile out = new RandomAccessFile(partFile, "rw")) {
                if (startSegment == 0) {
                    out.setLength(0);
                    d.downloadedBytes = 0;
                } else {
                    out.seek(out.length());
                }
                for (int i = startSegment; i < segmentUrls.size(); i++) {
                    if (Boolean.TRUE.equals(downloadPauseFlags.get(d.id))) {
                        d.status = "paused";
                        updateNexDownload(d);
                        writeSmallFile(progressFile, String.valueOf(i));
                        return;
                    }
                    byte[] segBytes = fetchBytesUrl(segmentUrls.get(i));
                    out.write(segBytes);
                    d.downloadedBytes += segBytes.length;
                    d.error = "Segment " + (i + 1) + "/" + segmentUrls.size();
                    updateNexDownload(d);
                    writeSmallFile(progressFile, String.valueOf(i + 1));
                }
            }

            d.error = "";
            moveToPublicDownloads(partFile, d);
            d.status = "done";
            updateNexDownload(d);
            progressFile.delete();
            syncDownloadsMetadataToBackend();
            mainHandler.post(() -> Toast.makeText(this, d.fileName + " downloaded", Toast.LENGTH_SHORT).show());

        } catch (Exception e) {
            NexDownload latest = findNexDownload(d.id);
            if (latest != null) {
                latest.status = "failed";
                latest.error = e.getMessage() != null ? e.getMessage() : "Download failed";
                latest.retryCount++;
                updateNexDownload(latest);
                syncDownloadsMetadataToBackend();
            }
        }
    }

    private String guessFileNameFromUrl(String url) {
        return DownloadUtils.guessFileNameFromUrl(url, System.currentTimeMillis());
    }

    private String guessMimeFromFileName(String fileName) {
        return DownloadUtils.guessMimeFromFileName(fileName);
    }

    private String sanitizeFileName(String name) {
        return DownloadUtils.sanitizeFileName(name, System.currentTimeMillis());
    }

    // ---- Recognizes media resource URLs by extension or known media-CDN
    // hostnames — used both for live-sniffing the currently open tab and
    // for scanning a pasted webpage link. Deliberately pattern-based
    // (not per-site scraping) so it doesn't need separate, fragile code
    // for every platform. ----
    private boolean isLikelyMediaUrl(String url) {
        return DownloadUtils.isLikelyMediaUrl(url);
    }

    private boolean isDirectMediaUrl(String url) {
        return DownloadUtils.isDirectMediaUrl(url);
    }

    // ---- "+ " on the Downloads page: paste literally any link. Direct
    // files go straight into the queue; a webpage link gets scanned for
    // playable media (see scanPageForMedia). ----
    private void showAddDownloadDialog() {
        EditText input = new EditText(this);
        input.setHint("Paste any link — direct file, YouTube, TikTok, etc.");
        input.setTextColor(getColor(R.color.text_primary));
        input.setHintTextColor(getColor(R.color.text_dim));

        new AccentDialogBuilder(this)
                .setTitle("Add Download")
                .setView(input)
                .setPositiveButton("Add", (d, w) -> {
                    String url = input.getText().toString().trim();
                    if (url.isEmpty()) return;
                    if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
                    resolveAndDownload(url);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void resolveAndDownload(String url) {
        Toast.makeText(this, "Checking link…", Toast.LENGTH_SHORT).show();
        if (url.toLowerCase(Locale.US).contains(".m3u8")) {
            resolveHlsQuality(url);
            return;
        }
        if (isDirectMediaUrl(url)) {
            String fileName = guessFileNameFromUrl(url);
            enqueueNexDownload(url, fileName, guessMimeFromFileName(fileName));
            return;
        }
        networkExecutor.execute(() -> {
            String contentType = null;
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setRequestMethod("HEAD");
                conn.setConnectTimeout(10000);
                conn.setInstanceFollowRedirects(true);
                contentType = conn.getContentType();
                conn.disconnect();
            } catch (Exception ignored) {
                // Some servers reject HEAD — fall through and treat as a webpage.
            }
            String finalType = contentType;
            mainHandler.post(() -> {
                if (finalType != null && finalType.contains("mpegurl")) {
                    resolveHlsQuality(url);
                } else if (finalType != null && !finalType.startsWith("text/html") && !finalType.startsWith("application/xhtml")) {
                    String fileName = guessFileNameFromUrl(url);
                    enqueueNexDownload(url, fileName, finalType);
                } else {
                    scanPageForMedia(url);
                }
            });
        });
    }

    // ---- Loads the pasted page in a hidden WebView and passively watches
    // its network requests for anything media-looking, same mechanism as
    // the live per-tab sniffing below. Honest limitation: adaptive-stream
    // sites (HLS .m3u8) will surface the manifest, not a single muxed
    // video file, and some heavily protected players may expose nothing
    // sniffable at all — both cases are surfaced clearly to the user
    // rather than silently failing. ----
    private void scanPageForMedia(String pageUrl) {
        Toast.makeText(this, "Scanning page for media…", Toast.LENGTH_SHORT).show();
        LinkedHashSet<String> found = new LinkedHashSet<>();
        WebView scanner = new WebView(this);
        WebSettings s = scanner.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        scanner.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String reqUrl = request.getUrl().toString();
                if (isLikelyMediaUrl(reqUrl)) found.add(reqUrl);
                return super.shouldInterceptRequest(view, request);
            }
        });
        scanner.loadUrl(pageUrl);

        mainHandler.postDelayed(() -> {
            scanner.stopLoading();
            scanner.destroy();
            if (found.isEmpty()) {
                new AccentDialogBuilder(this)
                        .setTitle("No media found")
                        .setMessage("Couldn't find a downloadable media link on this page. Some sites protect their video player enough that nothing sniffable ever loads as a plain request.")
                        .setPositiveButton("OK", null)
                        .show();
            } else {
                showMediaPickerDialog(new ArrayList<>(found));
            }
        }, 9000);
    }

    // ---- "Download Video" in the Main Menu — offers whatever media URLs
    // the CURRENT tab has organically loaded so far (populated live by the
    // shouldInterceptRequest hook on that tab's own WebView). Works for
    // whatever you're already watching, no separate scan needed. ----
    private void showDownloadVideoForCurrentTab() {
        DevilTab tab = tabs.get(currentTabIndex);
        if (tab.detectedMediaUrls.isEmpty()) {
            Toast.makeText(this, "No media detected yet on this page — try playing the video first, or use Downloads → + to paste the page link directly.", Toast.LENGTH_LONG).show();
            return;
        }
        showMediaPickerDialog(new ArrayList<>(tab.detectedMediaUrls));
    }

    private void showMediaPickerDialog(List<String> urls) {
        String[] labels = new String[urls.size()];
        for (int i = 0; i < urls.size(); i++) {
            String u = urls.get(i);
            String host = Uri.parse(u).getHost();
            String tag = u.toLowerCase(Locale.US).contains(".m3u8") ? "  (choose quality)" : "";
            labels[i] = (host != null ? host : "media") + tag;
        }
        new AccentDialogBuilder(this)
                .setTitle("Found " + urls.size() + " media link(s)")
                .setItems(labels, (d, which) -> {
                    String chosen = urls.get(which);
                    if (chosen.toLowerCase(Locale.US).contains(".m3u8")) {
                        // HLS stream — read the real available qualities and let
                        // the user pick (this is the actual "360 ya 480" choice).
                        resolveHlsQuality(chosen);
                        return;
                    }
                    String fileName = guessFileNameFromUrl(chosen);
                    if (!fileName.contains(".")) {
                        fileName = sanitizeFileName("media_" + System.currentTimeMillis()) + ".mp4";
                    }
                    enqueueNexDownload(chosen, fileName, guessMimeFromFileName(fileName));
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---- Main "Downloads" page: the custom queue (with pause/resume/
    // retry/delete controls) plus the historical read-only list of
    // downloads that went through the browser's normal WebView download
    // path (e.g. tapping a direct download link on a page) — those still
    // go through Android's system DownloadManager as before, listed here
    // for one combined view. ----
    private View buildDownloadsManagerView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        TextView addIcon = new TextView(this);
        addIcon.setText("+");
        addIcon.setTextColor(getColor(R.color.gold));
        addIcon.setTextSize(20);
        addIcon.setPadding(20, 4, 12, 4);
        addIcon.setOnClickListener(v -> showAddDownloadDialog());

        root.addView(buildPageHeader("Downloads", this::hideFullPage, addIcon));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(24, 16, 24, 24);
        scroll.addView(content);
        root.addView(scroll);

        TextView hint = new TextView(this);
        hint.setText("Tap + to paste any link — direct files, YouTube, TikTok, or any page. Or open Main Menu → Download Video to grab whatever's already playing in this tab.");
        hint.setTextColor(getColor(R.color.text_dim));
        hint.setTextSize(10);
        hint.setPadding(0, 0, 0, 16);
        content.addView(hint);

        List<NexDownload> downloads = loadNexDownloads();
        if (downloads.isEmpty()) {
            content.addView(buildEmptyState("No downloads yet — tap + to add one"));
        } else {
            for (NexDownload d : downloads) {
                content.addView(buildNexDownloadRow(d));
            }
        }

        // Historical browser downloads (via WebView's normal DownloadListener,
        // unrelated to the queue above) — real entries from the system
        // DownloadManager, shown read-only underneath.
        List<String[]> systemEntries = readSystemDownloadEntries();
        if (!systemEntries.isEmpty()) {
            TextView label = new TextView(this);
            label.setText("FROM BROWSING");
            label.setTextColor(ThemeManager.getAccentColor(this));
            label.setTextSize(10);
            label.setLetterSpacing(0.06f);
            LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            labelParams.topMargin = 20;
            label.setLayoutParams(labelParams);
            content.addView(label);

            for (String[] entry : systemEntries) {
                content.addView(buildSystemDownloadRow(entry[0], entry[1]));
            }
        }

        boolean anyActive = false;
        for (NexDownload d : downloads) {
            if ("downloading".equals(d.status) || "queued".equals(d.status)) {
                anyActive = true;
                break;
            }
        }
        if (anyActive) {
            mainHandler.postDelayed(() -> {
                if (isPageShown) showFullPage(buildDownloadsManagerView());
            }, 1200);
        }

        return root;
    }

    private List<String[]> readSystemDownloadEntries() {
        List<String[]> out = new ArrayList<>();
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        android.database.Cursor cursor = dm.query(new DownloadManager.Query());
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String title = cursor.getString(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                int status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                String statusText;
                if (status == DownloadManager.STATUS_SUCCESSFUL) statusText = "Completed";
                else if (status == DownloadManager.STATUS_RUNNING) statusText = "Downloading";
                else if (status == DownloadManager.STATUS_FAILED) statusText = "Failed";
                else statusText = "Pending";
                out.add(new String[]{title != null ? title : "Download", statusText});
            }
            cursor.close();
        }
        return out;
    }

    private View buildSystemDownloadRow(String title, String statusText) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(12, 14, 12, 14);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.topMargin = 6;
        row.setLayoutParams(rowParams);
        row.setBackgroundResource(R.drawable.bg_tab_inactive);

        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(11);
        row.addView(titleView);

        TextView statusView = new TextView(this);
        statusView.setText(statusText);
        statusView.setTextColor(getColor(R.color.text_dim));
        statusView.setTextSize(9.5f);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        statusParams.topMargin = 4;
        statusView.setLayoutParams(statusParams);
        row.addView(statusView);

        return row;
    }

    private View buildNexDownloadRow(NexDownload d) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(16, 16, 16, 16);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 8;
        row.setLayoutParams(rowParams);
        row.setBackgroundResource(R.drawable.bg_tab_inactive);

        TextView titleView = new TextView(this);
        titleView.setText(d.fileName);
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(11);
        row.addView(titleView);

        String statusLine;
        switch (d.status) {
            case "downloading":
                if (d.isHls) {
                    statusLine = d.error.isEmpty() ? ("Downloading stream… " + formatBytes(d.downloadedBytes)) : ("Downloading stream — " + d.error);
                } else if (d.totalBytes > 0) {
                    int pct = (int) ((d.downloadedBytes * 100) / d.totalBytes);
                    statusLine = "Downloading… " + pct + "% (" + formatBytes(d.downloadedBytes) + " / " + formatBytes(d.totalBytes) + ")";
                } else {
                    statusLine = "Downloading… " + formatBytes(d.downloadedBytes);
                }
                break;
            case "paused":
                statusLine = "Paused at " + formatBytes(d.downloadedBytes) + (d.totalBytes > 0 ? " / " + formatBytes(d.totalBytes) : "");
                break;
            case "done":
                statusLine = "Completed • " + formatBytes(d.downloadedBytes);
                break;
            case "failed":
                statusLine = "Failed" + (d.error.isEmpty() ? "" : " — " + d.error) + (d.retryCount > 0 ? " (retried " + d.retryCount + "x)" : "");
                break;
            default:
                statusLine = "Queued";
        }
        TextView statusView = new TextView(this);
        statusView.setText(statusLine);
        statusView.setTextColor("failed".equals(d.status) ? ThemeManager.getAccentColor(this) : getColor(R.color.text_dim));
        statusView.setTextSize(9.5f);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        statusParams.topMargin = 4;
        statusView.setLayoutParams(statusParams);
        row.addView(statusView);

        if ("downloading".equals(d.status) && d.totalBytes > 0) {
            ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            bar.setMax(100);
            bar.setProgress((int) ((d.downloadedBytes * 100) / d.totalBytes));
            LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 8);
            barParams.topMargin = 8;
            bar.setLayoutParams(barParams);
            row.addView(bar);
        }

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams actionsParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        actionsParams.topMargin = 10;
        actions.setLayoutParams(actionsParams);

        if ("downloading".equals(d.status)) {
            actions.addView(buildDownloadActionBtn("Pause", () -> pauseNexDownload(d.id)));
        } else if ("paused".equals(d.status)) {
            actions.addView(buildDownloadActionBtn("Resume", () -> resumeNexDownload(d.id)));
        } else if ("failed".equals(d.status)) {
            actions.addView(buildDownloadActionBtn("Retry", () -> retryNexDownload(d.id)));
        }
        actions.addView(buildDownloadActionBtn("Delete", () -> deleteNexDownload(d.id)));
        row.addView(actions);

        // Smart Download Intelligence (#114): a quick heuristic caution
        // for file types that can execute code — shown once the
        // download actually finishes, not before (no point warning
        // about a file that isn't there yet).
        if ("done".equals(d.status) && isRiskyDownloadExtension(d.fileName)) {
            TextView riskyNote = new TextView(this);
            riskyNote.setText("⚠️ This file type can run code — only open it if you trust where it came from");
            riskyNote.setTextColor(ThemeManager.getAccentColor(this));
            riskyNote.setTextSize(9);
            LinearLayout.LayoutParams riskyParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            riskyParams.topMargin = 8;
            riskyNote.setLayoutParams(riskyParams);
            row.addView(riskyNote);
        }

        // AI File Intelligence (#111): plain-text-readable files, plus PDFs (the
        // backend hands the PDF to the model directly, so scanned pages work too).
        // Images have their own "Understand Image" button just below.
        if ("done".equals(d.status) && (isTextReadableExtension(d.fileName) || isPdfExtension(d.fileName))
                && !d.savedUri.isEmpty()) {
            TextView analyzeBtn = new TextView(this);
            analyzeBtn.setText("🔍 Analyze with AI");
            analyzeBtn.setTextColor(getColor(R.color.gold));
            analyzeBtn.setTextSize(10.5f);
            LinearLayout.LayoutParams analyzeParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            analyzeParams.topMargin = 8;
            analyzeBtn.setLayoutParams(analyzeParams);
            analyzeBtn.setOnClickListener(v -> analyzeDownloadedFile(d.fileName, d.savedUri, analyzeBtn));
            row.addView(analyzeBtn);
        }

        // AI Screenshot Understanding for saved images (#115) — distinct
        // from #111's text-file analysis just above and from #54's LIVE
        // browser screenshot reading: this is for an image the user
        // actually downloaded/saved.
        if ("done".equals(d.status) && isImageDownloadExtension(d.fileName) && !d.savedUri.isEmpty()) {
            TextView understandBtn = new TextView(this);
            understandBtn.setText("🔍 Understand Image");
            understandBtn.setTextColor(getColor(R.color.gold));
            understandBtn.setTextSize(10.5f);
            LinearLayout.LayoutParams understandParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            understandParams.topMargin = 8;
            understandBtn.setLayoutParams(understandParams);
            understandBtn.setOnClickListener(v -> understandSavedImage(d.savedUri, understandBtn));
            row.addView(understandBtn);
        }

        return row;
    }

    private boolean isImageDownloadExtension(String fileName) {
        return DownloadUtils.isImageDownloadExtension(fileName);
    }

    private void understandSavedImage(String savedUri, TextView triggerBtn) {
        triggerBtn.setText("Looking…");
        networkExecutor.execute(() -> {
            try {
                Bitmap bitmap;
                try (InputStream is = getContentResolver().openInputStream(Uri.parse(savedUri))) {
                    bitmap = android.graphics.BitmapFactory.decodeStream(is);
                }
                if (bitmap == null) throw new Exception("Couldn't read image");
                // Downscale large images before upload — the AI doesn't need
                // full resolution to describe/read text, and this keeps the
                // request small and fast.
                int maxDim = 1024;
                if (bitmap.getWidth() > maxDim || bitmap.getHeight() > maxDim) {
                    float scale = Math.min((float) maxDim / bitmap.getWidth(), (float) maxDim / bitmap.getHeight());
                    bitmap = Bitmap.createScaledBitmap(bitmap, Math.round(bitmap.getWidth() * scale), Math.round(bitmap.getHeight() * scale), true);
                }
                java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 70, baos);
                bitmap.recycle();
                String base64 = android.util.Base64.encodeToString(baos.toByteArray(), android.util.Base64.NO_WRAP);

                JSONObject body = new JSONObject();
                body.put("image_base64", base64);
                JSONObject resp = httpPostJson(backendUrl + "/files/analyze-image", body, authToken);
                String description = resp.optString("description", "No description returned");
                mainHandler.post(() -> {
                    triggerBtn.setText("🔍 Understand Image");
                    new AccentDialogBuilder(this)
                            .setTitle("🔍 Image")
                            .setMessage(description)
                            .setPositiveButton("OK", null)
                            .show();
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    triggerBtn.setText("🔍 Understand Image");
                    Toast.makeText(this, "Couldn't understand image: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    // Smart Download Intelligence (#114): a small fixed list of
    // extensions that can execute code on the device — deliberately a
    // caution note, not a block, since these ARE sometimes exactly what
    // the user meant to download (an APK from a trusted source, etc.).
    private boolean isRiskyDownloadExtension(String fileName) {
        return DownloadUtils.isRiskyDownloadExtension(fileName);
    }

    private boolean isTextReadableExtension(String fileName) {
        return DownloadUtils.isTextReadableExtension(fileName);
    }

    private boolean isPdfExtension(String fileName) {
        return DownloadUtils.isPdfExtension(fileName);
    }

    private void analyzeDownloadedFile(String fileName, String savedUri, TextView triggerBtn) {
        triggerBtn.setText("Analyzing…");
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("filename", fileName);
                if (isPdfExtension(fileName)) {
                    // Read the PDF's bytes (capped at ~5 MB — the server enforces the same limit).
                    final int maxBytes = 5 * 1024 * 1024;
                    java.io.ByteArrayOutputStream pdfBytes = new java.io.ByteArrayOutputStream();
                    try (InputStream is = getContentResolver().openInputStream(Uri.parse(savedUri))) {
                        byte[] buf = new byte[16 * 1024];
                        int n;
                        while ((n = is.read(buf)) != -1) {
                            pdfBytes.write(buf, 0, n);
                            if (pdfBytes.size() > maxBytes) {
                                throw new Exception("PDF is larger than 5 MB");
                            }
                        }
                    }
                    body.put("content_base64", android.util.Base64.encodeToString(pdfBytes.toByteArray(), android.util.Base64.NO_WRAP));
                    body.put("mime_type", "application/pdf");
                } else {
                    StringBuilder sb = new StringBuilder();
                    try (InputStream is = getContentResolver().openInputStream(Uri.parse(savedUri));
                         BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = reader.readLine()) != null && sb.length() < 8000) {
                            sb.append(line).append('\n');
                        }
                    }
                    body.put("content", sb.toString());
                }
                JSONObject resp = httpPostJson(backendUrl + "/files/analyze", body, authToken);
                String summary = resp.optString("summary", "No summary returned");
                mainHandler.post(() -> {
                    triggerBtn.setText("🔍 Analyze with AI");
                    new AccentDialogBuilder(this)
                            .setTitle("🔍 " + fileName)
                            .setMessage(summary)
                            .setPositiveButton("OK", null)
                            .show();
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    triggerBtn.setText("🔍 Analyze with AI");
                    Toast.makeText(this, "Couldn't analyze: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private View buildDownloadActionBtn(String label, Runnable action) {
        TextView btn = new TextView(this);
        btn.setText(label);
        btn.setTextColor(getColor(R.color.gold));
        btn.setTextSize(10.5f);
        btn.setPadding(20, 10, 20, 10);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.rightMargin = 12;
        btn.setLayoutParams(params);
        btn.setOnClickListener(v -> {
            action.run();
            if (isPageShown) showFullPage(buildDownloadsManagerView());
        });
        return btn;
    }

    private String formatBytes(long bytes) {
        return DownloadUtils.formatBytes(bytes);
    }

    // ================================================================
    // FILES MANAGER — category grid, storage bar, Wi-Fi Send/Receive.
    // Categories are computed from REAL Download Manager entries
    // (by mimetype/extension) — this browser doesn't have broad storage
    // permission, so "files" here means files this browser downloaded.
    // ================================================================
    private ServerSocket receiveServerSocket;

    private View buildFilesManagerView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(buildPageHeader("Files", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(24, 20, 24, 24);
        scroll.addView(content);
        root.addView(scroll);

        // Category counts from real DownloadManager entries
        int[] counts = getFileCategoryCounts(); // [music, video, photo, apps, archive, docs, webpage, others]
        String[] labels = {"Music", "Video", "Photo", "Apps", "Archive", "Docs", "Webpage", "Others"};
        String[] icons = {"🎵", "▶", "🖼", "📱", "🗜", "📄", "🌐", "📦"};

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        for (int i = 0; i < labels.length; i++) {
            grid.addView(buildFileCategoryTile(icons[i], labels[i], counts[i]));
        }
        content.addView(grid);

        // Storage bar (real, via StatFs)
        content.addView(buildStorageBar());

        // Wi-Fi Send / Receive
        LinearLayout transferRow = new LinearLayout(this);
        transferRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams transferRowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        transferRowParams.topMargin = 32;
        transferRow.setLayoutParams(transferRowParams);

        TextView sendBtn = new TextView(this);
        sendBtn.setText("↑\nSend");
        sendBtn.setTextColor(getColor(R.color.gold));
        sendBtn.setTextSize(13);
        sendBtn.setGravity(android.view.Gravity.CENTER);
        sendBtn.setPadding(20, 24, 20, 24);
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        sendParams.weight = 1;
        sendParams.rightMargin = 8;
        sendBtn.setLayoutParams(sendParams);
        sendBtn.setBackgroundResource(R.drawable.bg_tab_inactive);
        sendBtn.setOnClickListener(v -> showSendFilePicker());
        transferRow.addView(sendBtn);

        TextView receiveBtn = new TextView(this);
        receiveBtn.setText("↓\nReceive");
        receiveBtn.setTextColor(getColor(R.color.gold));
        receiveBtn.setTextSize(13);
        receiveBtn.setGravity(android.view.Gravity.CENTER);
        receiveBtn.setPadding(20, 24, 20, 24);
        LinearLayout.LayoutParams receiveParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        receiveParams.weight = 1;
        receiveBtn.setLayoutParams(receiveParams);
        receiveBtn.setBackgroundResource(R.drawable.bg_tab_inactive);
        receiveBtn.setOnClickListener(v -> showReceiveDialog());
        transferRow.addView(receiveBtn);

        content.addView(transferRow);

        TextView note = new TextView(this);
        note.setText("Send/Receive work over your local Wi-Fi network between two phones running Nex Browser.");
        note.setTextColor(getColor(R.color.text_dim));
        note.setTextSize(9);
        note.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        noteParams.topMargin = 12;
        note.setLayoutParams(noteParams);
        content.addView(note);

        return root;
    }

    private View buildFileCategoryTile(String icon, String label, int count) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(android.view.Gravity.CENTER);
        tile.setPadding(12, 20, 12, 20);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        tile.setLayoutParams(params);

        TextView iconView = new TextView(this);
        iconView.setText(icon);
        iconView.setTextSize(20);
        tile.addView(iconView);

        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextColor(getColor(R.color.text_primary));
        labelView.setTextSize(9);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        labelParams.topMargin = 8;
        labelView.setLayoutParams(labelParams);
        tile.addView(labelView);

        TextView countView = new TextView(this);
        countView.setText(String.valueOf(count));
        countView.setTextColor(getColor(R.color.text_dim));
        countView.setTextSize(9);
        tile.addView(countView);

        return tile;
    }

    private View buildStorageBar() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams wrapParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        wrapParams.topMargin = 24;
        wrap.setLayoutParams(wrapParams);

        StatFs stat = new StatFs(Environment.getDataDirectory().getPath());
        long availableGB = (stat.getAvailableBytes()) / (1024L * 1024 * 1024);
        long totalGB = (stat.getTotalBytes()) / (1024L * 1024 * 1024);
        float usedFraction = totalGB > 0 ? 1f - ((float) availableGB / totalGB) : 0f;

        LinearLayout barBg = new LinearLayout(this);
        LinearLayout.LayoutParams barBgParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 24);
        barBg.setLayoutParams(barBgParams);
        barBg.setBackgroundColor(getColor(R.color.line_color));

        View fill = new View(this);
        LinearLayout.LayoutParams fillParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.MATCH_PARENT);
        fillParams.weight = Math.max(0.02f, usedFraction);
        fill.setLayoutParams(fillParams);
        fill.setBackgroundColor(ThemeManager.getAccentColor(this));
        barBg.addView(fill);

        View spacer = new View(this);
        LinearLayout.LayoutParams spacerParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.MATCH_PARENT);
        spacerParams.weight = 1f - Math.max(0.02f, usedFraction);
        spacer.setLayoutParams(spacerParams);
        barBg.addView(spacer);

        wrap.addView(barBg);

        TextView label = new TextView(this);
        label.setText("Available: " + availableGB + "GB / Total: " + totalGB + "GB");
        label.setTextColor(getColor(R.color.text_dim));
        label.setTextSize(9.5f);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        labelParams.topMargin = 8;
        label.setLayoutParams(labelParams);
        wrap.addView(label);

        return wrap;
    }

    // ---- Categorizes real DownloadManager entries by mimetype/extension ----
    private int[] getFileCategoryCounts() {
        int[] counts = new int[8]; // music, video, photo, apps, archive, docs, webpage, others
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        android.database.Cursor cursor = dm.query(new DownloadManager.Query());
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String title = cursor.getString(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                String mime = cursor.getString(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE));
                String lower = (title != null ? title : "").toLowerCase(Locale.US);
                String mimeLower = (mime != null ? mime : "").toLowerCase(Locale.US);

                if (mimeLower.startsWith("audio") || lower.matches(".*\\.(mp3|wav|m4a|ogg)$")) counts[0]++;
                else if (mimeLower.startsWith("video") || lower.matches(".*\\.(mp4|mkv|webm|avi|mov)$")) counts[1]++;
                else if (mimeLower.startsWith("image") || lower.matches(".*\\.(png|jpg|jpeg|gif|webp)$")) counts[2]++;
                else if (lower.endsWith(".apk")) counts[3]++;
                else if (lower.matches(".*\\.(zip|rar|7z|tar|gz)$")) counts[4]++;
                else if (lower.matches(".*\\.(pdf|doc|docx|txt|xls|xlsx|ppt|pptx)$")) counts[5]++;
                else if (lower.matches(".*\\.(html|htm|mht|mhtml)$")) counts[6]++;
                else counts[7]++;
            }
            cursor.close();
        }
        return counts;
    }

    // ---- Send: pick from real downloaded files, share via Android's share sheet
    // (works with Nearby Share, Bluetooth, or any Wi-Fi-capable app already installed) ----
    private void showSendFilePicker() {
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        android.database.Cursor cursor = dm.query(new DownloadManager.Query()
                .setFilterByStatus(DownloadManager.STATUS_SUCCESSFUL));

        List<String> titles = new ArrayList<>();
        List<Long> ids = new ArrayList<>();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                titles.add(cursor.getString(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)));
                ids.add(cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)));
            }
            cursor.close();
        }

        if (titles.isEmpty()) {
            Toast.makeText(this, "No downloaded files to send yet", Toast.LENGTH_SHORT).show();
            return;
        }

        new AccentDialogBuilder(this)
                .setTitle("Send which file?")
                .setItems(titles.toArray(new String[0]), (d, which) -> {
                    Uri fileUri = dm.getUriForDownloadedFile(ids.get(which));
                    if (fileUri == null) {
                        Toast.makeText(this, "File not available", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    android.content.Intent shareIntent = new android.content.Intent(android.content.Intent.ACTION_SEND);
                    shareIntent.setType("*/*");
                    shareIntent.putExtra(android.content.Intent.EXTRA_STREAM, fileUri);
                    shareIntent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(android.content.Intent.createChooser(shareIntent, "Send via"));
                })
                .show();
    }

    // ---- Receive: opens a raw local-network socket and saves the first
    // incoming file to Downloads. Simple by design — one file per session,
    // no handshake protocol. ----
    private void showReceiveDialog() {
        String ip = getLocalIpAddress();
        int port = 8988;

        TextView statusView = new TextView(this);
        statusView.setText(ip != null
                ? "Waiting for a file at:\n" + ip + ":" + port
                : "Couldn't determine Wi-Fi IP — make sure you're connected to Wi-Fi");
        statusView.setTextColor(getColor(R.color.text_primary));
        statusView.setTextSize(12);
        statusView.setPadding(40, 40, 40, 40);
        statusView.setGravity(android.view.Gravity.CENTER);

        AlertDialog dialog = new AccentDialogBuilder(this)
                .setTitle("Receive File")
                .setView(statusView)
                .setNegativeButton("Cancel", (d, w) -> stopReceiveServer())
                .setCancelable(false)
                .create();
        dialog.show();

        if (ip == null) return;

        networkExecutor.execute(() -> {
            try {
                receiveServerSocket = new ServerSocket(port);
                Socket client = receiveServerSocket.accept(); // blocks until a sender connects

                String fileName = "received_" + System.currentTimeMillis() + ".bin";
                File outFile = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName);
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    byte[] buffer = new byte[4096];
                    int read;
                    while ((read = client.getInputStream().read(buffer)) != -1) {
                        fos.write(buffer, 0, read);
                    }
                }
                client.close();

                mainHandler.post(() -> {
                    dialog.dismiss();
                    Toast.makeText(this, "File received: " + fileName, Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                mainHandler.post(dialog::dismiss);
            } finally {
                stopReceiveServer();
            }
        });
    }

    private void stopReceiveServer() {
        try {
            if (receiveServerSocket != null && !receiveServerSocket.isClosed()) {
                receiveServerSocket.close();
            }
        } catch (Exception ignored) {}
    }

    private String getLocalIpAddress() {
        try {
            android.net.wifi.WifiManager wm =
                    (android.net.wifi.WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            int ipInt = wm.getConnectionInfo().getIpAddress();
            if (ipInt == 0) return null;
            return String.format(Locale.US, "%d.%d.%d.%d",
                    (ipInt & 0xff), (ipInt >> 8 & 0xff), (ipInt >> 16 & 0xff), (ipInt >> 24 & 0xff));
        } catch (Exception e) {
            return null;
        }
    }

    // ================================================================
    // MY VIDEOS — real list, filtered from Download Manager entries by
    // video mimetype. Tapping a video opens it in the device's default
    // video player (matches how a real "video library" tile should behave).
    // ================================================================
    private View buildMyVideosView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(buildPageHeader("My Videos", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(20, 20, 20, 20);
        scroll.addView(list);
        root.addView(scroll);

        boolean foundAny = false;

        // Videos pulled in through the Universal Downloader (paste-a-link or
        // "Download Video") — these have a real saved content:// URI once done.
        for (NexDownload d : loadNexDownloads()) {
            if (!"done".equals(d.status) || d.savedUri.isEmpty()) continue;
            boolean isVideo = (d.mimeType != null && d.mimeType.startsWith("video"))
                    || d.fileName.toLowerCase(Locale.US).matches(".*\\.(mp4|mkv|webm|avi|mov|ts)$");
            if (isVideo) {
                foundAny = true;
                list.addView(buildNexVideoRow(d));
            }
        }

        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        android.database.Cursor cursor = dm.query(new DownloadManager.Query()
                .setFilterByStatus(DownloadManager.STATUS_SUCCESSFUL));

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String title = cursor.getString(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                String mime = cursor.getString(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE));
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_ID));
                boolean isVideo = (mime != null && mime.startsWith("video"))
                        || (title != null && title.toLowerCase(Locale.US).matches(".*\\.(mp4|mkv|webm|avi|mov)$"));
                if (isVideo) {
                    foundAny = true;
                    list.addView(buildVideoRow(dm, id, title != null ? title : "Video"));
                }
            }
            cursor.close();
        }

        if (!foundAny) {
            TextView empty = new TextView(this);
            empty.setText("🎬\n\nYou don't have any video at this moment");
            empty.setTextColor(getColor(R.color.text_dim));
            empty.setTextSize(11);
            empty.setGravity(android.view.Gravity.CENTER);
            empty.setPadding(0, 100, 0, 100);
            list.addView(empty);
        }

        return root;
    }

    private View buildNexVideoRow(NexDownload d) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(16, 20, 16, 20);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 6;
        row.setLayoutParams(rowParams);
        row.setBackgroundResource(R.drawable.bg_tab_inactive);

        TextView icon = new TextView(this);
        icon.setText("▶");
        icon.setTextColor(getColor(R.color.gold));
        icon.setTextSize(16);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        iconParams.rightMargin = 16;
        icon.setLayoutParams(iconParams);
        row.addView(icon);

        TextView titleView = new TextView(this);
        titleView.setText(d.fileName);
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(12);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleParams.weight = 1;
        titleView.setLayoutParams(titleParams);
        row.addView(titleView);

        row.setOnClickListener(v -> {
            try {
                Uri uri = Uri.parse(d.savedUri);
                android.content.Intent playIntent = new android.content.Intent(android.content.Intent.ACTION_VIEW);
                playIntent.setDataAndType(uri, "video/*");
                playIntent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(playIntent);
            } catch (Exception e) {
                Toast.makeText(this, "No video player app found", Toast.LENGTH_SHORT).show();
            }
        });

        return row;
    }

    private View buildVideoRow(DownloadManager dm, long downloadId, String title) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(16, 20, 16, 20);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 6;
        row.setLayoutParams(rowParams);
        row.setBackgroundResource(R.drawable.bg_tab_inactive);

        TextView icon = new TextView(this);
        icon.setText("▶");
        icon.setTextColor(getColor(R.color.gold));
        icon.setTextSize(16);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        iconParams.rightMargin = 16;
        icon.setLayoutParams(iconParams);
        row.addView(icon);

        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(12);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleParams.weight = 1;
        titleView.setLayoutParams(titleParams);
        row.addView(titleView);

        row.setOnClickListener(v -> {
            Uri uri = dm.getUriForDownloadedFile(downloadId);
            if (uri == null) {
                Toast.makeText(this, "File not available", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                android.content.Intent playIntent = new android.content.Intent(android.content.Intent.ACTION_VIEW);
                playIntent.setDataAndType(uri, "video/*");
                playIntent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(playIntent);
            } catch (Exception e) {
                Toast.makeText(this, "No video player app found", Toast.LENGTH_SHORT).show();
            }
        });

        return row;
    }

    // ---- Night: dims the screen further than system brightness (a lightweight
    // "easier on the eyes at night" toggle, distinct from the app's permanent
    // dark theme) ----
    private void toggleNightDim() {
        isNightDimOn = !isNightDimOn;
        android.view.WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = isNightDimOn ? 0.12f : -1f; // -1 restores system default
        getWindow().setAttributes(lp);
        Toast.makeText(this, "Night dim " + (isNightDimOn ? "ON" : "OFF"), Toast.LENGTH_SHORT).show();
    }

    private void confirmExitApp() {
        new AccentDialogBuilder(this)
                .setTitle("Close Nex Browser?")
                .setMessage("This will close the app.")
                .setPositiveButton("Close", (d, w) -> finishAffinity())
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ================================================================
    // FULL-PAGE OVERLAY SYSTEM — used by Settings, Add-ons, and Ad Block.
    // Each "page" is just a View swapped into pageContainer; each page's
    // own "‹" header button decides where "back" goes (its own mini stack).
    // ================================================================
    // Tab Relationship Graph (#17) — visual node-edge view of which tab
    // was opened from which (parentTabId, already tracked and used for
    // cascade-close). Simple layered layout: BFS levels from each root
    // (a tab whose parent is -1 or has since been closed), evenly
    // spaced left-to-right within each level.
    private View buildTabRelationshipGraphView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("Tab Relationships", this::hideFullPage));

        TextView hint = new TextView(this);
        hint.setText("Lines show which tab was opened from which. Tap a node to switch to it.");
        hint.setTextColor(getColor(R.color.text_dim));
        hint.setTextSize(10);
        hint.setPadding(32, 12, 32, 12);
        root.addView(hint);

        ScrollView vScroll = new ScrollView(this);
        vScroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        HorizontalScrollView hScroll = new HorizontalScrollView(this);
        hScroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TabGraphCanvasView graphView = new TabGraphCanvasView(this);
        hScroll.addView(graphView);
        vScroll.addView(hScroll);
        root.addView(vScroll);
        return root;
    }

    // Custom-drawn (Canvas) rather than laid out with nested view groups
    // — a node-edge graph with parent-to-child lines doesn't map cleanly
    // onto Android's box-based layout system, but is straightforward to
    // draw directly once node positions are computed.
    private class TabGraphCanvasView extends View {
        private final int nodeRadius = 70;
        private final int levelSpacingY = 260;
        private final int nodeSpacingX = 220;
        private final Map<Integer, float[]> nodePositions = new HashMap<>(); // tabId -> {x, y}
        private final Paint linePaint = new Paint();
        private final Paint nodePaint = new Paint();
        private final Paint nodeBorderPaint = new Paint();
        private final Paint textPaint = new Paint();

        TabGraphCanvasView(android.content.Context ctx) {
            super(ctx);
            linePaint.setColor(getColor(R.color.line_color));
            linePaint.setStrokeWidth(4);
            linePaint.setAntiAlias(true);
            nodeBorderPaint.setStyle(Paint.Style.STROKE);
            nodeBorderPaint.setStrokeWidth(5);
            nodeBorderPaint.setAntiAlias(true);
            nodePaint.setAntiAlias(true);
            textPaint.setColor(Color.WHITE);
            textPaint.setTextSize(24);
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setAntiAlias(true);

            // Layout pass: BFS level assignment from every root (a tab
            // whose parent is -1, or whose parent has since been closed
            // — findTabById returning null covers both).
            List<DevilTab> roots = new ArrayList<>();
            for (DevilTab t : tabs) {
                if (findTabById(t.parentTabId) == null) roots.add(t);
            }
            Map<Integer, Integer> levelOf = new HashMap<>();
            List<List<DevilTab>> levels = new ArrayList<>();
            List<DevilTab> currentLevel = roots;
            int levelIdx = 0;
            Set<Integer> visited = new HashSet<>();
            while (!currentLevel.isEmpty()) {
                levels.add(currentLevel);
                List<DevilTab> nextLevel = new ArrayList<>();
                for (DevilTab t : currentLevel) {
                    levelOf.put(t.id, levelIdx);
                    visited.add(t.id);
                }
                for (DevilTab t : currentLevel) {
                    for (DevilTab candidate : tabs) {
                        if (candidate.parentTabId == t.id && !visited.contains(candidate.id)) {
                            nextLevel.add(candidate);
                        }
                    }
                }
                currentLevel = nextLevel;
                levelIdx++;
            }
            // Any tab not reached (shouldn't normally happen, but a
            // defensive catch-all so nothing is silently missing from
            // the graph) gets appended as its own extra root level.
            List<DevilTab> orphans = new ArrayList<>();
            for (DevilTab t : tabs) if (!visited.contains(t.id)) orphans.add(t);
            if (!orphans.isEmpty()) levels.add(orphans);

            int maxPerLevel = 1;
            for (List<DevilTab> lvl : levels) maxPerLevel = Math.max(maxPerLevel, lvl.size());
            int canvasWidth = Math.max(maxPerLevel * nodeSpacingX, nodeSpacingX) + 200;
            int canvasHeight = Math.max(levels.size(), 1) * levelSpacingY + 200;

            for (int li = 0; li < levels.size(); li++) {
                List<DevilTab> lvl = levels.get(li);
                int n = lvl.size();
                float startX = (canvasWidth - (n - 1) * (float) nodeSpacingX) / 2f;
                for (int i = 0; i < n; i++) {
                    float x = startX + i * nodeSpacingX;
                    float y = 150 + li * levelSpacingY;
                    nodePositions.put(lvl.get(i).id, new float[]{x, y});
                }
            }

            setLayoutParams(new LinearLayout.LayoutParams(canvasWidth, canvasHeight));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            // Edges first, so node circles draw on top of the lines
            // meeting at their edge rather than lines crossing over circles.
            for (DevilTab t : tabs) {
                float[] childPos = nodePositions.get(t.id);
                float[] parentPos = nodePositions.get(t.parentTabId);
                if (childPos != null && parentPos != null) {
                    canvas.drawLine(parentPos[0], parentPos[1], childPos[0], childPos[1], linePaint);
                }
            }
            for (DevilTab t : tabs) {
                float[] pos = nodePositions.get(t.id);
                if (pos == null) continue;
                boolean isCurrent = tabs.indexOf(t) == currentTabIndex;
                nodePaint.setColor(t.isIncognito ? Color.parseColor("#3A2E57") : Color.parseColor("#2A2A3E"));
                canvas.drawCircle(pos[0], pos[1], nodeRadius, nodePaint);
                nodeBorderPaint.setColor(isCurrent ? getColor(R.color.gold) : getColor(R.color.line_color));
                canvas.drawCircle(pos[0], pos[1], nodeRadius, nodeBorderPaint);
                String icon = t.isIncognito ? "🕶" : ("home".equals(t.type) ? "🌟" : "🌐");
                canvas.drawText(icon, pos[0], pos[1] + 12, textPaint);
                String label = t.title != null && !t.title.isEmpty() ? t.title : "New Tab";
                if (label.length() > 14) label = label.substring(0, 13) + "…";
                canvas.drawText(label, pos[0], pos[1] + nodeRadius + 34, textPaint);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                float tapX = event.getX();
                float tapY = event.getY();
                for (Map.Entry<Integer, float[]> entry : nodePositions.entrySet()) {
                    float[] pos = entry.getValue();
                    float dx = tapX - pos[0];
                    float dy = tapY - pos[1];
                    if (Math.sqrt(dx * dx + dy * dy) <= nodeRadius) {
                        DevilTab tapped = findTabById(entry.getKey());
                        if (tapped != null) {
                            currentTabIndex = tabs.indexOf(tapped);
                            switchToTab(currentTabIndex);
                            hideFullPage();
                        }
                        return true;
                    }
                }
            }
            return true;
        }
    }

    // ================================================================
    // AI WEB COMPARISON (#97) — pick 2+ open tabs, extract each one's
    // main content (reuses Reader Mode's #96 extraction JS), send them
    // all to /web/compare for a structured similarities/differences
    // breakdown. General-purpose comparison — not specifically about
    // factual conflicts (that's Contradiction Detector, #99) or source
    // trustworthiness (Source Reliability Engine, #98).
    // ================================================================
    private View buildCompareTabsPickerView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("Compare Tabs", this::hideFullPage));

        TextView hint = new TextView(this);
        hint.setText("Pick 2 or more open tabs to compare with AI. Suspended and incognito tabs aren't available.");
        hint.setTextColor(getColor(R.color.text_dim));
        hint.setTextSize(10);
        hint.setPadding(32, 12, 32, 12);
        root.addView(hint);

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(24, 8, 24, 8);
        list.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        Set<Integer> selected = new HashSet<>();
        int available = 0;
        for (int i = 0; i < tabs.size(); i++) {
            DevilTab t = tabs.get(i);
            if (t.isIncognito || t.isSuspended || !"web".equals(t.type)) continue;
            available++;
            int idx = i;
            android.widget.CheckBox cb = new android.widget.CheckBox(this);
            String url = t.webView != null ? t.webView.getUrl() : null;
            String label = (t.title != null && !t.title.isEmpty()) ? t.title : (url != null ? url : "Tab");
            cb.setText(label);
            cb.setTextColor(getColor(R.color.text_primary));
            cb.setTextSize(12);
            cb.setOnCheckedChangeListener((btn, checked) -> {
                if (checked) selected.add(idx); else selected.remove(idx);
            });
            LinearLayout.LayoutParams cbParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            cbParams.bottomMargin = 8;
            cb.setLayoutParams(cbParams);
            list.addView(cb);
        }
        if (available == 0) {
            TextView empty = new TextView(this);
            empty.setText("No comparable tabs open right now.");
            empty.setTextColor(getColor(R.color.text_dim));
            empty.setTextSize(11);
            list.addView(empty);
        }
        scroll.addView(list);
        root.addView(scroll);

        TextView compareBtn = new TextView(this);
        compareBtn.setText("Compare Selected");
        compareBtn.setTextColor(getColor(R.color.gold));
        compareBtn.setTextSize(12);
        compareBtn.setGravity(android.view.Gravity.CENTER);
        compareBtn.setPadding(20, 20, 20, 20);
        compareBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams compareBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        compareBtnParams.setMargins(24, 12, 24, 24);
        compareBtn.setLayoutParams(compareBtnParams);
        compareBtn.setOnClickListener(v -> {
            if (selected.size() < 2) {
                Toast.makeText(this, "Pick at least 2 tabs", Toast.LENGTH_SHORT).show();
                return;
            }
            runWebComparison(new ArrayList<>(selected), "compare");
        });
        root.addView(compareBtn);

        // Contradiction Detector (#99): same picked tabs, same
        // extraction, a narrower AI question — not "what's similar/
        // different overall" but specifically "where do these disagree".
        TextView contradictBtn = new TextView(this);
        contradictBtn.setText("Find Contradictions");
        contradictBtn.setTextColor(getColor(R.color.gold));
        contradictBtn.setTextSize(12);
        contradictBtn.setGravity(android.view.Gravity.CENTER);
        contradictBtn.setPadding(20, 20, 20, 20);
        contradictBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams contradictBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        contradictBtnParams.setMargins(24, 0, 24, 24);
        contradictBtn.setLayoutParams(contradictBtnParams);
        contradictBtn.setOnClickListener(v -> {
            if (selected.size() < 2) {
                Toast.makeText(this, "Pick at least 2 tabs", Toast.LENGTH_SHORT).show();
                return;
            }
            runWebComparison(new ArrayList<>(selected), "contradictions");
        });
        root.addView(contradictBtn);

        return root;
    }

    private void runWebComparison(List<Integer> tabIndices, String mode) {
        Toast.makeText(this, "Extracting pages…", Toast.LENGTH_SHORT).show();
        List<JSONObject> pages = new ArrayList<>();
        java.util.concurrent.atomic.AtomicInteger remaining = new java.util.concurrent.atomic.AtomicInteger(tabIndices.size());

        for (int idx : tabIndices) {
            if (idx < 0 || idx >= tabs.size()) {
                if (remaining.decrementAndGet() == 0) finishExtractionAndCompare(pages, mode);
                continue;
            }
            DevilTab t = tabs.get(idx);
            WebView wv = t.webView;
            if (wv == null) {
                if (remaining.decrementAndGet() == 0) finishExtractionAndCompare(pages, mode);
                continue;
            }
            String url = wv.getUrl();
            wv.evaluateJavascript(READER_EXTRACT_JS, raw -> {
                String json = unescapeJsString(raw);
                try {
                    JSONObject obj = new JSONObject(json);
                    JSONObject page = new JSONObject();
                    page.put("title", obj.optString("title", t.title != null ? t.title : "Page"));
                    page.put("url", url != null ? url : "");
                    page.put("text", obj.optString("text", ""));
                    pages.add(page);
                } catch (Exception ignored) {}
                if (remaining.decrementAndGet() == 0) finishExtractionAndCompare(pages, mode);
            });
        }
    }

    // mode: "compare" (#97, general similarities/differences) or
    // "contradictions" (#99, specifically factual disagreements) — same
    // extraction pipeline, different backend endpoint + result framing.
    private void finishExtractionAndCompare(List<JSONObject> pages, String mode) {
        if (pages.size() < 2) {
            Toast.makeText(this, "Couldn't extract enough content to compare", Toast.LENGTH_LONG).show();
            return;
        }
        boolean isContradictions = "contradictions".equals(mode);
        String endpoint = isContradictions ? "/web/contradictions" : "/web/compare";
        String resultKey = isContradictions ? "result" : "comparison";
        String resultTitle = isContradictions ? "⚡ Contradictions" : "🆚 Comparison";
        Toast.makeText(this, isContradictions ? "Checking for contradictions…" : "Comparing…", Toast.LENGTH_SHORT).show();
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                JSONArray arr = new JSONArray();
                for (JSONObject p : pages) arr.put(p);
                body.put("pages", arr);
                JSONObject resp = httpPostJson(backendUrl + endpoint, body, authToken);
                String output = resp.optString(resultKey, "No result returned");
                mainHandler.post(() -> showFullPage(buildComparisonResultView(output, resultTitle)));
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private View buildComparisonResultView(String comparison, String headerTitle) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader(headerTitle, this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(32, 16, 32, 48);
        content.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        for (String para : comparison.split("\\n\\s*\\n")) {
            String trimmed = para.trim();
            if (trimmed.isEmpty()) continue;
            TextView paraView = new TextView(this);
            paraView.setText(trimmed);
            paraView.setTextColor(getColor(R.color.text_primary));
            paraView.setTextSize(13.5f);
            paraView.setLineSpacing(8, 1.15f);
            LinearLayout.LayoutParams paraParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            paraParams.bottomMargin = 24;
            paraView.setLayoutParams(paraParams);
            content.addView(paraView);
        }

        scroll.addView(content);
        root.addView(scroll);
        return root;
    }

    /** AlertDialog.Builder that paints the dialog's buttons and inputs with the exact accent colour
     *  (the stock buttons use the theme's nearest-preset colour — see ThemeManager.tintViewTree). */
    private class AccentDialogBuilder extends AlertDialog.Builder {
        AccentDialogBuilder(android.content.Context context) {
            super(context);
        }

        @Override
        public AlertDialog create() {
            final AlertDialog dialog = super.create();
            dialog.setOnShowListener(d -> {
                int accent = ThemeManager.getAccentColor(MainActivity.this);
                int[] buttons = {android.content.DialogInterface.BUTTON_POSITIVE, android.content.DialogInterface.BUTTON_NEGATIVE, android.content.DialogInterface.BUTTON_NEUTRAL};
                for (int which : buttons) {
                    android.widget.Button b = dialog.getButton(which);
                    if (b != null) b.setTextColor(accent);
                }
                if (dialog.getWindow() != null) ThemeManager.tintViewTree(dialog.getWindow().getDecorView(), accent);
            });
            return dialog;
        }
    }

    private void showFullPage(View content) {
        ThemeManager.tintViewTree(content, ThemeManager.getAccentColor(this));
        pageContainer.removeAllViews();
        pageContainer.addView(content);
        pageContainer.setVisibility(View.VISIBLE);
        isPageShown = true;
    }

    private void hideFullPage() {
        pageContainer.setVisibility(View.GONE);
        isPageShown = false;
    }

    // ---- Universal Panel drawer: true edge-anchored slide-in, not a full page ----

    private void showUniversalPanel(View content) {
        ThemeManager.tintViewTree(content, ThemeManager.getAccentColor(this));
        universalPanelDrawer.removeAllViews();
        universalPanelDrawer.addView(content);

        if (isUniversalPanelShown) {
            // Already open (e.g. switching Bookmarks ↔ History ↔ Tabs, or
            // rebuilding after a change) — just swap content in place,
            // no need to re-run the slide/dim animation.
            return;
        }

        universalPanelContainer.setAlpha(0f);
        universalPanelContainer.setVisibility(View.VISIBLE);
        universalPanelDrawer.setTranslationX(universalPanelDrawer.getLayoutParams().width);
        universalPanelContainer.animate().alpha(1f).setDuration(220).start();
        universalPanelDrawer.animate().translationX(0f).setDuration(240).start();
        isUniversalPanelShown = true;
    }

    private void hideUniversalPanel() {
        if (!isUniversalPanelShown) return;
        int width = universalPanelDrawer.getWidth() > 0
                ? universalPanelDrawer.getWidth()
                : universalPanelDrawer.getLayoutParams().width;
        universalPanelContainer.animate().alpha(0f).setDuration(200).start();
        universalPanelDrawer.animate().translationX(width).setDuration(200)
                .withEndAction(() -> universalPanelContainer.setVisibility(View.GONE))
                .start();
        isUniversalPanelShown = false;
    }

    // Some row builders (buildBookmarkHistoryRow) are shared between the
    // Universal Panel drawer AND separate full-page screens (History
    // Timeline, semantic history search) that reuse the same row layout.
    // A shared row can't assume which container it's currently sitting in,
    // so its "open this URL" tap uses this instead of hideFullPage() or
    // hideUniversalPanel() directly — it closes whichever is actually open.
    private void hideAnyOverlay() {
        if (isUniversalPanelShown) hideUniversalPanel();
        if (isPageShown) hideFullPage();
    }

    private LinearLayout buildPageHeader(String title, Runnable onBack, View... rightIcons) {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(android.view.Gravity.CENTER_VERTICAL);
        header.setPadding(16, 40, 16, 20);
        header.setBackgroundColor(getColor(R.color.bg_secondary));

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextColor(getColor(R.color.text_primary));
        back.setTextSize(20);
        back.setPadding(12, 8, 24, 8);
        back.setOnClickListener(v -> onBack.run());
        header.addView(back);

        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(14);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleParams.weight = 1;
        titleView.setLayoutParams(titleParams);
        header.addView(titleView);

        for (View icon : rightIcons) header.addView(icon);

        return header;
    }

    // ================================================================
    // SETTINGS SCREEN
    // ================================================================
    private View buildSettingsView() {
        // Agent Permission Firewall (#79) / Agent Policy Engine (#80):
        // fetch here too (not just Automation) so that by the time the
        // user taps into either sub-screen below, the values are
        // already synced rather than showing stale defaults.
        if (!agentFirewallLoaded) {
            agentFirewallLoaded = true;
            fetchAgentFirewallConfig();
        }
        if (!agentPolicyLoaded) {
            agentPolicyLoaded = true;
            fetchAgentPolicyConfig();
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(buildPageHeader("Settings", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(24, 12, 24, 24);
        scroll.addView(list);
        root.addView(scroll);

        list.addView(buildSettingsRow("Add-ons", null, true,
                () -> showFullPage(buildAddOnsView())));

        list.addView(buildSettingsToggleRow("Set as Default Browser", true,
                () -> toggleSetAsDefaultBrowser()));

        list.addView(buildSettingsRow("Browsing Settings", null, true,
                () -> showFullPage(buildBrowsingSettingsView())));

        list.addView(buildSettingsRow("Download Settings", null, true,
                () -> showFullPage(buildDownloadSettingsView())));

        list.addView(buildSettingsRow("Notification Settings", null, true,
                () -> showFullPage(buildNotificationSettingsView())));

        list.addView(buildSettingsRow("Language", prefs.getString("language", "English"), true,
                () -> showFullPage(buildLanguageView())));

        list.addView(buildSettingsRow("Clear Records", null, false, this::clearRecords));

        List<SavedCredential> savedCreds = loadCredentials();
        list.addView(buildSettingsRow("Passwords", savedCreds.size() + " saved", true,
                this::showPasswordsScreenGated));

        list.addView(buildSettingsRow("Security Settings", biometricLockEnabled ? "Biometric Lock ON" : "Biometric Lock OFF", true,
                () -> showFullPage(buildSecuritySettingsView())));

        list.addView(buildSettingsRow("Backend Server", backendUrl.isEmpty() ? "Not set" : "Configured", true,
                this::showBackendUrlDialog));

        list.addView(buildSettingsRow("Account", authToken.isEmpty() ? "Not signed in" : authEmail, true,
                this::showAccountScreen));

        list.addView(buildSettingsRow("Sync Now", authToken.isEmpty() ? "Sign in to sync" : "Settings, bookmarks, history & tabs", true,
                this::syncEverythingNow));

        list.addView(buildSettingsRow("🤖 AI", "Used for Autopilot, Task Planning & Visual AI", true,
                this::showAiKeyDialog));

        list.addView(buildSettingsRow("🔌 Custom APIs", customApisCache.isEmpty() ? "Add any app's API key" : customApisCache.size() + " saved", true,
                this::showCustomApisDialog));

        list.addView(buildSettingsRow("🧠 AI Answer Cache", aiCacheSummary(), true,
                this::showAiCacheDialog));

        list.addView(buildSettingsRow("🧩 Extensions", extensionsSummary(), true,
                this::showExtensionsDialog));

        list.addView(buildSettingsRow("🔥 Agent Firewall", "Which domains Automation tasks can navigate to", true,
                () -> showFullPage(buildAgentFirewallView())));

        list.addView(buildSettingsRow("📐 Agent Policy", "Global sensitive-action & step-limit rules", true,
                () -> showFullPage(buildAgentPolicyView())));

        list.addView(buildSettingsRow("About Nex Browser", null, true, this::showAboutDialog));

        TextView reset = new TextView(this);
        reset.setText("Reset to Default");
        reset.setTextColor(ThemeManager.getAccentColor(this));
        reset.setTextSize(12);
        reset.setGravity(android.view.Gravity.CENTER);
        reset.setPadding(20, 32, 20, 20);
        reset.setOnClickListener(v -> resetBrowserToDefault());
        list.addView(reset);

        return root;
    }

    private View buildSettingsRow(String label, String rightText, boolean showChevron, Runnable onClick) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(8, 28, 8, 28);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        row.setLayoutParams(rowParams);

        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextColor(getColor(R.color.text_primary));
        labelView.setTextSize(12);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        labelParams.weight = 1;
        labelView.setLayoutParams(labelParams);
        row.addView(labelView);

        if (rightText != null) {
            TextView rightView = new TextView(this);
            rightView.setText(rightText);
            rightView.setTextColor(getColor(R.color.text_dim));
            rightView.setTextSize(11);
            rightView.setPadding(0, 0, 12, 0);
            row.addView(rightView);
        }

        if (showChevron) {
            TextView chevron = new TextView(this);
            chevron.setText("›");
            chevron.setTextColor(getColor(R.color.text_dim));
            chevron.setTextSize(14);
            row.addView(chevron);
        } else {
            TextView dots = new TextView(this);
            dots.setText("⋯");
            dots.setTextColor(getColor(R.color.text_dim));
            dots.setTextSize(14);
            row.addView(dots);
        }

        row.setOnClickListener(v -> onClick.run());
        return row;
    }

    /**
     * Explicit runtime tint for a Switch, instead of relying on the
     * theme's default colorSecondary. This is what actually makes Accent
     * Color (all 5 presets AND custom RGB) reach every on/off switch in
     * the app correctly — including colors that have no compiled
     * ThemeOverlay, which colorSecondary alone can't do (see
     * CUSTOM-ACCENT-COLOR-CHANGES.md). Called from every place in the
     * file that builds a Switch, five in total.
     */
    private void tintSwitch(android.widget.Switch toggle) {
        int accent = ThemeManager.getAccentColor(this);
        android.content.res.ColorStateList thumbTint = new android.content.res.ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{accent, getColor(R.color.text_dim)});
        android.content.res.ColorStateList trackTint = new android.content.res.ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{ThemeManager.shade(accent, 0.6f), getColor(R.color.line_color)});
        toggle.setThumbTintList(thumbTint);
        toggle.setTrackTintList(trackTint);
    }

    private View buildSettingsToggleRow(String label, boolean initialOn, Runnable onToggle) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(8, 28, 8, 28);

        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextColor(getColor(R.color.text_primary));
        labelView.setTextSize(12);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        labelParams.weight = 1;
        labelView.setLayoutParams(labelParams);
        row.addView(labelView);

        android.widget.Switch toggle = new android.widget.Switch(this);
        toggle.setChecked(initialOn);
        tintSwitch(toggle);
        toggle.setOnClickListener(v -> onToggle.run());
        row.addView(toggle);

        return row;
    }

    // ---- "Set as Default Browser" opens Android's own default-apps settings
    // (an app cannot silently make itself the default — the user must confirm
    // it in system settings, same as every real browser) ----
    private void toggleSetAsDefaultBrowser() {
        try {
            startActivity(new android.content.Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't open system default-apps settings", Toast.LENGTH_SHORT).show();
        }
    }

    // ---- Clear Records: real cache/cookie/history wipe ----
    private void clearRecords() {
        new AccentDialogBuilder(this)
                .setTitle("Clear Records")
                .setMessage("Clear browsing history, cache, and cookies?")
                .setPositiveButton("Clear", (d, w) -> {
                    for (DevilTab tab : tabs) if (tab.webView != null) tab.webView.clearCache(true);
                    CookieManager.getInstance().removeAllCookies(null);
                    prefs.edit().putString("history", "[]").apply();
                    Toast.makeText(this, "Records cleared", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showAboutDialog() {
        String version = "1.0";
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            version = info.versionName;
        } catch (Exception ignored) {}
        new AccentDialogBuilder(this)
                .setTitle("About Nex Browser")
                .setMessage("Nex Browser\nVersion " + version + "\n\nA fast, private, real native Android browser.")
                .setPositiveButton("OK", null)
                .show();
    }

    // ================================================================
    // BACKEND SERVER CONFIG — the URL of your deployed nex-backend
    // (Railway etc.). Required before AI Summarizer, Cloud Sync, or
    // Push Notifications will work — everything else in the app runs
    // fine without ever setting this.
    // ================================================================
    private void showBackendUrlDialog() {
        EditText input = new EditText(this);
        input.setHint("https://your-app.up.railway.app");
        input.setText(backendUrl);
        input.setTextColor(getColor(R.color.text_primary));
        input.setHintTextColor(getColor(R.color.text_dim));
        input.setPadding(32, 24, 32, 24);

        new AccentDialogBuilder(this)
                .setTitle("Backend Server URL")
                .setMessage("Needed only for AI Summarizer and Cloud Sync. See the nex-backend README for how to deploy one.")
                .setView(input)
                .setPositiveButton("Save", (d, w) -> {
                    String url = input.getText().toString().trim();
                    if (url.endsWith("/")) url = url.substring(0, url.length() - 1);
                    if (!url.isEmpty() && !url.startsWith("http://") && !url.startsWith("https://")) {
                        url = "https://" + url; // no scheme typed — default to the safe one, not a guess
                    }
                    // SECURITY (release QA item: "production backend traffic
                    // policy... authentication/sync/API traffic must be
                    // protected"). General http:// browsing is fine for a
                    // browser (see AndroidManifest's usesCleartextTraffic
                    // note) — this is different: sign-in tokens, Cloud Sync
                    // data, AI provider keys and Custom API keys all travel
                    // to THIS exact URL, so plain http here would send all
                    // of that unencrypted. Only warn-and-allow for obvious
                    // local development addresses, where that's expected.
                    if (url.startsWith("http://") && !isLocalDevAddress(url)) {
                        String finalUrl = url;
                        new AccentDialogBuilder(this)
                                .setTitle("⚠️ Use plain HTTP for your backend?")
                                .setMessage("Your sign-in, Cloud Sync data, and any AI/Custom API keys you save all travel through this server. Over plain http://, that would be sent unencrypted. Only continue if this is a local/test server.")
                                .setPositiveButton("Use HTTP anyway", (d2, w2) -> saveBackendUrl(finalUrl))
                                .setNegativeButton("Cancel", null)
                                .show();
                        return;
                    }
                    saveBackendUrl(url);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveBackendUrl(String url) {
        backendUrl = url;
        prefs.edit().putString("backend_url", backendUrl).apply();
        showFullPage(buildSettingsView());
    }

    // Obvious local-development hosts (localhost, loopback, and the private
    // IP ranges a phone/emulator uses to reach a computer on the same
    // network/USB bridge) — the one legitimate reason to point this app's
    // backend at plain http:// instead of a warning being pure friction.
    private boolean isLocalDevAddress(String url) {
        try {
            return DownloadUtils.isPrivateOrLocalHost(Uri.parse(url).getHost());
        } catch (Exception e) {
            return false;
        }
    }

    // ================================================================
    // ACCOUNT / AUTH — needed only for Cloud Sync (bookmarks) and
    // Push Notifications. Calls the backend's /auth/register and
    // /auth/login endpoints.
    // ================================================================
    // ================================================================
    // SECURITY SETTINGS — a dedicated box (reached from Settings, and
    // linked from Security Center) holding every security-related on/off
    // toggle as a REAL Switch widget, not a tap-a-text-row action. Flip
    // one and it takes effect immediately — off means off (no prompt
    // shows up anywhere until turned back on), on means genuinely on
    // (the very next time a fingerprint/face/PIN check applies, it
    // actually asks).
    // ================================================================
    private View buildSecuritySettingsView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("Security Settings", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(24, 12, 24, 24);
        scroll.addView(list);
        root.addView(scroll);

        list.addView(buildSettingsToggleRow("Biometric Vault Lock", biometricLockEnabled, () -> {
            toggleBiometricLock();
            showFullPage(buildSecuritySettingsView());
        }));
        TextView biometricNote = new TextView(this);
        biometricNote.setText("When ON: opening Passwords asks for your fingerprint, face, or PIN first — every time you leave the app and come back, or after 2 minutes idle. When OFF: Passwords open straight away, no prompt, ever.");
        biometricNote.setTextColor(getColor(R.color.text_dim));
        biometricNote.setTextSize(10);
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        noteParams.bottomMargin = 20;
        biometricNote.setLayoutParams(noteParams);
        list.addView(biometricNote);

        list.addView(buildSettingsToggleRow("Password Manager (save & autofill)", passwordManagerEnabled, () -> {
            passwordManagerEnabled = !passwordManagerEnabled;
            prefs.edit().putBoolean("password_manager_enabled", passwordManagerEnabled).apply();
            showFullPage(buildSecuritySettingsView());
        }));
        TextView pmNote = new TextView(this);
        pmNote.setText("When OFF: the app stops offering to save new logins and stops autofilling saved ones — passwords already saved stay saved, just not offered/filled until turned back on.");
        pmNote.setTextColor(getColor(R.color.text_dim));
        pmNote.setTextSize(10);
        list.addView(pmNote);

        return root;
    }

    private void showAccountScreen() {
        if (!authToken.isEmpty()) {
            LinearLayout content = new LinearLayout(this);
            content.setOrientation(LinearLayout.VERTICAL);
            content.setPadding(24, 8, 24, 16);

            TextView emailView = new TextView(this);
            emailView.setText("Signed in as " + authEmail);
            emailView.setTextColor(getColor(R.color.text_primary));
            emailView.setTextSize(13);
            LinearLayout.LayoutParams emailParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            emailParams.bottomMargin = 20;
            emailView.setLayoutParams(emailParams);
            content.addView(emailView);

            AlertDialog dialog = new AccentDialogBuilder(this)
                    .setTitle("Account")
                    .setView(content)
                    .setNegativeButton("Close", null)
                    .create();

            content.addView(buildAccountActionRow("🛡 Security Center", () -> {
                dialog.dismiss();
                showFullPage(buildSecurityCenterView());
            }));
            content.addView(buildAccountActionRow("📱 Manage Sessions", () -> {
                dialog.dismiss();
                showFullPage(buildSessionsView());
            }));
            content.addView(buildAccountActionRow("🚪 Sign Out Everywhere", () -> {
                dialog.dismiss();
                confirmSignOutEverywhere();
            }));
            content.addView(buildAccountActionRow("Sign Out (this device)", () -> {
                // Only clears this device's local session — the backend
                // session row naturally expires (refresh token TTL) rather
                // than being revoked immediately. Use "Sign Out Everywhere"
                // to force every session to end right now instead.
                authToken = "";
                refreshToken = "";
                authEmail = "";
                accessTokenExpiresAt = 0;
                securePrefs.edit().remove("auth_token").remove("refresh_token")
                        .remove("auth_email").remove("auth_access_expires_at").apply();
                dialog.dismiss();
                showFullPage(buildSettingsView());
            }));

            dialog.show();
            return;
        }

        if (backendUrl.isEmpty()) {
            Toast.makeText(this, "Set your Backend Server URL first", Toast.LENGTH_LONG).show();
            return;
        }

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(32, 16, 32, 16);

        EditText emailInput = new EditText(this);
        emailInput.setHint("Email");
        emailInput.setTextColor(getColor(R.color.text_primary));
        emailInput.setHintTextColor(getColor(R.color.text_dim));
        form.addView(emailInput);

        EditText passInput = new EditText(this);
        passInput.setHint("Password (8+ characters)");
        passInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        passInput.setTextColor(getColor(R.color.text_primary));
        passInput.setHintTextColor(getColor(R.color.text_dim));
        form.addView(passInput);

        AlertDialog dialog = new AccentDialogBuilder(this)
                .setTitle("Sign In / Register")
                .setView(form)
                .setPositiveButton("Login", (d, w) ->
                        callAuth("/auth/login", emailInput.getText().toString().trim(), passInput.getText().toString()))
                .setNeutralButton("Register", (d, w) ->
                        callAuth("/auth/register", emailInput.getText().toString().trim(), passInput.getText().toString()))
                .setNegativeButton("Cancel", null)
                .create();

        // ---- Google Sign-In — an alternative path below the existing
        // email/password fields, not a replacement. The 3 AlertDialog
        // buttons above stay exactly as they were. ----
        View divider = new View(this);
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 2);
        dividerParams.topMargin = 28;
        dividerParams.bottomMargin = 16;
        divider.setLayoutParams(dividerParams);
        divider.setBackgroundColor(getColor(R.color.text_dim));
        form.addView(divider);

        TextView googleBtn = new TextView(this);
        googleBtn.setText("Sign in with Google");
        googleBtn.setTextColor(getColor(R.color.text_primary));
        googleBtn.setTextSize(14);
        googleBtn.setGravity(android.view.Gravity.CENTER);
        googleBtn.setPadding(24, 24, 24, 24);
        googleBtn.setBackgroundResource(R.drawable.bg_tab_inactive);
        googleBtn.setOnClickListener(v -> {
            dialog.dismiss();
            signInWithGoogle();
        });
        form.addView(googleBtn);

        boolean googleConfigured = !prefs.getString("google_client_id", "").isEmpty();
        TextView googleIdRow = new TextView(this);
        googleIdRow.setText(googleConfigured ? "Google Client ID: configured (tap to change)" : "Set Google Client ID first ›");
        googleIdRow.setTextColor(getColor(R.color.text_dim));
        googleIdRow.setTextSize(11);
        googleIdRow.setGravity(android.view.Gravity.CENTER);
        googleIdRow.setPadding(16, 14, 16, 0);
        googleIdRow.setOnClickListener(v -> {
            dialog.dismiss();
            showGoogleClientIdDialog();
        });
        form.addView(googleIdRow);

        TextView forgotPasswordRow = new TextView(this);
        forgotPasswordRow.setText("Forgot Password?");
        forgotPasswordRow.setTextColor(getColor(R.color.text_dim));
        forgotPasswordRow.setTextSize(11);
        forgotPasswordRow.setGravity(android.view.Gravity.CENTER);
        forgotPasswordRow.setPadding(16, 20, 16, 0);
        forgotPasswordRow.setOnClickListener(v -> {
            dialog.dismiss();
            showForgotPasswordDialog();
        });
        form.addView(forgotPasswordRow);

        dialog.show();
    }

    // ---- The Web Client ID (OAuth 2.0 "Web application" client, from
    // Google Cloud Console) that Credential Manager needs to request a
    // verifiable Google ID token. This is tied to the user's own project +
    // signing key SHA-1, so — same as the Firebase project earlier — it
    // can't be generated on their behalf; they set it once here. ----
    // ================================================================
    // DATA EXPORT (#38) — everything the user has saved on THIS device,
    // as one downloadable file. Bookmarks/history/shortcuts/downloads
    // metadata are safe to include by default. Saved passwords are
    // opt-in behind an explicit warning, since exporting them means they
    // exist as plain, readable text in a file once downloaded — same
    // tradeoff real browsers' own "export passwords" features have.
    // ================================================================
    private void showExportDataDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(32, 16, 32, 16);

        List<SavedCredential> creds = loadCredentials();
        android.widget.CheckBox includePasswordsBox = new android.widget.CheckBox(this);
        includePasswordsBox.setText("Include saved passwords (" + creds.size() + ")");
        includePasswordsBox.setTextColor(getColor(R.color.text_primary));
        includePasswordsBox.setChecked(false);
        form.addView(includePasswordsBox);

        TextView warning = new TextView(this);
        warning.setText("⚠️ If checked, passwords will be plain, readable text inside the exported file — anyone who opens that file can read them. Leave unchecked unless you specifically need this.");
        warning.setTextColor(ThemeManager.getAccentColor(this));
        warning.setTextSize(10);
        LinearLayout.LayoutParams warningParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        warningParams.topMargin = 8;
        warning.setLayoutParams(warningParams);
        form.addView(warning);

        new AccentDialogBuilder(this)
                .setTitle("Export My Data")
                .setMessage("Everything you've saved on this device — bookmarks, history, shortcuts, download history — as one file you can keep.")
                .setView(form)
                .setPositiveButton("Export", (d, w) -> exportUserData(includePasswordsBox.isChecked()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void exportUserData(boolean includePasswords) {
        networkExecutor.execute(() -> {
            try {
                JSONObject export = new JSONObject();
                export.put("exported_at", System.currentTimeMillis());
                export.put("account_email", authEmail);

                JSONArray bookmarksArr = new JSONArray();
                for (JSONObject b : loadBookmarks()) bookmarksArr.put(b);
                export.put("bookmarks", bookmarksArr);

                export.put("history", new JSONArray(prefs.getString("history", "[]")));

                JSONArray shortcutsArr = new JSONArray();
                for (Shortcut s : shortcuts) {
                    JSONObject o = new JSONObject();
                    o.put("name", s.name);
                    o.put("url", s.url);
                    o.put("color", s.color);
                    shortcutsArr.put(o);
                }
                export.put("shortcuts", shortcutsArr);

                JSONArray downloadsArr = new JSONArray();
                for (NexDownload dl : loadNexDownloads()) {
                    JSONObject o = new JSONObject();
                    o.put("fileName", dl.fileName);
                    o.put("url", dl.url);
                    o.put("status", dl.status);
                    o.put("createdAt", dl.createdAt);
                    downloadsArr.put(o);
                }
                export.put("downloads", downloadsArr);

                if (includePasswords) {
                    JSONArray passwordsArr = new JSONArray();
                    for (SavedCredential c : loadCredentials()) {
                        JSONObject o = new JSONObject();
                        o.put("domain", c.domain);
                        o.put("username", c.username);
                        o.put("password", c.password);
                        passwordsArr.put(o);
                    }
                    export.put("passwords", passwordsArr);
                } else {
                    export.put("passwords_note", "Not included — re-export with the password checkbox on if you need them.");
                }

                String fileName = "nex_browser_data_" + System.currentTimeMillis() + ".json";
                byte[] bytes = export.toString(2).getBytes(StandardCharsets.UTF_8);

                Uri savedUri;
                if (Build.VERSION.SDK_INT >= 29) {
                    android.content.ContentValues values = new android.content.ContentValues();
                    values.put(android.provider.MediaStore.Downloads.DISPLAY_NAME, fileName);
                    values.put(android.provider.MediaStore.Downloads.MIME_TYPE, "application/json");
                    values.put(android.provider.MediaStore.Downloads.IS_PENDING, 1);
                    savedUri = getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (savedUri == null) throw new Exception("Could not create a Downloads entry");
                    try (OutputStream out = getContentResolver().openOutputStream(savedUri)) {
                        out.write(bytes);
                    }
                    android.content.ContentValues done = new android.content.ContentValues();
                    done.put(android.provider.MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(savedUri, done, null, null);
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists()) dir.mkdirs();
                    File destFile = new File(dir, fileName);
                    try (FileOutputStream out = new FileOutputStream(destFile)) {
                        out.write(bytes);
                    }
                    android.media.MediaScannerConnection.scanFile(this, new String[]{destFile.getAbsolutePath()}, null, null);
                }

                mainHandler.post(() -> Toast.makeText(this, "Exported to Downloads: " + fileName, Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                mainHandler.post(() -> Toast.makeText(this, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // ---- Data Delete (#38, second half) — irreversible: wipes the
    // account and everything tied to it on the backend (bookmarks,
    // history, vault, automation jobs, device tokens, sessions). Local
    // data on THIS device (passwords, bookmarks, etc. saved here) is
    // untouched — that's a separate, deliberate choice so deleting the
    // cloud copy doesn't also silently wipe what's sitting on the phone;
    // use "Clear Records" / individual delete buttons for that. ----
    private void showDeleteAccountDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(32, 16, 32, 16);

        EditText confirmInput = new EditText(this);
        confirmInput.setHint("Account password (or Recovery Code)");
        confirmInput.setTextColor(getColor(R.color.text_primary));
        confirmInput.setHintTextColor(getColor(R.color.text_dim));
        form.addView(confirmInput);

        new AccentDialogBuilder(this)
                .setTitle("Delete Account & All Data")
                .setMessage("This permanently deletes your account and everything backed up to it — bookmarks, history, passwords, automation history, all of it. This CANNOT be undone. Data saved locally on this device is not affected.")
                .setView(form)
                .setPositiveButton("Delete Everything", (d, w) -> {
                    String confirmValue = confirmInput.getText().toString().trim();
                    if (confirmValue.isEmpty()) {
                        Toast.makeText(this, "Enter your password or recovery code to confirm", Toast.LENGTH_LONG).show();
                        return;
                    }
                    confirmDeleteAccount(confirmValue);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void confirmDeleteAccount(String confirmValue) {
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                // Recovery codes always contain a "-"; a plain password
                // essentially never will, in practice — good enough to
                // route to the right field without asking the user to
                // pick which one they're entering.
                if (confirmValue.contains("-")) {
                    body.put("recovery_code", confirmValue);
                } else {
                    body.put("password", confirmValue);
                }

                URL url = new URL(backendUrl + "/auth/account");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("DELETE");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Authorization", "Bearer " + authToken);
                conn.setDoOutput(true);
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(15000);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }
                int code = conn.getResponseCode();
                conn.disconnect();

                if (code >= 200 && code < 300) {
                    authToken = "";
                    refreshToken = "";
                    authEmail = "";
                    accessTokenExpiresAt = 0;
                    securePrefs.edit().remove("auth_token").remove("refresh_token")
                            .remove("auth_email").remove("auth_access_expires_at").apply();
                    mainHandler.post(() -> {
                        Toast.makeText(this, "Account and all backed-up data deleted", Toast.LENGTH_LONG).show();
                        showFullPage(buildSettingsView());
                    });
                } else {
                    mainHandler.post(() -> Toast.makeText(this, "Couldn't delete account — check your password/recovery code", Toast.LENGTH_LONG).show());
                }
            } catch (Exception e) {
                mainHandler.post(() -> Toast.makeText(this, "Delete failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // ================================================================
    // BIOMETRIC VAULT LOCK (#34) + VAULT AUTO-LOCK (#35) — when enabled,
    // opening Passwords requires a fingerprint/face/PIN prompt. Auto-locks
    // on leaving the app (onPause) and after VAULT_AUTO_LOCK_MS idle even
    // while the app stays foregrounded (e.g. sitting on another screen).
    // Falls through WITHOUT a prompt if the device has no screen lock/
    // biometric enrolled at all — the point is an extra check, not
    // locking the user out of their own passwords when the OS itself
    // can't offer one.
    // ================================================================
    private void showPasswordsScreenGated() {
        if (!biometricLockEnabled) {
            showFullPage(buildPasswordsView());
            return;
        }
        long now = System.currentTimeMillis();
        if (vaultUnlockedAt != 0 && now - vaultUnlockedAt < VAULT_AUTO_LOCK_MS) {
            showFullPage(buildPasswordsView());
            return;
        }
        requestBiometricUnlock(() -> {
            vaultUnlockedAt = System.currentTimeMillis();
            showFullPage(buildPasswordsView());
        });
    }

    private void requestBiometricUnlock(Runnable onSuccess) {
        BiometricManager biometricManager = BiometricManager.from(this);
        int canAuth = biometricManager.canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_WEAK | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "No screen lock set up on this device — showing passwords without a biometric check", Toast.LENGTH_LONG).show();
            onSuccess.run();
            return;
        }

        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt biometricPrompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                onSuccess.run();
            }

            @Override
            public void onAuthenticationError(int errorCode, CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                Toast.makeText(MainActivity.this, "Unlock cancelled", Toast.LENGTH_SHORT).show();
            }
        });

        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock Passwords")
                .setSubtitle("Confirm it's you to view saved passwords")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK | BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                .build();

        biometricPrompt.authenticate(promptInfo);
    }

    private void toggleBiometricLock() {
        biometricLockEnabled = !biometricLockEnabled;
        prefs.edit().putBoolean("biometric_lock_enabled", biometricLockEnabled).apply();
        vaultUnlockedAt = 0;
        Toast.makeText(this, "Biometric Vault Lock " + (biometricLockEnabled ? "ON" : "OFF"), Toast.LENGTH_SHORT).show();
    }

    // ---- A tappable row inside the Account dialog's custom view ----
    private TextView buildAccountActionRow(String label, Runnable action) {
        TextView row = new TextView(this);
        row.setText(label);
        row.setTextColor(getColor(R.color.gold));
        row.setTextSize(12.5f);
        row.setPadding(12, 20, 12, 20);
        row.setBackgroundResource(R.drawable.bg_tab_inactive);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = 8;
        row.setLayoutParams(p);
        row.setOnClickListener(v -> action.run());
        return row;
    }

    // ---- Sign Out Everywhere (#23): ends every OTHER session immediately
    // (this device stays signed in) — for "someone else has my account
    // open somewhere and I want them out right now". ----
    // ---- Autopilot API Key ----
    // The user's OWN key for whichever provider they pick (Gemini/OpenAI/
    // Anthropic) — never a key this app ships with, never shared across
    // users. Stored server-side per-account so it doesn't need re-entering
    // per device; only a masked preview ever comes back down. Multiple
    // keys can be saved at once (one per provider) — each key has its
    // own 3 feature toggles (Task Planning / Autopilot / Visual
    // Understanding), and turning a toggle ON for one key turns that
    // same feature OFF for every other key (enforced server-side), so
    // it's always unambiguous which key a feature actually uses.
    private static final String[] AUTOPILOT_PROVIDERS = {"gemini", "openai", "anthropic"};
    private static final String[] AUTOPILOT_PROVIDER_LABELS = {"Google Gemini", "OpenAI (GPT)", "Anthropic (Claude)"};
    private static final String[] AUTOPILOT_PROVIDER_KEY_LINKS = {
            "Free key: aistudio.google.com → Get API key",
            "platform.openai.com → API keys (paid)",
            "console.anthropic.com → API keys (paid)",
    };
    private final List<JSONObject> aiKeysCache = new ArrayList<>();

    // ---- Custom APIs (Settings → 🔌 Custom APIs) ----
    // Generic version of the AI Keys screen above, but for ANY third-party
    // API the user wants Nex Browser to be able to call — not just
    // Gemini/OpenAI/Anthropic. Each saved entry has a free-text name, a
    // base URL, an API key, and where that key gets attached (a header
    // like "Authorization: Bearer <key>", or a URL query param like
    // "?apikey=<key>" — some public APIs need the query-param style).
    // Stored server-side per-account (same as ai_keys), so a key added on
    // one device is immediately usable from any other signed-in device —
    // that cross-device part is the whole point, not local-only storage.
    private final List<JSONObject> customApisCache = new ArrayList<>();

    private String labelForProvider(String provider) {
        for (int i = 0; i < AUTOPILOT_PROVIDERS.length; i++) {
            if (AUTOPILOT_PROVIDERS[i].equals(provider)) return AUTOPILOT_PROVIDER_LABELS[i];
        }
        return "Unknown";
    }

    private void showAiKeyDialog() {
        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            Toast.makeText(this, "Sign in first (Settings → Account)", Toast.LENGTH_LONG).show();
            return;
        }
        showFullPage(buildAiKeysView());
    }

    private View buildAiKeysView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("AI Keys", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(24, 16, 24, 24);
        scroll.addView(content);
        root.addView(scroll);

        TextView hint = new TextView(this);
        hint.setText("Add one key per provider. Tap Edit on a key to choose which features use it — Task Planning, Autopilot, or Visual Understanding.");
        hint.setTextColor(getColor(R.color.text_dim));
        hint.setTextSize(10);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hintParams.bottomMargin = 16;
        hint.setLayoutParams(hintParams);
        content.addView(hint);

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        content.addView(list);

        if (aiKeysCache.isEmpty()) {
            list.addView(buildEmptyState("No AI keys added yet"));
        } else {
            for (JSONObject key : aiKeysCache) list.addView(buildAiKeyCard(key));
        }

        TextView addBtn = new TextView(this);
        addBtn.setText("+ Add Key");
        addBtn.setTextColor(getColor(R.color.gold));
        addBtn.setTextSize(11);
        addBtn.setGravity(android.view.Gravity.CENTER);
        addBtn.setPadding(20, 16, 20, 16);
        addBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams addBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        addBtnParams.topMargin = 16;
        addBtn.setLayoutParams(addBtnParams);
        addBtn.setOnClickListener(v -> showAddAiKeyDialog());
        content.addView(addBtn);

        refreshAiKeys(() -> {
            if (isPageShown) showFullPage(buildAiKeysView());
        });

        return root;
    }

    // Agent Permission Firewall (#79) settings screen — mode toggle
    // (Off/Whitelist/Blacklist) plus a simple add/remove domain list.
    // Edits agentFirewallMode/agentFirewallDomains in place, then Save
    // pushes the snapshot to the backend.
    private View buildAgentFirewallView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("Agent Firewall", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(32, 24, 32, 24);
        content.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView desc = new TextView(this);
        desc.setText("Controls which domains Automation tasks are allowed to navigate to — checked before every AI-directed navigation, plus clicks and redirects.");
        desc.setTextColor(getColor(R.color.text_dim));
        desc.setTextSize(10);
        content.addView(desc);

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams modeRowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        modeRowParams.topMargin = 16;
        modeRow.setLayoutParams(modeRowParams);
        content.addView(modeRow);

        String[] modes = {"off", "whitelist", "blacklist"};
        String[] modeLabels = {"Off", "Whitelist", "Blacklist"};
        TextView[] modeBtns = new TextView[3];
        for (int i = 0; i < 3; i++) {
            TextView btn = new TextView(this);
            btn.setText(modeLabels[i]);
            btn.setTextSize(11);
            btn.setGravity(android.view.Gravity.CENTER);
            btn.setPadding(16, 16, 16, 16);
            LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            btnParams.setMarginEnd(8);
            btn.setLayoutParams(btnParams);
            btn.setBackgroundResource(R.drawable.bg_toolbar_btn);
            modeBtns[i] = btn;
            modeRow.addView(btn);
        }
        Runnable refreshModeColors = () -> {
            for (int i = 0; i < 3; i++) {
                modeBtns[i].setTextColor(getColor(modes[i].equals(agentFirewallMode) ? R.color.gold : R.color.text_dim));
            }
        };
        refreshModeColors.run();
        for (int i = 0; i < 3; i++) {
            int idx = i;
            modeBtns[i].setOnClickListener(v -> {
                agentFirewallMode = modes[idx];
                refreshModeColors.run();
            });
        }

        EditText domainInput = new EditText(this);
        domainInput.setHint("example.com");
        domainInput.setTextColor(getColor(R.color.text_primary));
        domainInput.setHintTextColor(getColor(R.color.text_dim));
        LinearLayout.LayoutParams domainInputParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        domainInputParams.topMargin = 20;
        domainInput.setLayoutParams(domainInputParams);
        content.addView(domainInput);

        LinearLayout domainListContainer = new LinearLayout(this);
        domainListContainer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams domainListParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        domainListParams.topMargin = 12;
        domainListContainer.setLayoutParams(domainListParams);
        content.addView(domainListContainer);

        Runnable[] refreshDomainList = new Runnable[1];
        refreshDomainList[0] = () -> {
            domainListContainer.removeAllViews();
            for (String d : new ArrayList<>(agentFirewallDomains)) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(android.view.Gravity.CENTER_VERTICAL);
                TextView dText = new TextView(this);
                dText.setText(d);
                dText.setTextColor(getColor(R.color.text_primary));
                dText.setTextSize(11);
                dText.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                row.addView(dText);
                TextView removeBtn = new TextView(this);
                removeBtn.setText("✕");
                removeBtn.setTextColor(getColor(R.color.text_dim));
                removeBtn.setPadding(16, 8, 16, 8);
                removeBtn.setOnClickListener(v -> {
                    agentFirewallDomains.remove(d);
                    refreshDomainList[0].run();
                });
                row.addView(removeBtn);
                domainListContainer.addView(row);
            }
        };
        refreshDomainList[0].run();

        TextView addDomainBtn = new TextView(this);
        addDomainBtn.setText("+ Add Domain");
        addDomainBtn.setTextColor(getColor(R.color.gold));
        addDomainBtn.setTextSize(11);
        addDomainBtn.setPadding(16, 16, 16, 16);
        LinearLayout.LayoutParams addDomainBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        addDomainBtnParams.topMargin = 8;
        addDomainBtn.setLayoutParams(addDomainBtnParams);
        addDomainBtn.setOnClickListener(v -> {
            String d = domainInput.getText().toString().trim().toLowerCase(java.util.Locale.US);
            if (!d.isEmpty() && !agentFirewallDomains.contains(d)) {
                agentFirewallDomains.add(d);
                domainInput.setText("");
                refreshDomainList[0].run();
            }
        });
        content.addView(addDomainBtn);

        TextView saveBtn = new TextView(this);
        saveBtn.setText("Save Firewall Settings");
        saveBtn.setTextColor(getColor(R.color.gold));
        saveBtn.setTextSize(12);
        saveBtn.setGravity(android.view.Gravity.CENTER);
        saveBtn.setPadding(20, 20, 20, 20);
        saveBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams saveBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        saveBtnParams.topMargin = 24;
        saveBtnParams.bottomMargin = 20;
        saveBtn.setLayoutParams(saveBtnParams);
        saveBtn.setOnClickListener(v -> saveAgentFirewallConfig());
        content.addView(saveBtn);

        scroll.addView(content);
        root.addView(scroll);
        return root;
    }

    private void saveAgentFirewallConfig() {
        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            Toast.makeText(this, "Sign in first (Settings)", Toast.LENGTH_LONG).show();
            return;
        }
        String modeSnapshot = agentFirewallMode;
        List<String> domainsSnapshot = new ArrayList<>(agentFirewallDomains);
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("mode", modeSnapshot);
                JSONArray arr = new JSONArray();
                for (String d : domainsSnapshot) arr.put(d);
                body.put("domains", arr);
                httpPostJson(backendUrl + "/agent/firewall", body, authToken);
                mainHandler.post(() -> Toast.makeText(this, "Firewall settings saved", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                mainHandler.post(() -> Toast.makeText(this, "Couldn't save: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // Agent Policy Engine (#80) settings screen — custom keyword list
    // (extends Human Approval Layer's hardcoded list, #78) plus two
    // global overrides applied across every job.
    private View buildAgentPolicyView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("Agent Policy", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(32, 24, 32, 24);
        content.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView desc = new TextView(this);
        desc.setText("Global rules applied across every Automation task, on top of each task's own checkboxes.");
        desc.setTextColor(getColor(R.color.text_dim));
        desc.setTextSize(10);
        content.addView(desc);

        TextView kwLabel = new TextView(this);
        kwLabel.setText("Extra sensitive-action keywords (added to the built-in list: buy, pay, delete, send, checkout…)");
        kwLabel.setTextColor(getColor(R.color.text_dim));
        kwLabel.setTextSize(9.5f);
        LinearLayout.LayoutParams kwLabelParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        kwLabelParams.topMargin = 20;
        kwLabel.setLayoutParams(kwLabelParams);
        content.addView(kwLabel);

        EditText kwInput = new EditText(this);
        kwInput.setHint("e.g. \"renew lease\"");
        kwInput.setTextColor(getColor(R.color.text_primary));
        kwInput.setHintTextColor(getColor(R.color.text_dim));
        LinearLayout.LayoutParams kwInputParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        kwInputParams.topMargin = 8;
        kwInput.setLayoutParams(kwInputParams);
        content.addView(kwInput);

        LinearLayout kwListContainer = new LinearLayout(this);
        kwListContainer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams kwListParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        kwListParams.topMargin = 12;
        kwListContainer.setLayoutParams(kwListParams);
        content.addView(kwListContainer);

        Runnable[] refreshKwList = new Runnable[1];
        refreshKwList[0] = () -> {
            kwListContainer.removeAllViews();
            for (String kw : new ArrayList<>(agentPolicyCustomKeywords)) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(android.view.Gravity.CENTER_VERTICAL);
                TextView kwText = new TextView(this);
                kwText.setText(kw);
                kwText.setTextColor(getColor(R.color.text_primary));
                kwText.setTextSize(11);
                kwText.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                row.addView(kwText);
                TextView removeBtn = new TextView(this);
                removeBtn.setText("✕");
                removeBtn.setTextColor(getColor(R.color.text_dim));
                removeBtn.setPadding(16, 8, 16, 8);
                removeBtn.setOnClickListener(v -> {
                    agentPolicyCustomKeywords.remove(kw);
                    refreshKwList[0].run();
                });
                row.addView(removeBtn);
                kwListContainer.addView(row);
            }
        };
        refreshKwList[0].run();

        TextView addKwBtn = new TextView(this);
        addKwBtn.setText("+ Add Keyword");
        addKwBtn.setTextColor(getColor(R.color.gold));
        addKwBtn.setTextSize(11);
        addKwBtn.setPadding(16, 16, 16, 16);
        LinearLayout.LayoutParams addKwBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        addKwBtnParams.topMargin = 8;
        addKwBtn.setLayoutParams(addKwBtnParams);
        addKwBtn.setOnClickListener(v -> {
            String kw = kwInput.getText().toString().trim().toLowerCase(java.util.Locale.US);
            if (!kw.isEmpty() && !agentPolicyCustomKeywords.contains(kw)) {
                agentPolicyCustomKeywords.add(kw);
                kwInput.setText("");
                refreshKwList[0].run();
            }
        });
        content.addView(addKwBtn);

        android.widget.CheckBox alwaysApproveCheck = new android.widget.CheckBox(this);
        alwaysApproveCheck.setText("🔔 Always require approval for sensitive actions (every task, regardless of its own checkbox)");
        alwaysApproveCheck.setTextColor(getColor(R.color.text_dim));
        alwaysApproveCheck.setTextSize(9.5f);
        alwaysApproveCheck.setChecked(agentPolicyAlwaysRequireApproval);
        LinearLayout.LayoutParams alwaysApproveParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        alwaysApproveParams.topMargin = 24;
        alwaysApproveCheck.setLayoutParams(alwaysApproveParams);
        alwaysApproveCheck.setOnCheckedChangeListener((btn, checked) -> agentPolicyAlwaysRequireApproval = checked);
        content.addView(alwaysApproveCheck);

        TextView maxStepsLabel = new TextView(this);
        maxStepsLabel.setText("Max steps per job (0 = no extra limit beyond each mode's own cap)");
        maxStepsLabel.setTextColor(getColor(R.color.text_dim));
        maxStepsLabel.setTextSize(9.5f);
        LinearLayout.LayoutParams maxStepsLabelParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        maxStepsLabelParams.topMargin = 20;
        maxStepsLabel.setLayoutParams(maxStepsLabelParams);
        content.addView(maxStepsLabel);

        EditText maxStepsInput = new EditText(this);
        maxStepsInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        maxStepsInput.setText(agentPolicyMaxStepsPerJob > 0 ? String.valueOf(agentPolicyMaxStepsPerJob) : "");
        maxStepsInput.setHint("e.g. 15");
        maxStepsInput.setTextColor(getColor(R.color.text_primary));
        maxStepsInput.setHintTextColor(getColor(R.color.text_dim));
        LinearLayout.LayoutParams maxStepsInputParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        maxStepsInputParams.topMargin = 8;
        maxStepsInput.setLayoutParams(maxStepsInputParams);
        content.addView(maxStepsInput);

        TextView saveBtn = new TextView(this);
        saveBtn.setText("Save Policy Settings");
        saveBtn.setTextColor(getColor(R.color.gold));
        saveBtn.setTextSize(12);
        saveBtn.setGravity(android.view.Gravity.CENTER);
        saveBtn.setPadding(20, 20, 20, 20);
        saveBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams saveBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        saveBtnParams.topMargin = 24;
        saveBtnParams.bottomMargin = 20;
        saveBtn.setLayoutParams(saveBtnParams);
        saveBtn.setOnClickListener(v -> {
            int parsedMax = 0;
            try { parsedMax = Integer.parseInt(maxStepsInput.getText().toString().trim()); } catch (Exception ignored) {}
            agentPolicyMaxStepsPerJob = Math.max(parsedMax, 0);
            saveAgentPolicyConfig();
        });
        content.addView(saveBtn);

        scroll.addView(content);
        root.addView(scroll);
        return root;
    }

    private void saveAgentPolicyConfig() {
        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            Toast.makeText(this, "Sign in first (Settings)", Toast.LENGTH_LONG).show();
            return;
        }
        List<String> keywordsSnapshot = new ArrayList<>(agentPolicyCustomKeywords);
        boolean alwaysApproveSnapshot = agentPolicyAlwaysRequireApproval;
        int maxStepsSnapshot = agentPolicyMaxStepsPerJob;
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                JSONArray arr = new JSONArray();
                for (String kw : keywordsSnapshot) arr.put(kw);
                body.put("custom_keywords", arr);
                body.put("always_require_approval", alwaysApproveSnapshot);
                if (maxStepsSnapshot > 0) body.put("max_steps_per_job", maxStepsSnapshot);
                httpPostJson(backendUrl + "/agent/policy", body, authToken);
                mainHandler.post(() -> Toast.makeText(this, "Policy settings saved", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                mainHandler.post(() -> Toast.makeText(this, "Couldn't save: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private View buildAiKeyCard(JSONObject key) {
        String provider = key.optString("provider", "");
        String masked = key.optString("masked", "");
        boolean forPlanning = key.optBoolean("use_for_planning", false);
        boolean forAutopilot = key.optBoolean("use_for_autopilot", false);
        boolean forVisual = key.optBoolean("use_for_visual", false);
        boolean forForms = key.optBoolean("use_for_forms", false);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(20, 20, 20, 20);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.bottomMargin = 12;
        card.setLayoutParams(cardParams);
        card.setBackgroundResource(R.drawable.bg_tab_inactive);

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(android.view.Gravity.CENTER_VERTICAL);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleColParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleColParams.weight = 1;
        titleCol.setLayoutParams(titleColParams);

        TextView titleView = new TextView(this);
        titleView.setText(labelForProvider(provider));
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(12);
        titleCol.addView(titleView);

        TextView maskedView = new TextView(this);
        maskedView.setText(masked);
        maskedView.setTextColor(getColor(R.color.text_dim));
        maskedView.setTextSize(8.5f);
        LinearLayout.LayoutParams maskedParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        maskedParams.topMargin = 2;
        maskedView.setLayoutParams(maskedParams);
        titleCol.addView(maskedView);

        topRow.addView(titleCol);

        TextView editBtn = new TextView(this);
        editBtn.setText("Edit");
        editBtn.setTextColor(getColor(R.color.gold));
        editBtn.setTextSize(11);
        editBtn.setPadding(20, 12, 20, 12);
        editBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        editBtn.setOnClickListener(v -> showEditAiKeyDialog(key));
        topRow.addView(editBtn);

        card.addView(topRow);

        List<String> activeFor = new ArrayList<>();
        if (forPlanning) activeFor.add("Task Planning");
        if (forAutopilot) activeFor.add("Autopilot");
        if (forVisual) activeFor.add("Visual Understanding");
        if (forForms) activeFor.add("Form Filling");

        TextView usageView = new TextView(this);
        usageView.setText(activeFor.isEmpty() ? "Not used by any feature yet" : "Active for: " + String.join(", ", activeFor));
        usageView.setTextColor(activeFor.isEmpty() ? getColor(R.color.text_dim) : getColor(R.color.gold));
        usageView.setTextSize(8.5f);
        LinearLayout.LayoutParams usageParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        usageParams.topMargin = 8;
        usageView.setLayoutParams(usageParams);
        card.addView(usageView);

        return card;
    }

    private void showAddAiKeyDialog() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(32, 16, 32, 8);

        TextView providerLabel = new TextView(this);
        providerLabel.setText("Provider");
        providerLabel.setTextColor(getColor(R.color.text_dim));
        providerLabel.setTextSize(9);
        wrap.addView(providerLabel);

        android.widget.Spinner providerSpinner = new android.widget.Spinner(this);
        android.widget.ArrayAdapter<String> adapter = new android.widget.ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, AUTOPILOT_PROVIDER_LABELS);
        providerSpinner.setAdapter(adapter);
        LinearLayout.LayoutParams spinnerParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        spinnerParams.topMargin = 4;
        providerSpinner.setLayoutParams(spinnerParams);
        wrap.addView(providerSpinner);

        TextView linkHint = new TextView(this);
        linkHint.setText(AUTOPILOT_PROVIDER_KEY_LINKS[0]);
        linkHint.setTextColor(getColor(R.color.gold));
        linkHint.setTextSize(9.5f);
        LinearLayout.LayoutParams linkParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        linkParams.topMargin = 6;
        linkParams.bottomMargin = 16;
        linkHint.setLayoutParams(linkParams);
        wrap.addView(linkHint);

        providerSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                linkHint.setText(AUTOPILOT_PROVIDER_KEY_LINKS[position]);
            }
            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        EditText keyInput = new EditText(this);
        keyInput.setHint("Paste your API key");
        keyInput.setTextColor(getColor(R.color.text_primary));
        keyInput.setHintTextColor(getColor(R.color.text_dim));
        keyInput.setSingleLine(true);
        keyInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        wrap.addView(keyInput);

        new AccentDialogBuilder(this)
                .setTitle("Add AI Key")
                .setView(wrap)
                .setPositiveButton("Save", (d, w) -> {
                    String key = keyInput.getText().toString().trim();
                    if (key.isEmpty()) {
                        Toast.makeText(this, "Paste a key first", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    String selectedProvider = AUTOPILOT_PROVIDERS[providerSpinner.getSelectedItemPosition()];
                    saveAiKey(selectedProvider, key);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showEditAiKeyDialog(JSONObject key) {
        String provider = key.optString("provider", "");

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(32, 16, 32, 8);

        TextView info = new TextView(this);
        info.setText("Turning one of these on for " + labelForProvider(provider) + " turns it off for any other key.");
        info.setTextColor(getColor(R.color.text_dim));
        info.setTextSize(9.5f);
        LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        infoParams.bottomMargin = 12;
        info.setLayoutParams(infoParams);
        wrap.addView(info);

        android.widget.CheckBox planningCheck = new android.widget.CheckBox(this);
        planningCheck.setText("Task Planning (turns tasks into steps)");
        planningCheck.setTextColor(getColor(R.color.text_primary));
        planningCheck.setChecked(key.optBoolean("use_for_planning", false));
        wrap.addView(planningCheck);

        android.widget.CheckBox autopilotCheck = new android.widget.CheckBox(this);
        autopilotCheck.setText("Autopilot");
        autopilotCheck.setTextColor(getColor(R.color.text_primary));
        autopilotCheck.setChecked(key.optBoolean("use_for_autopilot", false));
        wrap.addView(autopilotCheck);

        android.widget.CheckBox visualCheck = new android.widget.CheckBox(this);
        visualCheck.setText("Visual Understanding");
        visualCheck.setTextColor(getColor(R.color.text_primary));
        visualCheck.setChecked(key.optBoolean("use_for_visual", false));
        wrap.addView(visualCheck);

        android.widget.CheckBox formsCheck = new android.widget.CheckBox(this);
        formsCheck.setText("Form Filling");
        formsCheck.setTextColor(getColor(R.color.text_primary));
        formsCheck.setChecked(key.optBoolean("use_for_forms", false));
        wrap.addView(formsCheck);

        new AccentDialogBuilder(this)
                .setTitle(labelForProvider(provider))
                .setView(wrap)
                .setPositiveButton("Save", (d, w) -> saveAiKeyFlags(
                        provider, planningCheck.isChecked(), autopilotCheck.isChecked(),
                        visualCheck.isChecked(), formsCheck.isChecked()))
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Remove Key", (d, w) -> removeAiKey(provider))
                .show();
    }

    private void refreshAiKeys(Runnable onDone) {
        if (backendUrl.isEmpty() || authToken.isEmpty()) return;
        networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(backendUrl + "/account/ai-keys", authToken);
                JSONArray keys = resp.optJSONArray("keys");
                aiKeysCache.clear();
                if (keys != null) {
                    for (int i = 0; i < keys.length(); i++) aiKeysCache.add(keys.getJSONObject(i));
                }
            } catch (Exception ignored) {}
            mainHandler.post(onDone);
        });
    }

    private void saveAiKey(String provider, String key) {
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("provider", provider);
                body.put("api_key", key);
                httpPostJson(backendUrl + "/account/ai-keys", body, authToken);
                refreshAiKeys(() -> {
                    if (isPageShown) showFullPage(buildAiKeysView());
                    Toast.makeText(this, "Key saved (" + labelForProvider(provider) + ")", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't save key: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private void saveAiKeyFlags(String provider, boolean forPlanning, boolean forAutopilot, boolean forVisual, boolean forForms) {
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("use_for_planning", forPlanning);
                body.put("use_for_autopilot", forAutopilot);
                body.put("use_for_visual", forVisual);
                body.put("use_for_forms", forForms);
                httpPostJson(backendUrl + "/account/ai-keys/" + provider + "/flags", body, authToken);
                refreshAiKeys(() -> {
                    if (isPageShown) showFullPage(buildAiKeysView());
                    Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't update: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private void removeAiKey(String provider) {
        networkExecutor.execute(() -> {
            try {
                URL url = new URL(backendUrl + "/account/ai-keys/" + provider);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("DELETE");
                conn.setRequestProperty("Authorization", "Bearer " + authToken);
                conn.getResponseCode();
            } catch (Exception ignored) {}
            refreshAiKeys(() -> {
                if (isPageShown) showFullPage(buildAiKeysView());
                Toast.makeText(this, "Key removed", Toast.LENGTH_SHORT).show();
            });
        });
    }

    // ================= Custom APIs (generic, any third-party API) =================

    private void showCustomApisDialog() {
        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            Toast.makeText(this, "Sign in first (Settings → Account)", Toast.LENGTH_LONG).show();
            return;
        }
        showFullPage(buildCustomApisView());
    }

    private View buildCustomApisView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("Custom APIs", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(24, 16, 24, 24);
        scroll.addView(content);
        root.addView(scroll);

        TextView hint = new TextView(this);
        hint.setText("Add any app or service's API here (weather, maps, your own server, anything with a key + base URL). Once saved, tap Test to have Nex Browser call it directly — and the same saved API is usable from any device you're signed in on.");
        hint.setTextColor(getColor(R.color.text_dim));
        hint.setTextSize(10);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hintParams.bottomMargin = 16;
        hint.setLayoutParams(hintParams);
        content.addView(hint);

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        content.addView(list);

        if (customApisCache.isEmpty()) {
            list.addView(buildEmptyState("No custom APIs added yet"));
        } else {
            for (JSONObject api : customApisCache) list.addView(buildCustomApiCard(api));
        }

        TextView addBtn = new TextView(this);
        addBtn.setText("+ Add API");
        addBtn.setTextColor(getColor(R.color.gold));
        addBtn.setTextSize(11);
        addBtn.setGravity(android.view.Gravity.CENTER);
        addBtn.setPadding(20, 16, 20, 16);
        addBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams addBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        addBtnParams.topMargin = 16;
        addBtn.setLayoutParams(addBtnParams);
        addBtn.setOnClickListener(v -> showAddCustomApiDialog());
        content.addView(addBtn);

        refreshCustomApis(() -> {
            if (isPageShown) showFullPage(buildCustomApisView());
        });

        return root;
    }

    private View buildCustomApiCard(JSONObject api) {
        String name = api.optString("name", "");
        String baseUrl = api.optString("base_url", "");
        String masked = api.optString("masked", "");
        String authStyle = api.optString("auth_style", "header");

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(20, 20, 20, 20);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.bottomMargin = 12;
        card.setLayoutParams(cardParams);
        card.setBackgroundResource(R.drawable.bg_tab_inactive);

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(android.view.Gravity.CENTER_VERTICAL);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleColParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleColParams.weight = 1;
        titleCol.setLayoutParams(titleColParams);

        TextView titleView = new TextView(this);
        titleView.setText(name);
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(12);
        titleCol.addView(titleView);

        TextView urlView = new TextView(this);
        urlView.setText(baseUrl);
        urlView.setTextColor(getColor(R.color.text_dim));
        urlView.setTextSize(8.5f);
        urlView.setSingleLine(true);
        urlView.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        LinearLayout.LayoutParams urlParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        urlParams.topMargin = 2;
        urlView.setLayoutParams(urlParams);
        titleCol.addView(urlView);

        TextView maskedView = new TextView(this);
        maskedView.setText("Key: " + masked + "  •  sent via " + (authStyle.equals("query") ? "query param" : "header"));
        maskedView.setTextColor(getColor(R.color.text_dim));
        maskedView.setTextSize(8.5f);
        LinearLayout.LayoutParams maskedParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        maskedParams.topMargin = 2;
        maskedView.setLayoutParams(maskedParams);
        titleCol.addView(maskedView);

        topRow.addView(titleCol);

        TextView editBtn = new TextView(this);
        editBtn.setText("Edit");
        editBtn.setTextColor(getColor(R.color.gold));
        editBtn.setTextSize(11);
        editBtn.setPadding(20, 12, 20, 12);
        editBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        editBtn.setOnClickListener(v -> showEditCustomApiDialog(api));
        topRow.addView(editBtn);

        card.addView(topRow);

        TextView testBtn = new TextView(this);
        testBtn.setText("▶ Test");
        testBtn.setTextColor(getColor(R.color.gold));
        testBtn.setTextSize(11);
        testBtn.setGravity(android.view.Gravity.CENTER);
        testBtn.setPadding(16, 14, 16, 14);
        testBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams testBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        testBtnParams.topMargin = 10;
        testBtn.setLayoutParams(testBtnParams);
        testBtn.setOnClickListener(v -> showTestCustomApiDialog(api));
        card.addView(testBtn);

        return card;
    }

    private void showAddCustomApiDialog() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(32, 16, 32, 8);

        EditText nameInput = new EditText(this);
        nameInput.setHint("Name (e.g. OpenWeather, My Server)");
        nameInput.setTextColor(getColor(R.color.text_primary));
        nameInput.setHintTextColor(getColor(R.color.text_dim));
        nameInput.setSingleLine(true);
        wrap.addView(nameInput);

        EditText urlInput = new EditText(this);
        urlInput.setHint("Base URL (https://api.example.com)");
        urlInput.setTextColor(getColor(R.color.text_primary));
        urlInput.setHintTextColor(getColor(R.color.text_dim));
        urlInput.setSingleLine(true);
        urlInput.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI);
        LinearLayout.LayoutParams urlParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        urlParams.topMargin = 12;
        urlInput.setLayoutParams(urlParams);
        wrap.addView(urlInput);

        EditText keyInput = new EditText(this);
        keyInput.setHint("Paste the API key");
        keyInput.setTextColor(getColor(R.color.text_primary));
        keyInput.setHintTextColor(getColor(R.color.text_dim));
        keyInput.setSingleLine(true);
        keyInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout.LayoutParams keyParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        keyParams.topMargin = 12;
        keyInput.setLayoutParams(keyParams);
        wrap.addView(keyInput);

        TextView authLabel = new TextView(this);
        authLabel.setText("How should the key be sent?");
        authLabel.setTextColor(getColor(R.color.text_dim));
        authLabel.setTextSize(9);
        LinearLayout.LayoutParams authLabelParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        authLabelParams.topMargin = 16;
        authLabel.setLayoutParams(authLabelParams);
        wrap.addView(authLabel);

        String[] authStyles = {"header", "query"};
        String[] authLabels = {"As a header (Authorization: Bearer …)", "As a URL query param (?api_key=…)"};
        android.widget.Spinner authSpinner = new android.widget.Spinner(this);
        android.widget.ArrayAdapter<String> authAdapter = new android.widget.ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, authLabels);
        authSpinner.setAdapter(authAdapter);
        wrap.addView(authSpinner);

        new AccentDialogBuilder(this)
                .setTitle("Add Custom API")
                .setView(wrap)
                .setPositiveButton("Save", (d, w) -> {
                    String name = nameInput.getText().toString().trim();
                    String url = urlInput.getText().toString().trim();
                    String key = keyInput.getText().toString().trim();
                    if (name.isEmpty() || url.isEmpty() || key.isEmpty()) {
                        Toast.makeText(this, "Fill in name, base URL and key", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (!url.startsWith("http://") && !url.startsWith("https://")) {
                        Toast.makeText(this, "Base URL must start with http:// or https://", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    saveCustomApi(name, url, key, authStyles[authSpinner.getSelectedItemPosition()]);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showEditCustomApiDialog(JSONObject api) {
        int id = api.optInt("id", -1);
        String name = api.optString("name", "");

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(32, 16, 32, 8);

        EditText nameInput = new EditText(this);
        nameInput.setHint("Name");
        nameInput.setText(name);
        nameInput.setTextColor(getColor(R.color.text_primary));
        nameInput.setHintTextColor(getColor(R.color.text_dim));
        wrap.addView(nameInput);

        EditText urlInput = new EditText(this);
        urlInput.setHint("Base URL");
        urlInput.setText(api.optString("base_url", ""));
        urlInput.setTextColor(getColor(R.color.text_primary));
        urlInput.setHintTextColor(getColor(R.color.text_dim));
        LinearLayout.LayoutParams urlParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        urlParams.topMargin = 12;
        urlInput.setLayoutParams(urlParams);
        wrap.addView(urlInput);

        EditText keyInput = new EditText(this);
        keyInput.setHint("Leave blank to keep current key");
        keyInput.setTextColor(getColor(R.color.text_primary));
        keyInput.setHintTextColor(getColor(R.color.text_dim));
        keyInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout.LayoutParams keyParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        keyParams.topMargin = 12;
        keyInput.setLayoutParams(keyParams);
        wrap.addView(keyInput);

        new AccentDialogBuilder(this)
                .setTitle("Edit " + name)
                .setView(wrap)
                .setPositiveButton("Save", (d, w) -> updateCustomApi(
                        id, nameInput.getText().toString().trim(),
                        urlInput.getText().toString().trim(),
                        keyInput.getText().toString().trim()))
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Remove", (d, w) -> removeCustomApi(id))
                .show();
    }

    private void showTestCustomApiDialog(JSONObject api) {
        int id = api.optInt("id", -1);
        EditText pathInput = new EditText(this);
        pathInput.setHint("Path to call, e.g. /status (leave blank for base URL)");
        pathInput.setTextColor(getColor(R.color.text_primary));
        pathInput.setHintTextColor(getColor(R.color.text_dim));
        int pad = 32;
        pathInput.setPadding(pad, pad / 2, pad, pad / 2);

        new AccentDialogBuilder(this)
                .setTitle("Test " + api.optString("name", ""))
                .setView(pathInput)
                .setPositiveButton("Call it", (d, w) ->
                        testCustomApi(id, pathInput.getText().toString().trim()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void refreshCustomApis(Runnable onDone) {
        if (backendUrl.isEmpty() || authToken.isEmpty()) return;
        networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(backendUrl + "/account/custom-apis", authToken);
                JSONArray apis = resp.optJSONArray("apis");
                customApisCache.clear();
                if (apis != null) {
                    for (int i = 0; i < apis.length(); i++) customApisCache.add(apis.getJSONObject(i));
                }
            } catch (Exception ignored) {}
            mainHandler.post(onDone);
        });
    }

    private void saveCustomApi(String name, String baseUrl, String key, String authStyle) {
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("name", name);
                body.put("base_url", baseUrl);
                body.put("api_key", key);
                body.put("auth_style", authStyle);
                httpPostJson(backendUrl + "/account/custom-apis", body, authToken);
                refreshCustomApis(() -> {
                    if (isPageShown) showFullPage(buildCustomApisView());
                    Toast.makeText(this, "Saved (" + name + ")", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't save: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private void updateCustomApi(int id, String name, String baseUrl, String key) {
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                if (!name.isEmpty()) body.put("name", name);
                if (!baseUrl.isEmpty()) body.put("base_url", baseUrl);
                if (!key.isEmpty()) body.put("api_key", key);
                httpPutJson(backendUrl + "/account/custom-apis/" + id, body, authToken);
                refreshCustomApis(() -> {
                    if (isPageShown) showFullPage(buildCustomApisView());
                    Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't update: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private void removeCustomApi(int id) {
        networkExecutor.execute(() -> {
            try {
                httpDeleteJson(backendUrl + "/account/custom-apis/" + id, authToken);
            } catch (Exception ignored) {}
            refreshCustomApis(() -> {
                if (isPageShown) showFullPage(buildCustomApisView());
                Toast.makeText(this, "Removed", Toast.LENGTH_SHORT).show();
            });
        });
    }

    // Fires a real request through a saved Custom API and shows the raw
    // result — this is the concrete "the browser can actually use this
    // API" step, not just storage. Any other feature (Automation steps,
    // Agent tools, etc.) can reuse the same callCustomApi() below instead
    // of duplicating this network call.
    private void testCustomApi(int id, String path) {
        Toast.makeText(this, "Calling…", Toast.LENGTH_SHORT).show();
        callCustomApi(id, "GET", path, null, (success, resultText) -> {
            new AccentDialogBuilder(this)
                    .setTitle(success ? "✅ Success" : "⚠️ Response")
                    .setMessage(resultText)
                    .setPositiveButton("OK", null)
                    .show();
        });
    }

    interface CustomApiCallback {
        void onResult(boolean success, String resultText);
    }

    // Generic entry point for "use one of my saved custom APIs" — pass the
    // saved API's id, an HTTP method, a path to append to its base_url,
    // and an optional JSON body. The stored key is attached server-side
    // (see /account/custom-apis/{id}/call in nex-backend), so this device
    // never needs to hold the raw key at all. Intended to be called from
    // anywhere in the app — Settings' own Test button today, and future
    // Automation/Agent steps that want to reach a user's saved API.
    private void callCustomApi(int id, String method, String path, JSONObject jsonBody, CustomApiCallback callback) {
        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            if (callback != null) mainHandler.post(() -> callback.onResult(false, "Sign in first (Settings → Account)"));
            return;
        }
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("method", method);
                body.put("path", path == null ? "" : path);
                if (jsonBody != null) body.put("json_body", jsonBody);
                JSONObject resp = httpPostJson(backendUrl + "/account/custom-apis/" + id + "/call", body, authToken);
                boolean ok = resp.optBoolean("ok", false);
                int statusCode = resp.optInt("status_code", 0);
                Object respBody = resp.opt("body");
                String resultText = "HTTP " + statusCode + "\n\n" + String.valueOf(respBody);
                if (callback != null) mainHandler.post(() -> callback.onResult(ok, resultText));
            } catch (Exception e) {
                if (callback != null) mainHandler.post(() -> callback.onResult(false, "Call failed: " + e.getMessage()));
            }
        });
    }

    private void confirmSignOutEverywhere() {
        new AccentDialogBuilder(this)
                .setTitle("Sign Out Everywhere")
                .setMessage("This signs out every OTHER device using this account. This device stays signed in.")
                .setPositiveButton("Sign Out Everywhere", (d, w) -> {
                    networkExecutor.execute(() -> {
                        try {
                            JSONObject body = new JSONObject();
                            body.put("include_current_device", false);
                            JSONObject resp = httpPostJson(backendUrl + "/auth/sign-out-everywhere", body, authToken);
                            int revoked = resp.optInt("sessions_revoked", 0);
                            mainHandler.post(() -> Toast.makeText(this,
                                    revoked == 0 ? "No other devices were signed in" : (revoked + " other device(s) signed out"),
                                    Toast.LENGTH_LONG).show());
                        } catch (Exception e) {
                            mainHandler.post(() -> Toast.makeText(this, "Couldn't sign out other devices: " + e.getMessage(), Toast.LENGTH_LONG).show());
                        }
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---- Multi-device Sessions (#22): lists every device currently
    // signed in to this account, with a Revoke button per device (except
    // the current one — that's what "Sign Out" on the Account screen is for). ----
    private View buildSessionsView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("Sessions", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(24, 20, 24, 24);
        scroll.addView(list);
        root.addView(scroll);

        TextView loading = new TextView(this);
        loading.setText("Loading sessions…");
        loading.setTextColor(getColor(R.color.text_dim));
        loading.setTextSize(11);
        list.addView(loading);

        networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(backendUrl + "/auth/sessions", authToken);
                JSONArray sessions = resp.optJSONArray("sessions");
                mainHandler.post(() -> {
                    list.removeAllViews();
                    if (sessions == null || sessions.length() == 0) {
                        list.addView(buildEmptyState("No active sessions"));
                        return;
                    }
                    for (int i = 0; i < sessions.length(); i++) {
                        try {
                            list.addView(buildSessionRow(sessions.getJSONObject(i)));
                        } catch (Exception ignored) {}
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    list.removeAllViews();
                    TextView error = new TextView(this);
                    error.setText("Couldn't load sessions: " + e.getMessage());
                    error.setTextColor(ThemeManager.getAccentColor(this));
                    error.setTextSize(11);
                    list.addView(error);
                });
            }
        });

        return root;
    }

    // ---- Device Management (#26): rename any session's device label
    // (works on the current device too) so the Sessions list is actually
    // easy to tell apart instead of just showing raw manufacturer/model
    // strings. ----
    private void showRenameSessionDialog(int sessionId, String currentLabel) {
        EditText input = new EditText(this);
        input.setText(currentLabel);
        input.setTextColor(getColor(R.color.text_primary));
        input.setSelection(input.getText().length());

        new AccentDialogBuilder(this)
                .setTitle("Rename Device")
                .setView(input)
                .setPositiveButton("Save", (d, w) -> {
                    String newLabel = input.getText().toString().trim();
                    if (newLabel.isEmpty()) return;
                    networkExecutor.execute(() -> {
                        try {
                            ensureFreshAccessToken(authToken);
                            JSONObject body = new JSONObject();
                            body.put("device_label", newLabel);
                            URL url = new URL(backendUrl + "/auth/sessions/" + sessionId);
                            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                            conn.setRequestMethod("PATCH");
                            conn.setRequestProperty("Content-Type", "application/json");
                            conn.setRequestProperty("Authorization", "Bearer " + authToken);
                            conn.setDoOutput(true);
                            conn.setConnectTimeout(15000);
                            conn.setReadTimeout(15000);
                            try (OutputStream os = conn.getOutputStream()) {
                                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                            }
                            int code = conn.getResponseCode();
                            conn.disconnect();
                            if (code >= 200 && code < 300) {
                                mainHandler.post(() -> {
                                    if (isPageShown) showFullPage(buildSessionsView());
                                });
                            } else {
                                mainHandler.post(() -> Toast.makeText(this, "Couldn't rename device", Toast.LENGTH_SHORT).show());
                            }
                        } catch (Exception e) {
                            mainHandler.post(() -> Toast.makeText(this, "Couldn't rename device: " + e.getMessage(), Toast.LENGTH_LONG).show());
                        }
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private View buildSessionRow(JSONObject session) throws Exception {
        boolean isCurrent = session.optBoolean("is_current_device", false);
        String deviceLabel = session.optString("device_label", "Unknown device");
        long lastUsedAt = session.optLong("last_used_at", 0);
        int sessionId = session.optInt("session_id", -1);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(16, 16, 16, 16);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 8;
        row.setLayoutParams(rowParams);
        row.setBackgroundResource(R.drawable.bg_tab_inactive);

        LinearLayout textCol = new LinearLayout(this);
        textCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textColParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        textColParams.weight = 1;
        textCol.setLayoutParams(textColParams);

        TextView labelView = new TextView(this);
        labelView.setText(deviceLabel + (isCurrent ? "  (this device)" : "") + "  ✎");
        labelView.setTextColor(isCurrent ? getColor(R.color.gold) : getColor(R.color.text_primary));
        labelView.setTextSize(12);
        labelView.setOnClickListener(v -> showRenameSessionDialog(sessionId, deviceLabel));
        textCol.addView(labelView);

        TextView lastUsedView = new TextView(this);
        long minutesAgo = Math.max(0, (System.currentTimeMillis() / 1000 - lastUsedAt) / 60);
        String whenText = minutesAgo < 1 ? "Active just now"
                : minutesAgo < 60 ? ("Active " + minutesAgo + "m ago")
                : minutesAgo < 1440 ? ("Active " + (minutesAgo / 60) + "h ago")
                : ("Active " + (minutesAgo / 1440) + "d ago");
        lastUsedView.setText(whenText);
        lastUsedView.setTextColor(getColor(R.color.text_dim));
        lastUsedView.setTextSize(9.5f);
        LinearLayout.LayoutParams lastUsedParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lastUsedParams.topMargin = 4;
        lastUsedView.setLayoutParams(lastUsedParams);
        textCol.addView(lastUsedView);

        row.addView(textCol);

        if (!isCurrent) {
            TextView revokeBtn = new TextView(this);
            revokeBtn.setText("Revoke");
            revokeBtn.setTextColor(ThemeManager.getAccentColor(this));
            revokeBtn.setTextSize(11);
            revokeBtn.setPadding(20, 12, 20, 12);
            revokeBtn.setOnClickListener(v -> {
                networkExecutor.execute(() -> {
                    try {
                        ensureFreshAccessToken(authToken);
                        URL url = new URL(backendUrl + "/auth/sessions/" + sessionId);
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setRequestMethod("DELETE");
                        conn.setRequestProperty("Authorization", "Bearer " + authToken);
                        conn.setConnectTimeout(15000);
                        conn.setReadTimeout(15000);
                        int code = conn.getResponseCode();
                        conn.disconnect();
                        if (code >= 200 && code < 300) {
                            mainHandler.post(() -> {
                                Toast.makeText(this, "Session revoked", Toast.LENGTH_SHORT).show();
                                if (isPageShown) showFullPage(buildSessionsView());
                            });
                        } else {
                            mainHandler.post(() -> Toast.makeText(this, "Couldn't revoke session", Toast.LENGTH_SHORT).show());
                        }
                    } catch (Exception e) {
                        mainHandler.post(() -> Toast.makeText(this, "Couldn't revoke session: " + e.getMessage(), Toast.LENGTH_LONG).show());
                    }
                });
            });
            row.addView(revokeBtn);
        }

        return row;
    }

    private void showGoogleClientIdDialog() {
        EditText input = new EditText(this);
        input.setText(prefs.getString("google_client_id", ""));
        input.setHint("xxxxxxxx.apps.googleusercontent.com");
        input.setTextColor(getColor(R.color.text_primary));
        input.setHintTextColor(getColor(R.color.text_dim));

        new AccentDialogBuilder(this)
                .setTitle("Google Web Client ID")
                .setMessage("Google Cloud Console → APIs & Services → Credentials → OAuth 2.0 Client IDs → the \"Web application\" client (not the Android one). See GOOGLE_SIGNIN_SETUP.md for the full steps.")
                .setView(input)
                .setPositiveButton("Save", (d, w) -> {
                    String id = input.getText().toString().trim();
                    prefs.edit().putString("google_client_id", id).apply();
                    showAccountScreen();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---- Kicks off the real Credential Manager flow: shows the system
    // Google account picker, gets back a signed ID token, and hands it to
    // the backend's /auth/google (which verifies it against Google's own
    // tokeninfo endpoint before issuing our session token). ----
    private void signInWithGoogle() {
        String googleClientId = prefs.getString("google_client_id", "");
        if (googleClientId.isEmpty()) {
            Toast.makeText(this, "Set your Google Client ID first", Toast.LENGTH_LONG).show();
            showGoogleClientIdDialog();
            return;
        }
        if (backendUrl.isEmpty()) {
            Toast.makeText(this, "Set your Backend Server URL first", Toast.LENGTH_LONG).show();
            return;
        }

        GetGoogleIdOption googleIdOption = new GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(googleClientId)
                .setAutoSelectEnabled(false)
                .build();

        GetCredentialRequest request = new GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build();

        CredentialManager credentialManager = CredentialManager.create(this);

        credentialManager.getCredentialAsync(
                this,
                request,
                new android.os.CancellationSignal(),
                networkExecutor,
                new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                    @Override
                    public void onResult(GetCredentialResponse result) {
                        handleGoogleCredentialResult(result);
                    }

                    @Override
                    public void onError(GetCredentialException e) {
                        mainHandler.post(() ->
                                Toast.makeText(MainActivity.this,
                                        "Google sign-in cancelled or failed: " + e.getMessage(),
                                        Toast.LENGTH_LONG).show());
                    }
                }
        );
    }

    private void handleGoogleCredentialResult(GetCredentialResponse result) {
        Credential credential = result.getCredential();

        if (!(credential instanceof CustomCredential) ||
                !GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
            mainHandler.post(() ->
                    Toast.makeText(this, "Unexpected credential type from Google", Toast.LENGTH_LONG).show());
            return;
        }

        GoogleIdTokenCredential googleIdTokenCredential =
                GoogleIdTokenCredential.createFrom(((CustomCredential) credential).getData());
        callGoogleAuth(googleIdTokenCredential.getIdToken());
    }

    // ---- Same session-establishing shape as callAuth() (email/password)
    // — sends the Google ID token to the backend, stores the returned
    // access+refresh tokens/email, wires up push-token registration, and
    // refreshes the Settings screen. ----
    private void callGoogleAuth(String idToken) {
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("id_token", idToken);
                body.put("device_label", Build.MANUFACTURER + " " + Build.MODEL);

                JSONObject resp = httpPostJson(backendUrl + "/auth/google", body, null);
                storeNewSession(resp);
                String recoveryCode = resp.optString("recovery_code", "");

                mainHandler.post(() -> {
                    Toast.makeText(this, "Signed in as " + authEmail, Toast.LENGTH_SHORT).show();
                    showFullPage(buildSettingsView());
                    if (!recoveryCode.isEmpty()) showRecoveryCodeDialog(recoveryCode, false);
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Google sign-in failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // ---- Saves a fresh {access_token, refresh_token, expires_in, email}
    // response from register/login/google-auth into memory + prefs. Every
    // successful sign-in is its own session (device) on the backend now —
    // signing in again on this device just replaces this device's session,
    // other devices already signed in stay signed in. ----
    private void storeNewSession(JSONObject resp) throws Exception {
        authToken = resp.getString("access_token");
        refreshToken = resp.getString("refresh_token");
        accessTokenExpiresAt = (System.currentTimeMillis() / 1000) + resp.optLong("expires_in", 1800);
        authEmail = resp.getString("email");
        securePrefs.edit()
                .putString("auth_token", authToken)
                .putString("refresh_token", refreshToken)
                .putLong("auth_access_expires_at", accessTokenExpiresAt)
                .putString("auth_email", authEmail)
                .apply();
        registerPendingFcmTokenIfReady();
        if (!backendUrl.isEmpty()) syncEverythingNow(); // pulls this account's settings/bookmarks/history/tabs in right away
    }

    private void callAuth(String path, String email, String password) {
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Email and password required", Toast.LENGTH_SHORT).show();
            return;
        }
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("email", email);
                body.put("password", password);
                body.put("device_label", Build.MANUFACTURER + " " + Build.MODEL);

                JSONObject resp = httpPostJson(backendUrl + path, body, null);
                storeNewSession(resp);
                String recoveryCode = resp.optString("recovery_code", "");

                mainHandler.post(() -> {
                    Toast.makeText(this, "Signed in as " + authEmail, Toast.LENGTH_SHORT).show();
                    showFullPage(buildSettingsView());
                    if (!recoveryCode.isEmpty()) showRecoveryCodeDialog(recoveryCode, false);
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Sign-in failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // ---- Account Recovery (#25): shown exactly once, right when a
    // recovery code is (re)generated — the server never returns the plain
    // code again after this. isRegenerate just changes the copy shown;
    // the dialog behavior is identical either way. ----
    private void showRecoveryCodeDialog(String code, boolean isRegenerate) {
        TextView codeView = new TextView(this);
        codeView.setText(code);
        codeView.setTextColor(getColor(R.color.gold));
        codeView.setTextSize(20);
        codeView.setGravity(android.view.Gravity.CENTER);
        codeView.setPadding(24, 32, 24, 32);
        codeView.setBackgroundResource(R.drawable.bg_tab_inactive);
        codeView.setTypeface(android.graphics.Typeface.MONOSPACE);

        new AccentDialogBuilder(this)
                .setTitle(isRegenerate ? "New Recovery Code" : "Save Your Recovery Code")
                .setMessage((isRegenerate
                        ? "Your old recovery code no longer works. "
                        : "If you ever forget your password, this code is the only way back into your account — ")
                        + "write it down or save it somewhere safe. This is shown ONLY ONCE — the server never stores it in a readable form again.")
                .setView(codeView)
                .setPositiveButton("I've Saved It", null)
                .setCancelable(false)
                .show();
    }

    // ---- Account Recovery (#25): "Forgot Password?" — email + recovery
    // code (instead of the old password) + a new password. Every existing
    // session gets signed out server-side as part of this, since a
    // password reset is treated as "the old password may be compromised". ----
    private void showForgotPasswordDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(32, 16, 32, 16);

        EditText emailInput = new EditText(this);
        emailInput.setHint("Email");
        emailInput.setTextColor(getColor(R.color.text_primary));
        emailInput.setHintTextColor(getColor(R.color.text_dim));
        form.addView(emailInput);

        EditText codeInput = new EditText(this);
        codeInput.setHint("Recovery Code (XXXX-XXXX-XXXX)");
        codeInput.setTextColor(getColor(R.color.text_primary));
        codeInput.setHintTextColor(getColor(R.color.text_dim));
        LinearLayout.LayoutParams codeParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        codeParams.topMargin = 12;
        codeInput.setLayoutParams(codeParams);
        form.addView(codeInput);

        EditText newPassInput = new EditText(this);
        newPassInput.setHint("New Password (8+ characters)");
        newPassInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        newPassInput.setTextColor(getColor(R.color.text_primary));
        newPassInput.setHintTextColor(getColor(R.color.text_dim));
        LinearLayout.LayoutParams passParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        passParams.topMargin = 12;
        newPassInput.setLayoutParams(passParams);
        form.addView(newPassInput);

        new AccentDialogBuilder(this)
                .setTitle("Reset Password")
                .setView(form)
                .setPositiveButton("Reset", (d, w) -> {
                    String email = emailInput.getText().toString().trim();
                    String code = codeInput.getText().toString().trim();
                    String newPassword = newPassInput.getText().toString();
                    if (email.isEmpty() || code.isEmpty() || newPassword.length() < 8) {
                        Toast.makeText(this, "Fill in all fields (password needs 8+ characters)", Toast.LENGTH_LONG).show();
                        return;
                    }
                    resetPasswordWithRecoveryCode(email, code, newPassword);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void resetPasswordWithRecoveryCode(String email, String code, String newPassword) {
        if (backendUrl.isEmpty()) {
            Toast.makeText(this, "Set your Backend Server URL first", Toast.LENGTH_LONG).show();
            return;
        }
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("email", email);
                body.put("recovery_code", code);
                body.put("new_password", newPassword);
                body.put("device_label", Build.MANUFACTURER + " " + Build.MODEL);

                JSONObject resp = httpPostJson(backendUrl + "/auth/reset-password", body, null);
                storeNewSession(resp);
                String newRecoveryCode = resp.optString("new_recovery_code", "");

                mainHandler.post(() -> {
                    Toast.makeText(this, "Password reset — signed in as " + authEmail, Toast.LENGTH_SHORT).show();
                    showFullPage(buildSettingsView());
                    if (!newRecoveryCode.isEmpty()) showRecoveryCodeDialog(newRecoveryCode, true);
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Reset failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // ---- Security Center (#24): one dashboard screen for account
    // security status, instead of it being scattered across Account /
    // Passwords / Sessions screens. ----
    private View buildSecurityCenterView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("Security Center", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(24, 20, 24, 24);
        scroll.addView(list);
        root.addView(scroll);

        if (authToken.isEmpty()) {
            list.addView(buildEmptyState("Sign in to see your account's security status"));
            list.addView(buildAccountActionRow("🔑 Set/Change Vault Passphrase", () -> showVaultPassphraseSetupDialog(null)));
            list.addView(buildAccountActionRow("⚙ Security Settings (Biometric Lock, etc.)", () -> showFullPage(buildSecuritySettingsView())));
            list.addView(buildAccountActionRow("⬇ Export My Data", this::showExportDataDialog));
            return root;
        }

        TextView loading = new TextView(this);
        loading.setText("Loading…");
        loading.setTextColor(getColor(R.color.text_dim));
        loading.setTextSize(11);
        list.addView(loading);

        networkExecutor.execute(() -> {
            try {
                JSONObject info = httpGetJson(backendUrl + "/auth/me", authToken);
                mainHandler.post(() -> {
                    list.removeAllViews();

                    list.addView(buildSecurityStatusRow("Account", info.optString("email", authEmail)));
                    list.addView(buildSecurityStatusRow("Active Devices", String.valueOf(info.optInt("active_sessions", 1))));
                    list.addView(buildSecurityStatusRow("Vault Passphrase",
                            hasVaultPassphraseSetUp() ? "✅ Set — whole vault is end-to-end encrypted" : "⚠️ Not set — set one in Passwords"));
                    list.addView(buildSecurityStatusRow("Recovery Code",
                            info.optBoolean("recovery_code_set", false) ? "✅ Set" : "⚠️ Not set"));
                    list.addView(buildSecurityStatusRow("Biometric Vault Lock",
                            biometricLockEnabled ? "✅ On" : "⚠️ Off"));

                    list.addView(buildAccountActionRow("📱 Manage Sessions", () -> showFullPage(buildSessionsView())));
                    list.addView(buildAccountActionRow("🚪 Sign Out Everywhere", this::confirmSignOutEverywhere));
                    list.addView(buildAccountActionRow("🔑 Set/Change Vault Passphrase", () -> showVaultPassphraseSetupDialog(null)));
                    list.addView(buildAccountActionRow("🔁 Regenerate Recovery Code", this::confirmRegenerateRecoveryCode));
                    list.addView(buildAccountActionRow("🕐 Backup History", () -> showFullPage(buildVaultBackupsView())));
                    list.addView(buildAccountActionRow("⚙ Security Settings (Biometric Lock, etc.)", () -> showFullPage(buildSecuritySettingsView())));
                    list.addView(buildAccountActionRow("⬇ Export My Data", this::showExportDataDialog));
                    list.addView(buildAccountActionRow("🗑 Delete Account & All Data", this::showDeleteAccountDialog));
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    list.removeAllViews();
                    TextView error = new TextView(this);
                    error.setText("Couldn't load security status: " + e.getMessage());
                    error.setTextColor(ThemeManager.getAccentColor(this));
                    error.setTextSize(11);
                    list.addView(error);
                });
            }
        });

        return root;
    }

    private View buildSecurityStatusRow(String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(16, 16, 16, 16);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = 8;
        row.setLayoutParams(p);
        row.setBackgroundResource(R.drawable.bg_tab_inactive);

        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextColor(getColor(R.color.text_dim));
        labelView.setTextSize(9.5f);
        row.addView(labelView);

        TextView valueView = new TextView(this);
        valueView.setText(value);
        valueView.setTextColor(getColor(R.color.text_primary));
        valueView.setTextSize(12);
        LinearLayout.LayoutParams valueParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        valueParams.topMargin = 4;
        valueView.setLayoutParams(valueParams);
        row.addView(valueView);

        return row;
    }

    private void confirmRegenerateRecoveryCode() {
        new AccentDialogBuilder(this)
                .setTitle("Regenerate Recovery Code")
                .setMessage("Your current recovery code will stop working. Only do this if you've lost it or think someone else has seen it.")
                .setPositiveButton("Regenerate", (d, w) -> {
                    networkExecutor.execute(() -> {
                        try {
                            JSONObject resp = httpPostJson(backendUrl + "/auth/recovery-code/regenerate", new JSONObject(), authToken);
                            String newCode = resp.getString("recovery_code");
                            mainHandler.post(() -> showRecoveryCodeDialog(newCode, true));
                        } catch (Exception e) {
                            mainHandler.post(() -> Toast.makeText(this, "Couldn't regenerate: " + e.getMessage(), Toast.LENGTH_LONG).show());
                        }
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---- True only once a real google-services.json was present at build
    // time and Firebase actually initialized. Safe to call anytime —
    // never throws, never crashes if Firebase isn't set up. ----
    private boolean isFirebaseConfigured() {
        try {
            return !com.google.firebase.FirebaseApp.getApps(this).isEmpty();
        } catch (Throwable t) {
            return false;
        }
    }

    // ---- If Firebase already handed us a token (onNewToken fired before the
    // user signed in) and we now have both an account and a backend URL,
    // register it. Safe no-op otherwise. ----
    private void registerPendingFcmTokenIfReady() {
        if (!isFirebaseConfigured() || authToken.isEmpty() || backendUrl.isEmpty()) return;
        String fcmToken = prefs.getString("fcm_token", "");
        if (fcmToken.isEmpty()) return;

        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("fcm_token", fcmToken);
                httpPostJson(backendUrl + "/notifications/register-token", body, authToken);
            } catch (Exception ignored) {
                // best-effort; will retry next time this is called (e.g. next app open)
            }
        });
    }

    // ---- Sends a real push notification to this account's registered
    // device(s), via the backend's /notifications/send endpoint ----
    private void sendTestPushNotification() {
        if (authToken.isEmpty()) {
            Toast.makeText(this, "Sign in first (Settings → Account)", Toast.LENGTH_LONG).show();
            return;
        }
        if (backendUrl.isEmpty()) {
            Toast.makeText(this, "Set your Backend Server URL first", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Sending test notification…", Toast.LENGTH_SHORT).show();
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("title", "Nex Browser");
                body.put("body", "Push notifications are working! 🎉");
                JSONObject resp = httpPostJson(backendUrl + "/notifications/send", body, authToken);
                int delivered = resp.optInt("delivered_to", 0);
                mainHandler.post(() -> Toast.makeText(this,
                        delivered > 0 ? "Sent — check your notification bar" : "Sent, but no device received it yet",
                        Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't send: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // ================================================================
    // AI SUMMARIZER — extracts visible page text via JS, sends it to
    // the backend's /summarize endpoint (which calls Claude), shows
    // the result in a dialog.
    // ================================================================
    private void summarizeCurrentPage() {
        if (backendUrl.isEmpty()) {
            Toast.makeText(this, "Set your Backend Server URL in Settings first", Toast.LENGTH_LONG).show();
            return;
        }
        WebView wv = currentWebView();
        DevilTab tab = currentTab();
        if (wv == null || tab == null || !"web".equals(tab.type)) {
            Toast.makeText(this, "Open a page first", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Summarizing…", Toast.LENGTH_SHORT).show();
        String pageUrl = wv.getUrl();

        wv.evaluateJavascript(
                "(function(){return document.body ? document.body.innerText : '';})()",
                rawValue -> {
                    String pageText = unescapeJsString(rawValue);
                    networkExecutor.execute(() -> callSummarizeApi(pageText, pageUrl));
                });
    }

    private String unescapeJsString(String raw) {
        try {
            Object val = new JSONTokener(raw).nextValue();
            return val != null ? val.toString() : "";
        } catch (Exception e) {
            return raw != null ? raw.replace("\"", "") : "";
        }
    }

    private void callSummarizeApi(String pageText, String pageUrl) {
        try {
            JSONObject body = new JSONObject();
            body.put("text", pageText.length() > 15000 ? pageText.substring(0, 15000) : pageText);
            body.put("url", pageUrl);

            JSONObject resp = httpPostJson(backendUrl + "/summarize", body, authToken);
            String summary = resp.optString("summary", "No summary returned");

            mainHandler.post(() -> new AccentDialogBuilder(this)
                    .setTitle("✨ AI Summary")
                    .setMessage(summary)
                    .setPositiveButton("Close", null)
                    .show());
        } catch (Exception e) {
            mainHandler.post(() ->
                    Toast.makeText(this, "Summarizer error: " + e.getMessage(), Toast.LENGTH_LONG).show());
        }
    }

    // ================================================================
    // AI READER MODE (#96) — strips nav/ads/sidebars and shows just the
    // article: a DOM heuristic picks the most likely content block and
    // shows it INSTANTLY (no network wait), then a background AI cleanup
    // pass (/reader/clean) upgrades it in place once it returns — fixing
    // leftover fragments/broken paragraphs the heuristic let through,
    // without summarizing or rephrasing (that's AI Summary's job, #-).
    // ================================================================
    private int readerFontSizeSp = 17;

    // Tries <article>/<main>/role=main/common content selectors first;
    // if none of those look substantial, falls back to the single
    // densest <div>/<section> on the page (most text + most <p> tags).
    private static final String READER_EXTRACT_JS =
            "(function(){"
            + "function score(el){if(!el)return 0;var t=el.innerText||'';var p=el.querySelectorAll('p').length;return t.length+p*50;}"
            + "var sel=document.querySelectorAll('article,main,[role=\"main\"],.post,.post-content,.article,.article-body,.entry-content,#content,.content');"
            + "var best=null,bestScore=0;"
            + "for(var i=0;i<sel.length;i++){var s=score(sel[i]);if(s>bestScore){bestScore=s;best=sel[i];}}"
            + "if(bestScore<200){"
            + "var all=document.querySelectorAll('div,section');"
            + "for(var j=0;j<all.length;j++){var s2=score(all[j]);if(s2>bestScore){bestScore=s2;best=all[j];}}"
            + "}"
            + "var title=document.title||'';"
            + "var h1=document.querySelector('h1');"
            + "if(h1&&h1.innerText&&h1.innerText.trim().length>0)title=h1.innerText.trim();"
            + "var bodyText=best?best.innerText:(document.body?document.body.innerText:'');"
            + "return JSON.stringify({title:title,text:bodyText.slice(0,20000)});"
            + "})()";

    private void showReaderMode() {
        WebView wv = currentWebView();
        DevilTab tab = currentTab();
        if (wv == null || tab == null || !"web".equals(tab.type)) {
            Toast.makeText(this, "Open a page first", Toast.LENGTH_SHORT).show();
            return;
        }
        String pageUrl = wv.getUrl();

        wv.evaluateJavascript(READER_EXTRACT_JS, raw -> {
            String json = unescapeJsString(raw);
            String title = "Article";
            String text = "";
            try {
                JSONObject obj = new JSONObject(json);
                title = obj.optString("title", "Article");
                text = obj.optString("text", "");
            } catch (Exception ignored) {}

            if (text.trim().length() < 100) {
                Toast.makeText(this, "Couldn't find enough article content on this page", Toast.LENGTH_LONG).show();
                return;
            }

            String finalTitle = title;
            String finalText = text;
            showFullPage(buildReaderView(finalTitle, finalText, false));

            // AI cleanup pass — runs in the background; if the user is
            // still looking at Reader Mode when it comes back, the view
            // gets rebuilt with the cleaned text in place of the raw
            // DOM extraction. If they've already navigated away,
            // isPageShown simply won't refresh anything visible.
            networkExecutor.execute(() -> {
                try {
                    JSONObject body = new JSONObject();
                    body.put("title", finalTitle);
                    body.put("text", finalText);
                    body.put("url", pageUrl != null ? pageUrl : "");
                    JSONObject resp = httpPostJson(backendUrl + "/reader/clean", body, authToken);
                    String cleaned = resp.optString("text", "");
                    if (!cleaned.trim().isEmpty()) {
                        mainHandler.post(() -> {
                            if (isPageShown) showFullPage(buildReaderView(finalTitle, cleaned, true));
                        });
                    }
                } catch (Exception ignored) {
                    // Silent fail — the raw DOM extraction shown already is a
                    // perfectly usable Reader Mode on its own, AI cleanup is a bonus.
                }
            });
        });
    }

    private View buildReaderView(String title, String bodyText, boolean isCleaned) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        headerRow.addView(buildPageHeader("📖 Reader" + (isCleaned ? "" : " (cleaning up…)"), this::hideFullPage));
        root.addView(headerRow);

        TextView fontSizeBtn = new TextView(this);
        fontSizeBtn.setText("Aa");
        fontSizeBtn.setTextColor(getColor(R.color.gold));
        fontSizeBtn.setTextSize(14);
        fontSizeBtn.setGravity(android.view.Gravity.CENTER);
        fontSizeBtn.setPadding(24, 12, 24, 12);
        LinearLayout.LayoutParams fontBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        fontBtnParams.gravity = android.view.Gravity.END;
        fontBtnParams.rightMargin = 24;
        fontSizeBtn.setLayoutParams(fontBtnParams);
        fontSizeBtn.setOnClickListener(v -> {
            // Cycles small -> medium -> large -> back to small
            readerFontSizeSp = readerFontSizeSp >= 20 ? 14 : readerFontSizeSp + 3;
            if (isPageShown) showFullPage(buildReaderView(title, bodyText, isCleaned));
        });
        root.addView(fontSizeBtn);

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(40, 8, 40, 60);
        content.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(readerFontSizeSp + 6);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleParams.bottomMargin = 32;
        titleView.setLayoutParams(titleParams);
        content.addView(titleView);

        // One TextView per paragraph (split on blank lines) rather than
        // one giant block — real paragraph spacing reads far better
        // than a single wall of text with only line breaks.
        String[] paragraphs = bodyText.split("\\n\\s*\\n");
        for (String para : paragraphs) {
            String trimmed = para.trim();
            if (trimmed.isEmpty()) continue;
            TextView paraView = new TextView(this);
            paraView.setText(trimmed);
            paraView.setTextColor(getColor(R.color.text_primary));
            paraView.setTextSize(readerFontSizeSp);
            paraView.setLineSpacing(10, 1.2f);
            LinearLayout.LayoutParams paraParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            paraParams.bottomMargin = 28;
            paraView.setLayoutParams(paraParams);
            content.addView(paraView);
        }

        scroll.addView(content);
        root.addView(scroll);
        return root;
    }

    // ================================================================
    // ================================================================
    // SOURCE RELIABILITY ENGINE (#98) — a heuristic AI estimate of how
    // trustworthy the CURRENT page's source looks (byline, citations,
    // tone, domain reputation signals), always framed as an estimate,
    // never a verdict. Distinct from Fact-Checking (#100, checks ONE
    // claim) and Contradiction Detector (#99, compares MULTIPLE pages
    // against each other, never against outside truth).
    // ================================================================
    private void checkSourceReliability() {
        WebView wv = currentWebView();
        DevilTab tab = currentTab();
        if (wv == null || tab == null || !"web".equals(tab.type)) {
            Toast.makeText(this, "Open a page first", Toast.LENGTH_SHORT).show();
            return;
        }
        String pageUrl = wv.getUrl();
        if (pageUrl == null) { Toast.makeText(this, "Open a page first", Toast.LENGTH_SHORT).show(); return; }

        Toast.makeText(this, "Checking source…", Toast.LENGTH_SHORT).show();
        wv.evaluateJavascript(READER_EXTRACT_JS, raw -> {
            String json = unescapeJsString(raw);
            String title = "";
            String text = "";
            try {
                JSONObject obj = new JSONObject(json);
                title = obj.optString("title", "");
                text = obj.optString("text", "");
            } catch (Exception ignored) {}
            String finalTitle = title;
            String finalText = text;

            networkExecutor.execute(() -> {
                try {
                    JSONObject body = new JSONObject();
                    body.put("url", pageUrl);
                    body.put("title", finalTitle);
                    body.put("text", finalText);
                    JSONObject resp = httpPostJson(backendUrl + "/web/reliability", body, authToken);
                    String result = resp.optString("result", "");
                    mainHandler.post(() -> showReliabilityResultDialog(result));
                } catch (Exception e) {
                    mainHandler.post(() ->
                            Toast.makeText(this, "Couldn't check reliability: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            });
        });
    }

    private void showReliabilityResultDialog(String result) {
        String ratingLine = "";
        StringBuilder rest = new StringBuilder();
        for (String line : result.split("\n")) {
            if (line.toLowerCase(Locale.US).startsWith("rating:")) ratingLine = line;
            else if (!line.trim().isEmpty()) rest.append(line.trim()).append("\n\n");
        }
        String rating = ratingLine.toLowerCase(Locale.US);
        String badge = rating.contains("high") ? "🟢 High"
                : rating.contains("medium") ? "🟡 Medium"
                : rating.contains("low") ? "🔴 Low"
                : "⚪ Unknown";

        new AccentDialogBuilder(this)
                .setTitle("🛡️ Source Reliability — " + badge)
                .setMessage(rest.toString().trim())
                .setPositiveButton("OK", null)
                .show();
    }

    // ================================================================
    // FACT-CHECKING WORKFLOW (#100) — structured, multi-part check on
    // ONE typed claim against the AI's general knowledge only (no live
    // web access from the backend call) — always honest about that
    // limit, and always ends with concrete, tappable search suggestions
    // rather than pretending to have definitively verified anything.
    // ================================================================
    private void showFactCheckDialog() {
        EditText input = new EditText(this);
        input.setHint("Type or paste the claim to check…");
        input.setTextColor(getColor(R.color.text_primary));
        input.setHintTextColor(getColor(R.color.text_dim));
        input.setMinLines(2);
        input.setPadding(32, 24, 32, 24);

        new AccentDialogBuilder(this)
                .setTitle("🔬 Fact-Check")
                .setView(input)
                .setPositiveButton("Check", (d, w) -> {
                    String claim = input.getText().toString().trim();
                    if (claim.isEmpty()) {
                        Toast.makeText(this, "Type a claim first", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    runFactCheck(claim);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void runFactCheck(String claim) {
        Toast.makeText(this, "Checking…", Toast.LENGTH_SHORT).show();
        WebView wv = currentWebView();
        String contextUrl = wv != null ? wv.getUrl() : null;

        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("claim", claim);
                if (contextUrl != null) body.put("context_url", contextUrl);
                JSONObject resp = httpPostJson(backendUrl + "/web/factcheck", body, authToken);
                String result = resp.optString("result", "");
                mainHandler.post(() -> showFullPage(buildFactCheckResultView(result)));
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Fact-check error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private View buildFactCheckResultView(String result) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("🔬 Fact-Check", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(32, 16, 32, 48);
        content.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // "Verify further" suggestions are rendered as tappable rows
        // that open a new tab searching that query — every other
        // section is plain, wrapped text.
        boolean inVerifySection = false;
        for (String rawLine : result.split("\n")) {
            String line = rawLine.trim();
            if (line.isEmpty()) continue;
            if (line.toLowerCase(Locale.US).startsWith("verify further")) {
                inVerifySection = true;
                TextView header = new TextView(this);
                header.setText(line);
                header.setTextColor(getColor(R.color.text_primary));
                header.setTextSize(14);
                header.setTypeface(null, android.graphics.Typeface.BOLD);
                LinearLayout.LayoutParams headerParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                headerParams.topMargin = 20;
                headerParams.bottomMargin = 8;
                header.setLayoutParams(headerParams);
                content.addView(header);
                continue;
            }
            if (inVerifySection && (line.startsWith("-") || line.startsWith("•"))) {
                String query = line.replaceFirst("^[-•]\\s*", "").trim();
                TextView suggestion = new TextView(this);
                suggestion.setText("🔍  " + query);
                suggestion.setTextColor(getColor(R.color.gold));
                suggestion.setTextSize(13);
                suggestion.setPadding(0, 12, 0, 12);
                suggestion.setOnClickListener(v -> {
                    createNewTab(false, -1);
                    navigate(resolveUrl(query));
                    hideFullPage();
                });
                content.addView(suggestion);
                continue;
            }
            TextView lineView = new TextView(this);
            lineView.setText(line);
            lineView.setTextColor(getColor(R.color.text_primary));
            lineView.setTextSize(13.5f);
            lineView.setLineSpacing(8, 1.15f);
            LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lineParams.bottomMargin = 20;
            lineView.setLayoutParams(lineParams);
            content.addView(lineView);
        }

        scroll.addView(content);
        root.addView(scroll);
        return root;
    }

    // ================================================================
    // WEB PAGE CHANGE MONITOR (#104) + SEMANTIC PAGE DIFF (#105) — the
    // actual periodic checking happens server-side (backend's scheduler
    // loop, piggybacked on its existing 30s tick, throttled to once per
    // 30 min per page); Android just adds/removes/lists pages and shows
    // what changed. Pull-based (opens Watch List to see changes), no
    // push notification yet.
    // ================================================================
    private void addCurrentPageToWatchList() {
        WebView wv = currentWebView();
        if (wv == null || wv.getUrl() == null) {
            Toast.makeText(this, "Open a page first", Toast.LENGTH_SHORT).show();
            return;
        }
        String url = wv.getUrl();
        String title = currentTab() != null ? currentTab().title : url;
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("url", url);
                body.put("title", title);
                httpPostJson(backendUrl + "/watch/add", body, authToken);
                mainHandler.post(() -> Toast.makeText(this, "👁 Watching this page for changes", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                mainHandler.post(() -> Toast.makeText(this, "Couldn't add: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private View buildWatchListView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("👁 Watch List", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(20, 16, 20, 16);
        list.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        scroll.addView(list);
        root.addView(scroll);

        TextView loading = new TextView(this);
        loading.setText("Loading…");
        loading.setTextColor(getColor(R.color.text_dim));
        loading.setPadding(0, 20, 0, 20);
        list.addView(loading);

        networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(backendUrl + "/watch/list", authToken);
                JSONArray pages = resp.optJSONArray("pages");
                List<JSONObject> pageList = new ArrayList<>();
                if (pages != null) for (int i = 0; i < pages.length(); i++) pageList.add(pages.getJSONObject(i));
                mainHandler.post(() -> {
                    list.removeAllViews();
                    if (pageList.isEmpty()) {
                        list.addView(buildEmptyState("Not watching any pages yet — use \"👁 Watch Page\" from the menu"));
                    } else {
                        for (JSONObject p : pageList) list.addView(buildWatchListRow(p, list));
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    list.removeAllViews();
                    list.addView(buildEmptyState("Couldn't load watch list: " + e.getMessage()));
                });
            }
        });

        return root;
    }

    private View buildWatchListRow(JSONObject page, LinearLayout parentList) {
        int id = page.optInt("id", -1);
        String url = page.optString("url", "");
        String title = page.optString("title", url);
        boolean hasChange = page.optBoolean("has_change", false);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(20, 20, 20, 20);
        row.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 12;
        row.setLayoutParams(rowParams);

        TextView titleView = new TextView(this);
        titleView.setText((hasChange ? "🔴 " : "⚪ ") + title);
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(13);
        titleView.setMaxLines(2);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        row.addView(titleView);

        TextView urlView = new TextView(this);
        urlView.setText(url);
        urlView.setTextColor(getColor(R.color.text_dim));
        urlView.setTextSize(9.5f);
        urlView.setMaxLines(1);
        urlView.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        LinearLayout.LayoutParams urlParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        urlParams.topMargin = 4;
        urlParams.bottomMargin = 10;
        urlView.setLayoutParams(urlParams);
        row.addView(urlView);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        TextView checkBtn = new TextView(this);
        checkBtn.setText("🔄 Check Now");
        checkBtn.setTextColor(getColor(R.color.text_dim));
        checkBtn.setTextSize(10.5f);
        checkBtn.setPadding(0, 8, 24, 8);
        checkBtn.setOnClickListener(v -> {
            checkBtn.setText("Checking…");
            networkExecutor.execute(() -> {
                try {
                    JSONObject resp = httpPostJson(backendUrl + "/watch/" + id + "/check-now", new JSONObject(), authToken);
                    boolean changed = resp.optBoolean("changed", false);
                    mainHandler.post(() -> {
                        Toast.makeText(this, changed ? "Page has changed!" : "No change detected", Toast.LENGTH_SHORT).show();
                        showFullPage(buildWatchListView());
                    });
                } catch (Exception e) {
                    mainHandler.post(() -> {
                        checkBtn.setText("🔄 Check Now");
                        Toast.makeText(this, "Check failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    });
                }
            });
        });
        btnRow.addView(checkBtn);

        if (hasChange) {
            TextView diffBtn = new TextView(this);
            diffBtn.setText("📋 What changed?");
            diffBtn.setTextColor(getColor(R.color.gold));
            diffBtn.setTextSize(10.5f);
            diffBtn.setPadding(0, 8, 24, 8);
            diffBtn.setOnClickListener(v -> {
                networkExecutor.execute(() -> {
                    try {
                        JSONObject resp = httpPostJson(backendUrl + "/watch/" + id + "/diff-summary", new JSONObject(), authToken);
                        String summary = resp.optString("summary", "No summary available");
                        mainHandler.post(() -> new AccentDialogBuilder(this)
                                .setTitle("📋 What Changed")
                                .setMessage(summary)
                                .setPositiveButton("OK", null)
                                .show());
                    } catch (Exception e) {
                        mainHandler.post(() -> Toast.makeText(this, "Couldn't summarize: " + e.getMessage(), Toast.LENGTH_LONG).show());
                    }
                });
            });
            btnRow.addView(diffBtn);
        }

        TextView deleteBtn = new TextView(this);
        deleteBtn.setText("🗑 Remove");
        deleteBtn.setTextColor(getColor(R.color.text_dim));
        deleteBtn.setTextSize(10.5f);
        deleteBtn.setPadding(0, 8, 0, 8);
        deleteBtn.setOnClickListener(v -> {
            parentList.removeView(row);
            networkExecutor.execute(() -> {
                try { httpDeleteJson(backendUrl + "/watch/" + id, authToken); } catch (Exception ignored) {}
            });
        });
        btnRow.addView(deleteBtn);

        row.addView(btnRow);
        return row;
    }

    // ================================================================
    // AI RESEARCH WORKSPACE (#106) — a persistent collection of saved
    // pages the user is researching together, with an on-demand AI
    // synthesis of what the collected sources say TOGETHER — distinct
    // from Web Comparison (#97, similarities/differences) and
    // Contradiction Detector (#99, disagreements) which both work on
    // whatever's open in tabs right now rather than a saved collection.
    // ================================================================
    // Browser Agent OS (#116): lets a finished automation job's own
    // result become a saved Research Workspace (#106) item — the
    // instruction becomes the title, the job's final summary becomes
    // the content, and the last page it was on becomes the URL (falls
    // back to a placeholder if the job never actually navigated anywhere).
    private void saveJobResultToResearch(JSONObject job) {
        String instruction = job.optString("instruction", "Automation result");
        String currentUrl = job.optString("current_url", "");
        JSONObject result = job.optJSONObject("result");
        String finalResult = result != null ? result.optString("final", "") : "";
        if (finalResult.isEmpty()) {
            Toast.makeText(this, "This job has no final result to save yet", Toast.LENGTH_SHORT).show();
            return;
        }
        String urlForRecord = !currentUrl.isEmpty() ? currentUrl : "about:automation-result";

        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("url", urlForRecord);
                body.put("title", instruction);
                body.put("content", finalResult);
                httpPostJson(backendUrl + "/research/add", body, authToken);
                mainHandler.post(() -> Toast.makeText(this, "📚 Saved to Research Workspace", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                mainHandler.post(() -> Toast.makeText(this, "Couldn't save: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private void addCurrentPageToResearch() {
        WebView wv = currentWebView();
        DevilTab tab = currentTab();
        if (wv == null || tab == null || wv.getUrl() == null) {
            Toast.makeText(this, "Open a page first", Toast.LENGTH_SHORT).show();
            return;
        }
        String url = wv.getUrl();
        String title = tab.title != null ? tab.title : url;

        wv.evaluateJavascript(READER_EXTRACT_JS, raw -> {
            String json = unescapeJsString(raw);
            String content = "";
            try {
                JSONObject obj = new JSONObject(json);
                content = obj.optString("text", "");
            } catch (Exception ignored) {}
            String finalContent = content;
            networkExecutor.execute(() -> {
                try {
                    JSONObject body = new JSONObject();
                    body.put("url", url);
                    body.put("title", title);
                    body.put("content", finalContent);
                    httpPostJson(backendUrl + "/research/add", body, authToken);
                    mainHandler.post(() -> Toast.makeText(this, "📚 Added to Research Workspace", Toast.LENGTH_SHORT).show());
                } catch (Exception e) {
                    mainHandler.post(() -> Toast.makeText(this, "Couldn't add: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            });
        });
    }

    private View buildResearchWorkspaceView(Integer projectId, String projectName) {
        String displayName = projectName != null ? projectName : "Unsorted";
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("📂 " + displayName, this::hideFullPage));

        // Persistent Research Projects (#107): switch which project's
        // items/notes/synthesis this screen shows — "Unsorted"
        // (project_id null) always exists as the default, un-named bucket.
        LinearLayout switcherRow = new LinearLayout(this);
        switcherRow.setOrientation(LinearLayout.HORIZONTAL);
        switcherRow.setPadding(24, 8, 24, 8);
        TextView switchBtn = new TextView(this);
        switchBtn.setText("🗂 Switch Project");
        switchBtn.setTextColor(getColor(R.color.text_dim));
        switchBtn.setTextSize(10.5f);
        switchBtn.setPadding(0, 8, 24, 8);
        switchBtn.setOnClickListener(v -> showProjectSwitcherDialog());
        switcherRow.addView(switchBtn);

        // AI Notes (#108): notes are scoped to the same project as the
        // items shown here.
        TextView notesBtn = new TextView(this);
        notesBtn.setText("📝 Notes");
        notesBtn.setTextColor(getColor(R.color.gold));
        notesBtn.setTextSize(10.5f);
        notesBtn.setPadding(0, 8, 24, 8);
        notesBtn.setOnClickListener(v -> showFullPage(buildNotesView(projectId, displayName)));
        switcherRow.addView(notesBtn);
        root.addView(switcherRow);

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(20, 16, 20, 16);
        list.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        scroll.addView(list);
        root.addView(scroll);

        TextView synthesizeBtn = new TextView(this);
        synthesizeBtn.setText("✨ Synthesize Research");
        synthesizeBtn.setTextColor(getColor(R.color.gold));
        synthesizeBtn.setTextSize(12);
        synthesizeBtn.setGravity(android.view.Gravity.CENTER);
        synthesizeBtn.setPadding(20, 20, 20, 20);
        synthesizeBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams synthBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        synthBtnParams.setMargins(24, 8, 24, 24);
        synthesizeBtn.setLayoutParams(synthBtnParams);
        synthesizeBtn.setOnClickListener(v -> {
            synthesizeBtn.setText("Synthesizing…");
            String synthUrl = backendUrl + "/research/synthesize" + (projectId != null ? "?project_id=" + projectId : "");
            networkExecutor.execute(() -> {
                try {
                    JSONObject resp = httpPostJson(synthUrl, new JSONObject(), authToken);
                    String synthesis = resp.optString("synthesis", "No synthesis returned");
                    mainHandler.post(() -> {
                        synthesizeBtn.setText("✨ Synthesize Research");
                        showFullPage(buildComparisonResultView(synthesis, "✨ Research Synthesis"));
                    });
                } catch (Exception e) {
                    mainHandler.post(() -> {
                        synthesizeBtn.setText("✨ Synthesize Research");
                        Toast.makeText(this, "Couldn't synthesize: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    });
                }
            });
        });
        root.addView(synthesizeBtn);

        String listUrl = backendUrl + "/research/list" + (projectId != null ? "?project_id=" + projectId : "");
        networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(listUrl, authToken);
                JSONArray itemsArr = resp.optJSONArray("items");
                List<JSONObject> itemList = new ArrayList<>();
                if (itemsArr != null) for (int i = 0; i < itemsArr.length(); i++) itemList.add(itemsArr.getJSONObject(i));
                mainHandler.post(() -> {
                    list.removeAllViews();
                    if (itemList.isEmpty()) {
                        list.addView(buildEmptyState("Nothing saved yet — use \"📚 Add to Research\" from the menu"));
                    } else {
                        for (JSONObject item : itemList) list.addView(buildResearchItemRow(item, list));
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    list.removeAllViews();
                    list.addView(buildEmptyState("Couldn't load workspace: " + e.getMessage()));
                });
            }
        });

        return root;
    }

    // Persistent Research Projects (#107): lists existing projects (+
    // the always-present "Unsorted" bucket) and lets the user switch to
    // one, or create a new one.
    private void showProjectSwitcherDialog() {
        networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(backendUrl + "/research/projects", authToken);
                JSONArray projectsArr = resp.optJSONArray("projects");
                List<JSONObject> projectList = new ArrayList<>();
                if (projectsArr != null) for (int i = 0; i < projectsArr.length(); i++) projectList.add(projectsArr.getJSONObject(i));
                mainHandler.post(() -> {
                    List<String> labels = new ArrayList<>();
                    labels.add("Unsorted");
                    for (JSONObject p : projectList) labels.add(p.optString("name", "Project"));
                    labels.add("+ New Project");

                    new AccentDialogBuilder(this)
                            .setTitle("🗂 Switch Project")
                            .setItems(labels.toArray(new String[0]), (d, which) -> {
                                if (which == 0) {
                                    showFullPage(buildResearchWorkspaceView(null, null));
                                } else if (which == labels.size() - 1) {
                                    showCreateProjectDialog();
                                } else {
                                    JSONObject chosen = projectList.get(which - 1);
                                    showFullPage(buildResearchWorkspaceView(chosen.optInt("id"), chosen.optString("name")));
                                }
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                });
            } catch (Exception e) {
                mainHandler.post(() -> Toast.makeText(this, "Couldn't load projects: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private void showCreateProjectDialog() {
        EditText input = new EditText(this);
        input.setHint("Project name…");
        input.setTextColor(getColor(R.color.text_primary));
        input.setHintTextColor(getColor(R.color.text_dim));
        input.setPadding(32, 24, 32, 24);

        new AccentDialogBuilder(this)
                .setTitle("New Research Project")
                .setView(input)
                .setPositiveButton("Create", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) {
                        Toast.makeText(this, "Type a project name", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    networkExecutor.execute(() -> {
                        try {
                            JSONObject body = new JSONObject();
                            body.put("name", name);
                            JSONObject resp = httpPostJson(backendUrl + "/research/projects", body, authToken);
                            int newId = resp.optInt("id", -1);
                            mainHandler.post(() -> showFullPage(buildResearchWorkspaceView(newId, name)));
                        } catch (Exception e) {
                            mainHandler.post(() -> Toast.makeText(this, "Couldn't create project: " + e.getMessage(), Toast.LENGTH_LONG).show());
                        }
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Automatic Citation Builder (#110) — deterministic APA/MLA
    // formatting from title/url/today's date, no AI call needed.
    private void showCitationDialog(String title, String url) {
        String accessDate = new java.text.SimpleDateFormat("MMMM d, yyyy", Locale.US).format(new java.util.Date());
        String host = safeUrlHost(url);
        String siteName = host != null ? host : url;

        String apa = title + ". (n.d.). " + siteName + ". Retrieved " + accessDate + ", from " + url;
        String mla = "\"" + title + ".\" " + siteName + ", " + url + ". Accessed " + accessDate + ".";

        String combined = "APA:\n" + apa + "\n\nMLA:\n" + mla;

        new AccentDialogBuilder(this)
                .setTitle("📑 Citation")
                .setMessage(combined)
                .setPositiveButton("Copy APA", (d, w) -> copyToClipboard("Citation", apa))
                .setNeutralButton("Copy MLA", (d, w) -> copyToClipboard("Citation", mla))
                .setNegativeButton("Close", null)
                .show();
    }

    // ---- WebView crash recovery (see onRenderProcessGone) ----
    private void recoverFromRendererGone(DevilTab tab, WebView dead, boolean crashed) {
        if (tab.webView != dead) return; // stale callback: this WebView was already replaced
        long now = System.currentTimeMillis();
        boolean loopingCrash = now - tab.lastRendererGoneAt < 10_000;
        tab.lastRendererGoneAt = now;

        String url = null;
        try { url = dead.getUrl(); } catch (Exception ignored) {}
        int idx = tabs.indexOf(tab);
        boolean wasCurrent = idx >= 0 && idx == currentTabIndex;

        if (wasCurrent) webViewContainer.removeView(dead);
        try { dead.destroy(); } catch (Exception ignored) {}
        tab.webView = null;

        if (loopingCrash || url == null || url.isEmpty() || "about:blank".equals(url)) {
            // Crashing again right away (or nothing to go back to): stop retrying and
            // land on the home page instead of an endless crash/reload loop.
            tab.type = "home";
            tab.isSuspended = false;
            tab.hasError = false;
            Toast.makeText(this, "This page keeps crashing — opened Home instead", Toast.LENGTH_LONG).show();
        } else {
            tab.suspendedUrl = url;
            tab.isSuspended = true; // switchToTab() -> resumeSuspendedTab() rebuilds it and reloads
            Toast.makeText(this, crashed ? "Page crashed — reloading" : "Page ran out of memory — reloading",
                    Toast.LENGTH_SHORT).show();
        }
        if (wasCurrent) switchToTab(idx); else updateTabChip(tab);
    }

    // ---- HTTP auth prompt ----
    private void showHttpAuthDialog(android.webkit.HttpAuthHandler handler, String host, String realm) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(48, 24, 48, 0);
        EditText userInput = new EditText(this);
        userInput.setHint("Username");
        userInput.setSingleLine(true);
        EditText passInput = new EditText(this);
        passInput.setHint("Password");
        passInput.setSingleLine(true);
        passInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        form.addView(userInput);
        form.addView(passInput);
        new AccentDialogBuilder(this)
                .setTitle("Sign in to " + host)
                .setMessage(realm != null && !realm.isEmpty() ? realm : "This site requires a username and password.")
                .setView(form)
                .setCancelable(false)
                .setPositiveButton("Sign in", (d, w) ->
                        handler.proceed(userInput.getText().toString(), passInput.getText().toString()))
                .setNegativeButton("Cancel", (d, w) -> handler.cancel())
                .show();
    }

    // ---- Website camera / microphone permission flow ----
    private void handleWebPermissionRequest(final android.webkit.PermissionRequest request) {
        boolean wantsCamera = false, wantsMic = false;
        for (String r : request.getResources()) {
            if (android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) wantsCamera = true;
            else if (android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) wantsMic = true;
        }
        if (!wantsCamera && !wantsMic) { request.deny(); return; } // only camera/mic are supported
        String what = wantsCamera && wantsMic ? "camera and microphone" : (wantsCamera ? "camera" : "microphone");
        String host = request.getOrigin() != null && request.getOrigin().getHost() != null
                ? request.getOrigin().getHost() : "This site";
        new AccentDialogBuilder(this)
                .setTitle("Allow " + what + "?")
                .setMessage(host + " wants to use your " + what + ".")
                .setCancelable(false)
                .setPositiveButton("Allow", (d, w) -> {
                    ArrayList<String> missing = new ArrayList<>();
                    for (String r : request.getResources()) {
                        String perm = androidPermissionFor(r);
                        if (perm != null && checkSelfPermission(perm) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                            missing.add(perm);
                        }
                    }
                    if (missing.isEmpty()) {
                        answerWebPermissionRequest(request);
                    } else {
                        if (pendingWebPermissionRequest != null) pendingWebPermissionRequest.deny();
                        pendingWebPermissionRequest = request;
                        webPermissionLauncher.launch(missing.toArray(new String[0]));
                    }
                })
                .setNegativeButton("Block", (d, w) -> request.deny())
                .show();
    }

    private String androidPermissionFor(String webResource) {
        if (android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(webResource)) return android.Manifest.permission.CAMERA;
        if (android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(webResource)) return android.Manifest.permission.RECORD_AUDIO;
        return null;
    }

    /** Grants only the web resources whose Android permission is actually held. */
    private void answerWebPermissionRequest(android.webkit.PermissionRequest request) {
        ArrayList<String> ok = new ArrayList<>();
        for (String r : request.getResources()) {
            String perm = androidPermissionFor(r);
            if (perm != null && checkSelfPermission(perm) == android.content.pm.PackageManager.PERMISSION_GRANTED) ok.add(r);
        }
        if (ok.isEmpty()) request.deny(); else request.grant(ok.toArray(new String[0]));
    }

    /** For secrets (e.g. a curl command containing the access token): flagged
     *  sensitive so Android hides it from clipboard previews (API 33+), and
     *  cleared again after 60 seconds if it's still what's on the clipboard. */
    private void copySensitiveToClipboard(String label, String text) {
        final android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm == null) return;
        android.content.ClipData clip = android.content.ClipData.newPlainText(label, text);
        if (Build.VERSION.SDK_INT >= 33) {
            android.os.PersistableBundle extras = new android.os.PersistableBundle();
            extras.putBoolean("android.content.extra.IS_SENSITIVE", true);
            clip.getDescription().setExtras(extras);
        }
        cm.setPrimaryClip(clip);
        Toast.makeText(this, "Copied — clipboard clears in 60s", Toast.LENGTH_SHORT).show();
        mainHandler.postDelayed(() -> {
            try {
                android.content.ClipData cur = cm.getPrimaryClip();
                if (cur != null && cur.getItemCount() > 0 && cur.getItemAt(0).getText() != null
                        && text.contentEquals(cur.getItemAt(0).getText())) {
                    if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip();
                    else cm.setPrimaryClip(android.content.ClipData.newPlainText("", ""));
                }
            } catch (Exception ignored) { /* background clipboard read can be denied — best effort */ }
        }, 60_000);
    }

    private void copyToClipboard(String label, String text) {
        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(android.content.ClipData.newPlainText(label, text));
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
        }
    }

    private View buildResearchItemRow(JSONObject item, LinearLayout parentList) {
        int id = item.optInt("id", -1);
        String url = item.optString("url", "");
        String title = item.optString("title", url);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(16, 16, 16, 16);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 4;
        row.setLayoutParams(rowParams);

        LinearLayout textCol = new LinearLayout(this);
        textCol.setOrientation(LinearLayout.VERTICAL);
        textCol.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(12.5f);
        titleView.setMaxLines(1);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        textCol.addView(titleView);

        TextView urlView = new TextView(this);
        urlView.setText(url);
        urlView.setTextColor(getColor(R.color.text_dim));
        urlView.setTextSize(9.5f);
        urlView.setMaxLines(1);
        urlView.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        textCol.addView(urlView);
        row.addView(textCol);

        // Automatic Citation Builder (#110): generates ready-to-use
        // APA/MLA citations from what's already saved — no AI call
        // needed, citations are a deterministic format given
        // title/url/access-date, not something to "generate" with AI.
        TextView citeBtn = new TextView(this);
        citeBtn.setText("📑");
        citeBtn.setTextColor(getColor(R.color.text_dim));
        citeBtn.setTextSize(14);
        citeBtn.setPadding(20, 8, 20, 8);
        citeBtn.setOnClickListener(v -> showCitationDialog(title, url));
        row.addView(citeBtn);

        TextView removeBtn = new TextView(this);
        removeBtn.setText("✕");
        removeBtn.setTextColor(getColor(R.color.text_dim));
        removeBtn.setPadding(20, 8, 8, 8);
        removeBtn.setOnClickListener(v -> {
            parentList.removeView(row);
            networkExecutor.execute(() -> {
                try { httpDeleteJson(backendUrl + "/research/" + id, authToken); } catch (Exception ignored) {}
            });
        });
        row.addView(removeBtn);

        return row;
    }

    // ================================================================
    // AI NOTES (#108) + SOURCE-TO-NOTE LINKING (#109) — notes scoped to
    // the same project as the Research Workspace (#106/#107) they were
    // opened from; a note can optionally link back to ONE saved source
    // item, shown and tappable from the note itself.
    // ================================================================
    private View buildNotesView(Integer projectId, String projectName) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("📝 Notes — " + projectName, this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(20, 16, 20, 16);
        list.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        scroll.addView(list);
        root.addView(scroll);

        TextView addBtn = new TextView(this);
        addBtn.setText("+ Add Note");
        addBtn.setTextColor(getColor(R.color.gold));
        addBtn.setTextSize(12);
        addBtn.setGravity(android.view.Gravity.CENTER);
        addBtn.setPadding(20, 20, 20, 20);
        addBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams addBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        addBtnParams.setMargins(24, 8, 24, 24);
        addBtn.setLayoutParams(addBtnParams);
        addBtn.setOnClickListener(v -> showAddNoteDialog(projectId, projectName));
        root.addView(addBtn);

        loadNotesInto(list, projectId);
        return root;
    }

    private void loadNotesInto(LinearLayout list, Integer projectId) {
        String url = backendUrl + "/research/notes" + (projectId != null ? "?project_id=" + projectId : "");
        networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(url, authToken);
                JSONArray notesArr = resp.optJSONArray("notes");
                List<JSONObject> noteList = new ArrayList<>();
                if (notesArr != null) for (int i = 0; i < notesArr.length(); i++) noteList.add(notesArr.getJSONObject(i));
                mainHandler.post(() -> {
                    list.removeAllViews();
                    if (noteList.isEmpty()) {
                        list.addView(buildEmptyState("No notes yet"));
                    } else {
                        for (JSONObject note : noteList) list.addView(buildNoteRow(note, list));
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    list.removeAllViews();
                    list.addView(buildEmptyState("Couldn't load notes: " + e.getMessage()));
                });
            }
        });
    }

    private View buildNoteRow(JSONObject note, LinearLayout parentList) {
        int id = note.optInt("id", -1);
        String title = note.optString("title", "");
        String content = note.optString("content", "");
        String sourceTitle = note.optString("source_title", null);
        String sourceUrl = note.optString("source_url", null);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(20, 20, 20, 20);
        row.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 12;
        row.setLayoutParams(rowParams);

        if (!title.isEmpty()) {
            TextView titleView = new TextView(this);
            titleView.setText(title);
            titleView.setTextColor(getColor(R.color.text_primary));
            titleView.setTextSize(13);
            titleView.setTypeface(null, android.graphics.Typeface.BOLD);
            row.addView(titleView);
        }

        TextView contentView = new TextView(this);
        contentView.setText(content);
        contentView.setTextColor(getColor(R.color.text_primary));
        contentView.setTextSize(12);
        LinearLayout.LayoutParams contentParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        contentParams.topMargin = 6;
        contentParams.bottomMargin = 10;
        contentView.setLayoutParams(contentParams);
        row.addView(contentView);

        // Source-to-Note Linking (#109): tapping the source line opens
        // that saved page's URL in a new tab.
        if (sourceTitle != null && !sourceTitle.isEmpty()) {
            TextView sourceLink = new TextView(this);
            sourceLink.setText("🔗 " + sourceTitle);
            sourceLink.setTextColor(getColor(R.color.gold));
            sourceLink.setTextSize(10.5f);
            sourceLink.setMaxLines(1);
            sourceLink.setEllipsize(android.text.TextUtils.TruncateAt.END);
            sourceLink.setPadding(0, 0, 0, 10);
            if (sourceUrl != null && !sourceUrl.isEmpty()) {
                sourceLink.setOnClickListener(v -> {
                    createNewTab(false, -1);
                    navigate(sourceUrl);
                    hideFullPage();
                });
            }
            row.addView(sourceLink);
        }

        TextView deleteBtn = new TextView(this);
        deleteBtn.setText("🗑 Delete");
        deleteBtn.setTextColor(getColor(R.color.text_dim));
        deleteBtn.setTextSize(10.5f);
        deleteBtn.setOnClickListener(v -> {
            parentList.removeView(row);
            networkExecutor.execute(() -> {
                try { httpDeleteJson(backendUrl + "/research/notes/" + id, authToken); } catch (Exception ignored) {}
            });
        });
        row.addView(deleteBtn);

        return row;
    }

    private void showAddNoteDialog(Integer projectId, String projectName) {
        LinearLayout dialogLayout = new LinearLayout(this);
        dialogLayout.setOrientation(LinearLayout.VERTICAL);
        dialogLayout.setPadding(32, 16, 32, 16);

        EditText titleInput = new EditText(this);
        titleInput.setHint("Title (optional)");
        titleInput.setTextColor(getColor(R.color.text_primary));
        titleInput.setHintTextColor(getColor(R.color.text_dim));
        dialogLayout.addView(titleInput);

        EditText contentInput = new EditText(this);
        contentInput.setHint("Note…");
        contentInput.setTextColor(getColor(R.color.text_primary));
        contentInput.setHintTextColor(getColor(R.color.text_dim));
        contentInput.setMinLines(3);
        LinearLayout.LayoutParams contentInputParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        contentInputParams.topMargin = 12;
        contentInput.setLayoutParams(contentInputParams);
        dialogLayout.addView(contentInput);

        // Source-to-Note Linking (#109): optional — pick one saved item
        // from this project to link the note back to.
        int[] linkedSourceId = {-1};
        TextView linkBtn = new TextView(this);
        linkBtn.setText("🔗 Link to a source (optional)");
        linkBtn.setTextColor(getColor(R.color.text_dim));
        linkBtn.setTextSize(11);
        linkBtn.setPadding(0, 20, 0, 0);
        dialogLayout.addView(linkBtn);

        String listUrl = backendUrl + "/research/list" + (projectId != null ? "?project_id=" + projectId : "");
        linkBtn.setOnClickListener(v -> networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(listUrl, authToken);
                JSONArray itemsArr = resp.optJSONArray("items");
                List<JSONObject> itemList = new ArrayList<>();
                if (itemsArr != null) for (int i = 0; i < itemsArr.length(); i++) itemList.add(itemsArr.getJSONObject(i));
                mainHandler.post(() -> {
                    if (itemList.isEmpty()) {
                        Toast.makeText(this, "No saved sources in this project yet", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    String[] titles = new String[itemList.size()];
                    for (int i = 0; i < itemList.size(); i++) titles[i] = itemList.get(i).optString("title", "Source");
                    new AccentDialogBuilder(this)
                            .setTitle("Link to which source?")
                            .setItems(titles, (d2, which) -> {
                                linkedSourceId[0] = itemList.get(which).optInt("id", -1);
                                linkBtn.setText("🔗 Linked: " + titles[which]);
                            })
                            .show();
                });
            } catch (Exception e) {
                mainHandler.post(() -> Toast.makeText(this, "Couldn't load sources: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }));

        new AccentDialogBuilder(this)
                .setTitle("📝 Add Note")
                .setView(dialogLayout)
                .setPositiveButton("Save", (d, w) -> {
                    String content = contentInput.getText().toString().trim();
                    if (content.isEmpty()) {
                        Toast.makeText(this, "Type a note first", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    String title = titleInput.getText().toString().trim();
                    networkExecutor.execute(() -> {
                        try {
                            JSONObject body = new JSONObject();
                            body.put("content", content);
                            if (!title.isEmpty()) body.put("title", title);
                            if (projectId != null) body.put("project_id", projectId);
                            if (linkedSourceId[0] > 0) body.put("source_item_id", linkedSourceId[0]);
                            httpPostJson(backendUrl + "/research/notes", body, authToken);
                            mainHandler.post(() -> showFullPage(buildNotesView(projectId, projectName)));
                        } catch (Exception e) {
                            mainHandler.post(() -> Toast.makeText(this, "Couldn't save note: " + e.getMessage(), Toast.LENGTH_LONG).show());
                        }
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ================================================================
    // STRUCTURED DATA EXTRACTION (#112) + ONE-CLICK EXPORT (#113)
    // ================================================================
    private void extractStructuredData() {
        WebView wv = currentWebView();
        DevilTab tab = currentTab();
        if (wv == null || tab == null || wv.getUrl() == null) {
            Toast.makeText(this, "Open a page first", Toast.LENGTH_SHORT).show();
            return;
        }
        String pageUrl = wv.getUrl();
        String pageTitle = tab.title != null ? tab.title : pageUrl;

        Toast.makeText(this, "Looking for structured data…", Toast.LENGTH_SHORT).show();
        wv.evaluateJavascript(READER_EXTRACT_JS, raw -> {
            String json = unescapeJsString(raw);
            String text = "";
            try {
                JSONObject obj = new JSONObject(json);
                text = obj.optString("text", "");
            } catch (Exception ignored) {}
            String finalText = text;

            networkExecutor.execute(() -> {
                try {
                    JSONObject body = new JSONObject();
                    body.put("title", pageTitle);
                    body.put("url", pageUrl);
                    body.put("text", finalText);
                    JSONObject resp = httpPostJson(backendUrl + "/web/extract-structured", body, authToken);
                    JSONArray columnsArr = resp.optJSONArray("columns");
                    JSONArray rowsArr = resp.optJSONArray("rows");
                    List<String> columns = new ArrayList<>();
                    if (columnsArr != null) for (int i = 0; i < columnsArr.length(); i++) columns.add(columnsArr.optString(i, ""));
                    List<List<String>> rows = new ArrayList<>();
                    if (rowsArr != null) {
                        for (int i = 0; i < rowsArr.length(); i++) {
                            JSONArray rowArr = rowsArr.optJSONArray(i);
                            List<String> row = new ArrayList<>();
                            if (rowArr != null) for (int j = 0; j < rowArr.length(); j++) row.add(rowArr.optString(j, ""));
                            rows.add(row);
                        }
                    }
                    final boolean tableTruncated = resp.optBoolean("truncated", false);
                    mainHandler.post(() -> {
                        if (columns.isEmpty() || rows.isEmpty()) {
                            Toast.makeText(this, "No structured data (tables/lists) found on this page", Toast.LENGTH_LONG).show();
                        } else {
                            showFullPage(buildStructuredDataView(pageTitle, columns, rows));
                            if (tableTruncated) {
                                Toast.makeText(this, "Large table — showing the first " + rows.size() + " rows", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                } catch (Exception e) {
                    mainHandler.post(() -> Toast.makeText(this, "Extraction error: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            });
        });
    }

    private View buildStructuredDataView(String pageTitle, List<String> columns, List<List<String>> rows) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("📊 Extracted Data", this::hideFullPage));

        HorizontalScrollView hScroll = new HorizontalScrollView(this);
        hScroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        ScrollView vScroll = new ScrollView(this);
        LinearLayout table = new LinearLayout(this);
        table.setOrientation(LinearLayout.VERTICAL);
        table.setPadding(24, 16, 24, 16);

        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        for (String col : columns) headerRow.addView(buildTableCell(col, true));
        table.addView(headerRow);

        for (List<String> row : rows) {
            LinearLayout rowLayout = new LinearLayout(this);
            rowLayout.setOrientation(LinearLayout.HORIZONTAL);
            for (String cell : row) rowLayout.addView(buildTableCell(cell, false));
            table.addView(rowLayout);
        }

        vScroll.addView(table);
        hScroll.addView(vScroll);
        root.addView(hScroll);

        // One-click Export (#113): writes a CSV built from this same
        // table straight to Downloads.
        TextView exportBtn = new TextView(this);
        exportBtn.setText("💾 Export as CSV");
        exportBtn.setTextColor(getColor(R.color.gold));
        exportBtn.setTextSize(12);
        exportBtn.setGravity(android.view.Gravity.CENTER);
        exportBtn.setPadding(20, 20, 20, 20);
        exportBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams exportBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        exportBtnParams.setMargins(24, 12, 24, 24);
        exportBtn.setLayoutParams(exportBtnParams);
        exportBtn.setOnClickListener(v -> {
            StringBuilder csv = new StringBuilder();
            csv.append(String.join(",", escapeCsvRow(columns))).append('\n');
            for (List<String> row : rows) csv.append(String.join(",", escapeCsvRow(row))).append('\n');
            String safeName = pageTitle.replaceAll("[^a-zA-Z0-9-_ ]", "").trim();
            if (safeName.isEmpty()) safeName = "extracted-data";
            exportTextToFile(csv.toString(), safeName + ".csv");
        });
        root.addView(exportBtn);

        return root;
    }

    private List<String> escapeCsvRow(List<String> cells) {
        return DownloadUtils.escapeCsvRow(cells);
    }

    private View buildTableCell(String text, boolean isHeader) {
        TextView cell = new TextView(this);
        cell.setText(text);
        cell.setTextColor(isHeader ? getColor(R.color.gold) : getColor(R.color.text_primary));
        cell.setTextSize(11);
        cell.setTypeface(null, isHeader ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        cell.setPadding(20, 12, 20, 12);
        cell.setMinWidth(180);
        return cell;
    }

    // One-click Export (#113) — a shared helper any feature can hand
    // plain text to; writes straight to the public Downloads folder so
    // it shows up like any other download, no separate "exports" area
    // to remember to check.
    private void exportTextToFile(String content, String fileName) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                android.content.ContentValues values = new android.content.ContentValues();
                values.put(android.provider.MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(android.provider.MediaStore.Downloads.MIME_TYPE, "text/csv");
                values.put(android.provider.MediaStore.Downloads.IS_PENDING, 1);
                Uri collection = android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                Uri itemUri = getContentResolver().insert(collection, values);
                if (itemUri == null) throw new Exception("Couldn't create file");
                try (java.io.OutputStream os = getContentResolver().openOutputStream(itemUri)) {
                    if (os != null) os.write(content.getBytes(StandardCharsets.UTF_8));
                }
                values.clear();
                values.put(android.provider.MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(itemUri, values, null, null);
            } else {
                // Pre-Q (API < 29): MediaStore.Downloads doesn't exist yet —
                // scoped storage wasn't enforced, so writing straight to the
                // public Downloads directory via the File API still works.
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                File outFile = new File(dir, fileName);
                try (java.io.FileOutputStream fos = new java.io.FileOutputStream(outFile)) {
                    fos.write(content.getBytes(StandardCharsets.UTF_8));
                }
            }
            Toast.makeText(this, "Saved to Downloads: " + fileName, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't export: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // ================================================================
    // BROWSER AGENT OS (#116) — the combined end-state of Phases 5-8: a
    // single hub surfacing what the Automation (#82-94), Advanced Agent
    // (#71-81), and Web Intelligence (#95-115) systems are all doing,
    // instead of each living behind its own separate menu entry with no
    // shared view. The two pieces of genuine cross-feature wiring this
    // adds: automation-visited pages now feed AI Web Memory (#101, see
    // the automation WebViewClient's onPageFinished), and a finished
    // job's result can become a Research Workspace item directly (see
    // saveJobResultToResearch, wired into the job "⋮" menu).
    // ================================================================
    // ================================================================
    // TOOLS HUB (renamed from "Agent OS Hub" in redesign pass 3, Sep 2026)
    // — the single second-level home for everything the audit flagged as
    // too advanced for the main menu: Automation, Workflows, Watch List,
    // Research, Source Reliability, Fact-Check and Extract Data. Reached
    // via the main menu's "🧰 Tools" entry. Method name kept as-is to
    // avoid touching every call site; only the on-screen header changed.
    // ================================================================
    private View buildAgentOsHubView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("🧰 Tools", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(24, 16, 24, 32);
        content.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        content.addView(buildToolsHubSectionLabel("AI AGENT"));
        content.addView(buildAgentOsSection("⚙️ Automation", "Loading…", () -> showFullPage(buildAutomationView())));
        content.addView(buildAgentOsSection("📂 Workflows", "Saved workflows & schedules", () -> showFullPage(buildWorkflowsView())));

        content.addView(buildToolsHubSectionLabel("RESEARCH & WATCH"));
        content.addView(buildAgentOsSection("👁 Watch List", "Loading…", () -> showFullPage(buildWatchListView())));
        content.addView(buildAgentOsSection("📂 Research Workspace", "Loading…", () -> showFullPage(buildResearchWorkspaceView(null, null))));

        LinearLayout researchQuickRow = new LinearLayout(this);
        researchQuickRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams researchQuickRowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        researchQuickRowParams.topMargin = 8;
        researchQuickRow.setLayoutParams(researchQuickRowParams);
        researchQuickRow.addView(buildAgentOsQuickAction("👁 Watch This Page", this::addCurrentPageToWatchList));
        researchQuickRow.addView(buildAgentOsQuickAction("📚 Add to Research", this::addCurrentPageToResearch));
        content.addView(researchQuickRow);

        content.addView(buildToolsHubSectionLabel("RELIABILITY & DATA"));
        LinearLayout quickRow = new LinearLayout(this);
        quickRow.setOrientation(LinearLayout.HORIZONTAL);
        quickRow.addView(buildAgentOsQuickAction("🔮 Ask Memory", this::showSemanticHistorySearchDialog));
        quickRow.addView(buildAgentOsQuickAction("📊 Extract Data", this::extractStructuredData));
        content.addView(quickRow);

        LinearLayout quickRow2 = new LinearLayout(this);
        quickRow2.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams quickRow2Params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        quickRow2Params.topMargin = 8;
        quickRow2.setLayoutParams(quickRow2Params);
        quickRow2.addView(buildAgentOsQuickAction("🔬 Fact-Check", this::showFactCheckDialog));
        quickRow2.addView(buildAgentOsQuickAction("🛡️ Source Reliability", this::checkSourceReliability));
        content.addView(quickRow2);

        scroll.addView(content);
        root.addView(scroll);

        // Fetch counts for each section card in the background, then
        // update just that card's subtitle in place once known.
        refreshAgentOsAutomationCount((TextView) ((LinearLayout) content.getChildAt(1)).findViewWithTag("subtitle"));
        refreshAgentOsWatchCount((TextView) ((LinearLayout) content.getChildAt(4)).findViewWithTag("subtitle"));
        refreshAgentOsResearchCount((TextView) ((LinearLayout) content.getChildAt(5)).findViewWithTag("subtitle"));

        return root;
    }

    private View buildToolsHubSectionLabel(String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(ThemeManager.getAccentColor(this));
        label.setTextSize(10);
        label.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.topMargin = 20;
        params.bottomMargin = 10;
        label.setLayoutParams(params);
        return label;
    }

    private View buildAgentOsSection(String title, String initialSubtitle, Runnable onClick) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(20, 20, 20, 20);
        row.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 12;
        row.setLayoutParams(rowParams);
        row.setOnClickListener(v -> onClick.run());

        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(13.5f);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        row.addView(titleView);

        TextView subtitleView = new TextView(this);
        subtitleView.setTag("subtitle");
        subtitleView.setText(initialSubtitle);
        subtitleView.setTextColor(getColor(R.color.text_dim));
        subtitleView.setTextSize(10.5f);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        subtitleParams.topMargin = 4;
        subtitleView.setLayoutParams(subtitleParams);
        row.addView(subtitleView);

        return row;
    }

    private View buildAgentOsQuickAction(String label, Runnable onClick) {
        TextView btn = new TextView(this);
        btn.setText(label);
        btn.setTextColor(getColor(R.color.gold));
        btn.setTextSize(10.5f);
        btn.setGravity(android.view.Gravity.CENTER);
        btn.setPadding(12, 20, 12, 20);
        btn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        btnParams.setMargins(4, 0, 4, 0);
        btn.setLayoutParams(btnParams);
        btn.setOnClickListener(v -> onClick.run());
        return btn;
    }

    private void refreshAgentOsAutomationCount(TextView subtitleView) {
        if (subtitleView == null || backendUrl.isEmpty() || authToken.isEmpty()) return;
        networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(backendUrl + "/agent/jobs", authToken);
                JSONArray jobs = resp.optJSONArray("jobs");
                int running = 0, queued = 0;
                if (jobs != null) {
                    for (int i = 0; i < jobs.length(); i++) {
                        String s = jobs.optJSONObject(i).optString("status", "");
                        if ("running".equals(s)) running++;
                        else if ("queued".equals(s)) queued++;
                    }
                }
                int finalRunning = running, finalQueued = queued;
                mainHandler.post(() -> subtitleView.setText(finalRunning + " running · " + finalQueued + " queued"));
            } catch (Exception ignored) {}
        });
    }

    private void refreshAgentOsWatchCount(TextView subtitleView) {
        if (subtitleView == null || backendUrl.isEmpty() || authToken.isEmpty()) return;
        networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(backendUrl + "/watch/list", authToken);
                JSONArray pages = resp.optJSONArray("pages");
                int total = pages != null ? pages.length() : 0;
                int changed = 0;
                if (pages != null) {
                    for (int i = 0; i < pages.length(); i++) {
                        if (pages.optJSONObject(i).optBoolean("has_change", false)) changed++;
                    }
                }
                int finalTotal = total, finalChanged = changed;
                mainHandler.post(() -> subtitleView.setText(finalTotal + " watched · " + finalChanged + " changed"));
            } catch (Exception ignored) {}
        });
    }

    private void refreshAgentOsResearchCount(TextView subtitleView) {
        if (subtitleView == null || backendUrl.isEmpty() || authToken.isEmpty()) return;
        networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(backendUrl + "/research/list", authToken);
                JSONArray items = resp.optJSONArray("items");
                int count = items != null ? items.length() : 0;
                mainHandler.post(() -> subtitleView.setText(count + " saved source(s) in Unsorted"));
            } catch (Exception ignored) {}
        });
    }

    // CLOUD SYNC — bookmarks only. Pulls remote bookmarks, merges with
    // local (local wins on URL conflicts — simple, no fancy CRDT), saves
    // the merged list both locally and back up to the server.
    // ================================================================
    // ---- History Sync (#40) — real two-way merge, same shape as
    // syncBookmarksNow(): pulls the backend copy, merges it against local
    // (per URL: higher visit count wins, most recent timestamp wins —
    // not a blind overwrite, since count/recency both carry real meaning
    // for history unlike bookmarks), saves the merged result locally,
    // then pushes it back up so both sides end up identical. ----
    // ---- Settings Sync (#43) ----
    // Only these keys ever get synced — real user-preference toggles,
    // never device-specific things (backend_url, fcm_token, biometric
    // hardware settings, etc). Booleans and the one int/string setting
    // are handled separately since SharedPreferences is type-strict.
    private static final String[] SYNCABLE_BOOL_SETTINGS = {
            "animation_on", "auto_reconnect", "new_task_always_ask", "download_notification",
            "open_link_new_tab", "typing_assistant", "tab_view_grid", "adblock_enabled",
            "password_manager_enabled", "reopen_tabs_on_startup", "text_only", "desktop_ua",
    };
    // key -> default, matching the exact defaults already used elsewhere in the app
    private static final Map<String, Boolean> SYNCABLE_BOOL_DEFAULTS = new HashMap<String, Boolean>() {{
        put("animation_on", true);
        put("auto_reconnect", true);
        put("new_task_always_ask", true);
        put("download_notification", true);
        put("open_link_new_tab", false);
        put("typing_assistant", true);
        put("tab_view_grid", false);
        put("adblock_enabled", true);
        put("password_manager_enabled", true);
        put("reopen_tabs_on_startup", false);
        put("text_only", false);
        put("desktop_ua", false);
    }};

    private JSONObject buildSyncableSettingsSnapshot() throws Exception {
        JSONObject snapshot = new JSONObject();
        for (String key : SYNCABLE_BOOL_SETTINGS) {
            snapshot.put(key, prefs.getBoolean(key, SYNCABLE_BOOL_DEFAULTS.get(key)));
        }
        snapshot.put("max_downloads", prefs.getInt("max_downloads", 3));
        snapshot.put("language", prefs.getString("language", "English"));
        return snapshot;
    }

    private void applySettingsSnapshot(JSONObject snapshot) {
        SharedPreferences.Editor editor = prefs.edit();
        for (String key : SYNCABLE_BOOL_SETTINGS) {
            if (snapshot.has(key)) editor.putBoolean(key, snapshot.optBoolean(key, SYNCABLE_BOOL_DEFAULTS.get(key)));
        }
        if (snapshot.has("max_downloads")) editor.putInt("max_downloads", snapshot.optInt("max_downloads", 3));
        if (snapshot.has("language")) editor.putString("language", snapshot.optString("language", "English"));
        editor.apply();
    }

    // First-ever sync on a device pulls the account's existing settings
    // down (so a new phone inherits your setup) — every sync after that
    // pushes local up as the source of truth (no per-key dirty-tracking
    // needed across a dozen scattered toggle handlers; this two-phase
    // rule gets the useful behavior without that invasive a change),
    // while still adopting any key the server has that this device has
    // never seen (e.g. a setting added after this device's first sync).
    // ---- Tab Sync ----
    // Settings.Secure.ANDROID_ID is stable per app-install per device —
    // unlike device_label (just "Google Pixel 7", not unique if someone
    // has two of the same model), this is what actually keys each
    // device's row apart on the backend.
    private String getStableDeviceId() {
        String id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        return (id == null || id.isEmpty()) ? "unknown-device" : id;
    }

    private void syncTabsNow(Runnable onDone) {
        if (backendUrl.isEmpty() || authToken.isEmpty()) return;
        networkExecutor.execute(() -> {
            try {
                JSONArray tabsArr = new JSONArray();
                for (int i = 0; i < tabs.size(); i++) {
                    DevilTab tab = tabs.get(i);
                    if (!"web".equals(tab.type) || tab.isIncognito) continue;
                    String url = tab.isSuspended ? tab.suspendedUrl : (tab.webView != null ? tab.webView.getUrl() : null);
                    if (url == null || url.isEmpty()) continue;
                    JSONObject o = new JSONObject();
                    o.put("url", url);
                    o.put("title", tab.title);
                    o.put("active", i == currentTabIndex);
                    tabsArr.put(o);
                }

                JSONObject body = new JSONObject();
                body.put("device_id", getStableDeviceId());
                body.put("device_label", Build.MANUFACTURER + " " + Build.MODEL);
                body.put("tabs", tabsArr);
                httpPostJson(backendUrl + "/sync/tabs", body, authToken);
                recordSyncSuccess("tabs");
            } catch (Exception e) {
                recordSyncFailure("tabs");
            }
            if (onDone != null) mainHandler.post(onDone);
        });
    }

    // "Tabs from other devices" — never merged automatically into what's
    // currently open here; the user picks which ones (if any) to open,
    // the same way Chrome/Firefox handle it.
    private void showTabsFromOtherDevices() {
        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            Toast.makeText(this, "Set Backend Server URL and sign in first (Settings → Account)", Toast.LENGTH_LONG).show();
            return;
        }
        syncTabsNow(() -> networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(backendUrl + "/sync/tabs", authToken);
                JSONArray devices = resp.optJSONArray("devices");
                if (devices == null) devices = new JSONArray();
                String myDeviceId = getStableDeviceId();
                JSONArray finalDevices = devices;
                mainHandler.post(() -> renderTabsFromOtherDevices(finalDevices, myDeviceId));
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't load other devices' tabs: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }));
    }

    private void renderTabsFromOtherDevices(JSONArray devices, String myDeviceId) {
        List<String> deviceLabels = new ArrayList<>();
        List<JSONArray> deviceTabLists = new ArrayList<>();
        for (int i = 0; i < devices.length(); i++) {
            JSONObject device = devices.optJSONObject(i);
            if (device == null) continue;
            if (myDeviceId.equals(device.optString("device_id"))) continue; // never show my own device as "other"
            JSONArray deviceTabs = device.optJSONArray("tabs");
            if (deviceTabs == null || deviceTabs.length() == 0) continue;
            deviceLabels.add(device.optString("device_label", "Unknown device") + " (" + deviceTabs.length() + " tabs)");
            deviceTabLists.add(deviceTabs);
        }

        if (deviceLabels.isEmpty()) {
            Toast.makeText(this, "No open tabs from other devices yet", Toast.LENGTH_SHORT).show();
            return;
        }

        new AccentDialogBuilder(this)
                .setTitle("Tabs from Other Devices")
                .setItems(deviceLabels.toArray(new String[0]), (d, which) ->
                        showTabsFromOneDevice(deviceLabels.get(which), deviceTabLists.get(which)))
                .setNegativeButton("Close", null)
                .show();
    }

    private void showTabsFromOneDevice(String deviceLabel, JSONArray deviceTabs) {
        List<String> tabLabels = new ArrayList<>();
        List<String> tabUrls = new ArrayList<>();
        for (int i = 0; i < deviceTabs.length(); i++) {
            JSONObject t = deviceTabs.optJSONObject(i);
            if (t == null) continue;
            String url = t.optString("url", "");
            if (url.isEmpty()) continue;
            tabLabels.add(t.optString("title", url));
            tabUrls.add(url);
        }
        if (tabLabels.isEmpty()) {
            Toast.makeText(this, "No tabs to show", Toast.LENGTH_SHORT).show();
            return;
        }

        new AccentDialogBuilder(this)
                .setTitle(deviceLabel)
                .setItems(tabLabels.toArray(new String[0]), (d, which) -> {
                    createNewTab();
                    navigate(tabUrls.get(which));
                })
                .setNegativeButton("Back", null)
                .show();
    }

    // ---- Sync Retry Engine / Offline-first Sync Queue: core methods ----
    private JSONObject loadSyncRetryQueue() {
        try {
            return new JSONObject(prefs.getString("sync_retry_queue", "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private void recordSyncFailure(String type) {
        try {
            JSONObject queue = loadSyncRetryQueue();
            JSONObject existing = queue.optJSONObject(type);
            int attempts = (existing != null ? existing.optInt("attempts", 0) : 0) + 1;
            // 30s, 60s, 120s, 240s, ... capped at 30 minutes so a long
            // outage doesn't mean an eternally-hammering retry loop.
            long backoffMs = Math.min(30_000L * (1L << Math.min(attempts - 1, 6)), 30 * 60_000L);
            JSONObject entry = new JSONObject();
            entry.put("attempts", attempts);
            entry.put("next_retry_at", System.currentTimeMillis() + backoffMs);
            queue.put(type, entry);
            prefs.edit().putString("sync_retry_queue", queue.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void recordSyncSuccess(String type) {
        try {
            JSONObject queue = loadSyncRetryQueue();
            if (queue.has(type)) {
                queue.remove(type);
                prefs.edit().putString("sync_retry_queue", queue.toString()).apply();
            }
        } catch (Exception ignored) {}
    }

    private void retrySyncType(String type) {
        if (backendUrl.isEmpty() || authToken.isEmpty()) return; // nothing to retry against yet
        switch (type) {
            case "bookmarks": syncBookmarksNow(false); break;
            case "history": syncHistoryNow(false); break;
            case "settings": syncSettingsNow(false); break;
            case "tabs": syncTabsNow(null); break;
        }
    }

    // Ticks once a minute; only actually does anything for a sync type
    // whose backoff window has elapsed. Cheap to run constantly since
    // it's almost always a no-op (empty or not-yet-due queue).
    private void startSyncRetryTicker() {
        Runnable tick = new Runnable() {
            @Override
            public void run() {
                drainDueSyncRetries();
                mainHandler.postDelayed(this, 60_000);
            }
        };
        mainHandler.postDelayed(tick, 60_000);
    }

    private void drainDueSyncRetries() {
        if (backendUrl.isEmpty() || authToken.isEmpty()) return;
        JSONObject queue = loadSyncRetryQueue();
        long now = System.currentTimeMillis();
        for (String type : SYNC_TYPES) {
            JSONObject entry = queue.optJSONObject(type);
            if (entry == null) continue;
            if (entry.optLong("next_retry_at", 0) <= now) retrySyncType(type);
        }
    }

    // Offline-first: the moment real connectivity comes back (not just
    // "a network exists" — NET_CAPABILITY_VALIDATED means it can
    // actually reach the internet), immediately drain anything pending
    // instead of waiting for the next once-a-minute tick.
    private void registerSyncConnectivityCallback() {
        connectivityManager = (android.net.ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (connectivityManager == null) return;
        syncNetworkCallback = new android.net.ConnectivityManager.NetworkCallback() {
            @Override
            public void onCapabilitiesChanged(android.net.Network network, android.net.NetworkCapabilities capabilities) {
                if (capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
                    mainHandler.post(MainActivity.this::drainDueSyncRetries);
                }
            }
        };
        try {
            connectivityManager.registerDefaultNetworkCallback(syncNetworkCallback);
        } catch (Exception ignored) {}
    }

    // "Sync Now" — one place that fires all four, instead of the person
    // needing to know these are separate systems under the hood.
    private void syncEverythingNow() {
        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            Toast.makeText(this, "Set Backend Server URL and sign in first (Settings → Account)", Toast.LENGTH_LONG).show();
            return;
        }
        syncSettingsNow(true);
        syncBookmarksNow(true);
        syncHistoryNow(true);
        syncTabsNow(() -> Toast.makeText(this, "Tabs synced", Toast.LENGTH_SHORT).show());
    }

    private void syncSettingsNow() {
        syncSettingsNow(true);
    }

    private void syncSettingsNow(boolean showFeedback) {
        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            if (showFeedback) Toast.makeText(this, "Set Backend Server URL and sign in first (Settings → Account)", Toast.LENGTH_LONG).show();
            return;
        }
        if (showFeedback) Toast.makeText(this, "Syncing settings…", Toast.LENGTH_SHORT).show();

        networkExecutor.execute(() -> {
            try {
                JSONObject getResp = httpGetJson(backendUrl + "/sync/settings", authToken);
                JSONObject remote = getResp.optJSONObject("settings");
                if (remote == null) remote = new JSONObject();
                long remoteUpdatedAt = getResp.optLong("updated_at", 0);

                boolean firstSyncOnThisDevice = !prefs.getBoolean("settings_synced_once", false);
                long lastKnownRemoteUpdatedAt = prefs.getLong("settings_last_synced_remote_at", 0);

                // Cross-device Conflict Resolution: the backend copy
                // changed (from another device) since this device last
                // synced — same "ask before silently overwriting"
                // pattern the Vault already uses for its own checksum
                // conflicts, rather than blind last-write-wins.
                if (!firstSyncOnThisDevice && remoteUpdatedAt > 0 && lastKnownRemoteUpdatedAt > 0
                        && remoteUpdatedAt > lastKnownRemoteUpdatedAt) {
                    JSONObject finalRemote = remote;
                    mainHandler.post(() -> showSettingsConflictDialog(finalRemote, remoteUpdatedAt));
                    return;
                }

                JSONObject toPush;
                if (firstSyncOnThisDevice) {
                    applySettingsSnapshot(remote); // remote seeds this fresh device
                    prefs.edit().putBoolean("settings_synced_once", true).apply();
                    toPush = buildSyncableSettingsSnapshot(); // full whitelist, in case remote was missing keys
                } else {
                    // Local wins for anything local already has an opinion
                    // on; adopt remote-only keys this device has never had.
                    JSONObject localSnapshot = buildSyncableSettingsSnapshot();
                    java.util.Iterator<String> remoteKeys = remote.keys();
                    JSONObject newlyAdopted = new JSONObject();
                    while (remoteKeys.hasNext()) {
                        String key = remoteKeys.next();
                        if (!localSnapshot.has(key)) newlyAdopted.put(key, remote.get(key));
                    }
                    if (newlyAdopted.length() > 0) applySettingsSnapshot(newlyAdopted);
                    toPush = buildSyncableSettingsSnapshot();
                }

                JSONObject pushBody = new JSONObject();
                pushBody.put("settings", toPush);
                JSONObject pushResp = httpPostJson(backendUrl + "/sync/settings", pushBody, authToken);
                prefs.edit().putLong("settings_last_synced_remote_at",
                        pushResp.optLong("updated_at", System.currentTimeMillis() / 1000)).apply();

                recordSyncSuccess("settings");
                if (showFeedback) {
                    mainHandler.post(() -> {
                        Toast.makeText(this, "Settings synced", Toast.LENGTH_SHORT).show();
                        if (isPageShown) showFullPage(buildSettingsView());
                    });
                }
            } catch (Exception e) {
                recordSyncFailure("settings");
                if (showFeedback) {
                    mainHandler.post(() ->
                            Toast.makeText(this, "Sync failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            }
        });
    }

    private void showSettingsConflictDialog(JSONObject remote, long remoteUpdatedAt) {
        new AccentDialogBuilder(this)
                .setTitle("Settings Changed Elsewhere")
                .setMessage("Your settings were changed on another device since this device last synced. Choose which version to keep.")
                .setPositiveButton("Keep This Device's Settings", (d, w) -> networkExecutor.execute(() -> {
                    try {
                        JSONObject toPush = buildSyncableSettingsSnapshot();
                        JSONObject pushBody = new JSONObject();
                        pushBody.put("settings", toPush);
                        JSONObject pushResp = httpPostJson(backendUrl + "/sync/settings", pushBody, authToken);
                        prefs.edit().putLong("settings_last_synced_remote_at",
                                pushResp.optLong("updated_at", System.currentTimeMillis() / 1000)).apply();
                        recordSyncSuccess("settings");
                        mainHandler.post(() -> Toast.makeText(this, "Settings synced", Toast.LENGTH_SHORT).show());
                    } catch (Exception e) {
                        recordSyncFailure("settings");
                        mainHandler.post(() -> Toast.makeText(this, "Sync failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
                    }
                }))
                .setNegativeButton("Use Other Device's Settings", (d, w) -> {
                    applySettingsSnapshot(remote);
                    prefs.edit().putLong("settings_last_synced_remote_at", remoteUpdatedAt).apply();
                    recordSyncSuccess("settings");
                    Toast.makeText(this, "Applied the other device's settings", Toast.LENGTH_SHORT).show();
                    if (isPageShown) showFullPage(buildSettingsView());
                })
                .show();
    }

    private void syncHistoryNow() {
        syncHistoryNow(true);
    }

    private void syncHistoryNow(boolean showFeedback) {
        if (authToken.isEmpty()) {
            if (showFeedback) Toast.makeText(this, "Sign in first (Settings → Account)", Toast.LENGTH_LONG).show();
            return;
        }
        if (showFeedback) Toast.makeText(this, "Syncing…", Toast.LENGTH_SHORT).show();

        networkExecutor.execute(() -> {
            try {
                JSONObject getResp = httpGetJson(backendUrl + "/sync/history", authToken);
                JSONArray remoteArr = getResp.optJSONArray("history");
                if (remoteArr == null) remoteArr = new JSONArray();

                Map<String, JSONObject> merged = new LinkedHashMap<>();
                for (int i = 0; i < remoteArr.length(); i++) {
                    JSONObject h = remoteArr.getJSONObject(i);
                    merged.put(h.optString("url"), h);
                }
                for (JSONObject h : loadHistorySortedByRecency()) {
                    String url = h.optString("url");
                    JSONObject existing = merged.get(url);
                    if (existing == null) {
                        merged.put(url, h);
                        continue;
                    }
                    long localTs = h.optLong("ts", 0);
                    long remoteTs = existing.optLong("ts", 0);
                    JSONObject mergedEntry = new JSONObject();
                    mergedEntry.put("url", url);
                    mergedEntry.put("title", localTs >= remoteTs ? h.optString("title") : existing.optString("title"));
                    mergedEntry.put("count", Math.max(existing.optInt("count", 1), h.optInt("count", 1)));
                    mergedEntry.put("ts", Math.max(localTs, remoteTs));
                    merged.put(url, mergedEntry);
                }

                List<JSONObject> mergedList = new ArrayList<>(merged.values());
                mergedList.sort((a, b) -> Long.compare(a.optLong("ts", 0), b.optLong("ts", 0)));
                if (mergedList.size() > 200) {
                    mergedList = mergedList.subList(mergedList.size() - 200, mergedList.size());
                }

                JSONArray mergedArr = new JSONArray();
                for (JSONObject h : mergedList) mergedArr.put(h);
                prefs.edit().putString("history", mergedArr.toString()).apply();

                JSONObject pushBody = new JSONObject();
                pushBody.put("history", mergedArr);
                httpPostJson(backendUrl + "/sync/history", pushBody, authToken);

                recordSyncSuccess("history");
                int finalCount = merged.size();
                if (showFeedback) {
                    mainHandler.post(() -> {
                        Toast.makeText(this, "History synced (" + finalCount + ")", Toast.LENGTH_SHORT).show();
                        showUniversalPanel(buildBookmarksHistoryView(false));
                    });
                }
            } catch (Exception e) {
                recordSyncFailure("history");
                if (showFeedback) {
                    mainHandler.post(() ->
                            Toast.makeText(this, "Sync failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            }
        });
    }

    private void syncBookmarksNow() {
        syncBookmarksNow(true);
    }

    private void syncBookmarksNow(boolean showFeedback) {
        if (authToken.isEmpty()) {
            if (showFeedback) Toast.makeText(this, "Sign in first (Settings → Account)", Toast.LENGTH_LONG).show();
            return;
        }
        if (showFeedback) Toast.makeText(this, "Syncing…", Toast.LENGTH_SHORT).show();

        networkExecutor.execute(() -> {
            try {
                JSONObject getResp = httpGetJson(backendUrl + "/sync/bookmarks", authToken);
                JSONArray remoteArr = getResp.optJSONArray("bookmarks");
                if (remoteArr == null) remoteArr = new JSONArray();

                Map<String, JSONObject> merged = new LinkedHashMap<>();
                for (int i = 0; i < remoteArr.length(); i++) {
                    JSONObject b = remoteArr.getJSONObject(i);
                    merged.put(b.optString("url"), b);
                }
                for (JSONObject b : loadBookmarks()) {
                    merged.put(b.optString("url"), b); // local wins conflicts
                }

                JSONArray mergedArr = new JSONArray();
                for (JSONObject b : merged.values()) mergedArr.put(b);
                prefs.edit().putString("bookmarks", mergedArr.toString()).apply();

                JSONObject pushBody = new JSONObject();
                pushBody.put("bookmarks", mergedArr);
                httpPostJson(backendUrl + "/sync/bookmarks", pushBody, authToken);

                recordSyncSuccess("bookmarks");
                if (showFeedback) {
                    int finalCount = merged.size();
                    mainHandler.post(() -> {
                        Toast.makeText(this, "Bookmarks synced (" + finalCount + ")", Toast.LENGTH_SHORT).show();
                        showUniversalPanel(buildBookmarksHistoryView(true));
                    });
                }
            } catch (Exception e) {
                recordSyncFailure("bookmarks");
                if (showFeedback) {
                    mainHandler.post(() ->
                            Toast.makeText(this, "Sync failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            }
        });
    }

    // ================================================================
    // VAULT PASSPHRASE — a SEPARATE secret from the login password,
    // never sent to the backend in any form. Used to derive an AES-256
    // key (PBKDF2, 120k iterations) that encrypts saved passwords before
    // they ever leave the device for backend sync — so the server only
    // ever stores ciphertext it has no way to read, closing the gap
    // where on-device storage was genuinely AES-256/Keystore-encrypted
    // but the backend copy was previously being sent and stored as
    // plain text. Only the salt (not secret) and the resulting derived
    // key (cached locally, Keystore-encrypted, so the app isn't
    // reprompting every sync) ever get written anywhere.
    // ================================================================
    private static final int VAULT_PBKDF2_ITERATIONS = 120000;
    private static final int VAULT_KEY_LENGTH_BITS = 256;

    private byte[] getOrCreateVaultSalt() {
        String existing = securePrefs.getString("vault_salt", "");
        if (!existing.isEmpty()) {
            return android.util.Base64.decode(existing, android.util.Base64.NO_WRAP);
        }
        byte[] salt = new byte[16];
        new java.security.SecureRandom().nextBytes(salt);
        securePrefs.edit().putString("vault_salt",
                android.util.Base64.encodeToString(salt, android.util.Base64.NO_WRAP)).apply();
        return salt;
    }

    private javax.crypto.SecretKey deriveVaultKey(String passphrase, byte[] salt) throws Exception {
        javax.crypto.SecretKeyFactory factory = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        javax.crypto.spec.PBEKeySpec spec = new javax.crypto.spec.PBEKeySpec(
                passphrase.toCharArray(), salt, VAULT_PBKDF2_ITERATIONS, VAULT_KEY_LENGTH_BITS);
        byte[] keyBytes = factory.generateSecret(spec).getEncoded();
        return new javax.crypto.spec.SecretKeySpec(keyBytes, "AES");
    }

    private javax.crypto.SecretKey getCachedVaultKey() {
        String cached = securePrefs.getString("vault_key_cache", "");
        if (cached.isEmpty()) return null;
        byte[] keyBytes = android.util.Base64.decode(cached, android.util.Base64.NO_WRAP);
        return new javax.crypto.spec.SecretKeySpec(keyBytes, "AES");
    }

    private void cacheVaultKey(javax.crypto.SecretKey key) {
        securePrefs.edit().putString("vault_key_cache",
                android.util.Base64.encodeToString(key.getEncoded(), android.util.Base64.NO_WRAP)).apply();
    }

    private boolean hasVaultPassphraseSetUp() {
        return getCachedVaultKey() != null;
    }

    // ---- Generic AES-256-GCM encrypt/decrypt for any JSON text using the
    // Vault Passphrase-derived key — bookmarks/history/shortcuts use this
    // now too (End-to-End Encrypted Vault, #32), not just passwords.
    // Passwords keep their own dedicated method below since its call
    // sites already exist and work; this is the shared engine both use. ----
    private String encryptJsonForSync(String jsonText, javax.crypto.SecretKey key) throws Exception {
        byte[] iv = new byte[12];
        new java.security.SecureRandom().nextBytes(iv);
        javax.crypto.Cipher cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding");
        javax.crypto.spec.GCMParameterSpec spec = new javax.crypto.spec.GCMParameterSpec(128, iv);
        cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, key, spec);
        byte[] cipherText = cipher.doFinal(jsonText.getBytes(StandardCharsets.UTF_8));
        byte[] combined = new byte[iv.length + cipherText.length];
        System.arraycopy(iv, 0, combined, 0, iv.length);
        System.arraycopy(cipherText, 0, combined, iv.length, cipherText.length);
        return android.util.Base64.encodeToString(combined, android.util.Base64.NO_WRAP);
    }

    private String decryptJsonFromSync(String base64Combined, javax.crypto.SecretKey key) throws Exception {
        byte[] combined = android.util.Base64.decode(base64Combined, android.util.Base64.NO_WRAP);
        byte[] iv = java.util.Arrays.copyOfRange(combined, 0, 12);
        byte[] cipherText = java.util.Arrays.copyOfRange(combined, 12, combined.length);
        javax.crypto.Cipher cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding");
        javax.crypto.spec.GCMParameterSpec spec = new javax.crypto.spec.GCMParameterSpec(128, iv);
        cipher.init(javax.crypto.Cipher.DECRYPT_MODE, key, spec);
        byte[] plain = cipher.doFinal(cipherText);
        return new String(plain, StandardCharsets.UTF_8);
    }

    private String encryptPasswordsForSync(JSONArray passwordsArr, javax.crypto.SecretKey key) throws Exception {
        return encryptJsonForSync(passwordsArr.toString(), key);
    }

    private void showVaultPassphraseSetupDialog(Runnable onReady) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(32, 16, 32, 16);

        EditText passInput = new EditText(this);
        passInput.setHint("Vault Passphrase");
        passInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        passInput.setTextColor(getColor(R.color.text_primary));
        passInput.setHintTextColor(getColor(R.color.text_dim));
        form.addView(passInput);

        EditText confirmInput = new EditText(this);
        confirmInput.setHint("Confirm Passphrase");
        confirmInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        confirmInput.setTextColor(getColor(R.color.text_primary));
        confirmInput.setHintTextColor(getColor(R.color.text_dim));
        LinearLayout.LayoutParams confirmParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        confirmParams.topMargin = 12;
        confirmInput.setLayoutParams(confirmParams);
        form.addView(confirmInput);

        new AccentDialogBuilder(this)
                .setTitle("Vault Passphrase")
                .setMessage("This protects your ENTIRE vault backup — passwords, bookmarks, history, and shortcuts — before any of it ever leaves your phone. Your backend server only ever stores encrypted data it can't read. It's separate from your account login password.\n\n⚠️ If you forget it, this backup on the server can never be recovered — there's no reset for this, by design. Everything saved on THIS device stays safe either way.")
                .setView(form)
                .setPositiveButton("Set Passphrase", (d, w) -> {
                    String p1 = passInput.getText().toString();
                    String p2 = confirmInput.getText().toString();
                    if (p1.length() < 6) {
                        Toast.makeText(this, "Use at least 6 characters", Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (!p1.equals(p2)) {
                        Toast.makeText(this, "Passphrases don't match", Toast.LENGTH_LONG).show();
                        return;
                    }
                    try {
                        byte[] salt = getOrCreateVaultSalt();
                        javax.crypto.SecretKey key = deriveVaultKey(p1, salt);
                        cacheVaultKey(key);
                        Toast.makeText(this, "Vault Passphrase set", Toast.LENGTH_SHORT).show();
                        if (onReady != null) onReady.run();
                    } catch (Exception e) {
                        Toast.makeText(this, "Couldn't set passphrase: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ================================================================
    // VAULT — one combined, END-TO-END ENCRYPTED backup (#32: passwords,
    // bookmarks, history, AND shortcuts are all encrypted client-side with
    // the Vault Passphrase before this method ever builds the request body
    // — the backend only ever stores/returns ciphertext it can't read for
    // any of them). Auto-triggered every time a password is saved; also
    // available as a manual "Sync Now" from the Passwords screen.
    // Silently no-ops if backend/account aren't configured.
    //
    // Merge-safe Sync (#37): before pushing, checks whether another
    // device changed this account's vault since THIS device last synced
    // (comparing checksums) — if so, stops and asks rather than silently
    // overwriting whatever changed elsewhere. This is real conflict
    // DETECTION, not automatic three-way merging (that would need
    // decrypting and reconciling the other device's changes locally,
    // which this app doesn't do — there's no restore-into-app flow yet,
    // only restore-on-the-backend via Backup History). The honest,
    // safe behavior here is: warn clearly, let the user decide, never
    // guess silently.
    // ================================================================
    private void syncFullVaultToBackend() {
        if (backendUrl.isEmpty() || authToken.isEmpty()) return;

        javax.crypto.SecretKey vaultKey = getCachedVaultKey();
        if (vaultKey == null) {
            // The Vault Passphrase now protects the WHOLE backup (not just
            // passwords), so it's needed before ANY vault sync, not only
            // when there happen to be saved passwords.
            showVaultPassphraseSetupDialog(this::syncFullVaultToBackend);
            return;
        }

        networkExecutor.execute(() -> {
            try {
                String lastKnownChecksum = prefs.getString("last_synced_vault_checksum", "");
                if (!lastKnownChecksum.isEmpty()) {
                    try {
                        JSONObject checkResp = httpGetJson(backendUrl + "/vault/checksum", authToken);
                        String remoteChecksum = checkResp.isNull("checksum") ? "" : checkResp.optString("checksum", "");
                        if (!remoteChecksum.isEmpty() && !remoteChecksum.equals(lastKnownChecksum)) {
                            mainHandler.post(this::showVaultConflictDialog);
                            return;
                        }
                    } catch (Exception ignored) {
                        // Couldn't check (offline, backend hiccup) — proceed
                        // rather than blocking a routine sync on that.
                    }
                }
                pushVaultToBackend(vaultKey);
            } catch (Exception ignored) {
                // best-effort background sync — user can retry via "Sync Now"
            }
        });
    }

    // ---- The actual push, used both by the normal (conflict-checked)
    // path above and directly once the user has explicitly confirmed an
    // overwrite from the conflict dialog. ----
    private void pushVaultToBackend(javax.crypto.SecretKey vaultKey) throws Exception {
        JSONArray bookmarksArr = new JSONArray();
        for (JSONObject b : loadBookmarks()) bookmarksArr.put(b);

        JSONArray historyArr = new JSONArray(prefs.getString("history", "[]"));

        JSONArray shortcutsArr = new JSONArray();
        for (Shortcut s : shortcuts) {
            JSONObject o = new JSONObject();
            o.put("name", s.name);
            o.put("url", s.url);
            o.put("color", s.color);
            shortcutsArr.put(o);
        }

        JSONObject body = new JSONObject();
        body.put("bookmarks_encrypted", encryptJsonForSync(bookmarksArr.toString(), vaultKey));
        body.put("history_encrypted", encryptJsonForSync(historyArr.toString(), vaultKey));
        body.put("shortcuts_encrypted", encryptJsonForSync(shortcutsArr.toString(), vaultKey));
        body.put("vault_salt", android.util.Base64.encodeToString(getOrCreateVaultSalt(), android.util.Base64.NO_WRAP));

        List<SavedCredential> creds = loadCredentials();
        if (!creds.isEmpty()) {
            JSONArray passwordsArr = new JSONArray();
            for (SavedCredential c : creds) {
                JSONObject o = new JSONObject();
                o.put("domain", c.domain);
                o.put("username", c.username);
                o.put("password", c.password);
                passwordsArr.put(o);
            }
            body.put("passwords_encrypted", encryptPasswordsForSync(passwordsArr, vaultKey));
        }

        JSONObject resp = httpPostJson(backendUrl + "/vault/sync", body, authToken);
        String newChecksum = resp.optString("checksum", "");
        if (!newChecksum.isEmpty()) {
            prefs.edit().putString("last_synced_vault_checksum", newChecksum).apply();
        }
    }

    private void showVaultConflictDialog() {
        new AccentDialogBuilder(this)
                .setTitle("Vault Updated Elsewhere")
                .setMessage("Your account's vault backup was changed from another device since this device last synced. Overwriting now replaces that version with what's on THIS device.\n\nIf you'd rather keep the other device's changes, check Security Center → Backup History first — you can restore an earlier version there before continuing.")
                .setPositiveButton("Overwrite With This Device", (d, w) -> {
                    javax.crypto.SecretKey vaultKey = getCachedVaultKey();
                    if (vaultKey == null) return;
                    networkExecutor.execute(() -> {
                        try {
                            pushVaultToBackend(vaultKey);
                            mainHandler.post(() -> Toast.makeText(this, "Vault synced", Toast.LENGTH_SHORT).show());
                        } catch (Exception e) {
                            mainHandler.post(() -> Toast.makeText(this, "Sync failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
                        }
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void syncFullVaultToBackendWithFeedback() {
        if (authToken.isEmpty()) {
            Toast.makeText(this, "Sign in first (Settings → Account)", Toast.LENGTH_LONG).show();
            return;
        }
        if (backendUrl.isEmpty()) {
            Toast.makeText(this, "Set your Backend Server URL first", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Syncing vault…", Toast.LENGTH_SHORT).show();
        syncFullVaultToBackend();
        mainHandler.postDelayed(() ->
                Toast.makeText(this, "Vault synced", Toast.LENGTH_SHORT).show(), 1200);
    }

    // ================================================================
    // SECURE VAULT BACKUP (#36) — Backup History: every time a sync
    // actually changes the stored vault, the backend archives the
    // PREVIOUS version (keeps the last 5) before overwriting — so an
    // accidental bad sync/overwrite is recoverable, not just a single
    // row that's always the latest and nothing else. Also surfaces
    // server-side integrity verification (checksum match) so a corrupted
    // backup is detectable instead of silently trusted.
    // ================================================================
    private View buildVaultBackupsView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("Backup History", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(24, 20, 24, 24);
        scroll.addView(list);
        root.addView(scroll);

        TextView loading = new TextView(this);
        loading.setText("Loading…");
        loading.setTextColor(getColor(R.color.text_dim));
        loading.setTextSize(11);
        list.addView(loading);

        networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(backendUrl + "/vault/backups", authToken);
                JSONArray backups = resp.optJSONArray("backups");
                mainHandler.post(() -> {
                    list.removeAllViews();
                    if (backups == null || backups.length() == 0) {
                        list.addView(buildEmptyState("No earlier backups yet — one gets saved automatically the next time your vault changes on another device or gets re-synced"));
                        return;
                    }
                    for (int i = 0; i < backups.length(); i++) {
                        try {
                            list.addView(buildVaultBackupRow(backups.getJSONObject(i)));
                        } catch (Exception ignored) {}
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    list.removeAllViews();
                    TextView error = new TextView(this);
                    error.setText("Couldn't load backup history: " + e.getMessage());
                    error.setTextColor(ThemeManager.getAccentColor(this));
                    error.setTextSize(11);
                    list.addView(error);
                });
            }
        });

        return root;
    }

    private View buildVaultBackupRow(JSONObject backup) throws Exception {
        int backupId = backup.optInt("backup_id", -1);
        long createdAt = backup.optLong("created_at", 0);
        String checksum = backup.optString("checksum", "");

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(16, 16, 16, 16);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 8;
        row.setLayoutParams(rowParams);
        row.setBackgroundResource(R.drawable.bg_tab_inactive);

        TextView dateView = new TextView(this);
        dateView.setText(new java.text.SimpleDateFormat("d MMM yyyy, h:mm a", Locale.US).format(new java.util.Date(createdAt * 1000)));
        dateView.setTextColor(getColor(R.color.text_primary));
        dateView.setTextSize(12);
        row.addView(dateView);

        TextView checksumView = new TextView(this);
        checksumView.setText(checksum.length() > 12 ? checksum.substring(0, 12) + "…" : checksum);
        checksumView.setTextColor(getColor(R.color.text_dim));
        checksumView.setTextSize(9);
        LinearLayout.LayoutParams checksumParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        checksumParams.topMargin = 4;
        checksumView.setLayoutParams(checksumParams);
        row.addView(checksumView);

        TextView restoreBtn = new TextView(this);
        restoreBtn.setText("Restore This Version");
        restoreBtn.setTextColor(getColor(R.color.gold));
        restoreBtn.setTextSize(11);
        restoreBtn.setPadding(0, 12, 0, 0);
        restoreBtn.setOnClickListener(v -> new AccentDialogBuilder(this)
                .setTitle("Restore Backup")
                .setMessage("This replaces the CURRENT vault backup on the server with this earlier version. The current version is archived first, so this itself can be undone too.")
                .setPositiveButton("Restore", (d, w) -> {
                    networkExecutor.execute(() -> {
                        try {
                            httpPostJson(backendUrl + "/vault/backups/" + backupId + "/restore", new JSONObject(), authToken);
                            mainHandler.post(() -> {
                                Toast.makeText(this, "Backup restored", Toast.LENGTH_SHORT).show();
                                showFullPage(buildVaultBackupsView());
                            });
                        } catch (Exception e) {
                            mainHandler.post(() -> Toast.makeText(this, "Restore failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
                        }
                    });
                })
                .setNegativeButton("Cancel", null)
                .show());
        row.addView(restoreBtn);

        return row;
    }

    // ---- Real file download via Android's Download Manager, with the
    // auth header attached, saved to the public Downloads folder ----
    private void downloadVaultFile() {
        if (authToken.isEmpty()) {
            Toast.makeText(this, "Sign in first (Settings → Account)", Toast.LENGTH_LONG).show();
            return;
        }
        if (backendUrl.isEmpty()) {
            Toast.makeText(this, "Set your Backend Server URL first", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(backendUrl + "/vault/download"));
            request.addRequestHeader("Authorization", "Bearer " + authToken);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "nex-vault.json");
            request.allowScanningByMediaScanner();

            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            dm.enqueue(request);
            Toast.makeText(this, hasVaultPassphraseSetUp()
                    ? "Downloading vault file — contents are encrypted (need your Vault Passphrase elsewhere to read them)"
                    : "Downloading vault file to Downloads…", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Download failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // ================================================================
    // AUTOMATION (AGENT) — write an instruction, Claude (on the backend)
    // breaks it into browser steps, THIS app executes them for real in
    // its own WebView (your session/cookies), reports progress back, and
    // the same job is readable/controllable via the backend API too
    // (view progress, cancel, delete, reorder, "create API" for any job).
    // Multiple tasks queue up and run one after another automatically.
    // ================================================================
    private View buildAutomationView() {
        // Agent Permission Firewall (#79) / Agent Policy Engine (#80):
        // lazy, once-per-session fetch — cheap, and avoids a GET on
        // every rebuild of this view (which happens on every job status
        // change while the screen is open).
        if (!agentFirewallLoaded) {
            agentFirewallLoaded = true;
            fetchAgentFirewallConfig();
        }
        if (!agentPolicyLoaded) {
            agentPolicyLoaded = true;
            fetchAgentPolicyConfig();
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(buildPageHeader("Automation", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(24, 16, 24, 24);
        scroll.addView(content);
        root.addView(scroll);

        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            TextView warn = new TextView(this);
            warn.setText("Set your Backend Server URL and sign in (Settings) first — Automation needs both.");
            warn.setTextColor(getColor(R.color.text_dim));
            warn.setTextSize(10.5f);
            warn.setPadding(0, 0, 0, 20);
            content.addView(warn);
        }

        // Instruction input + Add Task
        EditText instructionInput = new EditText(this);
        instructionInput.setHint("e.g. search cats on youtube and get the first video's transcript");
        instructionInput.setTextColor(getColor(R.color.text_primary));
        instructionInput.setHintTextColor(getColor(R.color.text_dim));
        instructionInput.setMinLines(2);
        instructionInput.setBackgroundResource(R.drawable.bg_omnibox);
        instructionInput.setPadding(24, 20, 24, 20);
        content.addView(instructionInput);

        // Goal-Based Agent (#71): checked, the box above is treated as a
        // GOAL rather than a fixed instruction — the AI decides one
        // action at a time as the task actually unfolds instead of
        // planning every step upfront, which handles open-ended or
        // unpredictable tasks a fixed plan would get stuck on.
        android.widget.CheckBox goalModeCheck = new android.widget.CheckBox(this);
        goalModeCheck.setText("🎯 Goal mode — AI decides each step live, no fixed plan upfront");
        goalModeCheck.setTextColor(getColor(R.color.text_dim));
        goalModeCheck.setTextSize(9.5f);
        LinearLayout.LayoutParams goalModeParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        goalModeParams.topMargin = 10;
        goalModeCheck.setLayoutParams(goalModeParams);
        content.addView(goalModeCheck);

        // Agent-to-Agent Verification (#73): checked, a SECOND independent
        // AI call reviews this job's own claimed final result against a
        // real screenshot before it's allowed to be marked truly "done" —
        // catches a confidently-wrong "task complete" claim instead of
        // trusting it outright. Applies to either mode above.
        android.widget.CheckBox verifyResultCheck = new android.widget.CheckBox(this);
        verifyResultCheck.setText("✅ Verify result — double-check the AI's own \"done\" claim before trusting it");
        verifyResultCheck.setTextColor(getColor(R.color.text_dim));
        verifyResultCheck.setTextSize(9.5f);
        LinearLayout.LayoutParams verifyResultParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        verifyResultParams.topMargin = 4;
        verifyResultCheck.setLayoutParams(verifyResultParams);
        content.addView(verifyResultCheck);

        // Agent Sandbox (#76): checked, this job's lane WebView gets its
        // cache/history/form-data wiped right before the job starts (and
        // again once it ends) and blocks third-party cookies for the
        // duration — so the agent can't ride along on anything cached
        // from your regular browsing, and doesn't leave its own traces
        // behind either. Note: this clears/isolates that WebView
        // instance's transient state, not a fully separate cookie jar —
        // Android WebView's first-party cookie store is shared
        // process-wide and can't be split per-job without a much bigger
        // architecture change.
        android.widget.CheckBox sandboxCheck = new android.widget.CheckBox(this);
        sandboxCheck.setText("🧪 Sandbox mode — wipe this task's browsing data before/after");
        sandboxCheck.setTextColor(getColor(R.color.text_dim));
        sandboxCheck.setTextSize(9.5f);
        LinearLayout.LayoutParams sandboxParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        sandboxParams.topMargin = 4;
        sandboxCheck.setLayoutParams(sandboxParams);
        content.addView(sandboxCheck);

        // Dry Run Mode (#77): checked, this job gets fully PLANNED (its
        // step list is visible right away, same stepper as any job) but
        // the queue skips it until explicitly confirmed — nothing
        // actually clicks, types, or navigates until the user reviews
        // the plan and taps "▶️ Run for Real" from the job card's ⋮ menu.
        android.widget.CheckBox dryRunCheck = new android.widget.CheckBox(this);
        dryRunCheck.setText("📝 Dry run — plan only, review steps before anything runs");
        dryRunCheck.setTextColor(getColor(R.color.text_dim));
        dryRunCheck.setTextSize(9.5f);
        LinearLayout.LayoutParams dryRunParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        dryRunParams.topMargin = 4;
        dryRunCheck.setLayoutParams(dryRunParams);
        content.addView(dryRunCheck);

        // Human Approval Layer (#78): checked, a click or form-fill step
        // whose target text looks consequential (checkout, delete, pay,
        // etc.) pauses for your explicit OK before it runs, instead of
        // only catching that reactively the way Self-Healing (#57) does
        // for its own replacement guesses.
        android.widget.CheckBox requireApprovalCheck = new android.widget.CheckBox(this);
        requireApprovalCheck.setText("🔔 Require approval for sensitive actions (buy, delete, pay, send…)");
        requireApprovalCheck.setTextColor(getColor(R.color.text_dim));
        requireApprovalCheck.setTextSize(9.5f);
        LinearLayout.LayoutParams requireApprovalParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        requireApprovalParams.topMargin = 4;
        requireApprovalCheck.setLayoutParams(requireApprovalParams);
        content.addView(requireApprovalCheck);

        TextView addBtn = new TextView(this);
        addBtn.setText("+ Add Task");
        addBtn.setTextColor(getColor(R.color.gold));
        addBtn.setTextSize(12);
        addBtn.setGravity(android.view.Gravity.CENTER);
        addBtn.setPadding(20, 20, 20, 20);
        addBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams addBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        addBtnParams.topMargin = 12;
        addBtnParams.bottomMargin = 20;
        addBtn.setLayoutParams(addBtnParams);
        addBtn.setOnClickListener(v -> {
            String instruction = instructionInput.getText().toString().trim();
            if (instruction.isEmpty()) {
                Toast.makeText(this, "Type a task first", Toast.LENGTH_SHORT).show();
                return;
            }
            if (goalModeCheck.isChecked()) {
                addGoalTask(instruction, verifyResultCheck.isChecked(), sandboxCheck.isChecked(), dryRunCheck.isChecked(), requireApprovalCheck.isChecked());
            } else {
                addAutomationTask(instruction, verifyResultCheck.isChecked(), sandboxCheck.isChecked(), dryRunCheck.isChecked(), requireApprovalCheck.isChecked());
            }
        });
        content.addView(addBtn);

        // Batch API (#88): plan + queue several tasks in one go instead
        // of typing them in one at a time.
        TextView batchBtn = new TextView(this);
        batchBtn.setText("+ Add as Batch (multiple tasks)");
        batchBtn.setTextColor(getColor(R.color.text_dim));
        batchBtn.setTextSize(10.5f);
        batchBtn.setGravity(android.view.Gravity.CENTER);
        batchBtn.setPadding(20, 16, 20, 16);
        LinearLayout.LayoutParams batchBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        batchBtnParams.bottomMargin = 20;
        batchBtn.setLayoutParams(batchBtnParams);
        batchBtn.setOnClickListener(v -> showBatchTaskDialog());
        content.addView(batchBtn);

        // Multi-Agent Orchestrator (#72): unlike Batch (#88) above — where
        // YOU type out each separate task by hand — this takes ONE bigger
        // goal typed in the box up top and has the AI break it into an
        // ordered chain of sub-tasks itself, running them one after
        // another and feeding each sub-task the previous one's actual
        // result as context (a plain depends_on chain only waits for
        // completion, it doesn't pass anything forward).
        TextView orchestrateBtn = new TextView(this);
        orchestrateBtn.setText("🧩 Orchestrate (AI splits this into a chain of sub-tasks)");
        orchestrateBtn.setTextColor(getColor(R.color.text_dim));
        orchestrateBtn.setTextSize(10.5f);
        orchestrateBtn.setGravity(android.view.Gravity.CENTER);
        orchestrateBtn.setPadding(20, 16, 20, 16);
        LinearLayout.LayoutParams orchestrateBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        orchestrateBtnParams.bottomMargin = 20;
        orchestrateBtn.setLayoutParams(orchestrateBtnParams);
        orchestrateBtn.setOnClickListener(v -> {
            String goal = instructionInput.getText().toString().trim();
            if (goal.isEmpty()) {
                Toast.makeText(this, "Type a goal first", Toast.LENGTH_SHORT).show();
                return;
            }
            addOrchestrationTask(goal);
        });
        content.addView(orchestrateBtn);

        // Autopilot: AI drives the CURRENT VISIBLE TAB live, one step at a
        // time, deciding each next action from an actual screenshot —
        // unlike the fixed-upfront-plan tasks above, this watches the page
        // and re-decides after every action. Needs the user's own API key
        // (Settings → Account → Autopilot API Key).
        TextView autopilotBtn = new TextView(this);
        autopilotBtn.setText("🤖 Autopilot (AI drives your current tab)");
        autopilotBtn.setTextColor(getColor(R.color.gold));
        autopilotBtn.setTextSize(10.5f);
        autopilotBtn.setGravity(android.view.Gravity.CENTER);
        autopilotBtn.setPadding(20, 16, 20, 16);
        autopilotBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams autopilotBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        autopilotBtnParams.bottomMargin = 20;
        autopilotBtn.setLayoutParams(autopilotBtnParams);
        autopilotBtn.setOnClickListener(v -> showAutopilotGoalDialog());
        content.addView(autopilotBtn);

        // Small attached previews — one per parallel automation lane (#90).
        // These WebViews are what actually execute steps; kept small and
        // visible (not hidden) so pages render/behave normally.
        for (int lane = 0; lane < MAX_PARALLEL_AUTOMATION_JOBS; lane++) {
            Integer laneJobId = currentAutomationJobIds[lane];
            TextView laneLabel = new TextView(this);
            laneLabel.setText(laneJobId != null ? "Lane " + (lane + 1) + " — running Task #" + laneJobId : "Lane " + (lane + 1) + " — idle");
            laneLabel.setTextColor(getColor(R.color.text_dim));
            laneLabel.setTextSize(8.5f);
            LinearLayout.LayoutParams laneLabelParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            laneLabelParams.topMargin = lane == 0 ? 0 : 8;
            laneLabel.setLayoutParams(laneLabelParams);
            content.addView(laneLabel);

            FrameLayout previewWrap = new FrameLayout(this);
            LinearLayout.LayoutParams previewWrapParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 180);
            previewWrapParams.topMargin = 6;
            previewWrap.setLayoutParams(previewWrapParams);
            previewWrap.setBackgroundColor(getColor(R.color.bg_secondary));
            WebView webView = getOrCreateAutomationWebView(lane);
            if (webView.getParent() != null) ((ViewGroup) webView.getParent()).removeView(webView);
            previewWrap.addView(webView);
            content.addView(previewWrap);
        }
        TextView previewsSpacer = new TextView(this);
        LinearLayout.LayoutParams previewsSpacerParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        previewsSpacerParams.bottomMargin = 14;
        previewsSpacer.setLayoutParams(previewsSpacerParams);
        content.addView(previewsSpacer);

        TextView jobsLabel = new TextView(this);
        jobsLabel.setText("YOUR TASKS");
        jobsLabel.setTextColor(ThemeManager.getAccentColor(this));
        jobsLabel.setTextSize(10);
        jobsLabel.setLetterSpacing(0.06f);
        content.addView(jobsLabel);

        LinearLayout jobsList = new LinearLayout(this);
        jobsList.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams jobsListParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        jobsListParams.topMargin = 12;
        jobsList.setLayoutParams(jobsListParams);
        content.addView(jobsList);

        if (automationJobsCache.isEmpty()) {
            jobsList.addView(buildEmptyState("No tasks yet — add one above"));
        } else {
            for (JSONObject job : automationJobsCache.values()) {
                jobsList.addView(buildAutomationJobCard(job));
            }
        }

        // Refresh from backend every time this screen opens
        if (!backendUrl.isEmpty() && !authToken.isEmpty()) {
            refreshAutomationJobs(() -> {
                if (isPageShown) showFullPage(buildAutomationView());
                // Picks up any job left "running" from a previous app
                // session (interrupted mid-task) from where it left off,
                // or starts the next queued one if nothing was interrupted.
                maybeStartAutomationQueue();
            });
        }

        return root;
    }

    private WebView getOrCreateAutomationWebView(int lane) {
        if (automationWebViews[lane] != null) return automationWebViews[lane];

        WebView wv = new WebView(this);
        wv.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setUserAgentString(s.getUserAgentString().replace("; wv", ""));

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                // Agent Permission Firewall (#79): defense in depth
                // alongside the "navigate" action's own check — a click
                // or a page's own redirect can lead anywhere a link
                // points, not just where the AI explicitly planned to go.
                String url = (request != null && request.getUrl() != null) ? request.getUrl().toString() : null;
                if (url == null || isDomainAllowed(url)) return false;
                StepContext ctx = activeStepContexts[lane];
                if (ctx != null && pendingAutomationContinuations[lane] != null) {
                    cancelStepTimeout(lane);
                    pendingAutomationContinuations[lane] = null;
                    activeStepContexts[lane] = null;
                    String reason = "🔥 Blocked by firewall: " + safeUrlHost(url);
                    reportAutomationStep(lane, ctx.jobId, ctx.index, reason, false, null, reason);
                    executeAutomationStep(lane, ctx.jobId, ctx.steps, ctx.index + 1);
                }
                return true; // cancel the navigation regardless of whether a step was tracking it
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Browser Agent OS (#116): agent-visited pages feed into
                // the SAME AI Web Memory (#101) regular browsing does —
                // so Semantic History Search (#102) and the Timeline
                // (#103) also surface what automation jobs discovered,
                // not just what the user browsed by hand. One of the
                // concrete pieces of "the agent system and the browsing
                // system share one memory" rather than staying separate.
                if (pendingAutomationContinuations[lane] != null && url != null && !url.startsWith("about:")) {
                    trackVisit(url, view.getTitle(), view);
                }
                if (pendingAutomationContinuations[lane] != null) {
                    cancelStepTimeout(lane);
                    Runnable r = pendingAutomationContinuations[lane];
                    pendingAutomationContinuations[lane] = null;
                    activeStepContexts[lane] = null;
                    mainHandler.postDelayed(r, 600);
                }
            }

            @Override
            public void onReceivedError(WebView view, android.webkit.WebResourceRequest request, android.webkit.WebResourceError error) {
                super.onReceivedError(view, request, error);
                // Only a main-frame failure means the step itself failed —
                // a broken image/script on an otherwise-loading page isn't
                // a step failure.
                if (request != null && !request.isForMainFrame()) return;
                StepContext ctx = activeStepContexts[lane];
                if (ctx == null || pendingAutomationContinuations[lane] == null) return; // already resolved

                cancelStepTimeout(lane);
                pendingAutomationContinuations[lane] = null;
                activeStepContexts[lane] = null;
                String reason = error != null ? String.valueOf(error.getDescription()) : "Failed to load";
                if (shouldRetryStep(ctx.jobId, ctx.index, reason)) {
                    int attempt = retryAttemptNumber(ctx.jobId, ctx.index);
                    reportAutomationStep(lane, ctx.jobId, ctx.index, "Failed: " + reason + " — retrying (attempt " + (attempt + 1) + ")", false, null, null);
                    mainHandler.postDelayed(() -> executeAutomationStep(lane, ctx.jobId, ctx.steps, ctx.index),
                            adaptiveRetryDelayMs(reason, attempt));
                } else {
                    reportAutomationStep(lane, ctx.jobId, ctx.index, "Failed: " + reason, false, null, reason);
                    executeAutomationStep(lane, ctx.jobId, ctx.steps, ctx.index + 1);
                }
            }
        });

        automationWebViews[lane] = wv;
        return wv;
    }

    // ---- Card UI: title + green step-progress line + "⋮" menu ----
    // Agent Progress Tracking (#66) — feeds the "Step X of Y · Z% · ~ETA
    // left" line in buildAutomationJobCard below. ETA is only shown once
    // at least one step has actually completed, since "average time per
    // step" is meaningless before that.
    private String buildProgressLine(JSONObject job, JSONArray steps, JSONObject result) {
        int total = steps.length();
        int completed = 0;
        for (int i = 0; i < total; i++) if (result.has(String.valueOf(i))) completed++;
        if (completed > total) completed = total;

        // Goal-Based Agent (#71): a goal-mode job's total keeps growing
        // as it runs (one action decided at a time), so "of Y · Z%" —
        // meaningful for a fixed plan-mode step list — would just be a
        // moving, meaningless number here. Show elapsed time instead of
        // an ETA, since there's no known remaining-steps count to base one on.
        if ("goal".equals(job.optString("mode", "plan"))) {
            StringBuilder sb = new StringBuilder();
            sb.append("Step ").append(completed).append(" · goal mode");
            if ("running".equals(job.optString("status", ""))) {
                long startedAt = job.optLong("started_at", 0);
                if (startedAt > 0) {
                    sb.append(" · ").append(formatDurationShort(System.currentTimeMillis() - startedAt)).append(" elapsed");
                }
            }
            return sb.toString();
        }

        int percent = total > 0 ? (completed * 100 / total) : 0;

        StringBuilder sb = new StringBuilder();
        sb.append("Step ").append(completed).append(" of ").append(total).append(" · ").append(percent).append('%');

        if ("running".equals(job.optString("status", ""))) {
            long startedAt = job.optLong("started_at", 0);
            int remaining = total - completed;
            if (startedAt > 0 && completed > 0 && remaining > 0) {
                long elapsed = System.currentTimeMillis() - startedAt;
                long avgPerStep = elapsed / completed;
                if (avgPerStep > 0) {
                    sb.append(" · ~").append(formatDurationShort(avgPerStep * remaining)).append(" left");
                }
            } else if (job.has("eta_seconds") && !job.isNull("eta_seconds") && remaining > 0) {
                // No local timer (app was restarted / job started on another device):
                // use the server's measured per-step average instead.
                sb.append(" · ~").append(formatDurationShort(job.optLong("eta_seconds") * 1000L)).append(" left");
            }
        } else if ("paused".equals(job.optString("status", ""))) {
            sb.append(" · paused");
        }
        return sb.toString();
    }

    private String formatDurationShort(long ms) {
        return DownloadUtils.formatDurationShort(ms);
    }

    private View buildAutomationJobCard(JSONObject job) {
        int jobId = job.optInt("job_id");
        String instruction = job.optString("instruction", "");
        String status = job.optString("status", "queued");
        JSONArray steps = job.optJSONArray("steps");
        JSONObject result = job.optJSONObject("result");
        if (steps == null) steps = new JSONArray();
        if (result == null) result = new JSONObject();

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(20, 20, 20, 20);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.bottomMargin = 12;
        card.setLayoutParams(cardParams);
        card.setBackgroundResource("running".equals(status) ? R.drawable.bg_tab_active : R.drawable.bg_tab_inactive);

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(android.view.Gravity.CENTER_VERTICAL);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleColParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleColParams.weight = 1;
        titleCol.setLayoutParams(titleColParams);

        TextView titleView = new TextView(this);
        titleView.setText(instruction);
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(12);
        titleView.setMaxLines(2);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleCol.addView(titleView);

        TextView statusView = new TextView(this);
        statusView.setText(status.toUpperCase(Locale.US));
        statusView.setTextColor(getColor("done".equals(status) || "needs_approval".equals(status) || "needs_verification".equals(status) || "paused".equals(status) || job.optBoolean("dry_run", false) ? R.color.gold : R.color.text_dim));
        statusView.setTextSize(8.5f);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        statusParams.topMargin = 4;
        statusView.setLayoutParams(statusParams);
        titleCol.addView(statusView);

        // Agent Progress Tracking (#66): "Step X of Y · Z% · ~ETA left" —
        // beyond the per-step stepper dots below, this gives an actual
        // number to look at without counting circles, plus a rough time
        // estimate for running jobs based on this job's own average
        // time-per-step so far (not a generic guess).
        TextView progressView = new TextView(this);
        progressView.setText(buildProgressLine(job, steps, result));
        progressView.setTextColor(getColor(R.color.text_dim));
        progressView.setTextSize(8.5f);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        progressParams.topMargin = 2;
        progressView.setLayoutParams(progressParams);
        titleCol.addView(progressView);

        // Confidence Engine (#74): average of whatever steps the planner
        // actually attached a "confidence" score to — silently skips
        // jobs with none (older jobs, Autopilot) rather than showing a
        // misleading 0%.
        int confSum = 0, confCount = 0;
        for (int i = 0; i < steps.length(); i++) {
            JSONObject s = steps.optJSONObject(i);
            if (s != null && s.has("confidence")) {
                confSum += s.optInt("confidence", 0);
                confCount++;
            }
        }
        if (confCount > 0) {
            int avgConfidence = confSum / confCount;
            TextView confView = new TextView(this);
            confView.setText("🎯 Confidence: " + avgConfidence + "% avg" + (avgConfidence < LOW_CONFIDENCE_THRESHOLD ? " — some steps were guesses" : ""));
            confView.setTextColor(getColor(avgConfidence < LOW_CONFIDENCE_THRESHOLD ? R.color.gold : R.color.text_dim));
            confView.setTextSize(8.5f);
            LinearLayout.LayoutParams confParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            confParams.topMargin = 2;
            confView.setLayoutParams(confParams);
            titleCol.addView(confView);
        }

        // Dry Run Mode (#77): planned but deliberately not running yet —
        // this is the one status that needs the user to DO something
        // (⋮ → "Run for Real"), so it gets the same gold prominence as
        // needs_approval/needs_verification rather than a quiet tag.
        if (job.optBoolean("dry_run", false)) {
            TextView dryRunView = new TextView(this);
            dryRunView.setText("📝 Dry run — steps planned, nothing has run yet  (⋮ to run for real)");
            dryRunView.setTextColor(getColor(R.color.gold));
            dryRunView.setTextSize(8.5f);
            dryRunView.setMaxLines(2);
            LinearLayout.LayoutParams dryRunViewParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            dryRunViewParams.topMargin = 2;
            dryRunView.setLayoutParams(dryRunViewParams);
            titleCol.addView(dryRunView);
        }

        // Agent Sandbox (#76): quiet indicator that this job's browsing
        // data gets wiped before/after — mainly reassurance, not a
        // warning, so it's dim rather than gold.
        if (job.optBoolean("sandbox", false)) {
            TextView sandboxTag = new TextView(this);
            sandboxTag.setText("🧪 Sandboxed");
            sandboxTag.setTextColor(getColor(R.color.text_dim));
            sandboxTag.setTextSize(8.5f);
            LinearLayout.LayoutParams sandboxTagParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            sandboxTagParams.topMargin = 2;
            sandboxTag.setLayoutParams(sandboxTagParams);
            titleCol.addView(sandboxTag);
        }

        // Job Dependencies (#91): show what this job is waiting on, if anything.
        int dependsOn = job.optInt("depends_on", 0);
        if (dependsOn > 0 && "queued".equals(status)) {
            boolean blocked = isBlockedByDependency(job);
            TextView depView = new TextView(this);
            depView.setText(blocked ? "⏳ waiting on Task #" + dependsOn : "▶ Task #" + dependsOn + " done — starting soon");
            depView.setTextColor(getColor(R.color.text_dim));
            depView.setTextSize(8.5f);
            LinearLayout.LayoutParams depParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            depParams.topMargin = 2;
            depView.setLayoutParams(depParams);
            titleCol.addView(depView);
        }

        // Error Reason Tracking (#69) / Last Successful Step (#68): if the
        // most recent step attempt failed, show what and how far the job
        // actually got before that, instead of just a bare "RUNNING".
        // Automatic Error Classification (#75) adds a category tag up
        // front — at a glance, "is this worth watching or will it sort
        // itself out" — without reading the full message.
        String lastError = job.isNull("last_error") ? null : job.optString("last_error", null);
        if (lastError != null && !lastError.isEmpty() && !"done".equals(status) && !"cancelled".equals(status)) {
            int lastGoodStep = job.optInt("last_successful_step", -1);
            TextView errorView = new TextView(this);
            errorView.setText(errorCategoryLabel(classifyError(lastError)) + ": " + lastError + (lastGoodStep >= 0 ? " (last OK: step " + (lastGoodStep + 1) + ")" : ""));
            errorView.setTextColor(getColor(R.color.gold));
            errorView.setTextSize(8.5f);
            errorView.setMaxLines(2);
            errorView.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams errorParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            errorParams.topMargin = 2;
            errorView.setLayoutParams(errorParams);
            titleCol.addView(errorView);
        }

        // Self-Healing Agent (#57): the job is parked on a flagged
        // sensitive action — show why, and point at the menu that has
        // Approve/Skip, since there's no room for buttons in this row.
        if ("needs_approval".equals(status)) {
            String pendingMsg = job.optString("pending_approval_msg", "An action needs your approval — tap ⋮ to review");
            TextView approvalView = new TextView(this);
            approvalView.setText(pendingMsg + "  (⋮ to respond)");
            approvalView.setTextColor(getColor(R.color.gold));
            approvalView.setTextSize(8.5f);
            approvalView.setMaxLines(3);
            approvalView.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams approvalParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            approvalParams.topMargin = 2;
            approvalView.setLayoutParams(approvalParams);
            titleCol.addView(approvalView);
        }

        // Agent-to-Agent Verification (#73): the worker agent's own
        // "done" claim didn't hold up against a fresh screenshot —
        // parked for the user to accept anyway or retry, rather than
        // silently trusting a possibly-wrong "task complete".
        if ("needs_verification".equals(status)) {
            String reason = result.optString("verification_reason", "The AI's result didn't check out — tap ⋮ to review");
            TextView verifyView = new TextView(this);
            verifyView.setText("🔍 " + reason + "  (⋮ to respond)");
            verifyView.setTextColor(getColor(R.color.gold));
            verifyView.setTextSize(8.5f);
            verifyView.setMaxLines(3);
            verifyView.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams verifyParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            verifyParams.topMargin = 2;
            verifyView.setLayoutParams(verifyParams);
            titleCol.addView(verifyView);
        }

        topRow.addView(titleCol);

        TextView menuBtn = new TextView(this);
        menuBtn.setText("⋮");
        menuBtn.setTextColor(getColor(R.color.text_primary));
        menuBtn.setTextSize(16);
        menuBtn.setPadding(16, 8, 8, 8);
        menuBtn.setOnClickListener(v -> showAutomationJobMenu(jobId));
        topRow.addView(menuBtn);

        card.addView(topRow);

        // Green stepper: one circle per planned step, filled+connected once
        // that step's result has been reported
        LinearLayout stepperRow = new LinearLayout(this);
        stepperRow.setOrientation(LinearLayout.HORIZONTAL);
        stepperRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams stepperParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        stepperParams.topMargin = 16;
        stepperRow.setLayoutParams(stepperParams);

        for (int i = 0; i < steps.length(); i++) {
            boolean stepDone = result.has(String.valueOf(i));
            JSONObject stepObj = steps.optJSONObject(i);
            String action = stepObj != null ? stepObj.optString("action", "?") : "?";
            // Confidence Engine (#74): a step may not have a "confidence"
            // field at all (older jobs planned before this feature,
            // Autopilot, or a self-healed replacement action) — treat
            // that as "no signal" rather than as a low score.
            int confidence = stepObj != null && stepObj.has("confidence") ? stepObj.optInt("confidence", -1) : -1;
            boolean lowConfidence = confidence >= 0 && confidence < LOW_CONFIDENCE_THRESHOLD;
            int stepColor = stepDone
                    ? (lowConfidence ? Color.parseColor("#F5A623") : Color.parseColor("#2ECC71"))
                    : Color.parseColor("#3A2E57");

            LinearLayout stepCol = new LinearLayout(this);
            stepCol.setOrientation(LinearLayout.VERTICAL);
            stepCol.setGravity(android.view.Gravity.CENTER);
            LinearLayout.LayoutParams stepColParams = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT);
            stepColParams.weight = 1;
            stepCol.setLayoutParams(stepColParams);

            TextView circle = new TextView(this);
            circle.setText(stepDone ? (lowConfidence ? "?" : "✓") : "");
            circle.setTextColor(Color.WHITE);
            circle.setTextSize(10);
            circle.setGravity(android.view.Gravity.CENTER);
            circle.setLayoutParams(new LinearLayout.LayoutParams(36, 36));
            GradientDrawable circleBg = new GradientDrawable();
            circleBg.setShape(GradientDrawable.OVAL);
            circleBg.setColor(stepColor);
            circle.setBackground(circleBg);
            stepCol.addView(circle);

            TextView label = new TextView(this);
            label.setText(lowConfidence ? (action + " (" + confidence + "%)") : action);
            label.setTextColor(getColor(stepDone ? R.color.gold : R.color.text_dim));
            label.setTextSize(7.5f);
            label.setGravity(android.view.Gravity.CENTER);
            LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            labelParams.topMargin = 4;
            label.setLayoutParams(labelParams);
            stepCol.addView(label);

            stepperRow.addView(stepCol);

            // Connecting line to the next step (green if this step is done)
            if (i < steps.length() - 1) {
                View line = new View(this);
                LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(0, 3);
                lineParams.weight = 0.6f;
                lineParams.topMargin = -20;
                line.setLayoutParams(lineParams);
                line.setBackgroundColor(stepDone ? stepColor : getColor(R.color.line_color));
                stepperRow.addView(line);
            }
        }
        card.addView(stepperRow);

        return card;
    }

    private void showAutomationJobMenu(int jobId) {
        JSONObject job = automationJobsCache.get(jobId);
        if (job == null) return;
        String status = job.optString("status", "queued");

        List<String> options = new ArrayList<>();
        options.add("View Result");
        options.add("Create API for this");
        options.add("Save as Workflow");
        // Browser Agent OS (#116): a finished job's own summary can
        // become a Research Workspace (#106) item directly — another
        // piece of Automation and Research talking to each other
        // instead of staying separate tools.
        if ("done".equals(status)) options.add("📚 Save to Research");
        if ("queued".equals(status)) options.add("Do This First");
        if ("queued".equals(status)) options.add("Set Dependency");
        // Dry Run Mode (#77): the one action that actually starts a
        // dry-run job executing for real.
        if (job.optBoolean("dry_run", false)) options.add("Run for Real");
        // Self-Healing Agent (#57): a flagged sensitive action is parked
        // here until the user explicitly approves or skips it.
        if ("needs_approval".equals(status)) options.add("Approve & Continue");
        if ("needs_approval".equals(status)) options.add("Skip This Step");
        // Agent-to-Agent Verification (#73): the worker's "done" claim
        // was flagged — accept it anyway, or discard it and re-run the
        // whole task from scratch.
        if ("needs_verification".equals(status)) options.add("Accept Result");
        if ("needs_verification".equals(status)) options.add("Retry Task");
        // Agent Pause (#62): pause a running task, resume it exactly
        // where it left off — distinct from Cancel, which is final.
        if ("running".equals(status)) options.add("Pause");
        if ("paused".equals(status)) options.add("Resume");
        if (!"done".equals(status) && !"cancelled".equals(status)) options.add("Cancel");
        options.add("Delete");

        new AccentDialogBuilder(this)
                .setTitle("Task #" + jobId)
                .setItems(options.toArray(new String[0]), (d, which) -> {
                    String choice = options.get(which);
                    switch (choice) {
                        case "View Result":
                            showAutomationResult(job);
                            break;
                        case "Create API for this":
                            showAutomationApiInfo(jobId);
                            break;
                        case "Save as Workflow":
                            showSaveWorkflowDialog(job);
                            break;
                        case "📚 Save to Research":
                            saveJobResultToResearch(job);
                            break;
                        case "Do This First":
                            reorderAutomationJob(jobId);
                            break;
                        case "Set Dependency":
                            showSetDependencyDialog(job);
                            break;
                        case "Approve & Continue":
                            // Human Approval Layer (#78) and Self-Healing
                            // (#57) share the same "needs_approval" status
                            // and menu labels but park entries in different
                            // maps — route to whichever actually has this job.
                            if (automationPendingApprovals.containsKey(jobId)) {
                                approvePendingAction(jobId);
                            } else {
                                approvePendingHeal(jobId);
                            }
                            break;
                        case "Skip This Step":
                            if (automationPendingApprovals.containsKey(jobId)) {
                                skipPendingAction(jobId);
                            } else {
                                skipPendingHeal(jobId);
                            }
                            break;
                        case "Accept Result":
                            acceptVerification(jobId);
                            break;
                        case "Retry Task":
                            retryAutomationJob(jobId);
                            break;
                        case "Run for Real":
                            confirmDryRunJob(jobId);
                            break;
                        case "Pause":
                            pauseAutomationJob(jobId);
                            break;
                        case "Resume":
                            resumeAutomationJob(jobId);
                            break;
                        case "Cancel":
                            cancelAutomationJob(jobId);
                            break;
                        case "Delete":
                            deleteAutomationJob(jobId);
                            break;
                    }
                })
                .show();
    }

    // ---- Saved Workflows (#82): take an existing task's already-planned
    // steps and persist them under a name so they can be replayed later
    // without re-typing the instruction or spending an AI planning call
    // again. Only the steps are reused — result/progress are NOT copied,
    // since a replay is a fresh run. ----
    private void showSaveWorkflowDialog(JSONObject job) {
        JSONArray steps = job.optJSONArray("steps");
        if (steps == null || steps.length() == 0) {
            Toast.makeText(this, "This task has no steps to save yet", Toast.LENGTH_SHORT).show();
            return;
        }

        EditText nameInput = new EditText(this);
        nameInput.setHint("Workflow name");
        nameInput.setText(job.optString("instruction", ""));
        nameInput.setTextColor(getColor(R.color.text_primary));
        nameInput.setHintTextColor(getColor(R.color.text_dim));
        nameInput.setSingleLine(true);
        nameInput.setPadding(32, 24, 32, 8);

        new AccentDialogBuilder(this)
                .setTitle("Save as Workflow")
                .setView(nameInput)
                .setPositiveButton("Save", (d, w) -> {
                    String name = nameInput.getText().toString().trim();
                    if (name.isEmpty()) {
                        Toast.makeText(this, "Give it a name first", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    saveWorkflow(name, steps);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveWorkflow(String name, JSONArray steps) {
        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            Toast.makeText(this, "Set Backend Server URL and sign in first (Settings)", Toast.LENGTH_LONG).show();
            return;
        }
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("name", name);
                body.put("steps", steps);
                httpPostJson(backendUrl + "/workflows", body, authToken);
                mainHandler.post(() -> Toast.makeText(this, "Saved as workflow: " + name, Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't save workflow: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // ---- Job Dependencies (#91): let a queued task wait for another
    // task to finish before it can start. ----
    private void showSetDependencyDialog(JSONObject job) {
        int jobId = job.optInt("job_id");
        int currentDependsOn = job.optInt("depends_on", 0);

        List<String> labels = new ArrayList<>();
        List<Integer> candidateIds = new ArrayList<>();
        if (currentDependsOn > 0) {
            labels.add("None (clear dependency)");
            candidateIds.add(0);
        }
        for (JSONObject other : automationJobsCache.values()) {
            int otherId = other.optInt("job_id");
            if (otherId == jobId) continue; // can't depend on itself
            String otherInstruction = other.optString("instruction", "");
            labels.add("#" + otherId + " — " + otherInstruction);
            candidateIds.add(otherId);
        }

        if (labels.isEmpty()) {
            Toast.makeText(this, "No other tasks to depend on yet", Toast.LENGTH_SHORT).show();
            return;
        }

        new AccentDialogBuilder(this)
                .setTitle("Wait for which task first?")
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    Integer chosen = candidateIds.get(which);
                    setJobDependency(jobId, chosen == 0 ? null : chosen);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void setJobDependency(int jobId, Integer dependsOn) {
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("depends_on", dependsOn == null ? JSONObject.NULL : dependsOn);
                httpPostJson(backendUrl + "/agent/jobs/" + jobId + "/depend", body, authToken);
                refreshAutomationJobsSync();
                mainHandler.post(() -> {
                    if (isPageShown) showFullPage(buildAutomationView());
                    Toast.makeText(this, dependsOn == null ? "Dependency cleared" : "Now waits on Task #" + dependsOn, Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't set dependency: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // ================================================================
    // WORKFLOWS SCREEN — saved macros, each replayable into a fresh
    // Automation task without re-typing or re-planning it.
    // ================================================================
    private View buildWorkflowsView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(buildPageHeader("Workflows", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(24, 16, 24, 24);
        scroll.addView(content);
        root.addView(scroll);

        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            TextView warn = new TextView(this);
            warn.setText("Set your Backend Server URL and sign in (Settings) first — Workflows needs both.");
            warn.setTextColor(getColor(R.color.text_dim));
            warn.setTextSize(10.5f);
            warn.setPadding(0, 0, 0, 20);
            content.addView(warn);
        } else if (workflowsCache.isEmpty()) {
            // Nothing fetched yet this session — show the last-known
            // local copy immediately rather than a blank list while the
            // network refresh below is still in flight.
            loadWorkflowsFromOfflineCache();
        }

        if (workflowsShowingOfflineCache) {
            TextView offlineBanner = new TextView(this);
            offlineBanner.setText("⚠ Offline — showing last synced copy");
            offlineBanner.setTextColor(getColor(R.color.gold));
            offlineBanner.setTextSize(9.5f);
            offlineBanner.setPadding(0, 0, 0, 12);
            content.addView(offlineBanner);
        }

        TextView hint = new TextView(this);
        hint.setText("Saved from Automation tasks via ⋮ → Save as Workflow. Run any of them again anytime, without retyping or re-planning.");
        hint.setTextColor(getColor(R.color.text_dim));
        hint.setTextSize(10.5f);
        hint.setPadding(0, 0, 0, 16);
        content.addView(hint);

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        content.addView(list);

        if (workflowsCache.isEmpty()) {
            list.addView(buildEmptyState("No saved workflows yet"));
        } else {
            for (JSONObject workflow : workflowsCache.values()) {
                list.addView(buildWorkflowCard(workflow));
            }
        }

        if (!backendUrl.isEmpty() && !authToken.isEmpty()) {
            refreshWorkflows(() -> {
                if (isPageShown) showFullPage(buildWorkflowsView());
            });
        }

        return root;
    }

    private View buildWorkflowCard(JSONObject workflow) {
        int workflowId = workflow.optInt("workflow_id");
        String name = workflow.optString("name", "");
        int stepCount = workflow.optInt("step_count", 0);
        int version = workflow.optInt("version", 1);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(android.view.Gravity.CENTER_VERTICAL);
        card.setPadding(20, 20, 20, 20);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.bottomMargin = 12;
        card.setLayoutParams(cardParams);
        card.setBackgroundResource(R.drawable.bg_tab_inactive);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleColParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleColParams.weight = 1;
        titleCol.setLayoutParams(titleColParams);

        TextView titleView = new TextView(this);
        titleView.setText(name);
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(12);
        titleView.setMaxLines(2);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleCol.addView(titleView);

        TextView stepsView = new TextView(this);
        stepsView.setText(stepCount + (stepCount == 1 ? " step" : " steps") + " · v" + version);
        stepsView.setTextColor(getColor(R.color.text_dim));
        stepsView.setTextSize(8.5f);
        LinearLayout.LayoutParams stepsParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        stepsParams.topMargin = 4;
        stepsView.setLayoutParams(stepsParams);
        titleCol.addView(stepsView);

        JSONObject schedule = workflow.optJSONObject("schedule");
        if (schedule != null) {
            TextView scheduleView = new TextView(this);
            scheduleView.setText("⏰ " + describeScheduleShort(schedule));
            scheduleView.setTextColor(getColor(R.color.gold));
            scheduleView.setTextSize(8.5f);
            LinearLayout.LayoutParams scheduleParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            scheduleParams.topMargin = 2;
            scheduleView.setLayoutParams(scheduleParams);
            titleCol.addView(scheduleView);
        }

        card.addView(titleCol);

        TextView runBtn = new TextView(this);
        runBtn.setText("▶ Run");
        runBtn.setTextColor(getColor(R.color.gold));
        runBtn.setTextSize(11);
        runBtn.setPadding(20, 12, 20, 12);
        runBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        runBtn.setOnClickListener(v -> runWorkflow(workflowId, name));
        card.addView(runBtn);

        TextView menuBtn = new TextView(this);
        menuBtn.setText("⋮");
        menuBtn.setTextColor(getColor(R.color.text_primary));
        menuBtn.setTextSize(16);
        menuBtn.setPadding(16, 8, 8, 8);
        menuBtn.setOnClickListener(v -> showWorkflowMenu(workflow));
        card.addView(menuBtn);

        return card;
    }

    // ---- Workflow Edit (#83) / Duplicate (#84) / Versioning (#86) ----
    private void showWorkflowMenu(JSONObject workflow) {
        int workflowId = workflow.optInt("workflow_id");
        String name = workflow.optString("name", "");

        String[] options = {"Run", "Edit", "Duplicate", "Schedule", "Version History", "Delete"};

        new AccentDialogBuilder(this)
                .setTitle(name)
                .setItems(options, (d, which) -> {
                    switch (options[which]) {
                        case "Run":
                            runWorkflow(workflowId, name);
                            break;
                        case "Edit":
                            showEditWorkflowDialog(workflow);
                            break;
                        case "Duplicate":
                            duplicateWorkflow(workflowId);
                            break;
                        case "Schedule":
                            showScheduleWorkflowDialog(workflow);
                            break;
                        case "Version History":
                            showWorkflowVersionHistory(workflowId, name);
                            break;
                        case "Delete":
                            confirmDeleteWorkflow(workflowId, name);
                            break;
                    }
                })
                .show();
    }

    // Edit lets the name AND the raw steps be changed. Steps are shown as
    // editable JSON — the same shape the backend already stores and the
    // Automation engine already executes — rather than building a
    // separate structured step-by-step editor UI for a first version of
    // this feature. Every edit is versioned automatically on the backend
    // (see /workflows/{id}/edit), so a bad edit is always recoverable via
    // Version History.
    private void showEditWorkflowDialog(JSONObject workflow) {
        int workflowId = workflow.optInt("workflow_id");
        JSONArray steps = workflow.optJSONArray("steps");
        if (steps == null) steps = new JSONArray();

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(32, 16, 32, 8);

        EditText nameInput = new EditText(this);
        nameInput.setHint("Workflow name");
        nameInput.setText(workflow.optString("name", ""));
        nameInput.setTextColor(getColor(R.color.text_primary));
        nameInput.setHintTextColor(getColor(R.color.text_dim));
        nameInput.setSingleLine(true);
        wrap.addView(nameInput);

        TextView stepsLabel = new TextView(this);
        stepsLabel.setText("Steps (JSON)");
        stepsLabel.setTextColor(getColor(R.color.text_dim));
        stepsLabel.setTextSize(9);
        LinearLayout.LayoutParams stepsLabelParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        stepsLabelParams.topMargin = 16;
        stepsLabel.setLayoutParams(stepsLabelParams);
        wrap.addView(stepsLabel);

        EditText stepsInput = new EditText(this);
        String prettySteps;
        try {
            prettySteps = steps.toString(2);
        } catch (Exception e) {
            prettySteps = steps.toString();
        }
        stepsInput.setText(prettySteps);
        stepsInput.setTextColor(getColor(R.color.text_primary));
        stepsInput.setTypeface(android.graphics.Typeface.MONOSPACE);
        stepsInput.setTextSize(10);
        stepsInput.setMinLines(6);
        stepsInput.setMaxLines(14);
        stepsInput.setGravity(android.view.Gravity.TOP);
        wrap.addView(stepsInput);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(wrap);

        new AccentDialogBuilder(this)
                .setTitle("Edit Workflow")
                .setView(scroll)
                .setPositiveButton("Save", (d, w) -> {
                    String newName = nameInput.getText().toString().trim();
                    if (newName.isEmpty()) {
                        Toast.makeText(this, "Give it a name first", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    JSONArray newSteps;
                    try {
                        newSteps = new JSONArray(stepsInput.getText().toString());
                    } catch (Exception e) {
                        Toast.makeText(this, "Steps must be valid JSON — edit not saved", Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (newSteps.length() == 0) {
                        Toast.makeText(this, "Workflow needs at least one step", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    saveWorkflowEdit(workflowId, newName, newSteps);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveWorkflowEdit(int workflowId, String name, JSONArray steps) {
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("name", name);
                body.put("steps", steps);
                httpPostJson(backendUrl + "/workflows/" + workflowId + "/edit", body, authToken);
                refreshWorkflows(() -> {
                    if (isPageShown) showFullPage(buildWorkflowsView());
                    Toast.makeText(this, "Workflow updated", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't save edit: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // ---- Workflow Scheduling (#87): runs entirely on the backend via a
    // polling thread there — the phone does NOT need to be open, in the
    // foreground, or even installed-and-running for a scheduled workflow
    // to fire. This screen only creates/cancels the schedule row. ----
    private void showScheduleWorkflowDialog(JSONObject workflow) {
        int workflowId = workflow.optInt("workflow_id");
        String name = workflow.optString("name", "");
        JSONObject existing = workflow.optJSONObject("schedule");

        String[] options = existing != null
                ? new String[]{"Run Once (pick date & time)", "Run Daily (pick time)", "Cancel Schedule"}
                : new String[]{"Run Once (pick date & time)", "Run Daily (pick time)"};

        String currentInfo = existing != null ? describeSchedule(existing) : "No schedule set";

        new AccentDialogBuilder(this)
                .setTitle("Schedule — " + name)
                .setMessage(currentInfo)
                .setItems(options, (d, which) -> {
                    String choice = options[which];
                    if (choice.startsWith("Run Once")) {
                        pickOnceScheduleDateTime(workflowId);
                    } else if (choice.startsWith("Run Daily")) {
                        pickDailyScheduleTime(workflowId);
                    } else if (choice.equals("Cancel Schedule")) {
                        cancelWorkflowSchedule(workflowId);
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private String describeSchedule(JSONObject schedule) {
        String recurrence = schedule.optString("recurrence", "");
        long nextRunAt = schedule.optLong("next_run_at", 0) * 1000L;
        java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("d MMM, h:mm a", java.util.Locale.getDefault());
        if ("daily".equals(recurrence)) {
            return "Runs daily at " + schedule.optString("daily_time", "") +
                    " — next: " + fmt.format(new java.util.Date(nextRunAt));
        } else {
            return "Runs once at " + fmt.format(new java.util.Date(nextRunAt));
        }
    }

    private String describeScheduleShort(JSONObject schedule) {
        String recurrence = schedule.optString("recurrence", "");
        long nextRunAt = schedule.optLong("next_run_at", 0) * 1000L;
        if ("daily".equals(recurrence)) {
            return "Daily " + schedule.optString("daily_time", "");
        } else {
            java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("d MMM, h:mm a", java.util.Locale.getDefault());
            return "Once: " + fmt.format(new java.util.Date(nextRunAt));
        }
    }

    private void pickOnceScheduleDateTime(int workflowId) {
        Calendar now = Calendar.getInstance();
        new android.app.DatePickerDialog(this, (dView, year, month, day) -> {
            new android.app.TimePickerDialog(this, (tView, hour, minute) -> {
                Calendar picked = Calendar.getInstance();
                picked.set(year, month, day, hour, minute, 0);
                long runAtSeconds = picked.getTimeInMillis() / 1000L;
                if (runAtSeconds <= System.currentTimeMillis() / 1000L) {
                    Toast.makeText(this, "Pick a time in the future", Toast.LENGTH_SHORT).show();
                    return;
                }
                saveWorkflowSchedule(workflowId, "once", runAtSeconds, null);
            }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show();
        }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void pickDailyScheduleTime(int workflowId) {
        Calendar now = Calendar.getInstance();
        new android.app.TimePickerDialog(this, (tView, hour, minute) -> {
            String dailyTime = String.format(java.util.Locale.US, "%02d:%02d", hour, minute);
            saveWorkflowSchedule(workflowId, "daily", null, dailyTime);
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show();
    }

    private void saveWorkflowSchedule(int workflowId, String recurrence, Long runAtSeconds, String dailyTime) {
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("recurrence", recurrence);
                if (runAtSeconds != null) body.put("run_at", runAtSeconds);
                if (dailyTime != null) body.put("daily_time", dailyTime);
                httpPostJson(backendUrl + "/workflows/" + workflowId + "/schedule", body, authToken);
                refreshWorkflows(() -> {
                    if (isPageShown) showFullPage(buildWorkflowsView());
                    Toast.makeText(this, "Schedule saved", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't save schedule: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private void cancelWorkflowSchedule(int workflowId) {
        networkExecutor.execute(() -> {
            try {
                URL url = new URL(backendUrl + "/workflows/" + workflowId + "/schedule");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("DELETE");
                conn.setRequestProperty("Authorization", "Bearer " + authToken);
                conn.getResponseCode();
            } catch (Exception ignored) {}
            refreshWorkflows(() -> {
                if (isPageShown) showFullPage(buildWorkflowsView());
                Toast.makeText(this, "Schedule cancelled", Toast.LENGTH_SHORT).show();
            });
        });
    }

    private void duplicateWorkflow(int workflowId) {
        networkExecutor.execute(() -> {
            try {
                httpPostJson(backendUrl + "/workflows/" + workflowId + "/duplicate", new JSONObject(), authToken);
                refreshWorkflows(() -> {
                    if (isPageShown) showFullPage(buildWorkflowsView());
                    Toast.makeText(this, "Duplicated", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't duplicate: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private void showWorkflowVersionHistory(int workflowId, String name) {
        networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(backendUrl + "/workflows/" + workflowId + "/versions", authToken);
                JSONArray versions = resp.optJSONArray("versions");
                if (versions == null) versions = new JSONArray();
                JSONArray finalVersions = versions;
                mainHandler.post(() -> renderWorkflowVersionDialog(workflowId, name, finalVersions));
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't load history: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private void renderWorkflowVersionDialog(int workflowId, String name, JSONArray versions) {
        List<String> lines = new ArrayList<>();
        List<Integer> versionNumbers = new ArrayList<>();
        for (int i = 0; i < versions.length(); i++) {
            JSONObject v = versions.optJSONObject(i);
            if (v == null) continue;
            int versionNum = v.optInt("version");
            boolean isCurrent = v.optBoolean("is_current", false);
            String label = "v" + versionNum + (isCurrent ? " (current)" : "") +
                    " — " + v.optString("name", "") + " (" + v.optInt("step_count", 0) + " steps)";
            lines.add(label);
            versionNumbers.add(versionNum);
        }
        if (lines.isEmpty()) {
            Toast.makeText(this, "No version history yet", Toast.LENGTH_SHORT).show();
            return;
        }

        new AccentDialogBuilder(this)
                .setTitle("History — " + name)
                .setItems(lines.toArray(new String[0]), (d, which) -> {
                    int versionNum = versionNumbers.get(which);
                    boolean isCurrent = lines.get(which).contains("(current)");
                    if (isCurrent) return; // nothing to restore — it's already live
                    confirmRestoreWorkflowVersion(workflowId, versionNum);
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void confirmRestoreWorkflowVersion(int workflowId, int version) {
        new AccentDialogBuilder(this)
                .setTitle("Restore v" + version + "?")
                .setMessage("The current version will be kept in history too, so this is safe to undo later.")
                .setPositiveButton("Restore", (d, w) -> restoreWorkflowVersion(workflowId, version))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void restoreWorkflowVersion(int workflowId, int version) {
        networkExecutor.execute(() -> {
            try {
                httpPostJson(backendUrl + "/workflows/" + workflowId + "/versions/" + version + "/restore",
                        new JSONObject(), authToken);
                refreshWorkflows(() -> {
                    if (isPageShown) showFullPage(buildWorkflowsView());
                    Toast.makeText(this, "Restored v" + version, Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't restore: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // Workflow Sync (#45): workflows already live server-side only (no
    // per-device local copy to drift out of sync — any device signed
    // into the same account calling GET /workflows sees the identical
    // list immediately). What's still missing without this cache is
    // OFFLINE resilience: if the network hiccups, the screen would just
    // show empty instead of the last-known list. This local cache
    // (SharedPreferences, same pattern bookmarks/history already use)
    // closes that gap — a successful fetch refreshes it, a failed fetch
    // falls back to it instead of showing nothing.
    private boolean workflowsShowingOfflineCache = false;

    private void refreshWorkflows(Runnable onDone) {
        if (backendUrl.isEmpty() || authToken.isEmpty()) return;
        networkExecutor.execute(() -> {
            try {
                JSONObject resp = httpGetJson(backendUrl + "/workflows", authToken);
                JSONArray workflows = resp.optJSONArray("workflows");
                if (workflows != null) {
                    workflowsCache.clear();
                    for (int i = 0; i < workflows.length(); i++) {
                        JSONObject workflow = workflows.getJSONObject(i);
                        workflowsCache.put(workflow.optInt("workflow_id"), workflow);
                    }
                    workflowsShowingOfflineCache = false;
                    prefs.edit().putString("workflows_cache", workflows.toString()).apply();
                }
            } catch (Exception e) {
                loadWorkflowsFromOfflineCache();
            }
            mainHandler.post(onDone);
        });
    }

    private void loadWorkflowsFromOfflineCache() {
        if (!workflowsCache.isEmpty()) return; // already have something live — don't clobber it with a stale copy
        String cached = prefs.getString("workflows_cache", "");
        if (cached.isEmpty()) return;
        try {
            JSONArray workflows = new JSONArray(cached);
            for (int i = 0; i < workflows.length(); i++) {
                JSONObject workflow = workflows.getJSONObject(i);
                workflowsCache.put(workflow.optInt("workflow_id"), workflow);
            }
            workflowsShowingOfflineCache = true;
        } catch (Exception ignored) {}
    }

    private void runWorkflow(int workflowId, String name) {
        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            Toast.makeText(this, "Set Backend Server URL and sign in first (Settings)", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Starting \"" + name + "\"…", Toast.LENGTH_SHORT).show();
        networkExecutor.execute(() -> {
            try {
                httpPostJson(backendUrl + "/workflows/" + workflowId + "/run", new JSONObject(), authToken);
                refreshAutomationJobsSync();
                mainHandler.post(() -> {
                    showFullPage(buildAutomationView());
                    maybeStartAutomationQueue();
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't run workflow: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private void confirmDeleteWorkflow(int workflowId, String name) {
        new AccentDialogBuilder(this)
                .setTitle("Delete Workflow")
                .setMessage("Delete \"" + name + "\"? This can't be undone.")
                .setPositiveButton("Delete", (d, w) -> deleteWorkflow(workflowId))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteWorkflow(int workflowId) {
        workflowsCache.remove(workflowId);
        showFullPage(buildWorkflowsView());
        networkExecutor.execute(() -> {
            try {
                URL url = new URL(backendUrl + "/workflows/" + workflowId);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("DELETE");
                conn.setRequestProperty("Authorization", "Bearer " + authToken);
                conn.getResponseCode();
            } catch (Exception ignored) {}
            JSONArray remaining = new JSONArray();
            for (JSONObject w : workflowsCache.values()) remaining.put(w);
            prefs.edit().putString("workflows_cache", remaining.toString()).apply();
        });
    }

    private void showAutomationResult(JSONObject job) {
        JSONObject result = job.optJSONObject("result");
        StringBuilder sb = new StringBuilder();
        if (result != null) {
            if (result.has("final")) {
                sb.append(result.optString("final")).append("\n\n");
            }
            for (java.util.Iterator<String> it = result.keys(); it.hasNext(); ) {
                String key = it.next();
                if (!"final".equals(key)) {
                    sb.append("Step ").append(key).append(": ").append(result.optString(key)).append("\n\n");
                }
            }
        }
        if (sb.length() == 0) sb.append("No results yet — this task hasn't started running.");

        new AccentDialogBuilder(this)
                .setTitle(job.optString("instruction"))
                .setMessage(sb.toString().trim())
                .setPositiveButton("Close", null)
                .show();
    }

    private void showAutomationApiInfo(int jobId) {
        String getUrl = backendUrl + "/agent/result/" + jobId;
        String curl = "curl \"" + getUrl + "\" \\\n  -H \"Authorization: Bearer " + authToken + "\"";

        TextView msgView = new TextView(this);
        msgView.setText("Any script (or you, from anywhere) can fetch this task's live status and result with:\n\n" + curl);
        msgView.setTextColor(getColor(R.color.text_primary));
        msgView.setTextSize(10.5f);
        msgView.setPadding(32, 24, 32, 8);

        new AccentDialogBuilder(this)
                .setTitle("API for Task #" + jobId)
                .setView(msgView)
                .setPositiveButton("Copy", (d, w) -> {
                    copySensitiveToClipboard("Nex Automation API", curl);
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void addAutomationTask(String instruction, boolean verifyResult, boolean sandbox, boolean dryRun, boolean requireApproval) {
        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            Toast.makeText(this, "Set Backend Server URL and sign in first (Settings)", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Planning task…", Toast.LENGTH_SHORT).show();
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("instruction", instruction);
                if (verifyResult) body.put("verify_result", true);
                if (sandbox) body.put("sandbox", true);
                if (dryRun) body.put("dry_run", true);
                if (requireApproval) body.put("require_approval", true);
                httpPostJson(backendUrl + "/agent/plan", body, authToken);

                refreshAutomationJobsSync();
                mainHandler.post(() -> {
                    if (isPageShown) showFullPage(buildAutomationView());
                    maybeStartAutomationQueue();
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't plan task: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // Goal-Based Agent (#71): mirrors addAutomationTask above, but hits
    // /agent/goal/plan instead of /agent/plan — no upfront step list is
    // planned, the job starts with zero steps and fetchNextGoalStep
    // decides + persists each action live once it starts running.
    private void addGoalTask(String goal, boolean verifyResult, boolean sandbox, boolean dryRun, boolean requireApproval) {
        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            Toast.makeText(this, "Set Backend Server URL and sign in first (Settings)", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Starting goal task…", Toast.LENGTH_SHORT).show();
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("goal", goal);
                if (verifyResult) body.put("verify_result", true);
                if (sandbox) body.put("sandbox", true);
                if (dryRun) body.put("dry_run", true);
                if (requireApproval) body.put("require_approval", true);
                httpPostJson(backendUrl + "/agent/goal/plan", body, authToken);

                refreshAutomationJobsSync();
                mainHandler.post(() -> {
                    if (isPageShown) showFullPage(buildAutomationView());
                    maybeStartAutomationQueue();
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't start goal task: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // Multi-Agent Orchestrator (#72): posts the goal to /agent/orchestrate,
    // which breaks it into an ordered list of sub-tasks server-side and
    // creates the FIRST sub-task's job immediately. Every later sub-task's
    // job gets created reactively, server-side, from inside /agent/report
    // each time the previous one finishes — see reportAutomationStep's
    // post-report refresh below, which is what lets this device notice a
    // newly-appeared sub-job and start it without the user tapping anything.
    private void addOrchestrationTask(String goal) {
        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            Toast.makeText(this, "Set Backend Server URL and sign in first (Settings)", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Splitting goal into sub-tasks…", Toast.LENGTH_SHORT).show();
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("goal", goal);
                JSONObject resp = httpPostJson(backendUrl + "/agent/orchestrate", body, authToken);
                JSONArray subTasks = resp.optJSONArray("sub_tasks");
                int count = subTasks != null ? subTasks.length() : 0;

                refreshAutomationJobsSync();
                mainHandler.post(() -> {
                    Toast.makeText(this, "Split into " + count + " sub-task(s) — running now", Toast.LENGTH_LONG).show();
                    if (isPageShown) showFullPage(buildAutomationView());
                    maybeStartAutomationQueue();
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't start orchestration: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // ---- Batch API (#88): plan + queue several instructions in one
    // call. One line in the textbox = one task/instruction. ----
    private void showBatchTaskDialog() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(32, 16, 32, 8);

        TextView hint = new TextView(this);
        hint.setText("One task per line — up to 20.");
        hint.setTextColor(getColor(R.color.text_dim));
        hint.setTextSize(9.5f);
        wrap.addView(hint);

        EditText tasksInput = new EditText(this);
        tasksInput.setHint("search cats on youtube\ncheck weather in mumbai\n...");
        tasksInput.setTextColor(getColor(R.color.text_primary));
        tasksInput.setHintTextColor(getColor(R.color.text_dim));
        tasksInput.setMinLines(5);
        tasksInput.setMaxLines(12);
        tasksInput.setGravity(android.view.Gravity.TOP);
        LinearLayout.LayoutParams tasksInputParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tasksInputParams.topMargin = 12;
        tasksInput.setLayoutParams(tasksInputParams);
        wrap.addView(tasksInput);

        // Job Dependencies (#91): when checked, each task waits for the
        // one above it to finish — a simple linear pipeline — instead
        // of all running independently/in parallel.
        android.widget.CheckBox sequentialCheck = new android.widget.CheckBox(this);
        sequentialCheck.setText("Run in order (each waits for the one before it)");
        sequentialCheck.setTextColor(getColor(R.color.text_dim));
        sequentialCheck.setTextSize(9.5f);
        LinearLayout.LayoutParams sequentialParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        sequentialParams.topMargin = 8;
        sequentialCheck.setLayoutParams(sequentialParams);
        wrap.addView(sequentialCheck);

        new AccentDialogBuilder(this)
                .setTitle("Add as Batch")
                .setView(wrap)
                .setPositiveButton("Queue All", (d, w) -> {
                    String raw = tasksInput.getText().toString();
                    List<String> instructions = new ArrayList<>();
                    for (String line : raw.split("\n")) {
                        String trimmed = line.trim();
                        if (!trimmed.isEmpty()) instructions.add(trimmed);
                    }
                    if (instructions.isEmpty()) {
                        Toast.makeText(this, "Type at least one task", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (instructions.size() > 20) {
                        Toast.makeText(this, "Max 20 tasks per batch", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    addAutomationTaskBatch(instructions, sequentialCheck.isChecked());
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void addAutomationTaskBatch(List<String> instructions, boolean sequential) {
        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            Toast.makeText(this, "Set Backend Server URL and sign in first (Settings)", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Planning " + instructions.size() + " tasks…", Toast.LENGTH_SHORT).show();
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("instructions", new JSONArray(instructions));
                body.put("sequential", sequential);
                JSONObject resp = httpPostJson(backendUrl + "/agent/plan/batch", body, authToken);

                JSONArray jobs = resp.optJSONArray("jobs");
                int failed = 0;
                if (jobs != null) {
                    for (int i = 0; i < jobs.length(); i++) {
                        if (jobs.optJSONObject(i) != null && jobs.getJSONObject(i).has("error")) failed++;
                    }
                }
                int total = jobs != null ? jobs.length() : instructions.size();
                int finalFailed = failed;

                refreshAutomationJobsSync();
                mainHandler.post(() -> {
                    if (isPageShown) showFullPage(buildAutomationView());
                    maybeStartAutomationQueue();
                    if (finalFailed > 0) {
                        Toast.makeText(this, (total - finalFailed) + " queued, " + finalFailed + " failed", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(this, total + " tasks queued", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Couldn't queue batch: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // ================================================================
    // AUTOPILOT — a ReAct-style loop: screenshot + DOM summary + goal +
    // recent history go to whichever AI provider the user configured
    // (Settings → Account → Autopilot API Key), it decides ONE next
    // action, Android executes it on the CURRENT VISIBLE TAB, then the
    // loop asks again. Reuses the exact same click/type/scroll JS
    // (buildClickJs/buildTypeJs/buildScrollJs) that Universal Action
    // Engine (#51) already built, and inspect_dom's summary helper.
    // ================================================================
    private void showAutopilotGoalDialog() {
        if (backendUrl.isEmpty() || authToken.isEmpty()) {
            Toast.makeText(this, "Set Backend Server URL and sign in first (Settings)", Toast.LENGTH_LONG).show();
            return;
        }
        EditText goalInput = new EditText(this);
        goalInput.setHint("e.g. find the cheapest flight to Goa on this page");
        goalInput.setTextColor(getColor(R.color.text_primary));
        goalInput.setHintTextColor(getColor(R.color.text_dim));
        goalInput.setMinLines(2);
        goalInput.setMaxLines(5);
        goalInput.setPadding(32, 24, 32, 8);

        new AccentDialogBuilder(this)
                .setTitle("Autopilot Goal")
                .setMessage("AI will watch and drive your CURRENT tab live, one step at a time, until the goal is done or it gets stuck.")
                .setView(goalInput)
                .setPositiveButton("Start", (d, w) -> {
                    String goal = goalInput.getText().toString().trim();
                    if (goal.isEmpty()) {
                        Toast.makeText(this, "Type a goal first", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    startAutopilot(goal);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void startAutopilot(String goal) {
        if (tabs.isEmpty() || currentTabIndex < 0 || currentTabIndex >= tabs.size()) {
            Toast.makeText(this, "Open a tab first", Toast.LENGTH_SHORT).show();
            return;
        }
        DevilTab activeTab = tabs.get(currentTabIndex);
        if (activeTab.webView == null) {
            Toast.makeText(this, "This tab isn't ready yet", Toast.LENGTH_SHORT).show();
            return;
        }
        autopilotGoal = goal;
        autopilotHistory.clear();
        autopilotStepCount = 0;
        autopilotRunning = true;
        showAutopilotStatusDialog();
        runNextAutopilotStep();
    }

    private void runNextAutopilotStep() {
        if (!autopilotRunning) return;
        if (autopilotStepCount >= AUTOPILOT_MAX_STEPS) {
            stopAutopilot("Reached the " + AUTOPILOT_MAX_STEPS + "-step safety limit — stopping.");
            return;
        }
        DevilTab activeTab = tabs.get(currentTabIndex);
        WebView wv = activeTab.webView;
        if (wv == null) {
            stopAutopilot("Active tab is gone — stopping.");
            return;
        }
        autopilotStepCount++;
        appendAutopilotLog("Step " + autopilotStepCount + ": looking at the page…");

        String screenshotB64 = captureWebViewScreenshotBase64(wv);
        String currentUrl = wv.getUrl() != null ? wv.getUrl() : "";

        wv.evaluateJavascript(INSPECT_DOM_JS, raw -> {
            if (!autopilotRunning) return;
            String domJson = unescapeJsString(raw);
            String domSummary = describeDomInspection(domJson != null ? domJson : "{}");
            requestNextAutopilotAction(screenshotB64, domSummary, currentUrl);
        });
    }

    // Draws the live WebView into a Bitmap the same size as the page is
    // currently rendered — this is what the AI provider actually "sees",
    // not a description of it.
    private String captureWebViewScreenshotBase64(WebView wv) {
        try {
            int width = wv.getWidth();
            int height = wv.getHeight();
            if (width <= 0 || height <= 0) return "";
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            android.graphics.Canvas canvas = new android.graphics.Canvas(bitmap);
            wv.draw(canvas);
            java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
            // Quality 55 keeps the upload small (this happens every step) while
            // staying legible enough for the AI to read on-screen text/buttons.
            bitmap.compress(Bitmap.CompressFormat.JPEG, 55, baos);
            bitmap.recycle();
            return android.util.Base64.encodeToString(baos.toByteArray(), android.util.Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    // Tab Switcher thumbnails (redesign pass 2, Sep 2026): a small, cheap,
    // on-demand capture of a tab's LIVE WebView — only called while the
    // switcher sheet is being built, never persisted or uploaded anywhere.
    // Downscaled early (drawn straight into a small Bitmap) so opening the
    // switcher with many tabs open stays fast and light on memory. Returns
    // null for suspended tabs / home tabs / anything not yet rendered,
    // which the caller falls back to a plain placeholder for.
    private Bitmap captureTabThumbnail(DevilTab tab) {
        try {
            if (tab.isSuspended || tab.webView == null || "home".equals(tab.type)) return null;
            WebView wv = tab.webView;
            int width = wv.getWidth();
            int height = wv.getHeight();
            if (width <= 0 || height <= 0) return null;
            int thumbWidth = 240;
            int thumbHeight = Math.max(1, (int) (height * (thumbWidth / (float) width)));
            Bitmap full = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            android.graphics.Canvas fullCanvas = new android.graphics.Canvas(full);
            wv.draw(fullCanvas);
            Bitmap scaled = Bitmap.createScaledBitmap(full, thumbWidth, thumbHeight, true);
            full.recycle();
            return scaled;
        } catch (Exception e) {
            return null;
        }
    }

    private void requestNextAutopilotAction(String screenshotB64, String domSummary, String currentUrl) {
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("goal", autopilotGoal);
                body.put("screenshot_base64", screenshotB64);
                body.put("dom_summary", domSummary);
                body.put("current_url", currentUrl);
                JSONArray historyArr = new JSONArray();
                for (JSONObject h : autopilotHistory) historyArr.put(h);
                body.put("history", historyArr);

                JSONObject resp = httpPostJson(backendUrl + "/agent/autopilot/next", body, authToken);
                JSONObject nextAction = resp.optJSONObject("next_action");
                mainHandler.post(() -> {
                    if (!autopilotRunning) return;
                    if (nextAction == null) {
                        stopAutopilot("AI gave no action — stopping.");
                        return;
                    }
                    executeAutopilotAction(nextAction);
                });
            } catch (Exception e) {
                mainHandler.post(() -> stopAutopilot("Error: " + e.getMessage()));
            }
        });
    }

    private void executeAutopilotAction(JSONObject actionObj) {
        if (!autopilotRunning) return;
        String action = actionObj.optString("action", "done");
        appendAutopilotLog("→ " + action + (actionObj.has("text") ? ": " + actionObj.optString("text") : ""));

        DevilTab activeTab = tabs.get(currentTabIndex);
        WebView wv = activeTab.webView;
        if (wv == null) {
            stopAutopilot("Active tab is gone — stopping.");
            return;
        }

        switch (action) {
            case "navigate": {
                String url = actionObj.optString("url", "");
                navigate(url);
                recordAutopilotHistory(actionObj, "navigated");
                mainHandler.postDelayed(this::runNextAutopilotStep, 2500);
                break;
            }
            case "click": {
                String selector = actionObj.optString("selector", "");
                String text = actionObj.optString("text", "");
                wv.evaluateJavascript(buildClickJs(selector, text), raw -> {
                    if (!autopilotRunning) return;
                    boolean found = jsActionFound(unescapeJsString(raw));
                    recordAutopilotHistory(actionObj, found ? "clicked" : "not found");
                    mainHandler.postDelayed(this::runNextAutopilotStep, 1800);
                });
                break;
            }
            case "type": {
                String selector = actionObj.optString("selector", "");
                String label = actionObj.optString("label", "");
                String text = actionObj.optString("text", "");
                wv.evaluateJavascript(buildTypeJs(selector, label, text), raw -> {
                    if (!autopilotRunning) return;
                    boolean found = jsActionFound(unescapeJsString(raw));
                    recordAutopilotHistory(actionObj, found ? "typed" : "not found");
                    mainHandler.postDelayed(this::runNextAutopilotStep, 1200);
                });
                break;
            }
            case "scroll": {
                String direction = actionObj.optString("direction", "down");
                wv.evaluateJavascript(buildScrollJs(direction, 600), raw -> {
                    if (!autopilotRunning) return;
                    recordAutopilotHistory(actionObj, "scrolled");
                    mainHandler.postDelayed(this::runNextAutopilotStep, 800);
                });
                break;
            }
            case "wait": {
                int ms = actionObj.optInt("ms", 1000);
                recordAutopilotHistory(actionObj, "waited");
                mainHandler.postDelayed(this::runNextAutopilotStep, ms);
                break;
            }
            case "install_extension": {
                // The agent's own "figure out it needs an extension, fetch
                // it, and run it" path — same installExtensionFromUrl()
                // Settings uses, so it behaves identically either way.
                // Runs automatically from the next matching page load;
                // does not retry the current step, since the extension
                // wasn't necessarily needed for THIS exact action.
                String extUrl = actionObj.optString("url", "");
                if (extUrl.isEmpty()) {
                    recordAutopilotHistory(actionObj, "no extension url given");
                    mainHandler.postDelayed(this::runNextAutopilotStep, 500);
                    break;
                }
                appendAutopilotLog("🧩 Installing extension from " + extUrl + " …");
                installExtensionFromUrl(extUrl, (success, message) -> {
                    appendAutopilotLog((success ? "🧩 " : "⚠️ ") + message);
                    recordAutopilotHistory(actionObj, success ? "extension installed" : "extension install failed");
                    mainHandler.postDelayed(this::runNextAutopilotStep, 800);
                });
                break;
            }
            case "done":
            default: {
                stopAutopilot(actionObj.optString("summary", "Done."));
                break;
            }
        }
    }

    private void recordAutopilotHistory(JSONObject action, String result) {
        try {
            JSONObject h = new JSONObject();
            h.put("action", action);
            h.put("result", result);
            autopilotHistory.add(h);
            // Keep the prompt small — only recent history matters for
            // deciding the next step, and this rides along on every call.
            if (autopilotHistory.size() > 12) autopilotHistory.remove(0);
        } catch (Exception ignored) {}
    }

    private void showAutopilotStatusDialog() {
        autopilotLog.setLength(0);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(32, 16, 32, 8);

        TextView goalView = new TextView(this);
        goalView.setText("Goal: " + autopilotGoal);
        goalView.setTextColor(getColor(R.color.text_primary));
        goalView.setTextSize(11);
        LinearLayout.LayoutParams goalParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        goalParams.bottomMargin = 12;
        goalView.setLayoutParams(goalParams);
        wrap.addView(goalView);

        autopilotLogView = new TextView(this);
        autopilotLogView.setText("Starting…");
        autopilotLogView.setTextColor(getColor(R.color.text_dim));
        autopilotLogView.setTextSize(9.5f);
        wrap.addView(autopilotLogView);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(wrap);

        autopilotDialog = new AccentDialogBuilder(this)
                .setTitle("🤖 Autopilot running")
                .setView(scroll)
                .setCancelable(false)
                .setNegativeButton("Stop", (d, w) -> stopAutopilot("Stopped by user"))
                .create();
        autopilotDialog.show();
    }

    private void appendAutopilotLog(String line) {
        autopilotLog.append(line).append("\n");
        if (autopilotLogView != null) autopilotLogView.setText(autopilotLog.toString());
    }

    private void stopAutopilot(String reason) {
        autopilotRunning = false;
        appendAutopilotLog("⏹ " + reason);
        if (autopilotDialog != null) {
            autopilotDialog.setTitle("🤖 Autopilot stopped");
        }
    }

    private void refreshAutomationJobs(Runnable onDone) {
        if (backendUrl.isEmpty() || authToken.isEmpty()) return;
        networkExecutor.execute(() -> {
            refreshAutomationJobsSync();
            mainHandler.post(onDone);
        });
    }

    private void refreshAutomationJobsSync() {
        try {
            JSONObject resp = httpGetJson(backendUrl + "/agent/jobs", authToken);
            JSONArray jobs = resp.optJSONArray("jobs");
            if (jobs == null) return;
            automationJobsCache.clear();
            for (int i = 0; i < jobs.length(); i++) {
                JSONObject job = jobs.getJSONObject(i);
                automationJobsCache.put(job.optInt("job_id"), job);
            }
        } catch (Exception ignored) {}
    }

    // ---- Queue processor: runs one queued job at a time, automatically
    // moving to the next one when each finishes. Also the resume path: a
    // job left in "running" status from a previous app session (app was
    // closed, or the Automation page just wasn't open when it needed to
    // continue) is picked up here in preference to starting a fresh queued
    // job — and picked up from its last reported step/URL, not step 0. ----
    // ---- Job Dependencies (#91): a job with depends_on set is only
    // eligible to run once that other job's status is "done". If the
    // dependency itself no longer exists in the cache (deleted), treat
    // it as satisfied rather than blocking forever on a ghost job. ----
    private boolean isBlockedByDependency(JSONObject job) {
        int dependsOn = job.optInt("depends_on", 0);
        if (dependsOn <= 0) return false;
        JSONObject depJob = automationJobsCache.get(dependsOn);
        if (depJob == null) return false;
        return !"done".equals(depJob.optString("status"));
    }

    private void maybeStartAutomationQueue() {
        for (int lane = 0; lane < MAX_PARALLEL_AUTOMATION_JOBS; lane++) {
            if (currentAutomationJobIds[lane] != null) continue; // lane already busy

            Set<Integer> activeJobIds = new HashSet<>();
            for (Integer id : currentAutomationJobIds) if (id != null) activeJobIds.add(id);

            JSONObject next = null;
            for (JSONObject job : automationJobsCache.values()) {
                if (activeJobIds.contains(job.optInt("job_id"))) continue;
                if ("running".equals(job.optString("status"))) { next = job; break; }
            }
            if (next == null) {
                for (JSONObject job : automationJobsCache.values()) {
                    if (activeJobIds.contains(job.optInt("job_id"))) continue;
                    if (!"queued".equals(job.optString("status"))) continue;
                    if (isBlockedByDependency(job)) continue; // Job Dependencies (#91) — not eligible yet
                    // Dry Run Mode (#77): fully planned and sitting
                    // "queued" like any other job, but deliberately not
                    // picked up until the user confirms via ⋮ → "Run for
                    // Real" (see confirmDryRunJob / /agent/jobs/{id}/confirm-run).
                    if (job.optBoolean("dry_run", false)) continue;
                    next = job;
                    break;
                }
            }
            if (next == null) break; // no more runnable work for any remaining lane either

            startAutomationJobInLane(lane, next);
        }
    }

    // Agent Sandbox (#76): wipes cache, navigation history, and any
    // saved form-field values from this lane's WebView, and stops it
    // from accepting third-party cookies — so a sandboxed job can't
    // ride along on anything cached from the user's regular browsing,
    // and doesn't leave its own traces behind either. NOTE: this is
    // real, useful isolation, but not a fully separate browser profile
    // — Android's first-party cookie store (CookieManager) is shared
    // process-wide, and splitting it per-WebView would need a separate
    // data-directory suffix chosen before ANY WebView in the process is
    // created, which isn't compatible with toggling this per-job at
    // runtime in an already-running app.
    private void applySandboxIsolation(WebView wv) {
        wv.clearCache(true);
        wv.clearHistory();
        wv.clearFormData();
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, false);
    }

    private void startAutomationJobInLane(int lane, JSONObject next) {
        int jobId = next.optInt("job_id");
        JSONArray steps = next.optJSONArray("steps");
        if (steps == null) steps = new JSONArray();
        // Goal-Based Agent (#71): a goal-mode job legitimately starts
        // with ZERO steps — there's nothing to plan upfront, the first
        // action only gets decided once the job actually starts running
        // (see fetchNextGoalStep). A plan-mode job with no steps is the
        // old "nothing to do" case and should still be skipped.
        boolean goalMode = "goal".equals(next.optString("mode", "plan"));
        if (!goalMode && steps.length() == 0) return;
        JSONArray finalSteps = steps;

        currentAutomationJobIds[lane] = jobId;
        automationCancelFlags.put(jobId, false);
        // Agent Progress Tracking (#66): stamp when this job actually
        // started running so ETA has a clock to measure average
        // per-step time against. Only set once — a job-level auto-retry
        // (#58) or a pause/resume doesn't reset it, since "how long has
        // this task taken so far" should keep counting through those.
        if (!next.has("started_at")) {
            try { next.put("started_at", System.currentTimeMillis()); } catch (Exception ignored) {}
        }

        int resumeStep = next.optInt("current_step", 0);
        // Goal-mode jobs grow their step list one action at a time and
        // persist each one immediately as it's decided (#71), so
        // "resumeStep == steps.length()" is the NORMAL point to
        // continue from, not a stale state — only plan-mode's fixed-size
        // list means reaching the end is something to restart from.
        if (!goalMode && resumeStep >= steps.length()) resumeStep = 0; // stale/out-of-range — just restart this job
        String resumeUrl = next.optString("current_url", "");

        // Agent Sandbox (#76): wipe this lane's WebView before a FRESH
        // start (not a mid-job resume after an app restart, which
        // shouldn't wipe progress-adjacent browser state) so the job
        // can't ride along on anything cached from regular browsing.
        if (next.optBoolean("sandbox", false) && resumeStep == 0) {
            applySandboxIsolation(getOrCreateAutomationWebView(lane));
        }

        if (resumeStep > 0 && !resumeUrl.isEmpty()) {
            WebView wv = getOrCreateAutomationWebView(lane);
            int finalResumeStep = resumeStep;
            pendingAutomationContinuations[lane] = () -> executeAutomationStep(lane, jobId, finalSteps, finalResumeStep);
            wv.loadUrl(resumeUrl);
        } else {
            executeAutomationStep(lane, jobId, finalSteps, resumeStep);
        }
    }

    private void cancelStepTimeout(int lane) {
        if (automationStepTimeouts[lane] != null) {
            mainHandler.removeCallbacks(automationStepTimeouts[lane]);
            automationStepTimeouts[lane] = null;
        }
    }

    // Step Timeout (#60): schedules a timeout for any step that waits on
    // an async callback (page load / JS eval). If the real callback fires
    // first, cancelStepTimeout() removes this before it ever runs. If it
    // fires, the step is treated as failed and execution moves on rather
    // than hanging the lane forever on a stuck page.
    private void scheduleStepTimeout(int lane, int jobId, JSONArray steps, int index, String action) {
        Runnable timeout = () -> {
            automationStepTimeouts[lane] = null;
            pendingAutomationContinuations[lane] = null;
            activeStepContexts[lane] = null;
            String reason = "Step timed out after " + (AUTOMATION_STEP_TIMEOUT_MS / 1000) + "s (" + action + ")";
            if (shouldRetryStep(jobId, index, reason)) {
                int attempt = retryAttemptNumber(jobId, index);
                reportAutomationStep(lane, jobId, index, reason + " — retrying (attempt " + (attempt + 1) + ")", false, null, null);
                mainHandler.postDelayed(() -> executeAutomationStep(lane, jobId, steps, index),
                        adaptiveRetryDelayMs(reason, attempt));
            } else {
                reportAutomationStep(lane, jobId, index, reason, false, null, reason);
                executeAutomationStep(lane, jobId, steps, index + 1);
            }
        };
        automationStepTimeouts[lane] = timeout;
        mainHandler.postDelayed(timeout, AUTOMATION_STEP_TIMEOUT_MS);
    }

    // Goal-Based Agent (#71) — unlike a plan-mode job (whole step list
    // decided once, upfront), a goal-mode job only knows its GOAL; each
    // next action is decided fresh, after seeing the current page, via
    // /agent/goal/next. Reuses the exact same DOM-summary JS as
    // inspect_dom and the same Adaptive Retry (#59) helpers a normal
    // step uses on failure — but retries by asking again (same index),
    // not by re-running an already-decided action. If it can't get a
    // decision after MAX_STEP_RETRIES attempts (e.g. backend down), the
    // job ends cleanly instead of looping forever with nothing to run.
    private void fetchNextGoalStep(int lane, int jobId, JSONArray steps, int index) {
        if (Boolean.TRUE.equals(automationCancelFlags.get(jobId))) {
            currentAutomationJobIds[lane] = null;
            maybeStartAutomationQueue();
            return;
        }
        WebView wv = getOrCreateAutomationWebView(lane);
        String currentUrl = wv.getUrl();
        if (currentUrl == null) currentUrl = "";
        final String urlForRequest = currentUrl;

        wv.evaluateJavascript(INSPECT_DOM_JS, raw -> {
            String rawJson = unescapeJsString(raw);
            String domSummary = describeDomInspection(rawJson != null ? rawJson : "{}");
            networkExecutor.execute(() -> {
                JSONObject nextAction = null;
                String failReason = null;
                try {
                    JSONObject body = new JSONObject();
                    body.put("job_id", jobId);
                    body.put("current_url", urlForRequest);
                    body.put("dom_summary", domSummary);
                    JSONObject resp = httpPostJson(backendUrl + "/agent/goal/next", body, authToken);
                    nextAction = resp.optJSONObject("next_action");
                    if (nextAction == null) failReason = "Goal mode couldn't decide the next step";
                } catch (Exception e) {
                    failReason = "Goal mode request failed: " + e.getMessage();
                }
                final JSONObject finalNextAction = nextAction;
                final String finalFailReason = failReason;
                mainHandler.post(() -> {
                    if (Boolean.TRUE.equals(automationCancelFlags.get(jobId))) {
                        currentAutomationJobIds[lane] = null;
                        maybeStartAutomationQueue();
                        return;
                    }
                    if (finalNextAction != null) {
                        clearStepRetryCount(jobId, index);
                        steps.put(finalNextAction);
                        executeAutomationStep(lane, jobId, steps, index);
                        return;
                    }
                    if (shouldRetryStep(jobId, index, finalFailReason)) {
                        int attempt = retryAttemptNumber(jobId, index);
                        reportAutomationStep(lane, jobId, index, finalFailReason + " — retrying (attempt " + (attempt + 1) + ")", false, null, null);
                        mainHandler.postDelayed(() -> fetchNextGoalStep(lane, jobId, steps, index),
                                adaptiveRetryDelayMs(finalFailReason, attempt));
                    } else {
                        // Retries exhausted — end the job cleanly rather
                        // than looping forever with nothing to run.
                        reportAutomationStep(lane, jobId, index, finalFailReason, true, "Goal mode stopped: " + finalFailReason, finalFailReason);
                        currentAutomationJobIds[lane] = null;
                        mainHandler.post(() -> {
                            if (isPageShown) showFullPage(buildAutomationView());
                            maybeStartAutomationQueue();
                        });
                    }
                });
            });
        });
    }

    private void executeAutomationStep(int lane, int jobId, JSONArray steps, int index) {
        if (Boolean.TRUE.equals(automationCancelFlags.get(jobId))) {
            currentAutomationJobIds[lane] = null;
            maybeStartAutomationQueue();
            return;
        }
        if (Boolean.TRUE.equals(automationPauseFlags.get(jobId))) {
            automationPausedAtIndex.put(jobId, index);
            JSONObject pausedJob = automationJobsCache.get(jobId);
            if (pausedJob != null) { try { pausedJob.put("status", "paused"); } catch (Exception ignored) {} }
            if (isPageShown) showFullPage(buildAutomationView());
            return; // lane stays occupied, WebView untouched, waiting for Resume
        }
        // Agent Policy Engine (#80): a global ceiling across EVERY job
        // (plan-mode's own upfront list is usually short anyway, but
        // goal-mode's step-by-step growth has no natural end besides its
        // own hardcoded 25-step safety cap) — this is the user's own,
        // possibly stricter, limit. Ends the job cleanly rather than
        // mid-step, same shape as any other "done" ending.
        if (agentPolicyMaxStepsPerJob > 0 && index >= agentPolicyMaxStepsPerJob) {
            String summary = "Stopped by policy: reached the " + agentPolicyMaxStepsPerJob + "-step limit set in Agent Policy.";
            reportAutomationStep(lane, jobId, index, summary, true, summary, null);
            currentAutomationJobIds[lane] = null;
            mainHandler.post(() -> {
                if (isPageShown) showFullPage(buildAutomationView());
                maybeStartAutomationQueue();
            });
            return;
        }
        if (index >= steps.length()) {
            // Goal-Based Agent (#71): a goal-mode job's plan grows one
            // action at a time — "ran out of known steps" doesn't mean
            // the job is finished, it means the NEXT action hasn't been
            // decided yet. Fetch it instead of treating this like a
            // plan-mode job reaching its (fixed) end.
            JSONObject goalJob = automationJobsCache.get(jobId);
            if (goalJob != null && "goal".equals(goalJob.optString("mode", "plan"))) {
                fetchNextGoalStep(lane, jobId, steps, index);
                return;
            }
            if (tryJobLevelAutoRetry(lane, jobId, steps)) return;
            currentAutomationJobIds[lane] = null;
            maybeStartAutomationQueue();
            return;
        }

        JSONObject step = steps.optJSONObject(index);
        if (step == null) { executeAutomationStep(lane, jobId, steps, index + 1); return; }
        String action = step.optString("action", "");
        WebView wv = getOrCreateAutomationWebView(lane);

        switch (action) {
            case "navigate": {
                String url = step.optString("url", "");
                // Agent Permission Firewall (#79): checked here since
                // wv.loadUrl() (below) doesn't go through
                // shouldOverrideUrlLoading — that only fires for
                // navigations the WebView itself initiates (clicks,
                // redirects), not ones the app calls directly.
                if (!isDomainAllowed(url)) {
                    String reason = "🔥 Blocked by firewall: " + safeUrlHost(url);
                    reportAutomationStep(lane, jobId, index, reason, false, null, reason);
                    executeAutomationStep(lane, jobId, steps, index + 1);
                    break;
                }
                activeStepContexts[lane] = new StepContext(jobId, steps, index, action);
                pendingAutomationContinuations[lane] = () -> {
                    reportAutomationStep(lane, jobId, index, "Navigated to " + url, false, null, null);
                    executeAutomationStep(lane, jobId, steps, index + 1);
                };
                scheduleStepTimeout(lane, jobId, steps, index, action);
                wv.loadUrl(url);
                break;
            }
            case "autofill_login": {
                // Secure login action: never accepts a password from the
                // job/API. It selects a credential already stored in Nex's
                // encrypted Vault, matching the current site and requested
                // email — the job can only ask "log in as X", never supply
                // or read back a password itself.
                //
                // (Fixed misplaced-code bug: this case used to live in
                // executeAutopilotAction() — a different method with a
                // different parameter list — where it referenced step/
                // lane/jobId/steps/index that don't exist there at all,
                // and its password-manager-off check computed a condition
                // but never acted on it. Both are fixed here, in the
                // method that actually owns those variables.)
                if (!passwordManagerEnabled) {
                    String err = "Password manager is turned off — enable it in Settings to use autofill_login";
                    reportAutomationStep(lane, jobId, index, err, false, null, err);
                    executeAutomationStep(lane, jobId, steps, index + 1);
                    break;
                }
                String requestedEmail = step.optString("email", "");
                if (requestedEmail.isEmpty()) {
                    requestedEmail = step.optString("username", "");
                }
                String currentUrl = "";
                try { currentUrl = wv.getUrl() != null ? wv.getUrl() : ""; } catch (Exception ignored) {}
                String domain = extractDomain(currentUrl);
                if (domain.isEmpty()) {
                    String err = "Login autofill needs a valid website page";
                    reportAutomationStep(lane, jobId, index, err, false, null, err);
                    executeAutomationStep(lane, jobId, steps, index + 1);
                    break;
                }
                SavedCredential credential = findCredentialForDomainAndUsername(domain, requestedEmail);
                if (credential == null) {
                    String err = "No saved credential for " + requestedEmail + " on " + domain + ". Add it to Nex Passwords or complete login manually.";
                    reportAutomationStep(lane, jobId, index, err, false, null, err);
                    executeAutomationStep(lane, jobId, steps, index + 1);
                    break;
                }
                final String fillEmail = credential.username;
                final String fillPassword = credential.password;
                scheduleStepTimeout(lane, jobId, steps, index, action);
                wv.evaluateJavascript(buildAutofillLoginJs(fillEmail, fillPassword), raw -> {
                    if (automationStepTimeouts[lane] == null) return;
                    cancelStepTimeout(lane);
                    String result = unescapeJsString(raw);
                    if (result == null || result.isEmpty() || "password_field_missing".equals(result)) {
                        String err = "Login form not found for " + fillEmail;
                        reportAutomationStep(lane, jobId, index, err, false, null, err);
                        executeAutomationStep(lane, jobId, steps, index + 1);
                        return;
                    }
                    reportAutomationStep(lane, jobId, index, "Filled login for " + fillEmail + " from Nex Vault", false, null, null);
                    executeAutomationStep(lane, jobId, steps, index + 1);
                });
                break;
            }
            case "search": {
                String query = step.optString("query", "");
                String url = "https://www.google.com/search?q=" + Uri.encode(query);
                activeStepContexts[lane] = new StepContext(jobId, steps, index, action);
                pendingAutomationContinuations[lane] = () -> {
                    reportAutomationStep(lane, jobId, index, "Searched: " + query, false, null, null);
                    executeAutomationStep(lane, jobId, steps, index + 1);
                };
                scheduleStepTimeout(lane, jobId, steps, index, action);
                wv.loadUrl(url);
                break;
            }
            case "extract_text": {
                scheduleStepTimeout(lane, jobId, steps, index, action);
                wv.evaluateJavascript(
                        "(function(){return document.body?document.body.innerText.slice(0,3000):'';})()",
                        raw -> {
                            if (automationStepTimeouts[lane] == null) return; // already timed out and moved on
                            cancelStepTimeout(lane);
                            String text = unescapeJsString(raw);
                            reportAutomationStep(lane, jobId, index, text, false, null, null);
                            executeAutomationStep(lane, jobId, steps, index + 1);
                        });
                break;
            }
            case "get_youtube_transcript": {
                scheduleStepTimeout(lane, jobId, steps, index, action);
                wv.evaluateJavascript(YT_OPEN_TRANSCRIPT_JS, openResult ->
                        mainHandler.postDelayed(() -> {
                            if (automationStepTimeouts[lane] == null) return; // already timed out and moved on
                            wv.evaluateJavascript(YT_SCRAPE_TRANSCRIPT_JS, raw -> {
                                if (automationStepTimeouts[lane] == null) return;
                                cancelStepTimeout(lane);
                                String text = unescapeJsString(raw);
                                if (text == null || text.trim().isEmpty()) {
                                    text = "Transcript not found (YouTube may not offer captions for this video, or its layout changed)";
                                }
                                reportAutomationStep(lane, jobId, index, text, false, null, null);
                                executeAutomationStep(lane, jobId, steps, index + 1);
                            });
                        }, 1600));
                break;
            }
            case "click": {
                String selector = step.optString("selector", "");
                String text = step.optString("text", "");
                if (selector.isEmpty() && text.isEmpty()) {
                    String err = "Click step missing 'text' or 'selector'";
                    reportAutomationStep(lane, jobId, index, err, false, null, err);
                    executeAutomationStep(lane, jobId, steps, index + 1);
                    break;
                }
                String clickLabel = !selector.isEmpty() ? selector : text;

                // Human Approval Layer (#78): pause BEFORE attempting a
                // click whose target text looks consequential, rather
                // than only catching this reactively the way Self-
                // Healing (#57) does for its own replacement guesses.
                JSONObject clickJob = automationJobsCache.get(jobId);
                if (clickJob != null && (clickJob.optBoolean("require_approval", false) || agentPolicyAlwaysRequireApproval) && isSensitiveActionText(clickLabel)) {
                    parkForApproval(lane, jobId, index, "About to click: \"" + clickLabel + "\" — looks like a consequential action.");
                    break;
                }

                scheduleStepTimeout(lane, jobId, steps, index, action);
                wv.evaluateJavascript(buildClickJs(selector, text), raw -> {
                    if (automationStepTimeouts[lane] == null) return; // already timed out and moved on
                    cancelStepTimeout(lane);
                    boolean found = jsActionFound(unescapeJsString(raw));
                    if (found) {
                        clearStepRetryCount(jobId, index);
                        reportAutomationStep(lane, jobId, index, "Clicked: " + clickLabel, false, null, null);
                        executeAutomationStep(lane, jobId, steps, index + 1);
                        return;
                    }
                    String notFoundReason = "Element not found for click: " + clickLabel;
                    if (shouldRetryStep(jobId, index, notFoundReason)) {
                        int attempt = retryAttemptNumber(jobId, index);
                        reportAutomationStep(lane, jobId, index, "Couldn't find: " + clickLabel + " — retrying (attempt " + (attempt + 1) + ")", false, null, null);
                        mainHandler.postDelayed(() -> executeAutomationStep(lane, jobId, steps, index),
                                adaptiveRetryDelayMs(notFoundReason, attempt));
                    } else {
                        // Adaptive Retry is exhausted and it's genuinely not
                        // there under that text — Self-Healing (#57) gets one
                        // shot at finding a semantically similar element
                        // before this step is actually given up on.
                        attemptSelfHeal(lane, jobId, steps, index, "click", clickLabel, null, notFoundReason);
                    }
                });
                break;
            }
            case "type": {
                String selector = step.optString("selector", "");
                String label = step.optString("label", "");
                String text = step.optString("text", "");
                if (selector.isEmpty() && label.isEmpty()) {
                    String err = "Type step missing 'label' or 'selector'";
                    reportAutomationStep(lane, jobId, index, err, false, null, err);
                    executeAutomationStep(lane, jobId, steps, index + 1);
                    break;
                }
                String typeTarget = !selector.isEmpty() ? selector : label;

                // Sensitive Action Protection (#81): unconditional — see
                // isSensitiveFieldTarget's own comment for why this
                // can't be approved through the way #78 can.
                if (isSensitiveFieldTarget(label.isEmpty() ? selector : label, text)) {
                    String reason = "🔒 Blocked: won't type into what looks like a password/sensitive field (" + typeTarget + ")";
                    reportAutomationStep(lane, jobId, index, reason, false, null, reason);
                    executeAutomationStep(lane, jobId, steps, index + 1);
                    break;
                }

                scheduleStepTimeout(lane, jobId, steps, index, action);
                wv.evaluateJavascript(buildTypeJs(selector, label, text), raw -> {
                    if (automationStepTimeouts[lane] == null) return; // already timed out and moved on
                    cancelStepTimeout(lane);
                    boolean found = jsActionFound(unescapeJsString(raw));
                    if (found) {
                        clearStepRetryCount(jobId, index);
                        reportAutomationStep(lane, jobId, index, "Typed into: " + typeTarget, false, null, null);
                        executeAutomationStep(lane, jobId, steps, index + 1);
                        return;
                    }
                    String notFoundReason = "Field not found for type: " + typeTarget;
                    if (shouldRetryStep(jobId, index, notFoundReason)) {
                        int attempt = retryAttemptNumber(jobId, index);
                        reportAutomationStep(lane, jobId, index, "Couldn't find field: " + typeTarget + " — retrying (attempt " + (attempt + 1) + ")", false, null, null);
                        mainHandler.postDelayed(() -> executeAutomationStep(lane, jobId, steps, index),
                                adaptiveRetryDelayMs(notFoundReason, attempt));
                    } else {
                        attemptSelfHeal(lane, jobId, steps, index, "type", typeTarget, text, notFoundReason);
                    }
                });
                break;
            }
            case "scroll": {
                String direction = step.optString("direction", "down");
                int amount = step.optInt("amount", 600);
                wv.evaluateJavascript(buildScrollJs(direction, amount), raw -> {
                    reportAutomationStep(lane, jobId, index, "Scrolled " + direction, false, null, null);
                    executeAutomationStep(lane, jobId, steps, index + 1);
                });
                break;
            }
            case "inspect_dom": {
                scheduleStepTimeout(lane, jobId, steps, index, action);
                wv.evaluateJavascript(INSPECT_DOM_JS, raw -> {
                    if (automationStepTimeouts[lane] == null) return; // already timed out and moved on
                    cancelStepTimeout(lane);
                    String rawJson = unescapeJsString(raw);
                    String summary = describeDomInspection(rawJson != null ? rawJson : "{}");
                    reportAutomationStep(lane, jobId, index, summary, false, null, null);
                    executeAutomationStep(lane, jobId, steps, index + 1);
                });
                break;
            }
            // Visual Page Understanding (#53) — a real screenshot goes to
            // the server's own AI (works out of the box, no user-supplied
            // key needed, unlike Autopilot). Only used for things text/DOM
            // inspection can't answer (images, layout, "what does this
            // look like") — the planner is told to prefer inspect_dom/
            // extract_text otherwise, since this is slower and costs more.
            case "visual_understand": {
                String question = step.optString("question", "");
                String screenshotB64 = captureWebViewScreenshotBase64(wv);
                if (screenshotB64.isEmpty()) {
                    String err = "Couldn't capture a screenshot for this step";
                    reportAutomationStep(lane, jobId, index, err, false, null, err);
                    executeAutomationStep(lane, jobId, steps, index + 1);
                    break;
                }
                scheduleStepTimeout(lane, jobId, steps, index, action);
                networkExecutor.execute(() -> {
                    try {
                        JSONObject body = new JSONObject();
                        body.put("screenshot_base64", screenshotB64);
                        if (!question.isEmpty()) body.put("question", question);
                        JSONObject resp = httpPostJson(backendUrl + "/agent/visual-understand", body, authToken);
                        String description = resp.optString("description", "");
                        mainHandler.post(() -> {
                            if (automationStepTimeouts[lane] == null) return; // already timed out and moved on
                            cancelStepTimeout(lane);
                            reportAutomationStep(lane, jobId, index, description, false, null, null);
                            executeAutomationStep(lane, jobId, steps, index + 1);
                        });
                    } catch (Exception e) {
                        mainHandler.post(() -> {
                            if (automationStepTimeouts[lane] == null) return;
                            cancelStepTimeout(lane);
                            String err = "Visual understanding failed: " + e.getMessage();
                            reportAutomationStep(lane, jobId, index, err, false, null, err);
                            executeAutomationStep(lane, jobId, steps, index + 1);
                        });
                    }
                });
                break;
            }
            // Form Filling (#55), AI-assisted: inspect_dom's field list
            // goes to the AI (whichever key has "Form Filling" toggled on
            // in Settings → AI, or the server's key as fallback), it
            // decides a value per relevant field, then one JS pass fills
            // AND verifies every field (#56) in a single round trip.
            case "fill_form": {
                String instructions = step.optString("instructions", "");

                // Human Approval Layer (#78): same proactive pause as
                // "click" above — a form-fill whose own instructions
                // look consequential (checkout, payment, etc.) waits for
                // explicit OK before touching anything on the page.
                JSONObject fillFormJob = automationJobsCache.get(jobId);
                if (fillFormJob != null && (fillFormJob.optBoolean("require_approval", false) || agentPolicyAlwaysRequireApproval) && isSensitiveActionText(instructions)) {
                    parkForApproval(lane, jobId, index, "About to fill a form: \"" + instructions + "\" — looks like a consequential action.");
                    break;
                }

                scheduleStepTimeout(lane, jobId, steps, index, action);
                wv.evaluateJavascript(INSPECT_DOM_JS, raw -> {
                    if (automationStepTimeouts[lane] == null) return; // already timed out and moved on
                    String domJson = unescapeJsString(raw);
                    JSONArray fieldsArr;
                    try {
                        JSONObject parsed = new JSONObject(domJson != null ? domJson : "{}");
                        JSONArray f = parsed.optJSONArray("fields");
                        fieldsArr = f != null ? f : new JSONArray();
                    } catch (Exception e) {
                        fieldsArr = new JSONArray();
                    }
                    if (fieldsArr.length() == 0) {
                        cancelStepTimeout(lane);
                        String err = "No form fields found on this page";
                        reportAutomationStep(lane, jobId, index, err, false, null, err);
                        executeAutomationStep(lane, jobId, steps, index + 1);
                        return;
                    }
                    String currentUrl = wv.getUrl() != null ? wv.getUrl() : "";
                    JSONArray finalFieldsArr = fieldsArr;
                    networkExecutor.execute(() -> {
                        try {
                            JSONObject body = new JSONObject();
                            body.put("fields", finalFieldsArr);
                            body.put("instructions", instructions);
                            body.put("current_url", currentUrl);
                            JSONObject resp = httpPostJson(backendUrl + "/agent/fill-form", body, authToken);
                            JSONArray rawMapping = resp.optJSONArray("fields");
                            if (rawMapping == null) rawMapping = new JSONArray();

                            // Sensitive Action Protection (#81): strip any
                            // field entry that looks like a password or
                            // other sensitive value, despite
                            // /agent/fill-form's own prompt already
                            // telling the AI not to include one —
                            // enforced here, not just requested there.
                            JSONArray mapping = new JSONArray();
                            int blockedCount = 0;
                            for (int i = 0; i < rawMapping.length(); i++) {
                                JSONObject entry = rawMapping.optJSONObject(i);
                                if (entry == null) continue;
                                if (isSensitiveFieldTarget(entry.optString("label", ""), entry.optString("value", ""))) {
                                    blockedCount++;
                                    continue;
                                }
                                mapping.put(entry);
                            }
                            final int finalBlockedCount = blockedCount;

                            mainHandler.post(() -> {
                                if (automationStepTimeouts[lane] == null) return;
                                if (mapping.length() == 0) {
                                    cancelStepTimeout(lane);
                                    String err = finalBlockedCount > 0
                                            ? "🔒 Blocked " + finalBlockedCount + " sensitive field(s) — nothing else to fill"
                                            : "AI didn't return any fields to fill";
                                    reportAutomationStep(lane, jobId, index, err, false, null, err);
                                    executeAutomationStep(lane, jobId, steps, index + 1);
                                    return;
                                }
                                wv.evaluateJavascript(buildFormFillJs(mapping), fillRaw -> {
                                    if (automationStepTimeouts[lane] == null) return;
                                    cancelStepTimeout(lane);
                                    String summary = describeFormFillResult(unescapeJsString(fillRaw));
                                    if (finalBlockedCount > 0) summary = "🔒 Skipped " + finalBlockedCount + " sensitive field(s). " + summary;
                                    reportAutomationStep(lane, jobId, index, summary, false, null, null);
                                    executeAutomationStep(lane, jobId, steps, index + 1);
                                });
                            });
                        } catch (Exception e) {
                            mainHandler.post(() -> {
                                if (automationStepTimeouts[lane] == null) return;
                                cancelStepTimeout(lane);
                                String err = "Form filling failed: " + e.getMessage();
                                reportAutomationStep(lane, jobId, index, err, false, null, err);
                                executeAutomationStep(lane, jobId, steps, index + 1);
                            });
                        }
                    });
                });
                break;
            }
            // Screenshot Understanding (#54): OCR-style — reads text that's
            // baked INTO an image (logo, banner, photo), which DOM-based
            // extract_text/inspect_dom simply cannot see.
            case "read_screenshot_text": {
                String screenshotB64 = captureWebViewScreenshotBase64(wv);
                if (screenshotB64.isEmpty()) {
                    String err = "Couldn't capture a screenshot for this step";
                    reportAutomationStep(lane, jobId, index, err, false, null, err);
                    executeAutomationStep(lane, jobId, steps, index + 1);
                    break;
                }
                scheduleStepTimeout(lane, jobId, steps, index, action);
                networkExecutor.execute(() -> {
                    try {
                        JSONObject body = new JSONObject();
                        body.put("screenshot_base64", screenshotB64);
                        JSONObject resp = httpPostJson(backendUrl + "/agent/screenshot-text", body, authToken);
                        String text = resp.optString("text", "");
                        mainHandler.post(() -> {
                            if (automationStepTimeouts[lane] == null) return;
                            cancelStepTimeout(lane);
                            reportAutomationStep(lane, jobId, index, text, false, null, null);
                            executeAutomationStep(lane, jobId, steps, index + 1);
                        });
                    } catch (Exception e) {
                        mainHandler.post(() -> {
                            if (automationStepTimeouts[lane] == null) return;
                            cancelStepTimeout(lane);
                            String err = "Reading screenshot text failed: " + e.getMessage();
                            reportAutomationStep(lane, jobId, index, err, false, null, err);
                            executeAutomationStep(lane, jobId, steps, index + 1);
                        });
                    }
                });
                break;
            }
            // Screenshot Verification (#70): confirms an action's VISUAL
            // effect actually happened, for cases with no DOM signal to
            // check instead (a toast appearing, a modal closing). A FAIL
            // is reported as a real step error (visible in the job's
            // error tracking) rather than silently treated as success.
            case "verify_screenshot": {
                String expectation = step.optString("expectation", "");
                if (expectation.isEmpty()) {
                    String err = "verify_screenshot step missing 'expectation'";
                    reportAutomationStep(lane, jobId, index, err, false, null, err);
                    executeAutomationStep(lane, jobId, steps, index + 1);
                    break;
                }
                String screenshotB64ForVerify = captureWebViewScreenshotBase64(wv);
                if (screenshotB64ForVerify.isEmpty()) {
                    String err = "Couldn't capture a screenshot for this step";
                    reportAutomationStep(lane, jobId, index, err, false, null, err);
                    executeAutomationStep(lane, jobId, steps, index + 1);
                    break;
                }
                scheduleStepTimeout(lane, jobId, steps, index, action);
                networkExecutor.execute(() -> {
                    try {
                        JSONObject body = new JSONObject();
                        body.put("screenshot_base64", screenshotB64ForVerify);
                        body.put("expectation", expectation);
                        JSONObject resp = httpPostJson(backendUrl + "/agent/verify-screenshot", body, authToken);
                        boolean passed = resp.optBoolean("passed", false);
                        String result = resp.optString("result", "");
                        mainHandler.post(() -> {
                            if (automationStepTimeouts[lane] == null) return;
                            cancelStepTimeout(lane);
                            reportAutomationStep(lane, jobId, index, result, false, null, passed ? null : result);
                            executeAutomationStep(lane, jobId, steps, index + 1);
                        });
                    } catch (Exception e) {
                        mainHandler.post(() -> {
                            if (automationStepTimeouts[lane] == null) return;
                            cancelStepTimeout(lane);
                            String err = "Screenshot verification failed: " + e.getMessage();
                            reportAutomationStep(lane, jobId, index, err, false, null, err);
                            executeAutomationStep(lane, jobId, steps, index + 1);
                        });
                    }
                });
                break;
            }
            case "wait": {
                int ms = step.optInt("ms", 1000);
                reportAutomationStep(lane, jobId, index, "Waited " + ms + "ms", false, null, null);
                mainHandler.postDelayed(() -> executeAutomationStep(lane, jobId, steps, index + 1), ms);
                break;
            }
            case "done":
            default: {
                if (tryJobLevelAutoRetry(lane, jobId, steps)) { break; }
                String summary = step.optString("summary", "Task complete");
                JSONObject doneJob = automationJobsCache.get(jobId);
                boolean wantsVerification = doneJob != null && doneJob.optBoolean("verify_result", false);
                if (wantsVerification) {
                    attemptResultVerification(lane, jobId, index, summary);
                } else {
                    reportAutomationStep(lane, jobId, index, summary, true, summary, null);
                    currentAutomationJobIds[lane] = null;
                    mainHandler.post(() -> {
                        if (isPageShown) showFullPage(buildAutomationView());
                        maybeStartAutomationQueue();
                    });
                }
                break;
            }
        }
    }

    private static final String YT_OPEN_TRANSCRIPT_JS =
            "(function(){try{"
            + "var btns=document.querySelectorAll('button');"
            + "for(var i=0;i<btns.length;i++){"
            + "var label=(btns[i].getAttribute('aria-label')||btns[i].textContent||'').toLowerCase();"
            + "if(label.indexOf('transcript')>-1){btns[i].click();return 'clicked';}}"
            + "var more=document.querySelector('button[aria-label=\"More actions\"]');"
            + "if(more){more.click();}return 'tried';"
            + "}catch(e){return 'error';}})()";

    private static final String YT_SCRAPE_TRANSCRIPT_JS =
            "(function(){try{"
            + "var segs=document.querySelectorAll('ytd-transcript-segment-renderer');"
            + "if(!segs||segs.length===0)return '';"
            + "var out=[];for(var i=0;i<segs.length;i++){out.push(segs[i].innerText);}"
            + "return out.join(' ');"
            + "}catch(e){return '';}})()";

    // ================================================================
    // Universal Action Engine (#51) — click/type/scroll on top of the
    // existing navigate/search/extract_text vocabulary. The planner
    // (Claude, in AGENT_SYSTEM_PROMPT on the backend) never sees the
    // live page, so it can only describe WHAT to click/type by visible
    // text/label — never a guessed CSS selector. A "selector" field is
    // still accepted on both actions for anything that constructs steps
    // more directly (e.g. a future DOM Inspection step, #52, that has
    // actually seen the page) — text/label is the common case, selector
    // is the escape hatch.
    // ================================================================
    private static final String CLICK_BY_TEXT_JS_TEMPLATE =
            "(function(){try{"
            + "var target=%s.toLowerCase();"
            + "var els=document.querySelectorAll('button,a,input[type=submit],input[type=button],[role=button],[onclick]');"
            + "for(var i=0;i<els.length;i++){"
            + "var el=els[i];"
            + "var text=((el.innerText||el.value||el.getAttribute('aria-label')||'')+'').trim().toLowerCase();"
            + "if(text.indexOf(target)>-1){el.scrollIntoView({block:'center'});el.click();return 'clicked';}}"
            + "return 'NOT_FOUND';"
            + "}catch(e){return 'error:'+e.message;}})()";

    private static final String CLICK_BY_SELECTOR_JS_TEMPLATE =
            "(function(){try{"
            + "var el=document.querySelector(%s);"
            + "if(!el)return 'NOT_FOUND';"
            + "el.scrollIntoView({block:'center'});el.click();return 'clicked';"
            + "}catch(e){return 'error:'+e.message;}})()";

    private static final String TYPE_BY_LABEL_JS_TEMPLATE =
            "(function(){try{"
            + "var label=%s.toLowerCase();"
            + "var value=%s;"
            + "var inputs=document.querySelectorAll('input,textarea');"
            + "for(var i=0;i<inputs.length;i++){"
            + "var el=inputs[i];"
            + "var hay=((el.placeholder||'')+' '+(el.name||'')+' '+(el.id||'')+' '+(el.getAttribute('aria-label')||'')).toLowerCase();"
            + "if(hay.indexOf(label)>-1){"
            + "el.focus();"
            + "var proto=el.tagName==='TEXTAREA'?window.HTMLTextAreaElement.prototype:window.HTMLInputElement.prototype;"
            + "var setter=Object.getOwnPropertyDescriptor(proto,'value').set;"
            + "setter.call(el,value);"
            + "el.dispatchEvent(new Event('input',{bubbles:true}));"
            + "el.dispatchEvent(new Event('change',{bubbles:true}));"
            + "return 'typed';}}"
            + "return 'NOT_FOUND';"
            + "}catch(e){return 'error:'+e.message;}})()";

    private static final String TYPE_BY_SELECTOR_JS_TEMPLATE =
            "(function(){try{"
            + "var el=document.querySelector(%s);"
            + "if(!el)return 'NOT_FOUND';"
            + "var value=%s;"
            + "el.focus();"
            + "var proto=el.tagName==='TEXTAREA'?window.HTMLTextAreaElement.prototype:window.HTMLInputElement.prototype;"
            + "var setter=Object.getOwnPropertyDescriptor(proto,'value').set;"
            + "setter.call(el,value);"
            + "el.dispatchEvent(new Event('input',{bubbles:true}));"
            + "el.dispatchEvent(new Event('change',{bubbles:true}));"
            + "return 'typed';"
            + "}catch(e){return 'error:'+e.message;}})()";

    private static final String SCROLL_JS_TEMPLATE =
            "(function(){try{window.scrollBy(0,%d);return 'scrolled';}catch(e){return 'error';}})()";

    // DOM Inspection (#52) — a structured look at what's actually
    // clickable/fillable on the current page, rather than raw page text
    // (that's extract_text's job). Returned as JSON so Android can turn
    // it into a readable summary for the step result; also gives a
    // human reading the job's steps a concrete answer for WHY a later
    // click/type step might report "not found" (the element genuinely
    // wasn't there under that text/label).
    private static final String INSPECT_DOM_JS =
            "(function(){try{"
            + "var buttons=[];"
            + "var els=document.querySelectorAll('button,a,input[type=submit],input[type=button],[role=button]');"
            + "for(var i=0;i<els.length&&buttons.length<25;i++){"
            + "var t=(els[i].innerText||els[i].value||els[i].getAttribute('aria-label')||'').trim();"
            + "if(t)buttons.push(t.slice(0,60));}"
            + "var fields=[];"
            + "var inputs=document.querySelectorAll('input,textarea');"
            + "for(var j=0;j<inputs.length&&fields.length<25;j++){"
            + "var el=inputs[j];"
            + "if(el.type==='hidden')continue;"
            + "var label=el.placeholder||el.name||el.getAttribute('aria-label')||el.id||('field '+j);"
            + "fields.push((''+label).slice(0,60));}"
            + "return JSON.stringify({buttons:buttons,fields:fields});"
            + "}catch(e){return JSON.stringify({buttons:[],fields:[],error:String(e)});}})()";

    // Form Filling (#55) + Page Element Verification (#56): fills every
    // AI-decided {label,value} pair in one pass, then immediately reads
    // each field's value straight back off the DOM to confirm it actually
    // took — this readback IS the verification, not just an assumption
    // that setting .value succeeded.
    private static final String FORM_FILL_AND_VERIFY_JS_TEMPLATE =
            "(function(){try{"
            + "var mapping=%s;"
            + "var inputs=document.querySelectorAll('input,textarea');"
            + "var results=[];"
            + "for(var m=0;m<mapping.length;m++){"
            + "var label=(mapping[m].label||'').toLowerCase();"
            + "var value=mapping[m].value;"
            + "var found=false, verified=false;"
            + "for(var i=0;i<inputs.length;i++){"
            + "var el=inputs[i];"
            + "var hay=((el.placeholder||'')+' '+(el.name||'')+' '+(el.id||'')+' '+(el.getAttribute('aria-label')||'')).toLowerCase();"
            + "if(hay.indexOf(label)>-1){"
            + "found=true;"
            + "el.focus();"
            + "var proto=el.tagName==='TEXTAREA'?window.HTMLTextAreaElement.prototype:window.HTMLInputElement.prototype;"
            + "var setter=Object.getOwnPropertyDescriptor(proto,'value').set;"
            + "setter.call(el,value);"
            + "el.dispatchEvent(new Event('input',{bubbles:true}));"
            + "el.dispatchEvent(new Event('change',{bubbles:true}));"
            + "verified=(el.value===value);"
            + "break;}}"
            + "results.push({label:mapping[m].label,found:found,verified:verified});}"
            + "return JSON.stringify(results);"
            + "}catch(e){return JSON.stringify([{error:String(e)}]);}})()";

    private String buildClickJs(String selector, String text) {
        return !selector.isEmpty()
                ? String.format(java.util.Locale.US, CLICK_BY_SELECTOR_JS_TEMPLATE, JSONObject.quote(selector))
                : String.format(java.util.Locale.US, CLICK_BY_TEXT_JS_TEMPLATE, JSONObject.quote(text));
    }

    private String buildTypeJs(String selector, String label, String text) {
        return !selector.isEmpty()
                ? String.format(java.util.Locale.US, TYPE_BY_SELECTOR_JS_TEMPLATE, JSONObject.quote(selector), JSONObject.quote(text))
                : String.format(java.util.Locale.US, TYPE_BY_LABEL_JS_TEMPLATE, JSONObject.quote(label), JSONObject.quote(text));
    }

    private String buildScrollJs(String direction, int amount) {
        int delta = "up".equalsIgnoreCase(direction) ? -Math.abs(amount) : Math.abs(amount);
        return String.format(java.util.Locale.US, SCROLL_JS_TEMPLATE, delta);
    }

    private String buildFormFillJs(JSONArray mapping) {
        return String.format(java.util.Locale.US, FORM_FILL_AND_VERIFY_JS_TEMPLATE, mapping.toString());
    }

    private boolean jsActionFound(String outcome) {
        return outcome != null && !outcome.contains("NOT_FOUND") && !outcome.startsWith("error");
    }

    private String describeDomInspection(String rawJson) {
        try {
            JSONObject parsed = new JSONObject(rawJson);
            JSONArray buttons = parsed.optJSONArray("buttons");
            JSONArray fields = parsed.optJSONArray("fields");
            List<String> buttonList = new ArrayList<>();
            if (buttons != null) for (int i = 0; i < buttons.length(); i++) buttonList.add(buttons.optString(i));
            List<String> fieldList = new ArrayList<>();
            if (fields != null) for (int i = 0; i < fields.length(); i++) fieldList.add(fields.optString(i));

            StringBuilder sb = new StringBuilder();
            sb.append("Clickable: ").append(buttonList.isEmpty() ? "(none found)" : String.join(", ", buttonList));
            sb.append(" | Fields: ").append(fieldList.isEmpty() ? "(none found)" : String.join(", ", fieldList));
            return sb.toString();
        } catch (Exception e) {
            return "Couldn't read the page's elements";
        }
    }

    // Page Element Verification (#56), applied to Form Filling's result:
    // reads back the same {found, verified} flags the JS readback
    // produced, so the step report is honest about which fields actually
    // ended up with the value asked for, not just "ran without crashing".
    private String describeFormFillResult(String rawJson) {
        try {
            JSONArray results = new JSONArray(rawJson);
            List<String> filled = new ArrayList<>();
            List<String> notFound = new ArrayList<>();
            List<String> notVerified = new ArrayList<>();
            for (int i = 0; i < results.length(); i++) {
                JSONObject r = results.optJSONObject(i);
                if (r == null) continue;
                String label = r.optString("label", "field");
                boolean found = r.optBoolean("found", false);
                boolean verified = r.optBoolean("verified", false);
                if (!found) notFound.add(label);
                else if (!verified) notVerified.add(label);
                else filled.add(label);
            }
            StringBuilder sb = new StringBuilder();
            sb.append("Filled: ").append(filled.isEmpty() ? "(none)" : String.join(", ", filled));
            if (!notVerified.isEmpty()) sb.append(" | Set but unverified: ").append(String.join(", ", notVerified));
            if (!notFound.isEmpty()) sb.append(" | Not found: ").append(String.join(", ", notFound));
            return sb.toString();
        } catch (Exception e) {
            return "Couldn't read the form-fill result";
        }
    }

    // Self-Healing Agent (#57) — see the field comment near
    // automationSelfHealAttempted for the overall design. Captures a
    // fresh DOM summary + screenshot of the current page and asks the
    // backend's AI whether something else visible is clearly the same
    // element the plan was looking for.
    // Agent-to-Agent Verification (#73) — only called for a job that
    // opted in (verify_result checkbox at creation). A SECOND, separate
    // AI call reviews the worker's own claimed summary against a real
    // screenshot before the job is allowed to be marked truly "done" —
    // distinct from Screenshot Verification (#70), which checks ONE
    // action's immediate visual effect mid-task, not the whole job's
    // final claim.
    private void attemptResultVerification(int lane, int jobId, int index, String summary) {
        WebView wv = getOrCreateAutomationWebView(lane);
        String screenshotB64 = captureWebViewScreenshotBase64(wv);
        JSONObject job = automationJobsCache.get(jobId);
        String instruction = job != null ? job.optString("instruction", "") : "";

        if (screenshotB64.isEmpty()) {
            // Nothing to verify against — don't block the job on a
            // capture failure, just let it complete unverified.
            reportAutomationStep(lane, jobId, index, summary, true, summary, null);
            currentAutomationJobIds[lane] = null;
            mainHandler.post(() -> {
                if (isPageShown) showFullPage(buildAutomationView());
                maybeStartAutomationQueue();
            });
            return;
        }

        networkExecutor.execute(() -> {
            JSONObject resp;
            try {
                JSONObject body = new JSONObject();
                body.put("job_id", jobId);
                body.put("instruction", instruction);
                body.put("final_result", summary);
                body.put("screenshot_base64", screenshotB64);
                resp = httpPostJson(backendUrl + "/agent/verify", body, authToken);
            } catch (Exception e) {
                resp = null;
            }
            JSONObject finalResp = resp;
            mainHandler.post(() -> {
                // Couldn't reach the verifier at all — don't strand the
                // job in limbo over a network blip; let it complete
                // unverified rather than parking forever.
                Boolean verified = finalResp != null ? finalResp.optBoolean("verified", true) : null;
                String reason = finalResp != null ? finalResp.optString("reason", "") : null;
                reportAutomationStep(lane, jobId, index, summary, true, summary, null, false, verified, reason);
                currentAutomationJobIds[lane] = null;
                mainHandler.post(() -> {
                    if (isPageShown) showFullPage(buildAutomationView());
                    maybeStartAutomationQueue();
                });
            });
        });
    }

    private void attemptSelfHeal(int lane, int jobId, JSONArray steps, int index, String action,
                                  String originalTarget, String typeText, String notFoundReason) {
        String key = jobId + ":" + index;
        String label = "click".equals(action) ? ("Couldn't find: " + originalTarget) : ("Couldn't find field: " + originalTarget);
        if (automationSelfHealAttempted.contains(key)) {
            // Already tried healing this exact step once — don't guess again.
            reportAutomationStep(lane, jobId, index, label, false, null, notFoundReason);
            executeAutomationStep(lane, jobId, steps, index + 1);
            return;
        }
        automationSelfHealAttempted.add(key);

        WebView wv = getOrCreateAutomationWebView(lane);
        String screenshotB64 = captureWebViewScreenshotBase64(wv);
        JSONObject job = automationJobsCache.get(jobId);
        String goal = job != null ? job.optString("instruction", "") : "";

        wv.evaluateJavascript(INSPECT_DOM_JS, domRaw -> {
            String domJson = unescapeJsString(domRaw);
            networkExecutor.execute(() -> {
                JSONObject resp;
                try {
                    JSONObject body = new JSONObject();
                    body.put("target", originalTarget);
                    body.put("action", action);
                    body.put("dom_json", domJson != null ? domJson : "{}");
                    body.put("goal", goal);
                    if (!screenshotB64.isEmpty()) body.put("screenshot_base64", screenshotB64);
                    resp = httpPostJson(backendUrl + "/agent/self-heal", body, authToken);
                } catch (Exception e) {
                    resp = null;
                }
                JSONObject finalResp = resp;
                mainHandler.post(() -> {
                    boolean found = finalResp != null && finalResp.optBoolean("found", false);
                    String replacement = finalResp != null ? finalResp.optString("replacement", "") : "";
                    boolean needsApproval = finalResp != null && finalResp.optBoolean("needs_approval", false);
                    String reason = finalResp != null ? finalResp.optString("reason", "") : "";

                    if (!found || replacement.isEmpty()) {
                        reportAutomationStep(lane, jobId, index, label + " (self-heal found no match)", false, null, notFoundReason);
                        executeAutomationStep(lane, jobId, steps, index + 1);
                        return;
                    }

                    if (needsApproval) {
                        JSONObject pending = new JSONObject();
                        try {
                            pending.put("lane", lane);
                            pending.put("action", action);
                            pending.put("replacement", replacement);
                            pending.put("typeText", typeText == null ? "" : typeText);
                            pending.put("index", index);
                        } catch (Exception ignored) {}
                        automationPendingHeals.put(jobId, pending);
                        String msg = "🔔 Needs approval: " + (reason.isEmpty() ? "this action looks sensitive" : reason)
                                + " — found \"" + replacement + "\" for \"" + originalTarget + "\". Review in Task menu.";
                        reportAutomationStep(lane, jobId, index, msg, false, null, null, true);
                        // Deliberately DO NOT free the lane or advance to the next
                        // step here — the job stays parked exactly where it is,
                        // WebView untouched, until the user approves or skips it.
                        return;
                    }

                    // Not flagged as sensitive — safe to retry automatically,
                    // now targeting the AI's replacement instead of the
                    // original text that no longer matches anything.
                    executeHealedAction(lane, jobId, steps, index, action, originalTarget, replacement, typeText, notFoundReason);
                });
            });
        });
    }

    // Runs the actual click/type using a self-healed replacement label,
    // shared by the automatic (non-sensitive) path above and by the
    // user tapping "Approve & Continue" on a parked sensitive one.
    private void executeHealedAction(int lane, int jobId, JSONArray steps, int index, String action,
                                      String originalTarget, String replacement, String typeText, String notFoundReason) {
        WebView wv = getOrCreateAutomationWebView(lane);
        String js = "click".equals(action)
                ? buildClickJs("", replacement)
                : buildTypeJs("", replacement, typeText == null ? "" : typeText);
        wv.evaluateJavascript(js, raw -> {
            boolean found = jsActionFound(unescapeJsString(raw));
            if (found) {
                String verb = "click".equals(action) ? "Clicked" : "Typed into";
                clearStepRetryCount(jobId, index);
                reportAutomationStep(lane, jobId, index,
                        "Self-healed: " + verb + " \"" + replacement + "\" (was looking for \"" + originalTarget + "\")",
                        false, null, null);
            } else {
                String label = "click".equals(action) ? ("Couldn't find: " + originalTarget) : ("Couldn't find field: " + originalTarget);
                reportAutomationStep(lane, jobId, index, label + " (self-heal match \"" + replacement + "\" also failed)", false, null, notFoundReason);
            }
            executeAutomationStep(lane, jobId, steps, index + 1);
        });
    }

    // Human Approval Layer (#78) — deliberate, simple keyword check, no
    // AI call (this needs to run on every click/fill_form step of a job
    // that opted in). Scoped to CONSEQUENTIAL actions specifically
    // (purchases, deletions, sends, account changes) rather than
    // sensitive DATA — a typed password or card number is a different
    // concern from a click that spends money or deletes something.
    private boolean isSensitiveActionText(String text) {
        if (text == null || text.isEmpty()) return false;
        String t = text.toLowerCase(java.util.Locale.US);
        if (t.contains("buy") || t.contains("purchase") || t.contains("checkout") || t.contains("place order")
                || t.contains("pay") || t.contains("delete") || t.contains("remove") || t.contains("cancel subscription")
                || t.contains("unsubscribe") || t.contains("send") || t.contains("submit") || t.contains("confirm")
                || t.contains("transfer") || t.contains("deactivate") || t.contains("close account")) {
            return true;
        }
        // Agent Policy Engine (#80): the user's own additions to the
        // hardcoded list above — checked the same way, never replacing it.
        for (String kw : agentPolicyCustomKeywords) {
            if (!kw.isEmpty() && t.contains(kw)) return true;
        }
        return false;
    }

    // Sensitive Action Protection (#81) — distinct from Human Approval
    // Layer (#78) above: that pauses for consequential ACTIONS (buy,
    // delete, pay…) and can be approved through; this is an
    // unconditional block on typing sensitive DATA into a field, not an
    // opt-in and not something an approval can override, since it's
    // protecting data the agent shouldn't be handling at all — not a
    // real action the user might reasonably want to approve.
    private boolean isSensitiveFieldTarget(String label, String text) {
        if (label != null && !label.isEmpty()) {
            String t = label.toLowerCase(java.util.Locale.US);
            if (t.contains("password") || t.contains("passwd") || t.contains("passcode")
                    || t.contains("pin") || t.contains("cvv") || t.contains("cvc")
                    || t.contains("card number") || t.contains("credit card") || t.contains("debit card")
                    || t.contains("ssn") || t.contains("social security") || t.contains("passport")
                    || t.contains("routing number") || t.contains("bank account") || t.contains("account number")
                    || t.contains("security code") || t.contains("expiry") || t.contains("expiration")) {
                return true;
            }
        }
        if (text != null && !text.isEmpty()) {
            // Defense in depth even when the label itself doesn't say
            // so: a value that's SHAPED like a card number or an SSN is
            // worth blocking regardless of what the field was called.
            String cleaned = text.replaceAll("[\\s-]", "");
            if (cleaned.matches("\\d{13,19}") || cleaned.matches("\\d{9}")) return true;
        }
        return false;
    }

    // Parks a step exactly like Self-Healing (#57)'s own needs_approval
    // flow — lane deliberately left occupied, WebView untouched — but
    // for a step that hasn't been attempted at all yet, so approving it
    // just means "go ahead and run it as originally planned" rather
    // than "use this replacement guess".
    private void parkForApproval(int lane, int jobId, int index, String message) {
        JSONObject pending = new JSONObject();
        try {
            pending.put("lane", lane);
            pending.put("index", index);
        } catch (Exception ignored) {}
        automationPendingApprovals.put(jobId, pending);
        reportAutomationStep(lane, jobId, index, "🔔 " + message + " Review in Task menu.", false, null, null, true);
        // Deliberately DO NOT free the lane or advance to the next step
        // here — parked exactly where it is until approved or skipped.
    }

    // Called from the Task's "⋮" menu (routed there when
    // automationPendingApprovals, not automationPendingHeals, has this
    // job's entry). Just re-enters the step at the same index — it was
    // never attempted, so there's nothing to redo, only to finally run.
    private void approvePendingAction(int jobId) {
        JSONObject pending = automationPendingApprovals.remove(jobId);
        JSONObject job = automationJobsCache.get(jobId);
        JSONArray steps = job != null ? job.optJSONArray("steps") : null;
        if (pending == null || job == null || steps == null) {
            Toast.makeText(this, "Nothing pending to approve — try re-running the task", Toast.LENGTH_LONG).show();
            return;
        }
        int lane = pending.optInt("lane", -1);
        int index = pending.optInt("index", -1);
        if (lane < 0 || index < 0) {
            Toast.makeText(this, "Nothing pending to approve — try re-running the task", Toast.LENGTH_LONG).show();
            return;
        }
        executeAutomationStep(lane, jobId, steps, index);
    }

    // Also from the "⋮" menu — declines the flagged step and moves the
    // job on to the next one without performing it.
    private void skipPendingAction(int jobId) {
        JSONObject pending = automationPendingApprovals.remove(jobId);
        JSONObject job = automationJobsCache.get(jobId);
        JSONArray steps = job != null ? job.optJSONArray("steps") : null;
        if (pending == null || job == null || steps == null) return;
        int lane = pending.optInt("lane", -1);
        int index = pending.optInt("index", -1);
        if (lane < 0 || index < 0) return;
        reportAutomationStep(lane, jobId, index, "Skipped (user declined the flagged action)", false, null, null);
        executeAutomationStep(lane, jobId, steps, index + 1);
    }

    // Called from the Task's "⋮" menu when its status is "needs_approval".
    // Executes the exact action self-heal had parked, using the same
    // lane/WebView it was captured on (still on the right page since the
    // lane was deliberately never freed), then resumes normal execution.
    private void approvePendingHeal(int jobId) {
        JSONObject pending = automationPendingHeals.remove(jobId);
        JSONObject job = automationJobsCache.get(jobId);
        JSONArray steps = job != null ? job.optJSONArray("steps") : null;
        if (pending == null || job == null || steps == null) {
            Toast.makeText(this, "Nothing pending to approve — try re-running the task", Toast.LENGTH_LONG).show();
            return;
        }
        int lane = pending.optInt("lane", -1);
        int index = pending.optInt("index", -1);
        String action = pending.optString("action", "");
        String replacement = pending.optString("replacement", "");
        String typeText = pending.optString("typeText", "");
        if (lane < 0 || index < 0) {
            Toast.makeText(this, "Nothing pending to approve — try re-running the task", Toast.LENGTH_LONG).show();
            return;
        }
        executeHealedAction(lane, jobId, steps, index, action, "the flagged element", replacement, typeText, "Approved action failed");
    }

    // Also from the "⋮" menu — declines the flagged self-healed action and
    // moves the job on to the next step without performing it.
    private void skipPendingHeal(int jobId) {
        JSONObject pending = automationPendingHeals.remove(jobId);
        JSONObject job = automationJobsCache.get(jobId);
        JSONArray steps = job != null ? job.optJSONArray("steps") : null;
        if (pending == null || job == null || steps == null) return;
        int lane = pending.optInt("lane", -1);
        int index = pending.optInt("index", -1);
        if (lane < 0 || index < 0) return;
        reportAutomationStep(lane, jobId, index, "Skipped (user declined the flagged action)", false, null, null);
        executeAutomationStep(lane, jobId, steps, index + 1);
    }

    // Automatic Retry (#58) helper — see the field comment near
    // MAX_JOB_RETRIES for the full reasoning. Returns true if it kicked
    // off a full job restart (caller must not also finalize the job in
    // that case); false means the job should finish normally.
    private boolean tryJobLevelAutoRetry(int lane, int jobId, JSONArray steps) {
        if (Boolean.TRUE.equals(automationCancelFlags.get(jobId))) return false;
        JSONObject job = automationJobsCache.get(jobId);
        String priorError = (job != null && !job.isNull("last_error")) ? job.optString("last_error", null) : null;
        if (priorError == null || priorError.isEmpty()) return false;
        int retries = automationJobRetryCounts.getOrDefault(jobId, 0);
        if (retries >= MAX_JOB_RETRIES) return false;

        automationJobRetryCounts.put(jobId, retries + 1);
        retryPolicy.clearJob(jobId);
        automationSelfHealAttempted.removeIf(k -> k.startsWith(jobId + ":"));
        reportAutomationStep(lane, jobId, 0,
                "🔁 Automatic Retry: task ended with an unresolved error (" + priorError + ") — retrying the whole task from the start (attempt " + (retries + 2) + ")",
                false, null, null);
        executeAutomationStep(lane, jobId, steps, 0);
        return true;
    }

    // Agent Pause (#62) — see the field comment near automationPauseFlags.
    // Doesn't stop anything mid-flight; just sets the flag that
    // executeAutomationStep checks before starting its next step.
    private void pauseAutomationJob(int jobId) {
        automationPauseFlags.put(jobId, true);
        Toast.makeText(this, "Pausing after the current step finishes…", Toast.LENGTH_SHORT).show();
        // Persist the pause on the server right away so it survives an app
        // restart / device switch (previously it only lived in this process).
        if (!backendUrl.isEmpty() && !authToken.isEmpty()) {
            networkExecutor.execute(() -> {
                try { httpPostJson(backendUrl + "/agent/jobs/" + jobId + "/pause", new JSONObject(), authToken); }
                catch (Exception ignored) { /* local pause still applies; server state catches up on next pause */ }
            });
        }
    }

    // Resumes a job paused by pauseAutomationJob — continues on the exact
    // same lane/WebView it was paused on (never freed while paused), from
    // the exact step index it stopped at.
    private void resumeAutomationJob(int jobId) {
        automationPauseFlags.remove(jobId);
        Integer idx = automationPausedAtIndex.remove(jobId);
        JSONObject job = automationJobsCache.get(jobId);
        JSONArray steps = job != null ? job.optJSONArray("steps") : null;
        if (idx == null && job != null && steps != null && "paused".equals(job.optString("status"))) {
            // Paused in an earlier app session (or on another device): this process has
            // no lane/step in memory. Ask the server to resume — it flips the job back
            // to 'running' at its saved current_step — then refresh and let the normal
            // queue processor pick it up from exactly that step.
            if (backendUrl.isEmpty() || authToken.isEmpty()) return;
            networkExecutor.execute(() -> {
                try { httpPostJson(backendUrl + "/agent/jobs/" + jobId + "/resume", new JSONObject(), authToken); }
                catch (Exception ignored) {}
                refreshAutomationJobsSync();
                mainHandler.post(() -> {
                    if (isPageShown) showFullPage(buildAutomationView());
                    maybeStartAutomationQueue();
                });
            });
            return;
        }
        if (idx == null || job == null || steps == null) {
            Toast.makeText(this, "Nothing paused for this task", Toast.LENGTH_SHORT).show();
            return;
        }
        // In-session resume (lane still held): tell the server too, so its status matches.
        if (!backendUrl.isEmpty() && !authToken.isEmpty()) {
            networkExecutor.execute(() -> {
                try { httpPostJson(backendUrl + "/agent/jobs/" + jobId + "/resume", new JSONObject(), authToken); }
                catch (Exception ignored) {}
            });
        }
        int lane = -1;
        for (int l = 0; l < currentAutomationJobIds.length; l++) {
            if (currentAutomationJobIds[l] != null && jobId == currentAutomationJobIds[l]) { lane = l; break; }
        }
        if (lane < 0) {
            // Lane got freed some other way (shouldn't normally happen while
            // paused) — requeue rather than lose the task.
            try { job.put("status", "queued"); } catch (Exception ignored) {}
            showFullPage(buildAutomationView());
            maybeStartAutomationQueue();
            return;
        }
        try { job.put("status", "running"); } catch (Exception ignored) {}
        showFullPage(buildAutomationView());
        int finalLane = lane;
        int finalIdx = idx;
        executeAutomationStep(finalLane, jobId, steps, finalIdx);
    }

    private void reportAutomationStep(int lane, int jobId, int stepIndex, String stepResult, boolean done, String finalResult, String error) {
        reportAutomationStep(lane, jobId, stepIndex, stepResult, done, finalResult, error, false);
    }

    private void reportAutomationStep(int lane, int jobId, int stepIndex, String stepResult, boolean done, String finalResult, String error, boolean needsApproval) {
        reportAutomationStep(lane, jobId, stepIndex, stepResult, done, finalResult, error, needsApproval, null, null);
    }

    // Agent-to-Agent Verification (#73): verified/verificationReason are
    // only ever non-null for a job's OWN "done" report, and only when
    // that job opted into verification (see attemptResultVerification,
    // called from the "done" case before reaching here). Every other
    // call site keeps using the shorter overloads above, unaffected.
    private void reportAutomationStep(int lane, int jobId, int stepIndex, String stepResult, boolean done, String finalResult, String error, boolean needsApproval, Boolean verified, String verificationReason) {
        WebView wv = getOrCreateAutomationWebView(lane);
        String currentUrl = wv.getUrl();
        if (currentUrl == null) currentUrl = "";
        final String reportedUrl = currentUrl;

        // Reflect progress locally right away so the stepper UI updates without
        // waiting on a network round-trip
        JSONObject job = automationJobsCache.get(jobId);
        if (job != null) {
            try {
                JSONObject result = job.optJSONObject("result");
                if (result == null) result = new JSONObject();
                result.put(String.valueOf(stepIndex), stepResult);
                if (needsApproval) {
                    job.put("status", "needs_approval");
                    job.put("pending_approval_msg", stepResult);
                } else if (done && Boolean.FALSE.equals(verified)) {
                    job.put("status", "needs_verification");
                    job.remove("pending_approval_msg");
                    if (finalResult != null) result.put("final", finalResult);
                    if (verificationReason != null) result.put("verification_reason", verificationReason);
                } else if (done) {
                    job.put("status", "done");
                    job.remove("pending_approval_msg");
                    if (finalResult != null) result.put("final", finalResult);
                } else {
                    job.put("status", "running");
                    job.remove("pending_approval_msg");
                }
                job.put("result", result);
                // So a later resume (this session or a fresh app launch)
                // picks up from the step AFTER this one, at this page —
                // instead of restarting the whole task from scratch.
                job.put("current_step", stepIndex + 1);
                if (!reportedUrl.isEmpty()) job.put("current_url", reportedUrl);
                // Error Reason Tracking (#69) / Last Successful Step (#68):
                // a clean step clears any earlier error and advances how
                // far this job has actually gotten without a problem; a
                // failed step records why, without touching either.
                if (error != null) {
                    job.put("last_error", error);
                } else {
                    job.put("last_successful_step", stepIndex);
                    job.put("last_error", JSONObject.NULL);
                }
            } catch (Exception ignored) {}
        }
        if (isPageShown) mainHandler.post(() -> showFullPage(buildAutomationView()));

        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("job_id", jobId);
                body.put("step_index", stepIndex);
                body.put("step_result", stepResult);
                body.put("done", done);
                if (finalResult != null) body.put("final_result", finalResult);
                if (!reportedUrl.isEmpty()) body.put("current_url", reportedUrl);
                if (error != null) body.put("error", error);
                if (needsApproval) body.put("needs_approval", true);
                if (verified != null) body.put("verified", verified.booleanValue());
                if (verificationReason != null) body.put("verification_reason", verificationReason);
                httpPostJson(backendUrl + "/agent/report", body, authToken);

                // Multi-Agent Orchestrator (#72): finishing a job can make
                // the backend create its NEXT sub-task's job server-side
                // (see /agent/report's orchestrator hook), which this
                // device otherwise has no way to notice — there's no
                // periodic polling. Only bother refreshing when a job
                // actually finished, not on every single step.
                if (done) {
                    refreshAutomationJobsSync();
                    mainHandler.post(() -> {
                        // Agent Sandbox (#76): best-effort cleanup wipe
                        // once a sandboxed job ends, so it doesn't leave
                        // its own cache/history/form-data behind for
                        // whatever non-sandboxed job uses this lane next.
                        // The start-of-job wipe is the one that actually
                        // matters for safety; this is just good hygiene.
                        JSONObject finishedJob = automationJobsCache.get(jobId);
                        if (finishedJob != null && finishedJob.optBoolean("sandbox", false)) {
                            WebView laneWv = automationWebViews[lane];
                            if (laneWv != null) applySandboxIsolation(laneWv);
                        }
                        maybeStartAutomationQueue();
                    });
                }
            } catch (Exception ignored) {}
        });
    }

    private void cancelAutomationJob(int jobId) {
        automationCancelFlags.put(jobId, true);
        automationJobRetryCounts.remove(jobId);
        // A job parked awaiting self-heal approval (#57) or user Pause
        // (#62) never calls back into executeAutomationStep on its own,
        // so the normal cancel-flag check there never runs for it — free
        // its lane here explicitly, or it'd sit occupied forever even
        // though cancelled.
        boolean wasParked = automationPendingHeals.remove(jobId) != null
                || automationPendingApprovals.remove(jobId) != null;
        boolean wasPaused = automationPauseFlags.remove(jobId) != null;
        automationPausedAtIndex.remove(jobId);
        if (wasParked || wasPaused) {
            for (int lane = 0; lane < currentAutomationJobIds.length; lane++) {
                if (currentAutomationJobIds[lane] != null && jobId == currentAutomationJobIds[lane]) {
                    currentAutomationJobIds[lane] = null;
                }
            }
            maybeStartAutomationQueue();
        }
        JSONObject job = automationJobsCache.get(jobId);
        if (job != null) { try { job.put("status", "cancelled"); } catch (Exception ignored) {} }
        showFullPage(buildAutomationView());
        networkExecutor.execute(() -> {
            try { httpPostJson(backendUrl + "/agent/jobs/" + jobId + "/cancel", new JSONObject(), authToken); }
            catch (Exception ignored) {}
        });
    }

    private void deleteAutomationJob(int jobId) {
        automationJobsCache.remove(jobId);
        automationJobRetryCounts.remove(jobId);
        boolean wasParked = automationPendingHeals.remove(jobId) != null
                || automationPendingApprovals.remove(jobId) != null;
        boolean wasPaused = automationPauseFlags.remove(jobId) != null;
        automationPausedAtIndex.remove(jobId);
        if (wasParked || wasPaused) {
            for (int lane = 0; lane < currentAutomationJobIds.length; lane++) {
                if (currentAutomationJobIds[lane] != null && jobId == currentAutomationJobIds[lane]) {
                    currentAutomationJobIds[lane] = null;
                }
            }
            maybeStartAutomationQueue();
        }
        showFullPage(buildAutomationView());
        networkExecutor.execute(() -> {
            try {
                URL url = new URL(backendUrl + "/agent/jobs/" + jobId);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("DELETE");
                conn.setRequestProperty("Authorization", "Bearer " + authToken);
                conn.getResponseCode();
            } catch (Exception ignored) {}
        });
    }

    private void reorderAutomationJob(int jobId) {
        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("direction", "top");
                httpPostJson(backendUrl + "/agent/jobs/" + jobId + "/reorder", body, authToken);
                refreshAutomationJobsSync();
                mainHandler.post(() -> { if (isPageShown) showFullPage(buildAutomationView()); });
            } catch (Exception ignored) {}
        });
    }

    // Agent-to-Agent Verification (#73): user override — accepts the
    // worker agent's original claimed result as good enough despite the
    // reviewer flagging it, marking the job truly "done" without
    // re-running anything.
    private void acceptVerification(int jobId) {
        JSONObject job = automationJobsCache.get(jobId);
        if (job != null) {
            try { job.put("status", "done"); } catch (Exception ignored) {}
        }
        if (isPageShown) showFullPage(buildAutomationView());
        networkExecutor.execute(() -> {
            try {
                httpPostJson(backendUrl + "/agent/jobs/" + jobId + "/accept-verification", new JSONObject(), authToken);
                refreshAutomationJobsSync();
                mainHandler.post(() -> { if (isPageShown) showFullPage(buildAutomationView()); });
            } catch (Exception ignored) {}
        });
    }

    // User-triggered full restart from step 0 — the manual counterpart
    // to Automatic Retry (#58)'s own-initiative version. Reachable from
    // a job flagged by Verification (#73)'s "Retry Task", but generic
    // enough to reuse for any job the user wants to re-run from scratch.
    private void retryAutomationJob(int jobId) {
        JSONObject job = automationJobsCache.get(jobId);
        if (job != null) {
            try {
                job.put("status", "queued");
                job.put("current_step", 0);
                job.put("current_url", "");
            } catch (Exception ignored) {}
        }
        automationJobRetryCounts.remove(jobId);
        retryPolicy.clearJob(jobId);
        automationSelfHealAttempted.removeIf(k -> k.startsWith(jobId + ":"));
        if (isPageShown) showFullPage(buildAutomationView());
        networkExecutor.execute(() -> {
            try {
                httpPostJson(backendUrl + "/agent/jobs/" + jobId + "/retry", new JSONObject(), authToken);
                refreshAutomationJobsSync();
                mainHandler.post(() -> {
                    if (isPageShown) showFullPage(buildAutomationView());
                    maybeStartAutomationQueue();
                });
            } catch (Exception ignored) {}
        });
    }

    // Dry Run Mode (#77): the job was already fully planned and sitting
    // "queued" the whole time — clearing the dry_run flag is all that's
    // needed for the normal queue to pick it up right after.
    private void confirmDryRunJob(int jobId) {
        JSONObject job = automationJobsCache.get(jobId);
        if (job != null) {
            try { job.put("dry_run", false); } catch (Exception ignored) {}
        }
        if (isPageShown) showFullPage(buildAutomationView());
        networkExecutor.execute(() -> {
            try {
                httpPostJson(backendUrl + "/agent/jobs/" + jobId + "/confirm-run", new JSONObject(), authToken);
                refreshAutomationJobsSync();
                mainHandler.post(() -> {
                    if (isPageShown) showFullPage(buildAutomationView());
                    maybeStartAutomationQueue();
                });
            } catch (Exception ignored) {}
        });
    }

    // ---- Small shared HTTP helpers (background-thread only) ----
    // ---- Session Management (#21): before any call using our OWN access
    // token, make sure it isn't about to expire — refresh it first if so.
    // This is the ONE place that needs to know about token refresh; every
    // existing call site (dozens of them) keeps working unchanged. Calls
    // using a token that ISN'T our stored authToken (e.g. null for
    // /auth/login itself) are left alone. ----
    private void ensureFreshAccessToken(String bearerToken) throws Exception {
        if (bearerToken == null || !bearerToken.equals(authToken)) return;
        if (authToken.isEmpty() || refreshToken.isEmpty()) return;
        long now = System.currentTimeMillis() / 1000;
        if (now < accessTokenExpiresAt - 60) return; // still fresh enough (60s safety buffer)

        JSONObject body = new JSONObject();
        body.put("refresh_token", refreshToken);
        try {
            JSONObject resp = httpPostJson(backendUrl + "/auth/refresh", body, null);
            authToken = resp.getString("access_token");
            accessTokenExpiresAt = now + resp.optLong("expires_in", 1800);
            securePrefs.edit()
                    .putString("auth_token", authToken)
                    .putLong("auth_access_expires_at", accessTokenExpiresAt)
                    .apply();
        } catch (Exception e) {
            // Refresh token itself is invalid/expired — clear the whole
            // session so the app stops trying with a token that will
            // never work, and the user sees "Not signed in" rather than
            // repeated silent failures.
            authToken = "";
            refreshToken = "";
            authEmail = "";
            accessTokenExpiresAt = 0;
            securePrefs.edit().remove("auth_token").remove("refresh_token")
                    .remove("auth_email").remove("auth_access_expires_at").apply();
            throw e;
        }
    }

    private JSONObject httpPostJson(String urlStr, JSONObject body, String bearerToken) throws Exception {
        ensureFreshAccessToken(bearerToken);
        String effectiveToken = (bearerToken != null && bearerToken.equals(authToken)) ? authToken : bearerToken;

        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        if (effectiveToken != null) conn.setRequestProperty("Authorization", "Bearer " + effectiveToken);
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(30000);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }

        int code = conn.getResponseCode();
        InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
        String responseStr = readStream(is);

        if (code < 200 || code >= 300) {
            String detail = responseStr;
            try { detail = new JSONObject(responseStr).optString("detail", responseStr); } catch (Exception ignored) {}
            throw new Exception(detail);
        }
        return new JSONObject(responseStr);
    }

    private JSONObject httpGetJson(String urlStr, String bearerToken) throws Exception {
        ensureFreshAccessToken(bearerToken);
        String effectiveToken = (bearerToken != null && bearerToken.equals(authToken)) ? authToken : bearerToken;

        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        if (effectiveToken != null) conn.setRequestProperty("Authorization", "Bearer " + effectiveToken);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(30000);

        int code = conn.getResponseCode();
        InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
        String responseStr = readStream(is);

        if (code < 200 || code >= 300) {
            String detail = responseStr;
            try { detail = new JSONObject(responseStr).optString("detail", responseStr); } catch (Exception ignored) {}
            throw new Exception(detail);
        }
        return new JSONObject(responseStr);
    }

    // Used by Watch List (#104) / Research Workspace (#106) removal —
    // same shape as httpGetJson above, just DELETE instead of GET.
    // PUT counterpart to httpPostJson above — same request/response shape,
    // just a different verb. Used by Custom APIs' "edit" flow (partial
    // updates: name/base_url/key, only the fields the user actually
    // changed) where POST is reserved for creating a brand-new entry.
    private JSONObject httpPutJson(String urlStr, JSONObject body, String bearerToken) throws Exception {
        ensureFreshAccessToken(bearerToken);
        String effectiveToken = (bearerToken != null && bearerToken.equals(authToken)) ? authToken : bearerToken;

        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("PUT");
        conn.setRequestProperty("Content-Type", "application/json");
        if (effectiveToken != null) conn.setRequestProperty("Authorization", "Bearer " + effectiveToken);
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(30000);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }

        int code = conn.getResponseCode();
        InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
        String responseStr = readStream(is);

        if (code < 200 || code >= 300) {
            String detail = responseStr;
            try { detail = new JSONObject(responseStr).optString("detail", responseStr); } catch (Exception ignored) {}
            throw new Exception(detail);
        }
        return new JSONObject(responseStr);
    }

    private JSONObject httpDeleteJson(String urlStr, String bearerToken) throws Exception {
        ensureFreshAccessToken(bearerToken);
        String effectiveToken = (bearerToken != null && bearerToken.equals(authToken)) ? authToken : bearerToken;

        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("DELETE");
        if (effectiveToken != null) conn.setRequestProperty("Authorization", "Bearer " + effectiveToken);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(30000);

        int code = conn.getResponseCode();
        InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
        String responseStr = readStream(is);

        if (code < 200 || code >= 300) {
            String detail = responseStr;
            try { detail = new JSONObject(responseStr).optString("detail", responseStr); } catch (Exception ignored) {}
            throw new Exception(detail);
        }
        return new JSONObject(responseStr);
    }

    private String readStream(InputStream is) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        return sb.toString();
    }

    private void resetBrowserToDefault() {
        new AccentDialogBuilder(this)
                .setTitle("Confirmation")
                .setMessage("Sure to reset your browser to default?")
                .setPositiveButton("Reset", (d, w) -> {
                    prefs.edit().remove("shortcuts").remove("history")
                            .remove("adblock_total_count").remove("adblock_pages_visited")
                            .remove("adblock_pages_filtered").remove("adblock_category_counts")
                            .remove("adblock_threat_count")
                            .remove("adblock_daily").apply();
                    loadShortcuts();
                    for (DevilTab tab : tabs) if (tab.webView != null) tab.webView.clearCache(true);
                    CookieManager.getInstance().removeAllCookies(null);
                    isAdBlockOn = true;
                    prefs.edit().putBoolean("adblock_enabled", true).apply();
                    Toast.makeText(this, "Browser reset to default", Toast.LENGTH_SHORT).show();
                    hideFullPage();
                    refreshHomeIfShown();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ================================================================
    // ADD-ONS SCREEN
    // ================================================================
    private View buildAddOnsView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(buildPageHeader("Add-ons", () -> showFullPage(buildSettingsView())));

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(24, 12, 24, 24);
        root.addView(list);

        int blocked = getIntPref("adblock_total_count");
        list.addView(buildSettingsRow("Ad Block", "Blocked " + blocked + " Ads", true,
                () -> showFullPage(buildAdBlockDashboard())));

        return root;
    }

    // ================================================================
    // AD BLOCK DASHBOARD — real, live stats from actual blocked requests
    // ================================================================
    private View buildAdBlockDashboard() {
        flushAdStats(); // include requests blocked in the last second or so
        int totalBlocked = getIntPref("adblock_total_count");
        int pagesFiltered = getIntPref("adblock_pages_filtered");
        int pagesVisited = getIntPref("adblock_pages_visited");
        JSONObject categoryCounts = getAdCategoryMap();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        TextView shareIcon = new TextView(this);
        shareIcon.setText("↗");
        shareIcon.setTextColor(getColor(R.color.text_primary));
        shareIcon.setTextSize(16);
        shareIcon.setPadding(20, 8, 20, 8);
        shareIcon.setOnClickListener(v -> {
            android.content.Intent shareIntent = new android.content.Intent(android.content.Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(android.content.Intent.EXTRA_TEXT,
                    "Nex Browser has blocked " + totalBlocked + " ads for me! 🛡");
            startActivity(android.content.Intent.createChooser(shareIntent, "Share via"));
        });

        TextView trashIcon = new TextView(this);
        trashIcon.setText("🗑");
        trashIcon.setTextSize(15);
        trashIcon.setPadding(8, 8, 12, 8);
        trashIcon.setOnClickListener(v -> new AccentDialogBuilder(this)
                .setTitle("Reset Ad Block stats?")
                .setPositiveButton("Reset", (d, w) -> {
                    resetAdBlockStats();
                    showFullPage(buildAdBlockDashboard());
                })
                .setNegativeButton("Cancel", null)
                .show());

        root.addView(buildPageHeader("Adblock", () -> showFullPage(buildAddOnsView()), shareIcon, trashIcon));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(32, 32, 32, 32);
        scroll.addView(content);
        root.addView(scroll);

        // Shield + count
        TextView shield = new TextView(this);
        shield.setText("🛡");
        shield.setTextSize(48);
        shield.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams shieldParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        shieldParams.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        shield.setLayoutParams(shieldParams);
        content.addView(shield);

        TextView countView = new TextView(this);
        countView.setText(totalBlocked + "\nAds Blocked");
        countView.setTextColor(getColor(R.color.gold));
        countView.setTextSize(16);
        countView.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams countParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        countParams.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        countParams.topMargin = 12;
        countView.setLayoutParams(countParams);
        content.addView(countView);

        // Stats row: Saved Data / Reduced Load Time / Averted Threat
        LinearLayout statsRow = new LinearLayout(this);
        statsRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams statsRowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        statsRowParams.topMargin = 40;
        statsRow.setLayoutParams(statsRowParams);
        statsRow.addView(buildStatColumn((totalBlocked * 15) + " KB", "SAVED DATA"));
        statsRow.addView(buildStatColumn(String.format(Locale.US, "%.1fs", totalBlocked * 0.3), "REDUCED LOAD TIME"));
        statsRow.addView(buildStatColumn(String.valueOf(getIntPref("adblock_threat_count")), "AVERTED THREAT"));
        content.addView(statsRow);

        // Ad Blocker toggle
        LinearLayout toggleRow = new LinearLayout(this);
        toggleRow.setOrientation(LinearLayout.HORIZONTAL);
        toggleRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams toggleRowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        toggleRowParams.topMargin = 40;
        toggleRow.setLayoutParams(toggleRowParams);

        TextView toggleLabel = new TextView(this);
        toggleLabel.setText("Ad Blocker");
        toggleLabel.setTextColor(getColor(R.color.text_primary));
        toggleLabel.setTextSize(13);
        LinearLayout.LayoutParams toggleLabelParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        toggleLabelParams.weight = 1;
        toggleLabel.setLayoutParams(toggleLabelParams);
        toggleRow.addView(toggleLabel);

        android.widget.Switch adToggle = new android.widget.Switch(this);
        adToggle.setChecked(isAdBlockOn);
        tintSwitch(adToggle);
        adToggle.setOnCheckedChangeListener((btn, checked) -> {
            isAdBlockOn = checked;
            prefs.edit().putBoolean("adblock_enabled", checked).apply();
        });
        toggleRow.addView(adToggle);
        content.addView(toggleRow);

        // Custom filter list (EasyList / hosts file)
        LinearLayout listRow = new LinearLayout(this);
        listRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams listRowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        listRowParams.topMargin = 24;
        listRow.setLayoutParams(listRowParams);
        TextView importBtn = new TextView(this);
        int customCount = adFilterEngine.ruleCount();
        importBtn.setText(customCount > 0
                ? "📥 Filter list: " + customCount + " rules · tap to replace"
                : "📥 Import filter list (EasyList / hosts file)");
        importBtn.setTextColor(ThemeManager.getAccentColor(this));
        importBtn.setTextSize(12f);
        importBtn.setOnClickListener(v -> adFilterPickerLauncher.launch("*/*"));
        listRow.addView(importBtn);
        if (customCount > 0) {
            TextView clearBtn = new TextView(this);
            clearBtn.setText("   ✕ Remove");
            clearBtn.setTextColor(getColor(R.color.text_dim));
            clearBtn.setTextSize(12f);
            clearBtn.setOnClickListener(v -> clearCustomAdFilters());
            listRow.addView(clearBtn);
        }
        content.addView(listRow);

        TextView detailsLabel = new TextView(this);
        detailsLabel.setText("DETAILS OVER LAST 30 DAYS");
        detailsLabel.setTextColor(ThemeManager.getAccentColor(this));
        detailsLabel.setTextSize(9.5f);
        detailsLabel.setLetterSpacing(0.06f);
        LinearLayout.LayoutParams detailsParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        detailsParams.topMargin = 32;
        detailsLabel.setLayoutParams(detailsParams);
        content.addView(detailsLabel);

        // Filtered Pages
        LinearLayout filteredRow = new LinearLayout(this);
        filteredRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams filteredRowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        filteredRowParams.topMargin = 20;
        filteredRow.setLayoutParams(filteredRowParams);
        filteredRow.addView(buildStatColumn(String.valueOf(pagesFiltered), "PAGES FILTERED"));
        filteredRow.addView(buildStatColumn(String.valueOf(pagesVisited), "PAGES VISITED"));
        content.addView(filteredRow);

        // 10-day bar chart
        content.addView(buildAdBlockBarChart());

        // Types of Ads Blocked
        TextView typesLabel = new TextView(this);
        typesLabel.setText("TYPES OF ADS BLOCKED");
        typesLabel.setTextColor(ThemeManager.getAccentColor(this));
        typesLabel.setTextSize(9.5f);
        typesLabel.setLetterSpacing(0.06f);
        LinearLayout.LayoutParams typesParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        typesParams.topMargin = 36;
        typesLabel.setLayoutParams(typesParams);
        content.addView(typesLabel);

        // Real breakdown by ad network category — only shows categories
        // that have actually been blocked at least once
        int maxType = 1;
        for (String cat : AD_CATEGORY_ORDER) {
            maxType = Math.max(maxType, categoryCounts.optInt(cat, 0));
        }
        boolean anyBlocked = false;
        for (String cat : AD_CATEGORY_ORDER) {
            int count = categoryCounts.optInt(cat, 0);
            if (count > 0) {
                anyBlocked = true;
                content.addView(buildAdTypeRow(cat, count, maxType));
            }
        }
        if (!anyBlocked) {
            TextView none = new TextView(this);
            none.setText("No ads blocked yet — browse a bit and check back");
            none.setTextColor(getColor(R.color.text_dim));
            none.setTextSize(10);
            LinearLayout.LayoutParams noneParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            noneParams.topMargin = 12;
            none.setLayoutParams(noneParams);
            content.addView(none);
        }

        return root;
    }

    private View buildStatColumn(String value, String label) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.weight = 1;
        col.setLayoutParams(params);

        TextView valueView = new TextView(this);
        valueView.setText(value);
        valueView.setTextColor(getColor(R.color.gold));
        valueView.setTextSize(15);
        valueView.setGravity(android.view.Gravity.CENTER);
        col.addView(valueView);

        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextColor(getColor(R.color.text_dim));
        labelView.setTextSize(8.5f);
        labelView.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        labelParams.topMargin = 6;
        labelView.setLayoutParams(labelParams);
        col.addView(labelView);

        return col;
    }

    private View buildAdBlockBarChart() {
        LinearLayout chartWrap = new LinearLayout(this);
        chartWrap.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams wrapParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        wrapParams.topMargin = 20;
        chartWrap.setLayoutParams(wrapParams);

        LinearLayout bars = new LinearLayout(this);
        bars.setOrientation(LinearLayout.HORIZONTAL);
        bars.setGravity(android.view.Gravity.BOTTOM);
        bars.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 200));

        List<String> keys = lastNDaysKeys(10);
        JSONObject daily = getDailyAdBlockMap();
        int max = 1;
        int[] values = new int[keys.size()];
        for (int i = 0; i < keys.size(); i++) {
            values[i] = daily.optInt(keys.get(i), 0);
            if (values[i] > max) max = values[i];
        }

        for (int v : values) {
            LinearLayout barCol = new LinearLayout(this);
            barCol.setOrientation(LinearLayout.VERTICAL);
            barCol.setGravity(android.view.Gravity.BOTTOM);
            LinearLayout.LayoutParams colParams = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.MATCH_PARENT);
            colParams.weight = 1;
            colParams.leftMargin = 4;
            colParams.rightMargin = 4;
            barCol.setLayoutParams(colParams);

            View bar = new View(this);
            int barHeight = Math.max(4, (int) (200f * v / max));
            LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, barHeight);
            bar.setLayoutParams(barParams);
            bar.setBackgroundColor(v > 0 ? ThemeManager.getAccentColor(this) : getColor(R.color.line_color));
            barCol.addView(bar);

            bars.addView(barCol);
        }
        chartWrap.addView(bars);

        LinearLayout labelsRow = new LinearLayout(this);
        labelsRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams labelsParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        labelsParams.topMargin = 6;
        labelsRow.setLayoutParams(labelsParams);

        TextView earlier = new TextView(this);
        earlier.setText("Earlier");
        earlier.setTextColor(getColor(R.color.text_dim));
        earlier.setTextSize(8.5f);
        LinearLayout.LayoutParams earlierParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        earlierParams.weight = 1;
        earlier.setLayoutParams(earlierParams);
        labelsRow.addView(earlier);

        TextView today = new TextView(this);
        today.setText("Today");
        today.setTextColor(getColor(R.color.text_dim));
        today.setTextSize(8.5f);
        today.setGravity(android.view.Gravity.END);
        LinearLayout.LayoutParams todayParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        todayParams.weight = 1;
        today.setLayoutParams(todayParams);
        labelsRow.addView(today);

        chartWrap.addView(labelsRow);
        return chartWrap;
    }

    private View buildAdTypeRow(String label, int count, int max) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.topMargin = 16;
        row.setLayoutParams(rowParams);

        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextColor(getColor(R.color.text_primary));
        labelView.setTextSize(10.5f);
        labelView.setWidth(200);
        row.addView(labelView);

        LinearLayout barBg = new LinearLayout(this);
        LinearLayout.LayoutParams barBgParams = new LinearLayout.LayoutParams(
                0, 16);
        barBgParams.weight = 1;
        barBgParams.rightMargin = 12;
        barBg.setLayoutParams(barBgParams);
        barBg.setBackgroundColor(getColor(R.color.line_color));

        View fill = new View(this);
        LinearLayout.LayoutParams fillParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.MATCH_PARENT);
        fillParams.weight = Math.max(0.02f, (float) count / max);
        fill.setLayoutParams(fillParams);
        fill.setBackgroundColor(ThemeManager.getAccentColor(this));
        barBg.addView(fill);

        View spacer = new View(this);
        LinearLayout.LayoutParams spacerParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.MATCH_PARENT);
        spacerParams.weight = 1f - Math.max(0.02f, (float) count / max);
        spacer.setLayoutParams(spacerParams);
        barBg.addView(spacer);

        row.addView(barBg);

        TextView countView = new TextView(this);
        countView.setText(String.valueOf(count));
        countView.setTextColor(getColor(R.color.text_dim));
        countView.setTextSize(10.5f);
        row.addView(countView);

        return row;
    }

    // ================================================================
    // AD BLOCK — matching, counting, and daily-stats persistence
    // ================================================================
    // ================================================================
    // Ad / tracker filtering. The rules, parser, matcher and cosmetic-script builder
    // live in AdFilterEngine (plain Java, unit-tested on a JVM); this file only does the
    // Android parts: the file picker, toasts, and handing the script to the WebView.
    // ================================================================
    private static final String CUSTOM_FILTER_FILE = "adblock_custom_v2.txt";
    private final AdFilterEngine adFilterEngine = new AdFilterEngine(AD_DOMAIN_CATEGORIES);

    private String matchAdDomain(String url) {
        return adFilterEngine.match(url);
    }

    private boolean isAdUrl(String url) {
        return adFilterEngine.isAd(url);
    }

    private void loadCustomAdFilters() {
        adFilterEngine.load(new java.io.File(getFilesDir(), CUSTOM_FILTER_FILE));
    }

    private void importAdFilterList(Uri uri) {
        Toast.makeText(this, "Importing filter list…", Toast.LENGTH_SHORT).show();
        networkExecutor.execute(() -> {
            try {
                AdFilterEngine.Rules parsed;
                try (InputStream is = getContentResolver().openInputStream(uri);
                     BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                    parsed = adFilterEngine.parse(r);
                }
                if (parsed.size() == 0) {
                    mainHandler.post(() -> Toast.makeText(this,
                            "No usable rules found (needs ||domain^ , hosts-style or ##cosmetic lines)", Toast.LENGTH_LONG).show());
                    return;
                }
                adFilterEngine.replace(parsed);
                adFilterEngine.save(new java.io.File(getFilesDir(), CUSTOM_FILTER_FILE));
                final String summary = parsed.blockHosts.size() + " blocked domains, "
                        + (parsed.pathRules.size() + parsed.netCount) + " pattern rules, "
                        + (parsed.genericCss.size() + parsed.domainCss.size()) + " hide rules";
                mainHandler.post(() -> {
                    Toast.makeText(this, "Imported: " + summary, Toast.LENGTH_LONG).show();
                    if (isPageShown) showFullPage(buildAdBlockDashboard());
                });
            } catch (Exception e) {
                mainHandler.post(() -> Toast.makeText(this, "Couldn't import list: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private void clearCustomAdFilters() {
        adFilterEngine.clear();
        new java.io.File(getFilesDir(), CUSTOM_FILTER_FILE).delete();
        Toast.makeText(this, "Imported rules removed", Toast.LENGTH_SHORT).show();
        if (isPageShown) showFullPage(buildAdBlockDashboard());
    }

    /** Hides ad elements with imported cosmetic rules (see AdFilterEngine.cosmeticScript). */
    private void injectCosmeticFilters(WebView view, String url) {
        if (!isAdBlockOn || url == null) return;
        String js = adFilterEngine.cosmeticScript(url);
        if (js != null) view.evaluateJavascript(js, null);
    }

    // Returns the matched category (Banners/Popups/Native Ads/Trackers),
    // or "Other" if it was blocked via isAdUrl but no specific category
    // domain matched (shouldn't normally happen since they're the same map,
    // kept as a safe fallback).
    private String categorizeAdUrl(String url) {
        String matched = matchAdDomain(url);
        if (matched != null) {
            String category = AD_DOMAIN_CATEGORIES.get(matched);
            if (category != null) return category;
            return "Banners"; // imported-list domain: no category info, count it as a banner/ad request
        }
        return "Other";
    }

    private boolean isThreatUrl(String url) {
        String matched = matchAdDomain(url);
        if (matched == null) return false;
        for (String domain : THREAT_DOMAINS) {
            if (matched.equals(domain)) return true;
        }
        return false;
    }

    // Ad-block statistics. recordAdBlocked() runs on WebView's request threads, many times per page
    // (20+ blocked requests is normal). The old version did a SharedPreferences read-modify-write of
    // JSON on every call: counters lost updates when two requests raced, and each call parsed and
    // rewrote JSON on a network thread. Now: lock-free in-memory counters, flushed to preferences in
    // one batch on the main thread.
    private final java.util.concurrent.atomic.AtomicInteger pendingAdTotal = new java.util.concurrent.atomic.AtomicInteger();
    private final java.util.concurrent.atomic.AtomicInteger pendingAdThreats = new java.util.concurrent.atomic.AtomicInteger();
    private final java.util.concurrent.ConcurrentHashMap<String, java.util.concurrent.atomic.AtomicInteger> pendingAdCategories =
            new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.concurrent.atomic.AtomicBoolean adFlushScheduled = new java.util.concurrent.atomic.AtomicBoolean(false);

    private void recordAdBlocked(String url, DevilTab tab, String category) {
        tab.blockedThisLoad = true;
        pendingAdTotal.incrementAndGet();
        pendingAdCategories.computeIfAbsent(category, k -> new java.util.concurrent.atomic.AtomicInteger()).incrementAndGet();
        if (isThreatUrl(url)) pendingAdThreats.incrementAndGet();
        if (adFlushScheduled.compareAndSet(false, true)) {
            mainHandler.postDelayed(this::flushAdStats, 1500);
        }
    }

    /** Writes the pending counters to preferences (main thread). Also called before the stats screen is built. */
    private void flushAdStats() {
        adFlushScheduled.set(false);
        int total = pendingAdTotal.getAndSet(0);
        int threats = pendingAdThreats.getAndSet(0);
        if (total == 0 && threats == 0) return;
        incrementIntPref("adblock_total_count", total);
        if (threats > 0) incrementIntPref("adblock_threat_count", threats);
        try {
            JSONObject counts = getAdCategoryMap();
            for (String category : new ArrayList<>(pendingAdCategories.keySet())) {
                java.util.concurrent.atomic.AtomicInteger n = pendingAdCategories.get(category);
                int delta = n == null ? 0 : n.getAndSet(0);
                if (delta > 0) counts.put(category, counts.optInt(category, 0) + delta);
            }
            prefs.edit().putString("adblock_category_counts", counts.toString()).apply();
        } catch (Exception ignored) {}
        try {
            JSONObject daily = getDailyAdBlockMap();
            String key = todayKey();
            daily.put(key, daily.optInt(key, 0) + total);
            prefs.edit().putString("adblock_daily", daily.toString()).apply();
        } catch (Exception ignored) {}
    }

    private JSONObject getAdCategoryMap() {
        try {
            return new JSONObject(prefs.getString("adblock_category_counts", "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private JSONObject getDailyAdBlockMap() {
        try {
            return new JSONObject(prefs.getString("adblock_daily", "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private String todayKey() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new java.util.Date());
    }

    private List<String> lastNDaysKeys(int n) {
        List<String> keys = new ArrayList<>();
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -(n - 1));
        for (int i = 0; i < n; i++) {
            keys.add(fmt.format(cal.getTime()));
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }
        return keys;
    }

    private void resetAdBlockStats() {
        prefs.edit()
                .remove("adblock_total_count").remove("adblock_pages_visited")
                .remove("adblock_pages_filtered").remove("adblock_category_counts")
                .remove("adblock_threat_count")
                .remove("adblock_daily")
                .apply();
    }

    private int getIntPref(String key) {
        return prefs.getInt(key, 0);
    }

    private void incrementIntPref(String key, int by) {
        prefs.edit().putInt(key, getIntPref(key) + by).apply();
    }

    // ================================================================
    // BOOKMARKS & HISTORY — tabbed full-page screen. Bookmarks are a
    // real, separate saved-URL list (not the Speed Dial shortcuts).
    // History reuses the same tracking already powering Most Visited.
    // ================================================================
    // Extended from Bookmarks+History to also host Tabs (Design v2's
    // "universal side panel" goal — Bookmarks/History/Tabs consolidated
    // into one screen with a shared header/tab-switcher pattern; AI/
    // Agent/Privacy remain separate full screens, too large a surface to
    // fold in here without their own redesign — see
    // UNIVERSAL-PANEL-CHANGES.md for what is and isn't covered).
    private int panelSection = 0; // 0 = Bookmarks, 1 = History, 2 = Tabs
    private boolean isEditMode = false;

    private View buildBookmarksHistoryView(boolean startOnBookmarks) {
        return buildBookmarksHistoryView(startOnBookmarks ? 0 : 1);
    }

    private View buildPanelQuickAccessChip(String label, Runnable onClick) {
        TextView chip = new TextView(this);
        chip.setText(label);
        chip.setTextColor(getColor(R.color.text_primary));
        chip.setTextSize(12);
        chip.setPadding(28, 14, 28, 14);
        chip.setBackground(getDrawable(R.drawable.bg_tab_inactive));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.rightMargin = 10;
        chip.setLayoutParams(params);
        chip.setOnClickListener(v -> onClick.run());
        return chip;
    }

    private View buildBookmarksHistoryView(int section) {
        panelSection = section;
        isEditMode = false;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // Header with tab switcher (Bookmarks | History) built into the title area
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(android.view.Gravity.CENTER_VERTICAL);
        header.setPadding(16, 40, 16, 20);
        header.setBackgroundColor(getColor(R.color.bg_secondary));

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextColor(getColor(R.color.text_primary));
        back.setTextSize(20);
        back.setPadding(12, 8, 20, 8);
        back.setOnClickListener(v -> hideUniversalPanel());
        header.addView(back);

        TextView bookmarksTabBtn = new TextView(this);
        bookmarksTabBtn.setText("Bookmarks");
        bookmarksTabBtn.setTextSize(13);
        bookmarksTabBtn.setPadding(16, 8, 16, 8);

        TextView historyTabBtn = new TextView(this);
        historyTabBtn.setText("History");
        historyTabBtn.setTextSize(13);
        historyTabBtn.setPadding(16, 8, 16, 8);

        TextView tabsTabBtn = new TextView(this);
        tabsTabBtn.setText("Tabs");
        tabsTabBtn.setTextSize(13);
        tabsTabBtn.setPadding(16, 8, 16, 8);

        bookmarksTabBtn.setOnClickListener(v -> showUniversalPanel(buildBookmarksHistoryView(0)));
        historyTabBtn.setOnClickListener(v -> showUniversalPanel(buildBookmarksHistoryView(1)));
        tabsTabBtn.setOnClickListener(v -> showUniversalPanel(buildBookmarksHistoryView(2)));

        bookmarksTabBtn.setTextColor(getColor(panelSection == 0 ? R.color.text_primary : R.color.text_dim));
        historyTabBtn.setTextColor(getColor(panelSection == 1 ? R.color.text_primary : R.color.text_dim));
        tabsTabBtn.setTextColor(getColor(panelSection == 2 ? R.color.text_primary : R.color.text_dim));

        header.addView(bookmarksTabBtn);
        header.addView(historyTabBtn);
        header.addView(tabsTabBtn);

        TextView spacer = new TextView(this);
        LinearLayout.LayoutParams spacerParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        spacerParams.weight = 1;
        spacer.setLayoutParams(spacerParams);
        header.addView(spacer);

        root.addView(header);

        // Quick-access strip — genuine navigation into AI/Agent, Vault, and
        // Ad Block from this one panel (Design v2's "universal side panel"
        // listed these alongside Bookmarks/History/AI/Agent). Each button
        // dismisses this panel and opens the existing, already-working
        // screen for that feature — deliberately NOT rebuilding their
        // logic inside this panel's tab system, since each is its own
        // large surface (see UNIVERSAL-PANEL-CHANGES.md for why that
        // boundary was chosen). This still means one screen the person
        // can reach all of them from, which is the actual point.
        HorizontalScrollView quickAccessScroll = new HorizontalScrollView(this);
        quickAccessScroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        LinearLayout quickAccessRow = new LinearLayout(this);
        quickAccessRow.setOrientation(LinearLayout.HORIZONTAL);
        quickAccessRow.setPadding(16, 12, 16, 12);
        quickAccessRow.setBackgroundColor(getColor(R.color.bg_secondary));
        quickAccessRow.addView(buildPanelQuickAccessChip("✨ AI & Agent", () -> {
            hideUniversalPanel();
            showFullPage(buildAgentOsHubView());
        }));
        quickAccessRow.addView(buildPanelQuickAccessChip("🔒 Vault", () -> {
            hideUniversalPanel();
            showFullPage(buildPasswordsView());
        }));
        quickAccessRow.addView(buildPanelQuickAccessChip("🛡 Ad Block", () -> {
            hideUniversalPanel();
            showFullPage(buildAdBlockDashboard());
        }));
        quickAccessRow.addView(buildPanelQuickAccessChip("🎨 Customize", () -> {
            hideUniversalPanel();
            showThemeCenter();
        }));
        quickAccessScroll.addView(quickAccessRow);
        root.addView(quickAccessScroll);

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(20, 16, 20, 16);
        scroll.addView(list);
        root.addView(scroll);

        if (panelSection == 0) {
            // Sign-in banner — shows real account status now
            LinearLayout signInBanner = new LinearLayout(this);
            signInBanner.setOrientation(LinearLayout.HORIZONTAL);
            signInBanner.setGravity(android.view.Gravity.CENTER_VERTICAL);
            signInBanner.setPadding(16, 20, 16, 20);
            signInBanner.setBackgroundResource(R.drawable.bg_tab_inactive);
            LinearLayout.LayoutParams bannerParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            bannerParams.bottomMargin = 16;
            signInBanner.setLayoutParams(bannerParams);

            TextView signInText = new TextView(this);
            signInText.setText(authToken.isEmpty() ? "Sign in to sync bookmarks" : "Signed in as " + authEmail);
            signInText.setTextColor(getColor(R.color.text_dim));
            signInText.setTextSize(11);
            LinearLayout.LayoutParams signInTextParams = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT);
            signInTextParams.weight = 1;
            signInText.setLayoutParams(signInTextParams);
            signInBanner.addView(signInText);

            TextView signInBtn = new TextView(this);
            signInBtn.setText(authToken.isEmpty() ? "Sign in" : "Account");
            signInBtn.setTextColor(getColor(R.color.gold));
            signInBtn.setTextSize(11);
            signInBtn.setOnClickListener(v -> showAccountScreen());
            signInBanner.addView(signInBtn);

            list.addView(signInBanner);

            List<JSONObject> bookmarks = loadBookmarks();
            if (bookmarks.isEmpty()) {
                list.addView(buildEmptyState("No bookmarks yet — tap ☆ next to the address bar to save a page"));
            } else {
                for (JSONObject bm : bookmarks) {
                    list.addView(buildBookmarkHistoryRow(bm, true));
                }
            }

            // Bottom bar: New Folder / Sync / Edit
            LinearLayout bottomBar = new LinearLayout(this);
            bottomBar.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams bottomBarParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            bottomBarParams.topMargin = 20;
            bottomBar.setLayoutParams(bottomBarParams);

            bottomBar.addView(buildBottomBarText("New Folder",
                    () -> Toast.makeText(this, "Folders — coming in a future refinement", Toast.LENGTH_SHORT).show()));
            bottomBar.addView(buildBottomBarText("Sync", this::syncBookmarksNow));
            bottomBar.addView(buildBottomBarText(isEditMode ? "Done" : "Edit",
                    () -> {
                        isEditMode = !isEditMode;
                        showUniversalPanel(buildBookmarksHistoryView(true));
                    }));
            list.addView(bottomBar);

        } else if (panelSection == 1) {
            List<JSONObject> history = loadHistorySortedByRecency();
            if (history.isEmpty()) {
                list.addView(buildEmptyState("No history yet"));
            } else {
                for (JSONObject h : history) {
                    list.addView(buildBookmarkHistoryRow(h, false));
                }

                LinearLayout historyBottomBar = new LinearLayout(this);
                historyBottomBar.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams historyBottomBarParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                historyBottomBarParams.topMargin = 20;
                historyBottomBar.setLayoutParams(historyBottomBarParams);
                historyBottomBar.addView(buildBottomBarText("Sync", this::syncHistoryNow));
                historyBottomBar.addView(buildBottomBarText("🔮 Ask", this::showSemanticHistorySearchDialog));
                historyBottomBar.addView(buildBottomBarText("🕰 Timeline", () -> { hideUniversalPanel(); showFullPage(buildBrowsingTimelineView()); }));
                historyBottomBar.addView(buildBottomBarText("Clear All",
                        () -> new AccentDialogBuilder(this)
                                .setTitle("Clear all history?")
                                .setPositiveButton("Clear", (d, w) -> {
                                    prefs.edit().putString("history", "[]").apply();
                                    showUniversalPanel(buildBookmarksHistoryView(1));
                                })
                                .setNegativeButton("Cancel", null)
                                .show()));
                list.addView(historyBottomBar);
            }
        } else {
            // Tabs section — same open-tab list the tab strip already
            // tracks, just presented alongside Bookmarks/History instead
            // of only in the horizontal strip/grid view.
            if (tabs.isEmpty()) {
                list.addView(buildEmptyState("No open tabs"));
            } else {
                for (int i = 0; i < tabs.size(); i++) {
                    final int tabIndex = i;
                    DevilTab t = tabs.get(i);

                    LinearLayout row = new LinearLayout(this);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setGravity(android.view.Gravity.CENTER_VERTICAL);
                    row.setPadding(16, 18, 16, 18);
                    row.setBackgroundResource(tabIndex == currentTabIndex ? R.drawable.bg_tab_active : R.drawable.bg_tab_inactive);
                    LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    rowParams.bottomMargin = 8;
                    row.setLayoutParams(rowParams);

                    TextView icon = new TextView(this);
                    icon.setText(t.isIncognito ? "🕶" : (t.type.equals("home") ? "🏠" : "🌐"));
                    icon.setTextSize(15);
                    LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    iconParams.rightMargin = 20;
                    icon.setLayoutParams(iconParams);
                    row.addView(icon);

                    LinearLayout textCol = new LinearLayout(this);
                    textCol.setOrientation(LinearLayout.VERTICAL);
                    textCol.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                    TextView title = new TextView(this);
                    title.setText(t.title == null || t.title.isEmpty() ? "New Tab" : t.title);
                    title.setTextColor(getColor(R.color.text_primary));
                    title.setTextSize(13.5f);
                    title.setMaxLines(1);
                    title.setEllipsize(android.text.TextUtils.TruncateAt.END);
                    textCol.addView(title);
                    if (t.webView != null && t.webView.getUrl() != null) {
                        TextView urlView = new TextView(this);
                        urlView.setText(t.webView.getUrl());
                        urlView.setTextColor(getColor(R.color.text_dim));
                        urlView.setTextSize(11);
                        urlView.setMaxLines(1);
                        urlView.setEllipsize(android.text.TextUtils.TruncateAt.END);
                        textCol.addView(urlView);
                    }
                    row.addView(textCol);

                    row.setOnClickListener(v -> {
                        hideUniversalPanel();
                        switchToTab(tabIndex);
                    });

                    TextView closeBtn = new TextView(this);
                    closeBtn.setText("✕");
                    closeBtn.setTextColor(getColor(R.color.text_dim));
                    closeBtn.setTextSize(15);
                    closeBtn.setPadding(20, 8, 8, 8);
                    closeBtn.setOnClickListener(v -> {
                        closeTab(tabIndex);
                        showUniversalPanel(buildBookmarksHistoryView(2)); // rebuild so the closed tab disappears
                    });
                    row.addView(closeBtn);

                    list.addView(row);
                }

                LinearLayout tabsBottomBar = new LinearLayout(this);
                tabsBottomBar.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams tabsBottomBarParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                tabsBottomBarParams.topMargin = 20;
                tabsBottomBar.setLayoutParams(tabsBottomBarParams);
                tabsBottomBar.addView(buildBottomBarText("+ New Tab", () -> {
                    hideUniversalPanel();
                    createNewTab(false);
                }));
                list.addView(tabsBottomBar);
            }
        }

        return root;
    }

    // ================================================================
    // SEMANTIC HISTORY SEARCH (#102) — natural-language search over
    // history, matched by MEANING against each entry's stored content
    // snippet (AI Web Memory, #101) rather than exact title/URL text.
    // ================================================================
    private void showSemanticHistorySearchDialog() {
        EditText input = new EditText(this);
        input.setHint("e.g. \"that article about tomatoes and heart health\"");
        input.setTextColor(getColor(R.color.text_primary));
        input.setHintTextColor(getColor(R.color.text_dim));
        input.setPadding(32, 24, 32, 24);

        new AccentDialogBuilder(this)
                .setTitle("🔮 Ask Your History")
                .setView(input)
                .setPositiveButton("Search", (d, w) -> {
                    String query = input.getText().toString().trim();
                    if (query.isEmpty()) {
                        Toast.makeText(this, "Type what you're looking for", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    runSemanticHistorySearch(query);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void runSemanticHistorySearch(String query) {
        Toast.makeText(this, "Searching your history…", Toast.LENGTH_SHORT).show();
        networkExecutor.execute(() -> {
            try {
                List<JSONObject> history = loadHistorySortedByRecency();
                JSONArray entries = new JSONArray();
                for (JSONObject h : history) {
                    JSONObject e = new JSONObject();
                    e.put("title", h.optString("title", ""));
                    e.put("url", h.optString("url", ""));
                    e.put("content", h.optString("content", ""));
                    entries.put(e);
                }
                JSONObject body = new JSONObject();
                body.put("query", query);
                body.put("entries", entries);
                JSONObject resp = httpPostJson(backendUrl + "/history/semantic-search", body, authToken);
                JSONArray matches = resp.optJSONArray("matches");
                List<JSONObject> matchList = new ArrayList<>();
                if (matches != null) {
                    for (int i = 0; i < matches.length(); i++) {
                        JSONObject m = matches.optJSONObject(i);
                        if (m != null) matchList.add(m);
                    }
                }
                mainHandler.post(() -> showFullPage(buildSemanticSearchResultsView(query, matchList)));
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "Search error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private View buildSemanticSearchResultsView(String query, List<JSONObject> matches) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("🔮 \"" + query + "\"", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(20, 16, 20, 16);
        list.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        if (matches.isEmpty()) {
            list.addView(buildEmptyState("Nothing in your history seems to match that"));
        } else {
            for (JSONObject m : matches) {
                list.addView(buildBookmarkHistoryRow(m, false));
            }
        }
        scroll.addView(list);
        root.addView(scroll);
        return root;
    }

    // ================================================================
    // BROWSING TIMELINE (#103) — history grouped by day, most recent
    // day first. Each day can be summarized on demand (one AI call per
    // TAP, not one per day shown) using that day's stored content
    // snippets (AI Web Memory, #101).
    // ================================================================
    private View buildBrowsingTimelineView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("🕰 Timeline", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(24, 8, 24, 32);
        content.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        List<JSONObject> history = loadHistorySortedByRecency();
        if (history.isEmpty()) {
            content.addView(buildEmptyState("No history yet"));
        } else {
            java.text.SimpleDateFormat dayFormat = new java.text.SimpleDateFormat("EEEE, MMM d", Locale.US);
            String currentDay = null;
            LinearLayout dayGroup = null;
            List<JSONObject> dayEntries = null;

            for (JSONObject h : history) {
                long ts = h.optLong("ts", 0);
                String day = dayFormat.format(new java.util.Date(ts));
                if (!day.equals(currentDay)) {
                    currentDay = day;
                    dayEntries = new ArrayList<>();
                    final List<JSONObject> thisDayEntries = dayEntries;

                    LinearLayout dayHeaderRow = new LinearLayout(this);
                    dayHeaderRow.setOrientation(LinearLayout.HORIZONTAL);
                    dayHeaderRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
                    LinearLayout.LayoutParams dayHeaderParams = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    dayHeaderParams.topMargin = 28;
                    dayHeaderParams.bottomMargin = 8;
                    dayHeaderRow.setLayoutParams(dayHeaderParams);

                    TextView dayLabel = new TextView(this);
                    dayLabel.setText(day);
                    dayLabel.setTextColor(getColor(R.color.gold));
                    dayLabel.setTextSize(13);
                    dayLabel.setTypeface(null, android.graphics.Typeface.BOLD);
                    LinearLayout.LayoutParams dayLabelParams = new LinearLayout.LayoutParams(
                            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
                    dayLabel.setLayoutParams(dayLabelParams);
                    dayHeaderRow.addView(dayLabel);

                    TextView summarizeBtn = new TextView(this);
                    summarizeBtn.setText("✨ Summarize");
                    summarizeBtn.setTextColor(getColor(R.color.text_dim));
                    summarizeBtn.setTextSize(10);
                    summarizeBtn.setPadding(12, 8, 12, 8);
                    summarizeBtn.setOnClickListener(v -> summarizeTimelineDay(summarizeBtn, thisDayEntries));
                    dayHeaderRow.addView(summarizeBtn);

                    content.addView(dayHeaderRow);
                    dayGroup = new LinearLayout(this);
                    dayGroup.setOrientation(LinearLayout.VERTICAL);
                    dayGroup.setLayoutParams(new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                    content.addView(dayGroup);
                }
                dayEntries.add(h);
                dayGroup.addView(buildBookmarkHistoryRow(h, false));
            }
        }

        scroll.addView(content);
        root.addView(scroll);
        return root;
    }

    private void summarizeTimelineDay(TextView triggerBtn, List<JSONObject> dayEntries) {
        triggerBtn.setText("Summarizing…");
        networkExecutor.execute(() -> {
            try {
                JSONArray entries = new JSONArray();
                for (JSONObject h : dayEntries) {
                    JSONObject e = new JSONObject();
                    e.put("title", h.optString("title", ""));
                    e.put("content", h.optString("content", ""));
                    entries.put(e);
                }
                JSONObject body = new JSONObject();
                body.put("entries", entries);
                JSONObject resp = httpPostJson(backendUrl + "/history/day-summary", body, authToken);
                String summary = resp.optString("summary", "");
                mainHandler.post(() -> {
                    if (!summary.isEmpty()) {
                        new AccentDialogBuilder(this)
                                .setTitle("✨ That day, in brief")
                                .setMessage(summary)
                                .setPositiveButton("OK", null)
                                .show();
                    }
                    triggerBtn.setText("✨ Summarize");
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    Toast.makeText(this, "Couldn't summarize: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    triggerBtn.setText("✨ Summarize");
                });
            }
        });
    }

    private View buildEmptyState(String message) {
        TextView empty = new TextView(this);
        empty.setText(message);
        empty.setTextColor(getColor(R.color.text_dim));
        empty.setTextSize(11);
        empty.setGravity(android.view.Gravity.CENTER);
        empty.setPadding(20, 60, 20, 60);
        return empty;
    }

    private View buildBottomBarText(String label, Runnable action) {
        TextView view = new TextView(this);
        view.setText(label);
        view.setTextColor(getColor(R.color.text_primary));
        view.setTextSize(11);
        view.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.weight = 1;
        view.setLayoutParams(params);
        view.setPadding(12, 16, 12, 16);
        view.setOnClickListener(v -> action.run());
        return view;
    }

    private View buildBookmarkHistoryRow(JSONObject entry, boolean isBookmarkRow) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(12, 18, 12, 18);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 4;
        row.setLayoutParams(rowParams);

        TextView icon = new TextView(this);
        icon.setText("🌐");
        icon.setTextSize(14);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        iconParams.rightMargin = 16;
        icon.setLayoutParams(iconParams);
        row.addView(icon);

        LinearLayout textCol = new LinearLayout(this);
        textCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textColParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        textColParams.weight = 1;
        textCol.setLayoutParams(textColParams);

        String title = entry.optString("title", entry.optString("url", ""));
        String url = entry.optString("url", "");

        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(12);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        textCol.addView(titleView);

        TextView urlView = new TextView(this);
        urlView.setText(url);
        urlView.setTextColor(getColor(R.color.text_dim));
        urlView.setTextSize(9.5f);
        urlView.setSingleLine(true);
        urlView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams urlParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        urlParams.topMargin = 3;
        urlView.setLayoutParams(urlParams);
        textCol.addView(urlView);

        row.addView(textCol);

        if (isBookmarkRow && isEditMode) {
            TextView removeBtn = new TextView(this);
            removeBtn.setText("✕");
            removeBtn.setTextColor(ThemeManager.getAccentColor(this));
            removeBtn.setTextSize(14);
            removeBtn.setPadding(20, 8, 8, 8);
            removeBtn.setOnClickListener(v -> {
                removeBookmark(url);
                showUniversalPanel(buildBookmarksHistoryView(true));
            });
            row.addView(removeBtn);
        }

        row.setOnClickListener(v -> {
            hideAnyOverlay();
            navigate(url);
        });

        return row;
    }

    // ---- Bookmarks persistence (separate from Speed Dial shortcuts) ----
    private void toggleBookmarkCurrentPage() {
        WebView wv = currentWebView();
        DevilTab tab = currentTab();
        if (wv == null || tab == null || "home".equals(tab.type) || wv.getUrl() == null) {
            Toast.makeText(this, "Open a page first", Toast.LENGTH_SHORT).show();
            return;
        }
        String url = wv.getUrl();
        String title = tab.title != null ? tab.title : url;
        if (isBookmarked(url)) {
            removeBookmark(url);
            Toast.makeText(this, "Bookmark removed", Toast.LENGTH_SHORT).show();
        } else {
            addBookmark(url, title);
            Toast.makeText(this, "Bookmarked", Toast.LENGTH_SHORT).show();
        }
        updateBookmarkStar();
    }

    private void updateBookmarkStar() {
        WebView wv = currentWebView();
        DevilTab tab = currentTab();
        boolean bookmarked = wv != null && tab != null && "web".equals(tab.type)
                && wv.getUrl() != null && isBookmarked(wv.getUrl());
        btnBookmarkStar.setText(bookmarked ? "★" : "☆");
        btnBookmarkStar.setTextColor(getColor(bookmarked ? R.color.gold : R.color.text_dim));
    }

    private List<JSONObject> loadBookmarks() {
        List<JSONObject> result = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString("bookmarks", "[]"));
            for (int i = 0; i < arr.length(); i++) result.add(arr.getJSONObject(i));
        } catch (Exception ignored) {}
        return result;
    }

    private boolean isBookmarked(String url) {
        for (JSONObject bm : loadBookmarks()) {
            if (url.equals(bm.optString("url"))) return true;
        }
        return false;
    }

    private void addBookmark(String url, String title) {
        try {
            JSONArray arr = new JSONArray(prefs.getString("bookmarks", "[]"));
            JSONObject entry = new JSONObject();
            entry.put("url", url);
            entry.put("title", title);
            arr.put(entry);
            prefs.edit().putString("bookmarks", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void removeBookmark(String url) {
        try {
            JSONArray arr = new JSONArray(prefs.getString("bookmarks", "[]"));
            JSONArray updated = new JSONArray();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject entry = arr.getJSONObject(i);
                if (!url.equals(entry.optString("url"))) updated.put(entry);
            }
            prefs.edit().putString("bookmarks", updated.toString()).apply();
        } catch (Exception ignored) {}
    }

    // ---- History for this screen: same store as Most Visited, sorted by recency ----
    private List<JSONObject> loadHistorySortedByRecency() {
        List<JSONObject> result = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString("history", "[]"));
            for (int i = 0; i < arr.length(); i++) result.add(arr.getJSONObject(i));
            result.sort((a, b) -> {
                try { return Long.compare(b.getLong("ts"), a.getLong("ts")); }
                catch (Exception e) { return 0; }
            });
        } catch (Exception ignored) {}
        return result;
    }

    // ---- Creates a BottomSheetDialog honoring the Animation preference ----
    private BottomSheetDialog newBottomSheet() {
        BottomSheetDialog dialog = new BottomSheetDialog(this);
        if (!isAnimationOn && dialog.getWindow() != null) {
            dialog.getWindow().setWindowAnimations(0);
        }
        return dialog;
    }

    // ================================================================
    // SESSION RECONSTRUCTION (#14) — full crash/restart recovery for
    // "Reopen Tabs on Startup": exact tab order + which tab was active,
    // not just a loose bag of URLs. Saved continuously (after every
    // navigation and every tab add/close/switch), debounced to avoid
    // writing on every keystroke — not only on a clean onPause — so a
    // genuine crash still has a recent snapshot to recover from, since a
    // crash never reaches onPause at all.
    // ================================================================
    static class SavedTabState {
        String url;
        boolean wasActive;
    }

    private final Handler sessionSaveHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingSessionSave = null;

    // Called from lots of small places (page loads, tab switches, tab
    // close) — debounced so a burst of these only writes once.
    private void scheduleSessionSave() {
        if (!reopenTabsOnStartup) return;
        if (pendingSessionSave != null) sessionSaveHandler.removeCallbacks(pendingSessionSave);
        pendingSessionSave = () -> {
            saveOpenTabsState();
            if (!backendUrl.isEmpty() && !authToken.isEmpty()) syncTabsNow(null); // Tab Sync — keep the server copy fresh
        };
        sessionSaveHandler.postDelayed(pendingSessionSave, 800);
    }

    private void saveOpenTabsState() {
        try {
            JSONArray arr = new JSONArray();
            for (int i = 0; i < tabs.size(); i++) {
                DevilTab tab = tabs.get(i);
                if (!"web".equals(tab.type) || tab.isIncognito) continue;
                String url = tab.isSuspended ? tab.suspendedUrl : (tab.webView != null ? tab.webView.getUrl() : null);
                if (url == null || url.isEmpty()) continue;
                JSONObject o = new JSONObject();
                o.put("url", url);
                o.put("active", i == currentTabIndex);
                arr.put(o);
            }
            prefs.edit().putString("saved_session", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private List<SavedTabState> loadSavedSession() {
        List<SavedTabState> result = new ArrayList<>();
        try {
            // New structured format first.
            JSONArray arr = new JSONArray(prefs.getString("saved_session", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                SavedTabState st = new SavedTabState();
                st.url = o.getString("url");
                st.wasActive = o.optBoolean("active", false);
                result.add(st);
            }
        } catch (Exception ignored) {}

        if (result.isEmpty()) {
            // Fall back to the old plain-URL-list format from before Session
            // Reconstruction, so nobody's existing saved session disappears
            // on this update.
            try {
                JSONArray oldArr = new JSONArray(prefs.getString("saved_tabs", "[]"));
                for (int i = 0; i < oldArr.length(); i++) {
                    SavedTabState st = new SavedTabState();
                    st.url = oldArr.getString(i);
                    st.wasActive = (i == 0);
                    result.add(st);
                }
            } catch (Exception ignored) {}
        }
        return result;
    }

    // ================================================================
    // BROWSING SETTINGS — Text-Only, Tab View, Reopen Tabs on Startup,
    // Brightness, Animation, Typing Assistant, Open Link, User-Agent.
    // All eight are real, wired to actual browser behavior.
    // ================================================================
    private View buildBrowsingSettingsView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(buildPageHeader("Browsing Settings", () -> showFullPage(buildSettingsView())));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(24, 12, 24, 24);
        scroll.addView(list);
        root.addView(scroll);

        list.addView(buildSettingsToggleRow("Text-Only", isTextOnlyOn, () -> {
            isTextOnlyOn = !isTextOnlyOn;
            prefs.edit().putBoolean("text_only", isTextOnlyOn).apply();
            applyImageBlockingToAllTabs();
            WebView wv = currentWebView();
            if (wv != null && currentTab() != null && "web".equals(currentTab().type)) wv.reload();
        }));

        String tabViewLabel = tabViewCarousel ? "Carousel View" : (tabViewGrid ? "Grid View" : "List View");
        list.addView(buildSettingsRow("Tab View", tabViewLabel, true, () -> {
            if (tabViewCarousel) {
                // Carousel -> List
                tabViewCarousel = false;
                tabViewGrid = false;
            } else if (tabViewGrid) {
                // Grid -> Carousel
                tabViewGrid = false;
                tabViewCarousel = true;
            } else {
                // List -> Grid
                tabViewGrid = true;
                tabViewCarousel = false;
            }
            prefs.edit().putBoolean("tab_view_grid", tabViewGrid)
                    .putBoolean("tab_view_carousel", tabViewCarousel).apply();
            showFullPage(buildBrowsingSettingsView());
        }));

        list.addView(buildSettingsToggleRow("Reopen Tabs on Startup", reopenTabsOnStartup, () -> {
            reopenTabsOnStartup = !reopenTabsOnStartup;
            prefs.edit().putBoolean("reopen_tabs_on_startup", reopenTabsOnStartup).apply();
            if (reopenTabsOnStartup) saveOpenTabsState();
        }));

        list.addView(buildSettingsRow("Brightness", null, true, this::showBrightnessDialog));

        list.addView(buildSettingsToggleRow("Animation", isAnimationOn, () -> {
            isAnimationOn = !isAnimationOn;
            prefs.edit().putBoolean("animation_on", isAnimationOn).apply();
        }));

        list.addView(buildSettingsToggleRow("Typing Assistant", isTypingAssistantOn, () -> {
            isTypingAssistantOn = !isTypingAssistantOn;
            prefs.edit().putBoolean("typing_assistant", isTypingAssistantOn).apply();
        }));

        list.addView(buildSettingsRow("Open Link", openLinkInNewTab ? "In New Tab" : "In Current Tab", true, () -> {
            openLinkInNewTab = !openLinkInNewTab;
            prefs.edit().putBoolean("open_link_new_tab", openLinkInNewTab).apply();
            showFullPage(buildBrowsingSettingsView());
        }));

        list.addView(buildSettingsRow("Website Preferences (UA)", isDesktopUA ? "Desktop" : "Mobile", true, () -> {
            isDesktopUA = !isDesktopUA;
            prefs.edit().putBoolean("desktop_ua", isDesktopUA).apply();
            for (DevilTab tab : tabs) {
                if (tab.webView == null) continue;
                tab.webView.getSettings().setUserAgentString(isDesktopUA ? DESKTOP_UA :
                        tab.webView.getSettings().getUserAgentString().replace("; wv", ""));
            }
            WebView wv = currentWebView();
            if (wv != null && currentTab() != null && "web".equals(currentTab().type)) wv.reload();
            showFullPage(buildBrowsingSettingsView());
        }));

        return root;
    }

    private void showBrightnessDialog() {
        android.widget.SeekBar seekBar = new android.widget.SeekBar(this);
        seekBar.setMax(100);
        float current = prefs.getFloat("brightness", -1f);
        seekBar.setProgress(current >= 0 ? (int) (current * 100) : 50);
        seekBar.setPadding(40, 40, 40, 40);

        new AccentDialogBuilder(this)
                .setTitle("Brightness")
                .setView(seekBar)
                .setPositiveButton("Apply", (d, w) -> {
                    float pct = seekBar.getProgress() / 100f;
                    android.view.WindowManager.LayoutParams lp = getWindow().getAttributes();
                    lp.screenBrightness = pct;
                    getWindow().setAttributes(lp);
                    prefs.edit().putFloat("brightness", pct).apply();
                })
                .setNeutralButton("Use System Default", (d, w) -> {
                    android.view.WindowManager.LayoutParams lp = getWindow().getAttributes();
                    lp.screenBrightness = -1f;
                    getWindow().setAttributes(lp);
                    prefs.edit().putFloat("brightness", -1f).apply();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ================================================================
    // LANGUAGE SELECTION — stores the choice and is used to pick the
    // default search-suggestion locale. NOTE (being upfront about scope):
    // this app's UI text is written directly in Java (not via strings.xml
    // resources), so picking a language here does NOT yet translate menus/
    // buttons — that would need every on-screen string moved into
    // per-language resource files first, which is a much bigger refactor.
    // What IS real: the selection is saved and shown correctly everywhere
    // this screen is referenced.
    // ================================================================
    private View buildLanguageView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(buildPageHeader("Language", () -> showFullPage(buildSettingsView())));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(24, 20, 24, 24);
        scroll.addView(list);
        root.addView(scroll);

        TextView note = new TextView(this);
        note.setText("Sets your preferred language for search suggestions. Full menu translation isn't built yet.");
        note.setTextColor(getColor(R.color.text_dim));
        note.setTextSize(9.5f);
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        noteParams.bottomMargin = 20;
        note.setLayoutParams(noteParams);
        list.addView(note);

        String current = prefs.getString("language", "English");
        for (String lang : AVAILABLE_LANGUAGES) {
            list.addView(buildLanguageRow(lang, lang.equals(current)));
        }

        return root;
    }

    private View buildLanguageRow(String lang, boolean isSelected) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(8, 24, 8, 24);

        TextView label = new TextView(this);
        label.setText(lang);
        label.setTextColor(getColor(R.color.text_primary));
        label.setTextSize(13);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        labelParams.weight = 1;
        label.setLayoutParams(labelParams);
        row.addView(label);

        if (isSelected) {
            TextView check = new TextView(this);
            check.setText("✓");
            check.setTextColor(getColor(R.color.gold));
            check.setTextSize(14);
            row.addView(check);
        }

        row.setOnClickListener(v -> {
            prefs.edit().putString("language", lang).apply();
            showFullPage(buildLanguageView());
        });

        return row;
    }

    // ================================================================
    // DOWNLOAD SETTINGS — Default Path (info), Max Downloads, New Task,
    // Auto Reconnect, Notification. New Task and Notification are wired
    // to the real DownloadListener; Max Downloads/Auto Reconnect are
    // saved preferences (Android's DownloadManager already auto-resumes
    // interrupted downloads at the OS level, so "Auto Reconnect" reflects
    // real built-in behavior rather than custom retry logic).
    // ================================================================
    private View buildDownloadSettingsView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(buildPageHeader("Download Settings", () -> showFullPage(buildSettingsView())));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(24, 12, 24, 24);
        scroll.addView(list);
        root.addView(scroll);

        list.addView(buildSettingsRow("Default Path", "/Download", false,
                () -> Toast.makeText(this, "Fixed to the public Downloads folder for compatibility", Toast.LENGTH_LONG).show()));

        list.addView(buildSettingsRow("Max Downloads", String.valueOf(maxDownloads), true, this::showMaxDownloadsDialog));

        list.addView(buildSettingsRow("New Task", newTaskAlwaysAsk ? "Always Ask" : "Auto Start", true, () -> {
            newTaskAlwaysAsk = !newTaskAlwaysAsk;
            prefs.edit().putBoolean("new_task_always_ask", newTaskAlwaysAsk).apply();
            showFullPage(buildDownloadSettingsView());
        }));

        list.addView(buildSettingsToggleRow("Auto Reconnect", autoReconnect, () -> {
            autoReconnect = !autoReconnect;
            prefs.edit().putBoolean("auto_reconnect", autoReconnect).apply();
        }));

        list.addView(buildSettingsToggleRow("Notification", downloadNotificationOn, () -> {
            downloadNotificationOn = !downloadNotificationOn;
            prefs.edit().putBoolean("download_notification", downloadNotificationOn).apply();
        }));

        return root;
    }

    private void showMaxDownloadsDialog() {
        String[] options = {"1", "2", "3", "5", "10"};
        new AccentDialogBuilder(this)
                .setTitle("Max Downloads")
                .setItems(options, (d, which) -> {
                    maxDownloads = Integer.parseInt(options[which]);
                    prefs.edit().putInt("max_downloads", maxDownloads).apply();
                    showFullPage(buildDownloadSettingsView());
                })
                .show();
    }

    // ================================================================
    // NOTIFICATION SETTINGS — Push Notification, per-site (Facebook),
    // Quick Access. Being upfront about scope: this app has no push
    // backend (no FCM/server), so the only notifications it can ever
    // send are its own download-complete notifications. "Push
    // Notification" here is genuinely wired to that (same flag as
    // Download Settings' Notification toggle). "Facebook" is saved but
    // honestly can't do anything yet — there's no infrastructure for
    // websites to push notifications through this browser. Quick Access
    // is real: it lists your actual bookmarks for one-tap opening.
    // ================================================================
    private View buildNotificationSettingsView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(buildPageHeader("Notification Settings", () -> showFullPage(buildSettingsView())));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(24, 12, 24, 24);
        scroll.addView(list);
        root.addView(scroll);

        // ---- Real status row: shows whether Firebase is actually wired in ----
        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setOrientation(LinearLayout.HORIZONTAL);
        statusRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        statusRow.setPadding(8, 8, 8, 24);
        LinearLayout statusTextCol = new LinearLayout(this);
        statusTextCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams statusTextParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        statusTextParams.weight = 1;
        statusTextCol.setLayoutParams(statusTextParams);
        TextView statusLabel = new TextView(this);
        statusLabel.setText("Server Push (Firebase)");
        statusLabel.setTextColor(getColor(R.color.text_primary));
        statusLabel.setTextSize(12);
        statusTextCol.addView(statusLabel);
        boolean fbConfigured = isFirebaseConfigured();
        TextView statusSub = new TextView(this);
        statusSub.setText(fbConfigured
                ? "Active — this device can receive real push notifications"
                : "Not set up — see PUSH_NOTIFICATIONS_SETUP.md to add your own Firebase project");
        statusSub.setTextColor(getColor(fbConfigured ? R.color.gold : R.color.text_dim));
        statusSub.setTextSize(9);
        statusTextCol.addView(statusSub);
        statusRow.addView(statusTextCol);

        if (fbConfigured) {
            TextView testBtn = new TextView(this);
            testBtn.setText("Send Test");
            testBtn.setTextColor(getColor(R.color.gold));
            testBtn.setTextSize(10.5f);
            testBtn.setPadding(20, 12, 20, 12);
            testBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
            testBtn.setOnClickListener(v -> sendTestPushNotification());
            statusRow.addView(testBtn);
        }
        list.addView(statusRow);

        LinearLayout pushRow = new LinearLayout(this);
        pushRow.setOrientation(LinearLayout.HORIZONTAL);
        pushRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        pushRow.setPadding(8, 24, 8, 24);
        LinearLayout pushTextCol = new LinearLayout(this);
        pushTextCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams pushTextParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        pushTextParams.weight = 1;
        pushTextCol.setLayoutParams(pushTextParams);
        TextView pushLabel = new TextView(this);
        pushLabel.setText("Push Notification");
        pushLabel.setTextColor(getColor(R.color.text_primary));
        pushLabel.setTextSize(12);
        pushTextCol.addView(pushLabel);
        TextView pushSub = new TextView(this);
        pushSub.setText("System Notification Bar (download alerts)");
        pushSub.setTextColor(getColor(R.color.text_dim));
        pushSub.setTextSize(9);
        pushTextCol.addView(pushSub);
        pushRow.addView(pushTextCol);
        android.widget.Switch pushToggle = new android.widget.Switch(this);
        pushToggle.setChecked(downloadNotificationOn);
        tintSwitch(pushToggle);
        pushToggle.setOnClickListener(v -> {
            downloadNotificationOn = !downloadNotificationOn;
            prefs.edit().putBoolean("download_notification", downloadNotificationOn).apply();
        });
        pushRow.addView(pushToggle);
        list.addView(pushRow);

        LinearLayout fbRow = new LinearLayout(this);
        fbRow.setOrientation(LinearLayout.HORIZONTAL);
        fbRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        fbRow.setPadding(8, 24, 8, 24);
        LinearLayout fbTextCol = new LinearLayout(this);
        fbTextCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams fbTextParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        fbTextParams.weight = 1;
        fbTextCol.setLayoutParams(fbTextParams);
        TextView fbLabel = new TextView(this);
        fbLabel.setText("Facebook");
        fbLabel.setTextColor(getColor(R.color.text_primary));
        fbLabel.setTextSize(12);
        fbTextCol.addView(fbLabel);
        TextView fbSub = new TextView(this);
        fbSub.setText("Backend endpoint exists, but this app has no FCM SDK wired in yet");
        fbSub.setTextColor(getColor(R.color.text_dim));
        fbSub.setTextSize(9);
        fbTextCol.addView(fbSub);
        fbRow.addView(fbTextCol);
        android.widget.Switch fbToggle = new android.widget.Switch(this);
        fbToggle.setChecked(prefs.getBoolean("notif_facebook", false));
        tintSwitch(fbToggle);
        fbToggle.setOnClickListener(v -> {
            boolean on = fbToggle.isChecked();
            prefs.edit().putBoolean("notif_facebook", on).apply();
            Toast.makeText(this, "Saved — see nex-backend README for Firebase setup steps needed to make this real", Toast.LENGTH_LONG).show();
        });
        fbRow.addView(fbToggle);
        list.addView(fbRow);

        list.addView(buildSettingsRow("Quick Access", null, true, () -> showUniversalPanel(buildBookmarksHistoryView(true))));

        return root;
    }

    // ================================================================
    // CUSTOM ERROR PAGE — shown natively (not WebView's own error UI)
    // when a main-frame page load fails (DNS failure, no connection, etc).
    // ================================================================
    private View buildErrorView(DevilTab tab) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        root.setPadding(48, 100, 48, 48);
        root.setBackgroundColor(getColor(R.color.bg_primary));

        TextView icon = new TextView(this);
        icon.setText("📡");
        icon.setTextSize(48);
        root.addView(icon);

        TextView title = new TextView(this);
        title.setText("Couldn't load this page");
        title.setTextColor(getColor(R.color.text_primary));
        title.setTextSize(16);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleParams.topMargin = 24;
        title.setLayoutParams(titleParams);
        root.addView(title);

        TextView urlView = new TextView(this);
        urlView.setText(tab.failedUrl);
        urlView.setTextColor(getColor(R.color.gold));
        urlView.setTextSize(10);
        urlView.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams urlParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        urlParams.topMargin = 12;
        urlView.setLayoutParams(urlParams);
        root.addView(urlView);

        TextView tips = new TextView(this);
        tips.setText("• Check your internet connection\n• Make sure the address is correct\n• Try again in a moment");
        tips.setTextColor(getColor(R.color.text_dim));
        tips.setTextSize(10.5f);
        tips.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams tipsParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tipsParams.topMargin = 28;
        tips.setLayoutParams(tipsParams);
        root.addView(tips);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams btnRowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        btnRowParams.topMargin = 32;
        btnRow.setLayoutParams(btnRowParams);

        TextView retryBtn = new TextView(this);
        retryBtn.setText("⟳ Retry");
        retryBtn.setTextColor(getColor(R.color.gold));
        retryBtn.setTextSize(12);
        retryBtn.setPadding(28, 16, 28, 16);
        retryBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        retryBtn.setOnClickListener(v -> {
            tab.hasError = false;
            webViewContainer.removeAllViews();
            webViewContainer.addView(tab.webView);
            tab.webView.loadUrl(tab.failedUrl);
        });
        LinearLayout.LayoutParams retryParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        retryParams.rightMargin = 12;
        retryBtn.setLayoutParams(retryParams);
        btnRow.addView(retryBtn);

        TextView homeBtn = new TextView(this);
        homeBtn.setText("Go Home");
        homeBtn.setTextColor(getColor(R.color.text_primary));
        homeBtn.setTextSize(12);
        homeBtn.setPadding(28, 16, 28, 16);
        homeBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        homeBtn.setOnClickListener(v -> {
            tab.hasError = false;
            tab.type = "home";
            tab.title = "New Tab";
            updateTabChip(tab);
            switchToTab(currentTabIndex);
        });
        btnRow.addView(homeBtn);

        root.addView(btnRow);

        TextView errorCode = new TextView(this);
        errorCode.setText(tab.errorMessage);
        errorCode.setTextColor(getColor(R.color.text_dim));
        errorCode.setTextSize(8.5f);
        LinearLayout.LayoutParams errorCodeParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        errorCodeParams.topMargin = 40;
        errorCode.setLayoutParams(errorCodeParams);
        root.addView(errorCode);

        return root;
    }

    // ---- Speed Mode (Data Saver): blocks images from loading to cut data usage ----
    private void toggleDataSaver() {
        isDataSaverOn = !isDataSaverOn;
        applyImageBlockingToAllTabs();
        Toast.makeText(this, "Speed Mode " + (isDataSaverOn ? "ON — images blocked" : "OFF"), Toast.LENGTH_SHORT).show();
        WebView wv = currentWebView();
        if (wv != null && "web".equals(currentTab().type)) wv.reload();
    }

    // Images are blocked if EITHER Speed Mode or Text-Only is on
    private void applyImageBlockingToAllTabs() {
        boolean block = isDataSaverOn || isTextOnlyOn;
        for (DevilTab tab : tabs) {
            if (tab.webView != null) tab.webView.getSettings().setBlockNetworkImage(block);
        }
    }

    // ---- Share current page URL via Android's native share sheet ----
    private void sharePage() {
        WebView wv = currentWebView();
        String url = (wv != null) ? wv.getUrl() : null;
        if (url == null) {
            Toast.makeText(this, "Nothing to share yet", Toast.LENGTH_SHORT).show();
            return;
        }
        android.content.Intent shareIntent = new android.content.Intent(android.content.Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(android.content.Intent.EXTRA_TEXT, url);
        startActivity(android.content.Intent.createChooser(shareIntent, "Share via"));
    }

    // ---- Save the current page as a local .mht archive (app's own storage,
    // no special permission needed on any Android version) ----
    private void savePage() {
        WebView wv = currentWebView();
        DevilTab tab = currentTab();
        if (wv == null || tab == null || "home".equals(tab.type)) {
            Toast.makeText(this, "Open a page first", Toast.LENGTH_SHORT).show();
            return;
        }
        String dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) + "/";
        wv.saveWebArchive(dir, true, value ->
                Toast.makeText(this, value != null ? "Saved: " + value : "Save failed", Toast.LENGTH_LONG).show());
    }

    // ---- Full Screen: hides the top bar / omnibox / tab bar and goes immersive ----
    private void toggleFullScreen() {
        isFullScreenMode = !isFullScreenMode;
        int visibility = isFullScreenMode ? View.GONE : View.VISIBLE;
        topBar.setVisibility(visibility);
        omniboxWrap.setVisibility(visibility);
        tabBarScroll.setVisibility(visibility);

        if (isFullScreenMode) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            Toast.makeText(this, "Full Screen ON — tap Back to exit", Toast.LENGTH_SHORT).show();
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    // ---- Find in Page: search text within the current page, matches highlighted ----
    private void showFindInPage() {
        WebView wv = currentWebView();
        DevilTab tab = currentTab();
        if (wv == null || tab == null || "home".equals(tab.type)) {
            Toast.makeText(this, "Open a page first", Toast.LENGTH_SHORT).show();
            return;
        }

        EditText input = new EditText(this);
        input.setHint("Find in page...");
        input.setTextColor(getColor(R.color.text_primary));
        input.setHintTextColor(getColor(R.color.text_dim));
        input.setPadding(32, 24, 32, 24);

        AlertDialog dialog = new AccentDialogBuilder(this)
                .setTitle("Find in Page")
                .setView(input)
                .setPositiveButton("Find", (d, w) -> {
                    String query = input.getText().toString().trim();
                    if (!query.isEmpty()) wv.findAllAsync(query);
                })
                .setNegativeButton("Close", (d, w) -> wv.clearMatches())
                .create();
        dialog.show();
    }

    // ================================================================
    // TAB SWITCHER — bottom sheet list of open tabs (icon + title + URL
    // + close), a "+ New Tab" row, and an incognito toggle icon — matches
    // the UC Mini reference layout (list rows, not a card grid).
    // ================================================================
    private void showTabSwitcher() {
        BottomSheetDialog dialog = newBottomSheet();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(getColor(R.color.bg_secondary));
        root.setPadding(16, 20, 16, 20);

        // ---- AI Tab Search: instant local filter as you type (title/URL),
        // plus a "✨" button for natural-language search over what each tab's
        // page is actually about (via the backend, needs Claude configured). ----
        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setOrientation(LinearLayout.HORIZONTAL);
        searchRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams searchRowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        searchRowParams.bottomMargin = 16;
        searchRow.setLayoutParams(searchRowParams);

        EditText tabSearchInput = new EditText(this);
        tabSearchInput.setHint("Search open tabs…");
        tabSearchInput.setTextColor(getColor(R.color.text_primary));
        tabSearchInput.setHintTextColor(getColor(R.color.text_dim));
        tabSearchInput.setTextSize(12);
        tabSearchInput.setSingleLine(true);
        tabSearchInput.setBackgroundResource(R.drawable.bg_tab_inactive);
        tabSearchInput.setPadding(20, 16, 20, 16);
        LinearLayout.LayoutParams searchInputParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        searchInputParams.weight = 1;
        searchInputParams.rightMargin = 8;
        tabSearchInput.setLayoutParams(searchInputParams);
        searchRow.addView(tabSearchInput);

        TextView aiSearchBtn = new TextView(this);
        aiSearchBtn.setText("✨");
        aiSearchBtn.setTextSize(16);
        aiSearchBtn.setPadding(20, 16, 20, 16);
        aiSearchBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams aiSearchBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        aiSearchBtnParams.rightMargin = 8;
        aiSearchBtn.setLayoutParams(aiSearchBtnParams);
        searchRow.addView(aiSearchBtn);

        boolean anyGroupedAlready = false;
        for (DevilTab t : tabs) {
            if (t.groupName != null && !t.groupName.isEmpty()) { anyGroupedAlready = true; break; }
        }

        TextView groupBtn = new TextView(this);
        groupBtn.setText(anyGroupedAlready ? "✕" : "🗂");
        groupBtn.setTextSize(16);
        groupBtn.setPadding(20, 16, 20, 16);
        groupBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        boolean finalAnyGroupedAlready = anyGroupedAlready;
        groupBtn.setOnClickListener(v -> {
            if (finalAnyGroupedAlready) {
                for (DevilTab t : tabs) t.groupName = "";
                showTabSwitcher();
            } else {
                performAiTabGroups(dialog);
            }
        });
        searchRow.addView(groupBtn);

        // Tab Sync — "Tabs from Other Devices", Chrome/Firefox-style.
        TextView otherDevicesBtn = new TextView(this);
        otherDevicesBtn.setText("📱");
        otherDevicesBtn.setTextSize(16);
        otherDevicesBtn.setPadding(20, 16, 20, 16);
        otherDevicesBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams otherDevicesBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        otherDevicesBtnParams.leftMargin = 8;
        otherDevicesBtn.setLayoutParams(otherDevicesBtnParams);
        otherDevicesBtn.setOnClickListener(v -> showTabsFromOtherDevices());
        searchRow.addView(otherDevicesBtn);

        // Tab Relationship Graph (#17): visual node-edge view of which
        // tab was opened from which (parentTabId).
        TextView graphBtn = new TextView(this);
        graphBtn.setText("🕸");
        graphBtn.setTextSize(16);
        graphBtn.setPadding(20, 16, 20, 16);
        graphBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams graphBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        graphBtnParams.leftMargin = 8;
        graphBtn.setLayoutParams(graphBtnParams);
        graphBtn.setOnClickListener(v -> {
            dialog.dismiss();
            showFullPage(buildTabRelationshipGraphView());
        });
        searchRow.addView(graphBtn);

        // AI Web Comparison (#97): pick 2+ open tabs to compare.
        TextView compareBtn = new TextView(this);
        compareBtn.setText("🆚");
        compareBtn.setTextSize(16);
        compareBtn.setPadding(20, 16, 20, 16);
        compareBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams compareBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        compareBtnParams.leftMargin = 8;
        compareBtn.setLayoutParams(compareBtnParams);
        compareBtn.setOnClickListener(v -> {
            dialog.dismiss();
            showFullPage(buildCompareTabsPickerView());
        });
        searchRow.addView(compareBtn);

        root.addView(searchRow);

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1200));
        root.addView(scroll);

        // Tracks rendered views alongside which tab (if any — null for a
        // group header) each one represents, so the search box can show/hide
        // rows live without rebuilding the whole list on every keystroke.
        List<View> tabViews = new ArrayList<>();
        List<DevilTab> tabViewOwner = new ArrayList<>();

        // If any tab has been AI-grouped, section the display by group name
        // (alphabetical, ungrouped tabs sort last) instead of plain tab order.
        List<DevilTab> displayOrder = new ArrayList<>(tabs);
        if (anyGroupedAlready) {
            displayOrder.sort((a, b) -> {
                String ga = (a.groupName == null || a.groupName.isEmpty()) ? "\uFFFF" : a.groupName;
                String gb = (b.groupName == null || b.groupName.isEmpty()) ? "\uFFFF" : b.groupName;
                return ga.compareTo(gb);
            });
        }

        if (tabViewCarousel) {
            // Carousel View — horizontally swipeable large cards. Kept
            // fully separate from the Grid/List branches below rather
            // than reusing their card builders, since those return views
            // with GridLayout/LinearLayout-specific LayoutParams that
            // aren't valid inside a HorizontalScrollView; safer to write
            // a self-contained card here than risk a ClassCastException
            // from mismatched LayoutParams that only shows up at runtime.
            // Group sectioning (headers) is skipped in this mode — tabs
            // of the same AI group still end up adjacent (displayOrder is
            // already sorted by group above), just without a header card,
            // since a header doesn't fit naturally in a horizontal strip.
            HorizontalScrollView hScroll = new HorizontalScrollView(this);
            hScroll.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            LinearLayout strip = new LinearLayout(this);
            strip.setOrientation(LinearLayout.HORIZONTAL);
            strip.setPadding(16, 16, 16, 16);
            hScroll.addView(strip);
            scroll.addView(hScroll);

            for (DevilTab tab : displayOrder) {
                int realIdx = tabs.indexOf(tab);
                View card = buildTabSwitcherCarouselCard(tab, realIdx, dialog);
                tabViews.add(card);
                tabViewOwner.add(tab);
                strip.addView(card);
            }
        } else if (tabViewGrid) {
            GridLayout grid = new GridLayout(this);
            grid.setColumnCount(2);
            scroll.addView(grid);
            String lastHeader = null;
            for (DevilTab tab : displayOrder) {
                int realIdx = tabs.indexOf(tab);
                if (anyGroupedAlready) {
                    String g = (tab.groupName == null || tab.groupName.isEmpty()) ? "Ungrouped" : tab.groupName;
                    if (!g.equals(lastHeader)) {
                        lastHeader = g;
                        View header = buildGroupHeaderView(g, true);
                        tabViews.add(header);
                        tabViewOwner.add(null);
                        grid.addView(header);
                    }
                }
                View card = buildTabSwitcherGridCard(tab, realIdx, dialog);
                tabViews.add(card);
                tabViewOwner.add(tab);
                grid.addView(card);
            }
        } else {
            LinearLayout list = new LinearLayout(this);
            list.setOrientation(LinearLayout.VERTICAL);
            scroll.addView(list);
            String lastHeader = null;
            for (DevilTab tab : displayOrder) {
                int realIdx = tabs.indexOf(tab);
                if (anyGroupedAlready) {
                    String g = (tab.groupName == null || tab.groupName.isEmpty()) ? "Ungrouped" : tab.groupName;
                    if (!g.equals(lastHeader)) {
                        lastHeader = g;
                        View header = buildGroupHeaderView(g, false);
                        tabViews.add(header);
                        tabViewOwner.add(null);
                        list.addView(header);
                    }
                }
                View row = buildTabSwitcherRow(tab, realIdx, dialog);
                tabViews.add(row);
                tabViewOwner.add(tab);
                list.addView(row);
            }
        }

        tabSearchInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(android.text.Editable s) {
                String q = s.toString().trim().toLowerCase(Locale.US);
                for (int i = 0; i < tabViews.size(); i++) {
                    DevilTab t = tabViewOwner.get(i);
                    if (t == null) continue; // group header — always left visible
                    String u = t.isSuspended ? t.suspendedUrl : (t.webView != null ? t.webView.getUrl() : null);
                    boolean match = q.isEmpty()
                            || t.title.toLowerCase(Locale.US).contains(q)
                            || (u != null && u.toLowerCase(Locale.US).contains(q));
                    tabViews.get(i).setVisibility(match ? View.VISIBLE : View.GONE);
                }
            }
        });

        aiSearchBtn.setOnClickListener(v -> {
            String q = tabSearchInput.getText().toString().trim();
            if (q.isEmpty()) {
                Toast.makeText(this, "Type what you're looking for first", Toast.LENGTH_SHORT).show();
                return;
            }
            performAiTabSearch(q, dialog);
        });

        // Bottom action row: "+ New Tab" (left) and Incognito icon (right)
        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams actionRowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        actionRowParams.topMargin = 20;
        actionRow.setLayoutParams(actionRowParams);

        TextView newTabBtn = new TextView(this);
        newTabBtn.setText("+  New Tab");
        newTabBtn.setTextColor(Color.WHITE);
        newTabBtn.setTypeface(newTabBtn.getTypeface(), android.graphics.Typeface.BOLD);
        newTabBtn.setTextSize(12.5f);
        newTabBtn.setPadding(20, 26, 20, 26);
        newTabBtn.setBackground(ThemeManager.buildProminentCardDrawable(this, 14 * getResources().getDisplayMetrics().density));
        LinearLayout.LayoutParams newTabParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        newTabParams.weight = 1;
        newTabParams.rightMargin = 12;
        newTabBtn.setLayoutParams(newTabParams);
        newTabBtn.setGravity(android.view.Gravity.CENTER);
        newTabBtn.setOnClickListener(v -> {
            createNewTab();
            dialog.dismiss();
        });
        actionRow.addView(newTabBtn);

        TextView incognitoBtn = new TextView(this);
        incognitoBtn.setText("🕶");
        incognitoBtn.setTextSize(16);
        incognitoBtn.setPadding(24, 24, 24, 24);
        incognitoBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        incognitoBtn.setOnClickListener(v -> {
            createIncognitoTab();
            dialog.dismiss();
        });
        actionRow.addView(incognitoBtn);

        root.addView(actionRow);

        dialog.setContentView(root);
        dialog.show();
    }

    // ---- AI Tab Search: sends the query plus every open (non-incognito)
    // tab's title + page extract to the backend, which asks Claude to pick
    // the best natural-language match — then switches straight to it. ----
    private void performAiTabSearch(String query, BottomSheetDialog dialog) {
        if (backendUrl.isEmpty()) {
            Toast.makeText(this, "Set your Backend Server URL in Settings first", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Asking AI…", Toast.LENGTH_SHORT).show();
        networkExecutor.execute(() -> {
            try {
                JSONArray tabsArr = new JSONArray();
                for (DevilTab t : tabs) {
                    if (t.isIncognito) continue;
                    JSONObject o = new JSONObject();
                    o.put("id", t.id);
                    o.put("title", t.title);
                    o.put("extract", t.pageExtract);
                    tabsArr.put(o);
                }
                JSONObject body = new JSONObject();
                body.put("query", query);
                body.put("tabs", tabsArr);

                JSONObject resp = httpPostJson(backendUrl + "/ai/tab-search", body, authToken);
                Integer tabId = resp.isNull("tab_id") ? null : resp.optInt("tab_id");
                String reason = resp.optString("reason", "");

                mainHandler.post(() -> {
                    if (tabId == null) {
                        Toast.makeText(this, "No matching tab found" + (reason.isEmpty() ? "" : (" — " + reason)), Toast.LENGTH_LONG).show();
                        return;
                    }
                    int idx = -1;
                    for (int i = 0; i < tabs.size(); i++) {
                        if (tabs.get(i).id == tabId) { idx = i; break; }
                    }
                    if (idx >= 0) {
                        switchToTab(idx);
                        dialog.dismiss();
                    } else {
                        Toast.makeText(this, "Matched tab isn't open anymore", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "AI Tab Search error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // ---- Section header shown above each group of tabs once AI Tab
    // Groups has been run — spans both columns in Grid View. ----
    private View buildGroupHeaderView(String groupName, boolean forGrid) {
        TextView header = new TextView(this);
        header.setText(groupName.toUpperCase(Locale.US));
        header.setTextColor(ThemeManager.getAccentColor(this));
        header.setTextSize(10);
        header.setLetterSpacing(0.06f);
        header.setPadding(8, 0, 0, 0);
        if (forGrid) {
            GridLayout.LayoutParams p = new GridLayout.LayoutParams();
            p.width = 0;
            p.columnSpec = GridLayout.spec(0, 2, 1f);
            p.topMargin = 24;
            p.bottomMargin = 8;
            header.setLayoutParams(p);
        } else {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            p.topMargin = 24;
            p.bottomMargin = 8;
            header.setLayoutParams(p);
        }
        return header;
    }

    // ---- AI Tab Groups: sends every open (non-incognito) tab's title +
    // page extract to the backend, which asks Claude to sort them into a
    // handful of short categories — then re-renders the Tab Switcher
    // sectioned by those groups instead of one flat list. ----
    private void performAiTabGroups(BottomSheetDialog dialog) {
        if (backendUrl.isEmpty()) {
            Toast.makeText(this, "Set your Backend Server URL in Settings first", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Grouping tabs…", Toast.LENGTH_SHORT).show();
        networkExecutor.execute(() -> {
            try {
                JSONArray tabsArr = new JSONArray();
                for (DevilTab t : tabs) {
                    if (t.isIncognito) continue;
                    JSONObject o = new JSONObject();
                    o.put("id", t.id);
                    o.put("title", t.title);
                    o.put("extract", t.pageExtract);
                    tabsArr.put(o);
                }
                JSONObject body = new JSONObject();
                body.put("tabs", tabsArr);

                JSONObject resp = httpPostJson(backendUrl + "/ai/tab-groups", body, authToken);
                JSONArray assignments = resp.optJSONArray("assignments");
                if (assignments != null) {
                    for (int i = 0; i < assignments.length(); i++) {
                        JSONObject a = assignments.getJSONObject(i);
                        int tabId = a.optInt("tab_id", -1);
                        String group = a.optString("group", "");
                        for (DevilTab t : tabs) {
                            if (t.id == tabId) { t.groupName = group; break; }
                        }
                    }
                }

                mainHandler.post(() -> {
                    Toast.makeText(this, "Tabs grouped", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                    showTabSwitcher();
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, "AI Tab Groups error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // ---- Grid View variant of a tab card (used when Tab View = "Grid View") ----
    private View buildTabSwitcherGridCard(DevilTab tab, int idx, BottomSheetDialog dialog) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(14, 14, 14, 16);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.height = LinearLayout.LayoutParams.WRAP_CONTENT;
        params.columnSpec = GridLayout.spec(idx % 2, 1f);
        params.setMargins(8, 8, 8, 8);
        card.setLayoutParams(params);
        card.setBackgroundResource(tab.isIncognito ? R.drawable.bg_tab_incognito
                : (isCurrentTab(tab) ? R.drawable.bg_tab_active : R.drawable.bg_tab_inactive));

        // ---- Thumbnail preview (real live capture, not just a favicon) ----
        FrameLayout thumbFrame = new FrameLayout(this);
        LinearLayout.LayoutParams thumbFrameParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 260);
        thumbFrame.setLayoutParams(thumbFrameParams);
        thumbFrame.setBackgroundResource(R.drawable.bg_tab_thumb_placeholder);
        thumbFrame.setClipToOutline(true);

        Bitmap thumb = captureTabThumbnail(tab);
        if (thumb != null) {
            ImageView thumbView = new ImageView(this);
            thumbView.setImageBitmap(thumb);
            thumbView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            thumbView.setLayoutParams(new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            thumbFrame.addView(thumbView);
        } else {
            TextView placeholderIcon = new TextView(this);
            placeholderIcon.setText(tab.isIncognito ? "🕶" : ("home".equals(tab.type) ? "🌟" : "🌐"));
            placeholderIcon.setTextSize(28);
            FrameLayout.LayoutParams phParams = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
            phParams.gravity = android.view.Gravity.CENTER;
            placeholderIcon.setLayoutParams(phParams);
            thumbFrame.addView(placeholderIcon);
        }

        if (tab.isIncognito) {
            TextView privateChip = new TextView(this);
            privateChip.setText("🕶 Private");
            privateChip.setTextColor(getColor(R.color.gold));
            privateChip.setTextSize(8.5f);
            privateChip.setBackgroundColor(Color.parseColor("#B3140E1F"));
            privateChip.setPadding(12, 4, 12, 4);
            FrameLayout.LayoutParams chipParams = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
            chipParams.gravity = android.view.Gravity.TOP | android.view.Gravity.START;
            chipParams.setMargins(8, 8, 0, 0);
            privateChip.setLayoutParams(chipParams);
            thumbFrame.addView(privateChip);
        }

        TextView closeBtn = new TextView(this);
        closeBtn.setText("✕");
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setTextSize(13);
        closeBtn.setBackgroundColor(Color.parseColor("#66000000"));
        closeBtn.setPadding(14, 6, 14, 6);
        FrameLayout.LayoutParams closeParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        closeParams.gravity = android.view.Gravity.TOP | android.view.Gravity.END;
        closeBtn.setLayoutParams(closeParams);
        closeBtn.setOnClickListener(v -> {
            closeTab(idx);
            dialog.dismiss();
            if (tabs.size() > 0) showTabSwitcher();
        });
        thumbFrame.addView(closeBtn);

        card.addView(thumbFrame);

        TextView titleView = new TextView(this);
        titleView.setText(tab.title);
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(11);
        titleView.setMaxLines(2);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleView.setPadding(4, 12, 4, 0);
        card.addView(titleView);

        // Tab Relationship Graph: which tab this one was opened from.
        DevilTab parentTab = findTabById(tab.parentTabId);
        if (parentTab != null) {
            TextView parentView = new TextView(this);
            parentView.setText("↳ " + parentTab.title);
            parentView.setTextColor(getColor(R.color.gold));
            parentView.setTextSize(9);
            parentView.setSingleLine(true);
            parentView.setEllipsize(android.text.TextUtils.TruncateAt.END);
            parentView.setPadding(4, 4, 4, 0);
            card.addView(parentView);
        }

        card.setOnClickListener(v -> {
            switchToTab(idx);
            dialog.dismiss();
        });

        return card;
    }

    // ---- Carousel View variant of a tab card (used when Tab View =
    // "Carousel View"). Same content/behavior as the Grid card above
    // (thumbnail, private chip, close, parent-tab link, tap to switch)
    // but built with LinearLayout.LayoutParams and a fixed width instead
    // of GridLayout.LayoutParams, since this one lives in a horizontal
    // LinearLayout strip rather than a GridLayout. ----
    private View buildTabSwitcherCarouselCard(DevilTab tab, int idx, BottomSheetDialog dialog) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(14, 14, 14, 16);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(320, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(8, 8, 8, 8);
        card.setLayoutParams(params);
        card.setBackgroundResource(tab.isIncognito ? R.drawable.bg_tab_incognito
                : (isCurrentTab(tab) ? R.drawable.bg_tab_active : R.drawable.bg_tab_inactive));

        FrameLayout thumbFrame = new FrameLayout(this);
        LinearLayout.LayoutParams thumbFrameParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 340);
        thumbFrame.setLayoutParams(thumbFrameParams);
        thumbFrame.setBackgroundResource(R.drawable.bg_tab_thumb_placeholder);
        thumbFrame.setClipToOutline(true);

        Bitmap carouselThumb = captureTabThumbnail(tab);
        if (carouselThumb != null) {
            ImageView thumbView = new ImageView(this);
            thumbView.setImageBitmap(carouselThumb);
            thumbView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            thumbView.setLayoutParams(new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            thumbFrame.addView(thumbView);
        } else {
            TextView placeholderIcon = new TextView(this);
            placeholderIcon.setText(tab.isIncognito ? "🕶" : ("home".equals(tab.type) ? "🌟" : "🌐"));
            placeholderIcon.setTextSize(34);
            FrameLayout.LayoutParams phParams = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
            phParams.gravity = android.view.Gravity.CENTER;
            placeholderIcon.setLayoutParams(phParams);
            thumbFrame.addView(placeholderIcon);
        }

        if (tab.isIncognito) {
            TextView privateChip = new TextView(this);
            privateChip.setText("🕶 Private");
            privateChip.setTextColor(getColor(R.color.gold));
            privateChip.setTextSize(9);
            privateChip.setBackgroundColor(Color.parseColor("#B3140E1F"));
            privateChip.setPadding(12, 4, 12, 4);
            FrameLayout.LayoutParams chipParams = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
            chipParams.gravity = android.view.Gravity.TOP | android.view.Gravity.START;
            chipParams.setMargins(8, 8, 0, 0);
            privateChip.setLayoutParams(chipParams);
            thumbFrame.addView(privateChip);
        }

        TextView closeBtn = new TextView(this);
        closeBtn.setText("✕");
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setTextSize(14);
        closeBtn.setBackgroundColor(Color.parseColor("#66000000"));
        closeBtn.setPadding(16, 8, 16, 8);
        FrameLayout.LayoutParams closeParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        closeParams.gravity = android.view.Gravity.TOP | android.view.Gravity.END;
        closeBtn.setLayoutParams(closeParams);
        closeBtn.setOnClickListener(v -> {
            closeTab(idx);
            dialog.dismiss();
            if (tabs.size() > 0) showTabSwitcher();
        });
        thumbFrame.addView(closeBtn);

        card.addView(thumbFrame);

        TextView titleView = new TextView(this);
        titleView.setText(tab.title);
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(12.5f);
        titleView.setMaxLines(2);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleView.setPadding(4, 12, 4, 0);
        card.addView(titleView);

        DevilTab carouselParentTab = findTabById(tab.parentTabId);
        if (carouselParentTab != null) {
            TextView parentView = new TextView(this);
            parentView.setText("↳ " + carouselParentTab.title);
            parentView.setTextColor(getColor(R.color.gold));
            parentView.setTextSize(10);
            parentView.setSingleLine(true);
            parentView.setEllipsize(android.text.TextUtils.TruncateAt.END);
            parentView.setPadding(4, 4, 4, 0);
            card.addView(parentView);
        }

        card.setOnClickListener(v -> {
            switchToTab(idx);
            dialog.dismiss();
        });

        return card;
    }

    private View buildTabSwitcherRow(DevilTab tab, int idx, BottomSheetDialog dialog) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(16, 16, 16, 16);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 6;
        row.setLayoutParams(rowParams);
        row.setBackgroundResource(tab.isIncognito ? R.drawable.bg_tab_incognito
                : (isCurrentTab(tab) ? R.drawable.bg_tab_active : R.drawable.bg_tab_inactive));

        // ---- Small live thumbnail (list view gets a compact square instead
        // of the full card-width preview used in Grid View) ----
        FrameLayout thumbFrame = new FrameLayout(this);
        LinearLayout.LayoutParams thumbFrameParams = new LinearLayout.LayoutParams(72, 72);
        thumbFrameParams.rightMargin = 20;
        thumbFrame.setLayoutParams(thumbFrameParams);
        thumbFrame.setBackgroundResource(R.drawable.bg_tab_thumb_placeholder);
        thumbFrame.setClipToOutline(true);

        Bitmap thumb = captureTabThumbnail(tab);
        if (thumb != null) {
            ImageView thumbView = new ImageView(this);
            thumbView.setImageBitmap(thumb);
            thumbView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            thumbView.setLayoutParams(new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            thumbFrame.addView(thumbView);
        } else {
            TextView icon = new TextView(this);
            icon.setText(tab.isIncognito ? "🕶" : ("home".equals(tab.type) ? "🌟" : "🌐"));
            icon.setTextSize(16);
            FrameLayout.LayoutParams iconParams = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
            iconParams.gravity = android.view.Gravity.CENTER;
            icon.setLayoutParams(iconParams);
            thumbFrame.addView(icon);
        }
        row.addView(thumbFrame);

        LinearLayout textCol = new LinearLayout(this);
        textCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textColParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        textColParams.weight = 1;
        textCol.setLayoutParams(textColParams);

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(android.view.Gravity.CENTER_VERTICAL);

        if (tab.isIncognito) {
            TextView privateChip = new TextView(this);
            privateChip.setText("PRIVATE");
            privateChip.setTextColor(getColor(R.color.gold));
            privateChip.setTextSize(8);
            privateChip.setLetterSpacing(0.05f);
            LinearLayout.LayoutParams chipParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            chipParams.rightMargin = 10;
            privateChip.setLayoutParams(chipParams);
            titleRow.addView(privateChip);
        }

        TextView titleView = new TextView(this);
        titleView.setText(tab.title);
        titleView.setTextColor(getColor(R.color.text_primary));
        titleView.setTextSize(12);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleView.setLayoutParams(new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        titleRow.addView(titleView);
        textCol.addView(titleRow);

        String currentUrl = tab.isSuspended ? tab.suspendedUrl : (tab.webView != null ? tab.webView.getUrl() : null);
        String urlText = "home".equals(tab.type) || currentUrl == null
                ? "Speed Dial" : currentUrl;
        TextView urlView = new TextView(this);
        urlView.setText(urlText);
        urlView.setTextColor(getColor(R.color.text_dim));
        urlView.setTextSize(9.5f);
        urlView.setSingleLine(true);
        urlView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams urlParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        urlParams.topMargin = 4;
        urlView.setLayoutParams(urlParams);
        textCol.addView(urlView);

        // Tab Relationship Graph: show which tab this one was opened from,
        // when that parent tab is still open.
        DevilTab parentTab = findTabById(tab.parentTabId);
        if (parentTab != null) {
            TextView parentView = new TextView(this);
            parentView.setText("↳ from " + parentTab.title);
            parentView.setTextColor(getColor(R.color.gold));
            parentView.setTextSize(9);
            parentView.setSingleLine(true);
            parentView.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams parentParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            parentParams.topMargin = 2;
            parentView.setLayoutParams(parentParams);
            textCol.addView(parentView);
        }

        row.addView(textCol);

        TextView closeBtn = new TextView(this);
        closeBtn.setText("✕");
        closeBtn.setTextColor(getColor(R.color.text_dim));
        closeBtn.setTextSize(14);
        closeBtn.setPadding(20, 8, 8, 8);
        closeBtn.setOnClickListener(v -> {
            closeTab(idx);
            dialog.dismiss();
            if (tabs.size() > 0) showTabSwitcher(); // reopen refreshed, unless it was the last tab
        });
        row.addView(closeBtn);

        row.setOnClickListener(v -> {
            switchToTab(idx);
            dialog.dismiss();
        });

        return row;
    }

    // ================================================================
    // OMNIBOX AUTOCOMPLETE SUGGESTIONS
    // Uses Google's free public "suggest" endpoint — no API key needed,
    // no daily limit. This is a different service from the Custom Search
    // JSON API (which is for full result pages, not suggestion dropdowns).
    // ================================================================
    // Smart Search (#95): the suggestion dropdown used to be plain typed-
    // history + Google's suggest strings only. Now it's a unified,
    // categorized search across open tabs, bookmarks, history, and
    // downloaded files too — one dropdown instead of needing a separate
    // search per source, each result tagged with what it is and where
    // tapping it goes.
    private static final String DELETE_HISTORY_SENTINEL = "🗑  Delete all input history";

    private static class SmartSearchResult {
        String type; // "tab" | "history" | "bookmark" | "file" | "typed" | "web" | "delete_history"
        String title;
        String subtitle;
        String value; // URL, file path, or query text to submit
        int tabIndex = -1;
    }

    // Smart Search (#95): renders each suggestion row with an icon for
    // its source (tab/bookmark/history/file/web/typed) plus a dim
    // subtitle (URL or file note) under the title, instead of the
    // single plain line the old ArrayAdapter<String> showed.
    private class SmartSearchAdapter extends ArrayAdapter<SmartSearchResult> {
        SmartSearchAdapter(android.content.Context ctx) {
            super(ctx, 0, new ArrayList<>());
        }

        private String iconFor(String type) {
            switch (type) {
                case "tab": return "🌐";
                case "bookmark": return "⭐";
                case "history": return "🕐";
                case "file": return "📄";
                case "web": return "🔍";
                case "delete_history": return "🗑";
                default: return "⌨️";
            }
        }

        @Override
        public View getView(int position, View convertView, android.view.ViewGroup parent) {
            SmartSearchResult item = getItem(position);
            LinearLayout row = new LinearLayout(MainActivity.this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setPadding(28, 22, 28, 22);
            if (item == null) return row;

            TextView icon = new TextView(MainActivity.this);
            icon.setText(iconFor(item.type));
            icon.setTextSize(15);
            LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            iconParams.rightMargin = 24;
            icon.setLayoutParams(iconParams);
            row.addView(icon);

            LinearLayout textCol = new LinearLayout(MainActivity.this);
            textCol.setOrientation(LinearLayout.VERTICAL);
            textCol.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            TextView titleView = new TextView(MainActivity.this);
            titleView.setText(item.title != null ? item.title : "");
            titleView.setTextColor(getColor(R.color.text_primary));
            titleView.setTextSize(13);
            titleView.setSingleLine(true);
            titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
            textCol.addView(titleView);

            if (item.subtitle != null && !item.subtitle.isEmpty()) {
                TextView subtitleView = new TextView(MainActivity.this);
                subtitleView.setText(item.subtitle);
                subtitleView.setTextColor(getColor(R.color.text_dim));
                subtitleView.setTextSize(10);
                subtitleView.setSingleLine(true);
                subtitleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
                textCol.addView(subtitleView);
            }
            row.addView(textCol);
            return row;
        }
    }

    private void setupSuggestions() {
        suggestAdapter = new SmartSearchAdapter(this);
        suggestPopup = new ListPopupWindow(this);
        suggestPopup.setAnchorView(omniInput);
        suggestPopup.setAdapter(suggestAdapter);
        suggestPopup.setModal(false);
        suggestPopup.setWidth(ListPopupWindow.MATCH_PARENT);

        suggestPopup.setOnItemClickListener((parent, view, position, id) -> {
            SmartSearchResult selected = suggestAdapter.getItem(position);
            if (selected == null) return;
            suggestPopup.dismiss();

            switch (selected.type) {
                case "delete_history":
                    prefs.edit().putString("typed_history", "[]").apply();
                    Toast.makeText(this, "Input history cleared", Toast.LENGTH_SHORT).show();
                    break;
                case "tab":
                    if (selected.tabIndex >= 0 && selected.tabIndex < tabs.size()) {
                        currentTabIndex = selected.tabIndex;
                        switchToTab(currentTabIndex);
                        omniInput.clearFocus();
                    }
                    break;
                case "file":
                    openLocalFile(new File(selected.value));
                    break;
                default:
                    omniInput.setText(selected.value);
                    omniInput.setSelection(selected.value.length());
                    submitOmnibox();
                    break;
            }
        });

        omniInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String query = s.toString().trim();
                if (pendingSuggestFetch != null) debounceHandler.removeCallbacks(pendingSuggestFetch);

                if (!isTypingAssistantOn || query.length() < 2) {
                    suggestPopup.dismiss();
                    return;
                }

                pendingSuggestFetch = () -> fetchSuggestions(query);
                debounceHandler.postDelayed(pendingSuggestFetch, 250);
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {}
        });
    }

    // ---- Typed-input history (distinct from page-visit history): what the
    // user has actually typed into the omnibox before, shown as suggestions ----
    private List<String> loadTypedHistory() {
        List<String> result = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString("typed_history", "[]"));
            for (int i = 0; i < arr.length(); i++) result.add(arr.getString(i));
        } catch (Exception ignored) {}
        return result;
    }

    private void recordTypedHistory(String input) {
        try {
            List<String> history = loadTypedHistory();
            history.remove(input); // avoid duplicates, most-recent-first
            history.add(0, input);
            if (history.size() > 50) history = history.subList(0, 50);
            JSONArray arr = new JSONArray();
            for (String h : history) arr.put(h);
            prefs.edit().putString("typed_history", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void fetchSuggestions(String query) {
        // Local sources answer instantly, no network wait — typed
        // history plus the new Smart Search sweep across tabs,
        // bookmarks, history, and downloaded files (#95).
        List<SmartSearchResult> localMatches = new ArrayList<>();
        String lowerQuery = query.toLowerCase(Locale.US);
        for (String entry : loadTypedHistory()) {
            if (entry.toLowerCase(Locale.US).contains(lowerQuery)) {
                SmartSearchResult r = new SmartSearchResult();
                r.type = "typed";
                r.title = entry;
                r.value = entry;
                localMatches.add(r);
            }
        }
        localMatches.addAll(searchLocalSmart(lowerQuery));

        mainHandler.post(() -> updateSuggestionList(localMatches, null));

        networkExecutor.execute(() -> {
            List<String> results = new ArrayList<>();
            try {
                String urlStr = "https://www.google.com/complete/search?client=firefox&q=" + Uri.encode(query);
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("User-Agent", "Mozilla/5.0");
                conn.setConnectTimeout(3000);
                conn.setReadTimeout(3000);

                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);
                reader.close();

                JSONArray arr = new JSONArray(sb.toString());
                JSONArray suggestions = arr.getJSONArray(1);
                for (int i = 0; i < suggestions.length(); i++) {
                    results.add(suggestions.getString(i));
                }
            } catch (Exception e) {
                // Silent fail — suggestions are a nice-to-have, never block typing
            }

            mainHandler.post(() -> updateSuggestionList(localMatches, results));
        });
    }

    // Smart Search (#95): searches open tabs, bookmarks, history, and
    // downloaded files by title/URL/filename — all local, no network,
    // so these show up in the dropdown instantly alongside typed history
    // while Google's web suggestions are still loading.
    private List<SmartSearchResult> searchLocalSmart(String lowerQuery) {
        List<SmartSearchResult> results = new ArrayList<>();

        for (int i = 0; i < tabs.size(); i++) {
            DevilTab t = tabs.get(i);
            if (t.isIncognito) continue; // Smart Search shouldn't surface incognito tabs in a shared suggestion list
            String title = t.title != null ? t.title : "";
            String url = (t.webView != null && t.webView.getUrl() != null) ? t.webView.getUrl() : "";
            if (title.toLowerCase(Locale.US).contains(lowerQuery) || url.toLowerCase(Locale.US).contains(lowerQuery)) {
                SmartSearchResult r = new SmartSearchResult();
                r.type = "tab";
                r.title = !title.isEmpty() ? title : url;
                r.subtitle = url;
                r.value = url;
                r.tabIndex = i;
                results.add(r);
            }
        }

        for (JSONObject bm : loadBookmarks()) {
            String title = bm.optString("title", "");
            String url = bm.optString("url", "");
            if (title.toLowerCase(Locale.US).contains(lowerQuery) || url.toLowerCase(Locale.US).contains(lowerQuery)) {
                SmartSearchResult r = new SmartSearchResult();
                r.type = "bookmark";
                r.title = !title.isEmpty() ? title : url;
                r.subtitle = url;
                r.value = url;
                results.add(r);
            }
        }

        int historyMatches = 0;
        for (JSONObject h : loadHistorySortedByRecency()) {
            if (historyMatches >= 8) break; // most-recent-first list, cap so it doesn't crowd out everything else
            String title = h.optString("title", "");
            String url = h.optString("url", "");
            if (title.toLowerCase(Locale.US).contains(lowerQuery) || url.toLowerCase(Locale.US).contains(lowerQuery)) {
                SmartSearchResult r = new SmartSearchResult();
                r.type = "history";
                r.title = !title.isEmpty() ? title : url;
                r.subtitle = url;
                r.value = url;
                results.add(r);
                historyMatches++;
            }
        }

        try {
            File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            File[] files = dir != null ? dir.listFiles() : null;
            if (files != null) {
                int fileMatches = 0;
                for (File f : files) {
                    if (fileMatches >= 6) break;
                    if (f.isFile() && f.getName().toLowerCase(Locale.US).contains(lowerQuery)) {
                        SmartSearchResult r = new SmartSearchResult();
                        r.type = "file";
                        r.title = f.getName();
                        r.subtitle = "Downloaded file";
                        r.value = f.getAbsolutePath();
                        results.add(r);
                        fileMatches++;
                    }
                }
            }
        } catch (Exception ignored) {}

        return results;
    }

    // Smart Search (#95): opens a downloaded file with whatever app the
    // device has for its type — same FileProvider-authority pattern
    // already used for saved video downloads elsewhere in this file.
    private void openLocalFile(File file) {
        try {
            Uri uri = androidx.core.content.FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", file);
            String mime = getContentResolver().getType(uri);
            if (mime == null) mime = "*/*";
            android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_VIEW);
            intent.setDataAndType(uri, mime);
            intent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't open file: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void updateSuggestionList(List<SmartSearchResult> localMatches, List<String> networkResults) {
        List<SmartSearchResult> combined = new ArrayList<>(localMatches);
        if (networkResults != null) {
            for (String r : networkResults) {
                boolean alreadyPresent = false;
                for (SmartSearchResult existing : combined) {
                    if (r.equals(existing.value)) { alreadyPresent = true; break; }
                }
                if (!alreadyPresent) {
                    SmartSearchResult webResult = new SmartSearchResult();
                    webResult.type = "web";
                    webResult.title = r;
                    webResult.value = r;
                    combined.add(webResult);
                }
            }
        }
        if (!loadTypedHistory().isEmpty()) {
            SmartSearchResult deleteItem = new SmartSearchResult();
            deleteItem.type = "delete_history";
            deleteItem.title = DELETE_HISTORY_SENTINEL;
            combined.add(deleteItem);
        }

        suggestAdapter.clear();
        suggestAdapter.addAll(combined);
        suggestAdapter.notifyDataSetChanged();
        if (!combined.isEmpty() && omniInput.hasFocus()) {
            suggestPopup.show();
        } else {
            suggestPopup.dismiss();
        }
    }

    /**
     * Address-bar mic button (Blueprint section 4 / Design v2 section 13-14:
     * "voice input" as one of the focused-address-bar actions). Requests
     * RECORD_AUDIO only the first time it's needed, then delegates the actual
     * capture to the system speech-recognition activity — Nex never records
     * audio itself, it only reads back the text result.
     */
    private void onVoiceSearchClicked() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            launchVoiceRecognizer();
        } else {
            voicePermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO);
        }
    }

    private void launchVoiceRecognizer() {
        android.content.Intent intent = new android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, getString(R.string.voice_search_prompt));
        try {
            voiceSearchLauncher.launch(intent);
        } catch (android.content.ActivityNotFoundException e) {
            // No speech-recognition app available on this device/ROM.
            Toast.makeText(this, R.string.voice_search_not_available, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Address-bar QR icon. CAMERA is already declared in the manifest (used
     * elsewhere for file uploads); this is the first place that requests it
     * at runtime. A scanned result is treated exactly like typed/spoken
     * input — most QR codes on the web resolve to a URL, and resolveUrl()
     * already falls back to a search for anything that isn't one.
     */
    private void onQrScanClicked() {
        if (checkSelfPermission(android.Manifest.permission.CAMERA)
                == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            launchQrScanner();
        } else {
            qrPermissionLauncher.launch(android.Manifest.permission.CAMERA);
        }
    }

    private void launchQrScanner() {
        com.journeyapps.barcodescanner.ScanOptions options = new com.journeyapps.barcodescanner.ScanOptions();
        options.setDesiredBarcodeFormats(com.journeyapps.barcodescanner.ScanOptions.QR_CODE);
        options.setPrompt(getString(R.string.qr_scan));
        options.setBeepEnabled(false);
        options.setOrientationLocked(false);
        qrScanLauncher.launch(options);
    }

    private void submitOmnibox() {
        String input = omniInput.getText().toString().trim();
        if (input.isEmpty()) return;
        suggestPopup.dismiss();

        if (isAiCommandMode) {
            runAiCommand(input);
            return;
        }

        recordTypedHistory(input);
        String url = resolveUrl(input);
        navigate(url);
        omniInput.clearFocus();
    }

    private void toggleAiCommandMode() {
        isAiCommandMode = !isAiCommandMode;
        btnAiMode.setImageTintList(android.content.res.ColorStateList.valueOf(
                (isAiCommandMode ? ThemeManager.getAccentColor(this) : getColor(R.color.text_dim))));
        omniInput.setHint(isAiCommandMode ? getString(R.string.ai_command_hint) : getString(R.string.search_hint));
        Toast.makeText(this,
                isAiCommandMode ? R.string.ai_command_mode_on : R.string.ai_command_mode_off,
                Toast.LENGTH_SHORT).show();
        if (isAiCommandMode) omniInput.requestFocus();
    }

    /**
     * Sends the typed text to the same backend that already powers AI
     * Summary (see summarizeCurrentPage() / callSummarizeApi() above),
     * hitting a new /ai-command endpoint instead of /summarize. Current-page
     * URL is passed along so the backend can answer page-aware questions
     * ("summarize this", "translate this page") as well as standalone ones.
     *
     * Repeat-question cache: if the exact same command was already asked
     * (on the same page, for page-aware commands) within the cache's TTL,
     * the saved reply is shown instantly — no AI call, no cost, no wait.
     */
    private void runAiCommand(String command) {
        if (backendUrl.isEmpty()) {
            Toast.makeText(this, "Set your Backend Server URL in Settings first", Toast.LENGTH_LONG).show();
            return;
        }
        omniInput.setText("");
        WebView wv = currentWebView();
        String pageUrl = wv != null ? wv.getUrl() : null;

        String cacheKey = buildAiCacheKey(command, pageUrl);
        String cached = getCachedAiReply(cacheKey);
        if (cached != null) {
            new AccentDialogBuilder(this)
                    .setTitle("✨ " + getString(R.string.ai_command_mode) + "  ·  🧠 cached")
                    .setMessage(cached)
                    .setPositiveButton("Close", null)
                    .show();
            if (isAiCommandMode) toggleAiCommandMode();
            return;
        }

        Toast.makeText(this, R.string.ai_command_thinking, Toast.LENGTH_SHORT).show();

        networkExecutor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("command", command);
                if (pageUrl != null) body.put("url", pageUrl);

                JSONObject resp = httpPostJson(backendUrl + "/ai-command", body, authToken);
                String reply = resp.optString("reply", "No response");
                putAiCacheReply(cacheKey, reply);

                mainHandler.post(() -> {
                    new AccentDialogBuilder(this)
                            .setTitle("✨ " + getString(R.string.ai_command_mode))
                            .setMessage(reply)
                            .setPositiveButton("Close", null)
                            .show();
                    // One command per toggle, like AI Summary's single-shot
                    // dialog — avoids the address bar staying silently stuck
                    // in AI mode after the user's done with it.
                    if (isAiCommandMode) toggleAiCommandMode();
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    Toast.makeText(this, "AI command error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    if (isAiCommandMode) toggleAiCommandMode();
                });
            }
        });
    }

    // ================================================================
    // AI ANSWER CACHE (Settings → 🧠 AI Answer Cache) — if the same
    // question/command gets asked again, answer instantly from what was
    // already learned instead of calling the AI (and paying for it) again.
    // Currently wired into AI Command Mode (runAiCommand above); any other
    // free-text "ask AI something" feature can reuse getCachedAiReply()/
    // putAiCacheReply() the same way.
    // ================================================================
    private static final String AI_CACHE_PREFS = "ai_cache_prefs";
    private static final String AI_CACHE_KEY = "entries";
    private static final long AI_CACHE_TTL_MS = 7L * 24 * 60 * 60 * 1000; // 7 days — long enough to catch someone re-asking the same thing this week, short enough that stale page-based answers don't linger forever
    private static final int AI_CACHE_MAX_ENTRIES = 200; // oldest entries get evicted past this, so the cache can't grow forever

    // Same question asked about different pages ("summarize this" on two
    // different articles) must NOT share an answer, so the page URL (when
    // there is one) is folded into the key; a page-independent question
    // ("what's the capital of France") caches on the text alone.
    private String buildAiCacheKey(String command, String pageUrl) {
        String normalized = command.trim().toLowerCase(Locale.US).replaceAll("\\s+", " ");
        return (pageUrl == null || pageUrl.isEmpty()) ? normalized : (pageUrl + "|" + normalized);
    }

    private JSONObject loadAiCacheEntries() {
        SharedPreferences cachePrefs = getSharedPreferences(AI_CACHE_PREFS, MODE_PRIVATE);
        try {
            return new JSONObject(cachePrefs.getString(AI_CACHE_KEY, "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private void saveAiCacheEntries(JSONObject entries) {
        getSharedPreferences(AI_CACHE_PREFS, MODE_PRIVATE)
                .edit().putString(AI_CACHE_KEY, entries.toString()).apply();
    }

    private String getCachedAiReply(String cacheKey) {
        JSONObject entries = loadAiCacheEntries();
        JSONObject hit = entries.optJSONObject(cacheKey);
        if (hit == null) return null;
        long age = System.currentTimeMillis() - hit.optLong("ts", 0);
        if (age > AI_CACHE_TTL_MS) return null; // expired — treat as a miss, next successful call refreshes it
        return hit.optString("reply", null);
    }

    private void putAiCacheReply(String cacheKey, String reply) {
        try {
            JSONObject entries = loadAiCacheEntries();

            if (entries.length() >= AI_CACHE_MAX_ENTRIES && !entries.has(cacheKey)) {
                // Evict the single oldest entry to make room, rather than
                // letting this file grow without bound.
                String oldestKey = null;
                long oldestTs = Long.MAX_VALUE;
                java.util.Iterator<String> it = entries.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    long ts = entries.optJSONObject(k) != null ? entries.optJSONObject(k).optLong("ts", 0) : 0;
                    if (ts < oldestTs) { oldestTs = ts; oldestKey = k; }
                }
                if (oldestKey != null) entries.remove(oldestKey);
            }

            JSONObject entry = new JSONObject();
            entry.put("reply", reply);
            entry.put("ts", System.currentTimeMillis());
            entries.put(cacheKey, entry);
            saveAiCacheEntries(entries);
        } catch (Exception ignored) {}
    }

    private String aiCacheSummary() {
        int count = loadAiCacheEntries().length();
        return count == 0 ? "No repeated questions cached yet" : count + " answer" + (count == 1 ? "" : "s") + " saved — repeated questions skip the AI call";
    }

    private void showAiCacheDialog() {
        int count = loadAiCacheEntries().length();
        new AccentDialogBuilder(this)
                .setTitle("🧠 AI Answer Cache")
                .setMessage("When AI Command Mode gets asked the exact same question again (same page, for page-aware commands), it answers instantly from here instead of calling the AI again — faster, and doesn't spend an AI call on a question it already answered.\n\n" +
                        count + " answer" + (count == 1 ? "" : "s") + " currently saved. Answers are kept for 7 days, then re-asked fresh.")
                .setPositiveButton("Close", null)
                .setNegativeButton(count == 0 ? null : "Clear Cache", (d, w) -> {
                    saveAiCacheEntries(new JSONObject());
                    Toast.makeText(this, "AI answer cache cleared", Toast.LENGTH_SHORT).show();
                    if (isPageShown) showFullPage(buildSettingsView());
                })
                .show();
    }

    // ================================================================
    // EXTENSIONS (Settings → 🧩 Extensions) — lightweight, WebView-real
    // "userscript" style extensions: small JavaScript that runs
    // automatically on pages matching a pattern.
    //
    // Honest limitation: this is NOT Chrome/Firefox Web Store
    // compatibility. Android's WebView — which this entire browser is
    // built on — has no extension host APIs at all (no background pages,
    // no browserAction, no .crx/.xpi loader). No WebView-based Android
    // browser can run a real Chrome extension; that's a limit of the
    // WebView engine itself, not a missing feature here. What genuinely
    // DOES work in WebView is injected JavaScript, so that's exactly what
    // this is — the same mechanism Tampermonkey/Greasemonkey-style
    // userscript managers use, honestly labelled as such.
    //
    // "Khud install kare, khud chalaye": installExtensionFromUrl() below
    // is the one install path everything shares — a Settings button today,
    // and the "install_extension" agent action (see
    // executeAutopilotAction()'s switch) so the agent can decide mid-task
    // that it needs one, fetch it, and have it running on the very next
    // matching page load, without asking first.
    // ================================================================
    private static final String EXT_PREFS = "extensions_prefs";
    private static final String EXT_KEY = "installed";

    private JSONArray loadExtensions() {
        SharedPreferences p = getSharedPreferences(EXT_PREFS, MODE_PRIVATE);
        try {
            return new JSONArray(p.getString(EXT_KEY, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private void saveExtensionsArray(JSONArray arr) {
        getSharedPreferences(EXT_PREFS, MODE_PRIVATE).edit().putString(EXT_KEY, arr.toString()).apply();
    }

    // Small glob support — "*" (every site) or something like
    // "*://*.reddit.com/*" — enough for real userscript-style matching
    // without pulling in a full match-pattern library.
    private boolean extensionMatches(String pattern, String url) {
        return DownloadUtils.extensionMatches(pattern, url);
    }

    interface ExtensionInstallCallback {
        void onResult(boolean success, String message);
    }

    /**
     * Fetches whatever is at url — a small JSON manifest
     * {"name","match","script"}, or a plain .js file used as-is with
     * match "*" — stores it, and from the very next matching page load it
     * runs automatically. Both Settings' "Install from URL" row and the
     * agent's own "install_extension" action call this exact same method,
     * so there is exactly one install path, not two diverging ones.
     */
    private void installExtensionFromUrl(String url, ExtensionInstallCallback callback) {
        networkExecutor.execute(() -> {
            try {
                java.net.URL u = new java.net.URL(url);
                HttpURLConnection conn = (HttpURLConnection) u.openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(20000);
                String body = readStream(conn.getInputStream());

                String name;
                String match;
                String script;
                try {
                    JSONObject manifest = new JSONObject(body);
                    script = manifest.optString("script", "");
                    if (script.isEmpty()) throw new Exception("manifest has no \"script\" field");
                    name = manifest.optString("name", "Extension");
                    match = manifest.optString("match", "*");
                } catch (Exception notAManifest) {
                    // Not JSON (or missing "script") — treat the whole
                    // response body as a plain userscript, matching every
                    // site by default.
                    String fileName = url.substring(url.lastIndexOf('/') + 1);
                    name = fileName.isEmpty() ? "Extension" : fileName;
                    match = "*";
                    script = body;
                }

                JSONObject ext = new JSONObject();
                ext.put("id", String.valueOf(System.currentTimeMillis()));
                ext.put("name", name);
                ext.put("match", match);
                ext.put("script", script);
                ext.put("sourceUrl", url);
                ext.put("enabled", true);

                JSONArray all = loadExtensions();
                all.put(ext);
                saveExtensionsArray(all);

                String finalName = name;
                if (callback != null) mainHandler.post(() ->
                        callback.onResult(true, "Installed \"" + finalName + "\" — it'll run automatically on matching pages"));
            } catch (Exception e) {
                if (callback != null) mainHandler.post(() -> callback.onResult(false, "Couldn't install: " + e.getMessage()));
            }
        });
    }

    private void setExtensionEnabled(String id, boolean enabled) {
        JSONArray all = loadExtensions();
        for (int i = 0; i < all.length(); i++) {
            JSONObject e = all.optJSONObject(i);
            if (e != null && id.equals(e.optString("id"))) {
                try { e.put("enabled", enabled); } catch (Exception ignored) {}
                break;
            }
        }
        saveExtensionsArray(all);
    }

    private void removeExtension(String id) {
        JSONArray all = loadExtensions();
        JSONArray kept = new JSONArray();
        for (int i = 0; i < all.length(); i++) {
            JSONObject e = all.optJSONObject(i);
            if (e != null && !id.equals(e.optString("id"))) kept.put(e);
        }
        saveExtensionsArray(kept);
    }

    // Called from the main WebViewClient's onPageFinished for every
    // regular (non-incognito) tab — runs every enabled extension whose
    // match pattern fits this URL. Each script runs wrapped in its own
    // try/catch inside the page so one broken extension can't take the
    // page (or the others) down with it.
    private void runMatchingExtensions(WebView view, String url, boolean incognito) {
        if (incognito) return; // extensions never run in Incognito — same boundary as history/passwords
        JSONArray all = loadExtensions();
        if (all.length() == 0) return;
        for (int i = 0; i < all.length(); i++) {
            JSONObject ext = all.optJSONObject(i);
            if (ext == null || !ext.optBoolean("enabled", true)) continue;
            if (!extensionMatches(ext.optString("match", "*"), url)) continue;
            String script = ext.optString("script", "");
            if (script.isEmpty()) continue;
            String safeName = ext.optString("name", "").replace("\"", "");
            String wrapped = "(function(){try{" + script + "}catch(e){console.warn('Nex extension \"" + safeName + "\" error: '+e);}})();";
            view.evaluateJavascript(wrapped, null);
        }
    }

    private String extensionsSummary() {
        int count = loadExtensions().length();
        return count == 0 ? "None installed" : count + " installed";
    }

    private void showExtensionsDialog() {
        showFullPage(buildExtensionsView());
    }

    private View buildExtensionsView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(buildPageHeader("Extensions", this::hideFullPage));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(24, 16, 24, 24);
        scroll.addView(content);
        root.addView(scroll);

        TextView hint = new TextView(this);
        hint.setText("Small scripts that run automatically on matching pages — Nex's own lightweight extension format, since real Chrome/Firefox extensions can't run inside any Android WebView-based browser. The agent can also install one of these on its own mid-task when it decides it needs one.");
        hint.setTextColor(getColor(R.color.text_dim));
        hint.setTextSize(10);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hintParams.bottomMargin = 16;
        hint.setLayoutParams(hintParams);
        content.addView(hint);

        JSONArray exts = loadExtensions();
        if (exts.length() == 0) {
            content.addView(buildEmptyState("No extensions installed yet"));
        } else {
            for (int i = 0; i < exts.length(); i++) {
                JSONObject ext = exts.optJSONObject(i);
                if (ext != null) content.addView(buildExtensionRow(ext));
            }
        }

        TextView installBtn = new TextView(this);
        installBtn.setText("+ Install from URL");
        installBtn.setTextColor(getColor(R.color.gold));
        installBtn.setTextSize(11);
        installBtn.setGravity(android.view.Gravity.CENTER);
        installBtn.setPadding(20, 16, 20, 16);
        installBtn.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams installBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        installBtnParams.topMargin = 16;
        installBtn.setLayoutParams(installBtnParams);
        installBtn.setOnClickListener(v -> showInstallExtensionDialog());
        content.addView(installBtn);

        return root;
    }

    private View buildExtensionRow(JSONObject ext) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(20, 18, 20, 18);
        row.setBackgroundResource(R.drawable.bg_tab_inactive);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 10;
        row.setLayoutParams(rowParams);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView name = new TextView(this);
        name.setText(ext.optString("name", "Extension"));
        name.setTextColor(getColor(R.color.text_primary));
        name.setTextSize(12);
        col.addView(name);
        TextView match = new TextView(this);
        match.setText("Runs on: " + ext.optString("match", "*"));
        match.setTextColor(getColor(R.color.text_dim));
        match.setTextSize(9);
        col.addView(match);
        row.addView(col);

        android.widget.Switch enabledSwitch = new android.widget.Switch(this);
        enabledSwitch.setChecked(ext.optBoolean("enabled", true));
        enabledSwitch.setOnCheckedChangeListener((btn, checked) -> setExtensionEnabled(ext.optString("id"), checked));
        row.addView(enabledSwitch);

        TextView removeBtn = new TextView(this);
        removeBtn.setText("✕");
        removeBtn.setTextColor(getColor(R.color.text_dim));
        removeBtn.setTextSize(15);
        removeBtn.setPadding(20, 8, 8, 8);
        removeBtn.setOnClickListener(v -> {
            removeExtension(ext.optString("id"));
            if (isPageShown) showFullPage(buildExtensionsView());
        });
        row.addView(removeBtn);

        return row;
    }

    private void showInstallExtensionDialog() {
        EditText input = new EditText(this);
        input.setHint("URL of a .js userscript or extension manifest");
        input.setTextColor(getColor(R.color.text_primary));
        input.setHintTextColor(getColor(R.color.text_dim));
        input.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI);
        input.setPadding(32, 24, 32, 24);

        new AccentDialogBuilder(this)
                .setTitle("Install Extension")
                .setView(input)
                .setPositiveButton("Install", (d, w) -> {
                    String url = input.getText().toString().trim();
                    if (url.isEmpty()) return;
                    Toast.makeText(this, "Installing…", Toast.LENGTH_SHORT).show();
                    installExtensionFromUrl(url, (success, message) -> {
                        Toast.makeText(this, message, success ? Toast.LENGTH_SHORT : Toast.LENGTH_LONG).show();
                        if (success && isPageShown) showFullPage(buildExtensionsView());
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Decide if input is a URL or a search query, exactly like a real
     * browser omnibox (Chrome/UC Mini logic).
     */
    private String resolveUrl(String input) {
        if (Patterns.WEB_URL.matcher(input).matches() || input.startsWith("http://") || input.startsWith("https://")) {
            if (!input.startsWith("http://") && !input.startsWith("https://")) {
                return "https://" + input;
            }
            return input;
        }
        return "https://www.google.com/search?q=" + Uri.encode(input);
    }

    // ---- Incognito: a tab that skips history tracking and clears cookies
    // when the last such tab closes. Note the honest limitation — cookies
    // are shared with normal tabs while open (no true per-tab isolated
    // cookie jar), but nothing from this tab is ever written to history. ----
    private void createIncognitoTab() {
        createNewTab(true);
        Toast.makeText(this, "🕶 Incognito Browsing is on — history won't be saved", Toast.LENGTH_LONG).show();
    }

    // ---- Creates a brand-new, independent, top-level WebView tab. Starts in
    // "home" state (Speed Dial shown) — the WebView is created and wired up
    // ready to go, but loadUrl only happens once the user actually navigates. ----
    // ---- Incognito isolation ----
    // Incognito tabs run in their own WebView *profile* (androidx.webkit multi-profile,
    // WebView 110+): separate cookies, localStorage, IndexedDB and cache from normal tabs.
    // Closing the last incognito tab deletes just that profile. Before this, incognito
    // shared one cookie jar with normal browsing and closing it called
    // CookieManager.removeAllCookies() — which also logged the person out of every
    // normal tab.
    private static final String INCOGNITO_PROFILE = "nex_incognito";
    private boolean warnedIncognitoNotIsolated = false;

    private boolean supportsIsolatedIncognito() {
        try {
            return androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE);
        } catch (Throwable t) {
            return false;
        }
    }

    /** The cookie jar that belongs to this tab (its profile's for incognito, the default otherwise). */
    private CookieManager cookieManagerFor(DevilTab tab) {
        if (tab != null && tab.isIncognito && supportsIsolatedIncognito()) {
            try {
                return androidx.webkit.ProfileStore.getInstance().getOrCreateProfile(INCOGNITO_PROFILE).getCookieManager();
            } catch (Throwable ignored) { /* fall through to the default jar */ }
        }
        return CookieManager.getInstance();
    }

    /** Called right after `new WebView()` for an incognito tab, before anything loads. */
    private boolean attachIncognitoProfile(WebView webView) {
        if (!supportsIsolatedIncognito()) return false;
        try {
            androidx.webkit.WebViewCompat.setProfile(webView, INCOGNITO_PROFILE);
            prefs.edit().putBoolean("incognito_profile_dirty", true).apply(); // so a crash can't leave it behind
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Erases everything the incognito profile stored. Only ever touches that profile. */
    private void wipeIncognitoData() {
        if (!supportsIsolatedIncognito()) return; // nothing separate to wipe, and we must NOT touch normal cookies
        try {
            androidx.webkit.Profile p = androidx.webkit.ProfileStore.getInstance().getOrCreateProfile(INCOGNITO_PROFILE);
            p.getCookieManager().removeAllCookies(null);
            p.getWebStorage().deleteAllData();
        } catch (Throwable ignored) {}
        try {
            if (androidx.webkit.ProfileStore.getInstance().deleteProfile(INCOGNITO_PROFILE)) {
                prefs.edit().putBoolean("incognito_profile_dirty", false).apply();
            }
        } catch (Throwable ignored) { /* still in use by a WebView that is mid-destroy; data was already cleared above, retried next launch */ }
    }

    private void createNewTab() {
        createNewTab(false, -1);
    }

    private void createNewTab(boolean incognito) {
        createNewTab(incognito, -1);
    }

    // ---- Tab Relationship Graph: parentTabId links this new tab back to
    // whichever tab it was opened FROM (a link click / "open in new tab"),
    // so closing a tab can offer to close what it spawned too, and the Tab
    // Switcher can show "opened from …". Pass -1 for a deliberate,
    // independent new tab (toolbar +, incognito button, session restore). ----
    @SuppressLint("SetJavaScriptEnabled")
    private void createNewTab(boolean incognito, int parentTabId) {
        DevilTab tab = new DevilTab();
        tab.id = ++tabIdCounter;
        tab.type = "home";
        tab.isIncognito = incognito;
        tab.parentTabId = parentTabId;
        tab.lastActiveTime = System.currentTimeMillis();

        createWebViewForTab(tab);

        tabs.add(tab);
        addTabChip(tab);
        switchToTab(tabs.size() - 1);
        updateTabCounter();
    }

    // ---- All WebView setup (settings, JS bridge, WebViewClient,
    // WebChromeClient, download handling) lives here so it's identical
    // whether a tab is being created fresh or being woken back up from
    // Smart Tab Suspension — sets tab.webView and returns it. ----
    @SuppressLint("SetJavaScriptEnabled")
    private WebView createWebViewForTab(DevilTab tab) {
        WebView webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        boolean incognitoIsolated = tab.isIncognito && attachIncognitoProfile(webView);
        if (tab.isIncognito && !incognitoIsolated && !warnedIncognitoNotIsolated) {
            warnedIncognitoNotIsolated = true;
            Toast.makeText(this, "This phone's WebView is too old to fully isolate Private tabs — "
                    + "update \"Android System WebView\" in Play Store", Toast.LENGTH_LONG).show();
        }

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        // Hardening: Nex never loads local file:// or content:// pages into a tab, so
        // turn those doors off explicitly (they default to ON for older targetSdk
        // behaviour and are the classic "malicious page reads local files" route).
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        // Google Safe Browsing (phishing / malware interstitials) — real reputation
        // service, complements the built-in domain lists.
        if (Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);
        // window.open() / target=_blank popups arrive in onCreateWindow as a real new
        // tab (needed for OAuth / "Sign in with Google" popups, payment windows).
        // setJavaScriptCanOpenWindowsAutomatically stays at its default (false), so a
        // script that opens a window WITHOUT a tap is blocked — that is the popup blocker.
        settings.setSupportMultipleWindows(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        // SECURITY FIX (Sep 2026 audit, High severity): ALWAYS_ALLOW let any
        // HTTPS page silently load active mixed content (scripts/iframes/XHR
        // over plain HTTP) with no warning — an easy injection point on any
        // shared/public network. COMPATIBILITY_MODE is the mode Google
        // recommends for WebView: blocks active mixed content (scripts) but
        // still loads passive content (images) so most real sites don't
        // visibly break.
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBlockNetworkImage(isTextOnlyOn || isDataSaverOn);
        // Incognito (#8): isolation comes from the WebView *profile* attached in
        // createWebViewForTab (see attachIncognitoProfile). Here: third-party cookies off,
        // no HTTP cache, and — only when NOT isolated — no on-disk site storage.
        // Isolated profile: site storage is safe to allow (it is deleted with the profile,
        // and many sites break without it). Without isolation keep it off so nothing
        // from a private tab lands in the shared on-disk stores.
        settings.setDomStorageEnabled(!tab.isIncognito || incognitoIsolated);
        settings.setDatabaseEnabled(!tab.isIncognito || incognitoIsolated);
        settings.setCacheMode(tab.isIncognito ? WebSettings.LOAD_NO_CACHE : WebSettings.LOAD_DEFAULT);
        // Real, standard mobile Chrome user-agent — sites see a genuine browser,
        // not an embedded iframe, so X-Frame-Options / CSP frame-blocking never
        // triggers here the way it did in the iframe-based PWA version.
        String mobileUA = settings.getUserAgentString().replace("; wv", "");
        settings.setUserAgentString(isDesktopUA ? DESKTOP_UA : mobileUA);

        CookieManager tabCookies = cookieManagerFor(tab);
        tabCookies.setAcceptCookie(true);
        tabCookies.setAcceptThirdPartyCookies(webView, !tab.isIncognito);
        // SECURITY: the password-capture bridge is never attached to incognito tabs.
        // On any phone with a modern WebView it is an androidx.webkit WebMessageListener
        // that accepts messages only from the MAIN frame whose origin equals the page shown
        // in this tab (so a third-party iframe / ad script can't trigger a fake "Save
        // password?" prompt). Only very old WebViews fall back to the legacy
        // addJavascriptInterface object. Either way nothing is saved without an explicit
        // tap on the confirmation dialog.
        if (!tab.isIncognito) {
            boolean listenerAttached = false;
            try {
                if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.WEB_MESSAGE_LISTENER)) {
                    // WebMessageListener tells us WHICH origin and WHICH frame sent the message,
                    // which addJavascriptInterface never did. So: main frame only (an ad iframe
                    // can't fake a "Save password?" prompt) and the sender's origin must equal
                    // the page actually shown in this tab.
                    androidx.webkit.WebViewCompat.addWebMessageListener(webView, "NexPasswordCapture",
                            java.util.Collections.singleton("*"),
                            (view, message, sourceOrigin, isMainFrame, replyProxy) -> {
                                if (!isMainFrame || !originMatchesTab(sourceOrigin, tab)) return;
                                String data = message.getData();
                                if (data != null) handleCapturedLogin(tab, data);
                            });
                    listenerAttached = true;
                }
            } catch (Throwable ignored) { /* fall back below */ }
            if (!listenerAttached) {
                webView.addJavascriptInterface(new NexJsBridge(tab), "NexPasswordCapture");
            }
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                tab.type = "web";
                tab.blockedThisLoad = false;
                tab.filterPageUrl = url != null ? url : "";
                tab.hasError = false;
                if (isCurrentTab(tab)) {
                    progressBar.setVisibility(View.VISIBLE);
                    omniInput.setText(url);
                    updateOmniboxSecurityIndicator(url);
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (isCurrentTab(tab)) {
                    progressBar.setVisibility(View.GONE);
                    updateBookmarkStar();
                }
                tab.title = view.getTitle() != null ? view.getTitle() : url;
                updateTabChip(tab);
                if (!tab.isIncognito) trackVisit(url, tab.title, view);
                incrementIntPref("adblock_pages_visited", 1);
                if (tab.blockedThisLoad) incrementIntPref("adblock_pages_filtered", 1);
                scheduleSessionSave();
                injectCosmeticFilters(view, url);

                // AI Tab Search: grab a short content extract for this tab so
                // search can match on what the page is actually about, not
                // just its title. Skipped for incognito, consistent with
                // everything else incognito never contributes to.
                if (!tab.isIncognito) {
                    view.evaluateJavascript(
                            "(function(){return document.body ? document.body.innerText.slice(0, 600) : '';})()",
                            rawValue -> tab.pageExtract = unescapeJsString(rawValue));
                }

                if (passwordManagerEnabled && !tab.isIncognito) {
                    view.evaluateJavascript(CAPTURE_JS, null);
                    tryAutofill(view, url);
                }

                // Extensions (userscripts): run every installed, enabled
                // extension whose match pattern fits this page.
                runMatchingExtensions(view, url, tab.isIncognito);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    tab.hasError = true;
                    tab.failedUrl = request.getUrl().toString();
                    tab.errorMessage = error.getDescription() != null
                            ? error.getDescription().toString() : "Unknown error";
                    if (isCurrentTab(tab)) {
                        progressBar.setVisibility(View.GONE);
                        webViewContainer.removeAllViews();
                        webViewContainer.addView(buildErrorView(tab));
                    }
                }
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String reqUrl = request.getUrl().toString();
                // Never block the page the person is actually navigating to — only the
                // sub-resources it loads. (Otherwise typing an ad network's own site, or
                // a redirect through one, just shows a blank page.)
                if (isAdBlockOn && !request.isForMainFrame()) {
                    // Context for $third-party / $script / domain= rules. The page URL is tracked on
                    // the tab (WebView.getUrl() may only be called on the UI thread, and this runs on
                    // WebView's own request thread).
                    java.util.Map<String, String> headers = request.getRequestHeaders();
                    int type = AdFilterEngine.guessType(reqUrl,
                            headers != null ? headers.get("Accept") : null,
                            headers != null ? headers.get("X-Requested-With") : null, false);
                    String hit = adFilterEngine.match(reqUrl, tab.filterPageUrl, type);
                    if (hit != null) {
                        recordAdBlocked(reqUrl, tab, adFilterEngine.categoryForMatch(hit));
                        return new WebResourceResponse("text/plain", "utf-8",
                                new ByteArrayInputStream(new byte[0]));
                    }
                }
                // Universal Downloader: passively note any media-looking request
                // this tab makes (e.g. once a video starts playing) so "Download
                // Video" in the Main Menu has something real to offer — this is
                // pure observation, nothing is blocked or altered here.
                if (isLikelyMediaUrl(reqUrl)) {
                    synchronized (tab.detectedMediaUrls) {
                        tab.detectedMediaUrls.add(reqUrl);
                        if (tab.detectedMediaUrls.size() > 40) {
                            Iterator<String> it = tab.detectedMediaUrls.iterator();
                            it.next();
                            it.remove();
                        }
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            // A tab's renderer process can die (crash, or killed by Android for
            // memory). If this callback isn't overridden Android terminates the
            // WHOLE APP. Returning true keeps Nex alive and we rebuild just this tab.
            @Override
            public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                final boolean crashed = detail != null && detail.didCrash();
                mainHandler.post(() -> recoverFromRendererGone(tab, view, crashed));
                return true;
            }

            // Sites protected with HTTP Basic/Digest auth (routers, staging sites, ...).
            @Override
            public void onReceivedHttpAuthRequest(WebView view, android.webkit.HttpAuthHandler handler,
                                                  String host, String realm) {
                if (!isCurrentTab(tab)) { handler.cancel(); return; }
                showHttpAuthDialog(handler, host, realm);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                // SECURITY FIX (Sep 2026 audit, High severity): this used to
                // call handler.proceed() unconditionally, silently accepting
                // ANY certificate error (expired, wrong host, self-signed,
                // untrusted CA) on every site with zero user visibility —
                // a textbook MITM opening. Now: cancel by default, and only
                // proceed if the person explicitly taps through a warning
                // that names the actual problem, once per host per app
                // session (so it doesn't nag on a site they already trusted).
                String host = error.getUrl() != null ? Uri.parse(error.getUrl()).getHost() : null;
                if (host != null && sslTrustedHostsThisSession.contains(host)) {
                    handler.proceed();
                    return;
                }
                handler.cancel();
                if (!isCurrentTab(tab)) return; // don't pop a dialog for a background tab
                String reason;
                switch (error.getPrimaryError()) {
                    case SslError.SSL_EXPIRED: reason = "The site's security certificate has expired."; break;
                    case SslError.SSL_IDMISMATCH: reason = "The certificate doesn't match this site's address."; break;
                    case SslError.SSL_NOTYETVALID: reason = "The site's security certificate isn't valid yet."; break;
                    case SslError.SSL_UNTRUSTED: reason = "The certificate isn't from a trusted authority."; break;
                    default: reason = "The connection to this site isn't fully secure."; break;
                }
                new AccentDialogBuilder(MainActivity.this)
                        .setTitle("Connection isn't private")
                        .setMessage(reason + "\n\n" + (host != null ? host : "This site")
                                + " may not be who it claims to be. Only proceed if you trust this site.")
                        .setPositiveButton("Proceed anyway", (d, w) -> {
                            if (host != null) sslTrustedHostsThisSession.add(host);
                            handler.proceed();
                        })
                        .setNegativeButton("Go back", (d, w) -> {
                            handler.cancel();
                            if (view.canGoBack()) view.goBack();
                        })
                        .setCancelable(false)
                        .show();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Keep navigation top-level inside this same WebView/tab —
                // this IS the top-level browsing context, so no framing
                // restrictions apply, unlike the PWA's <iframe> approach.
                if (openLinkInNewTab && isCurrentTab(tab)) {
                    // New tab inherits incognito-ness from the tab it was
                    // opened from (previously always opened as a normal
                    // tab even from inside incognito — a real leak this
                    // fixes), and records this tab as its parent for the
                    // Tab Relationship Graph.
                    createNewTab(tab.isIncognito, tab.id);
                    navigate(url);
                } else {
                    view.loadUrl(url);
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (isCurrentTab(tab)) {
                    progressBar.setProgress(newProgress);
                }
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                tab.title = title;
                updateTabChip(tab);
            }

            // ---- Fullscreen video support (YouTube, embedded players, etc.) ----
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (currentFullscreenView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                currentFullscreenView = view;
                fullscreenCallback = callback;
                fullscreenContainer.addView(view);
                fullscreenContainer.setVisibility(View.VISIBLE);
                webViewContainer.setVisibility(View.GONE);
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
            }

            @Override
            public void onHideCustomView() {
                if (currentFullscreenView == null) return;
                fullscreenContainer.setVisibility(View.GONE);
                fullscreenContainer.removeView(currentFullscreenView);
                webViewContainer.setVisibility(View.VISIBLE);
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
                if (fullscreenCallback != null) fullscreenCallback.onCustomViewHidden();
                currentFullscreenView = null;
                fullscreenCallback = null;
            }

            // ---- window.open() popups / target=_blank → a new tab linked to this one ----
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture,
                                          android.os.Message resultMsg) {
                if (!isUserGesture || resultMsg == null || !(resultMsg.obj instanceof WebView.WebViewTransport)) {
                    return false; // no tap behind it → treat as an unwanted popup
                }
                createNewTab(tab.isIncognito, tab.id);
                final int popupIndex = tabs.size() - 1;
                DevilTab popup = tabs.get(popupIndex);
                popup.type = "web"; // show its WebView, not the Speed Dial home
                switchToTab(popupIndex);
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popup.webView);
                resultMsg.sendToTarget();
                return true;
            }

            // The page closed its own popup (e.g. OAuth finished and called window.close()).
            @Override
            public void onCloseWindow(WebView window) {
                for (int i = 0; i < tabs.size(); i++) {
                    if (tabs.get(i).webView == window) {
                        closeTabInternal(i); // page-initiated: no "close child tabs too?" prompt
                        return;
                    }
                }
            }

            // ---- Website file uploads (<input type="file">) ----
            @Override
            public boolean onShowFileChooser(WebView view, android.webkit.ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (pendingFileChooserCallback != null) {
                    pendingFileChooserCallback.onReceiveValue(null); // a previous chooser was abandoned
                }
                pendingFileChooserCallback = filePathCallback;
                try {
                    fileChooserLauncher.launch(fileChooserParams.createIntent());
                } catch (Exception e) {
                    pendingFileChooserCallback = null;
                    filePathCallback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "Couldn't open the file picker", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            // ---- Website location permission ----
            @Override
            public void onGeolocationPermissionsShowPrompt(final String origin,
                                                           final android.webkit.GeolocationPermissions.Callback callback) {
                mainHandler.post(() -> {
                    String host = Uri.parse(origin).getHost();
                    new AccentDialogBuilder(MainActivity.this)
                            .setTitle("Share your location?")
                            .setMessage((host != null ? host : origin) + " wants to know where you are.")
                            .setCancelable(false)
                            .setPositiveButton("Allow", (d, w) -> {
                                boolean hasFine = checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)
                                        == android.content.pm.PackageManager.PERMISSION_GRANTED;
                                boolean hasCoarse = checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION)
                                        == android.content.pm.PackageManager.PERMISSION_GRANTED;
                                if (hasFine || hasCoarse) {
                                    callback.invoke(origin, true, false); // false = ask again next visit
                                } else {
                                    if (pendingGeoCallback != null) pendingGeoCallback.invoke(pendingGeoOrigin, false, false);
                                    pendingGeoCallback = callback;
                                    pendingGeoOrigin = origin;
                                    geoPermissionLauncher.launch(new String[]{
                                            android.Manifest.permission.ACCESS_FINE_LOCATION,
                                            android.Manifest.permission.ACCESS_COARSE_LOCATION});
                                }
                            })
                            .setNegativeButton("Block", (d, w) -> callback.invoke(origin, false, false))
                            .show();
                });
            }

            // ---- Website camera / microphone permission ----
            @Override
            public void onPermissionRequest(final android.webkit.PermissionRequest request) {
                mainHandler.post(() -> handleWebPermissionRequest(request));
            }
        });

        // ---- Real file downloads (images, videos, APKs, documents) ----
        webView.setDownloadListener((downloadUrl, userAgent, contentDisposition, mimeType, contentLength) -> {
            String fileName = URLUtil.guessFileName(downloadUrl, contentDisposition, mimeType);
            Runnable startDownload = () -> {
                try {
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(downloadUrl));
                    request.setMimeType(mimeType);
                    request.addRequestHeader("User-Agent", userAgent);
                    // Downloads behind a login (invoices, exports) need the page's session cookies.
                    String downloadCookies = cookieManagerFor(tab).getCookie(downloadUrl);
                    if (downloadCookies != null && !downloadCookies.isEmpty()) {
                        request.addRequestHeader("Cookie", downloadCookies);
                    }
                    request.setNotificationVisibility(downloadNotificationOn
                            ? DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                            : DownloadManager.Request.VISIBILITY_HIDDEN);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
                    request.allowScanningByMediaScanner();

                    DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    dm.enqueue(request);
                    Toast.makeText(this, "Downloading: " + fileName, Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Download failed to start", Toast.LENGTH_SHORT).show();
                }
            };

            if (newTaskAlwaysAsk) {
                new AccentDialogBuilder(this)
                        .setTitle("New Download")
                        .setMessage(fileName)
                        .setPositiveButton("Download", (d, w) -> startDownload.run())
                        .setNegativeButton("Cancel", null)
                        .show();
            } else {
                startDownload.run();
            }
        });

        tab.webView = webView;
        return webView;
    }

    private boolean isCurrentTab(DevilTab tab) {
        return currentTabIndex >= 0 && currentTabIndex < tabs.size() && tabs.get(currentTabIndex) == tab;
    }

    private WebView currentWebView() {
        if (currentTabIndex >= 0 && currentTabIndex < tabs.size()) {
            return tabs.get(currentTabIndex).webView;
        }
        return null;
    }

    // Navigates the current tab to a URL, transitioning it from "home"
    // (Speed Dial) to "web" state if needed.
    private void navigate(String url) {
        DevilTab tab = currentTab();
        if (tab == null) return;
        tab.type = "web";
        webViewContainer.removeAllViews();
        webViewContainer.addView(tab.webView);
        tab.webView.loadUrl(url);
    }

    private DevilTab currentTab() {
        if (currentTabIndex >= 0 && currentTabIndex < tabs.size()) {
            return tabs.get(currentTabIndex);
        }
        return null;
    }

    // Not-Secure indicator (Sep 2026 audit, High severity — cleartext
    // traffic pairs with the audit's #3 finding). This is a real, general-
    // purpose browser, so it still has to be able to open plain http://
    // sites the way Chrome/Firefox/Safari do — outright blocking cleartext
    // app-wide would break ordinary browsing, not just close a bug. What
    // every real browser does instead or actually does is make the
    // insecurity VISIBLE rather than silent, so that's the fix here: a
    // warning-triangle icon replaces the lock in the address bar on any
    // http:// page, and a plain lock shows on https:// — so a person can
    // always tell at a glance, instead of the previous flag which made
    // every connection look identical whether secure or not.
    private void updateOmniboxSecurityIndicator(String url) {
        if (url == null || url.isEmpty() || url.startsWith("data:") || url.equals("about:blank")) {
            omniInput.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
            return;
        }
        boolean isHttps = url.startsWith("https://");
        boolean isHttp = url.startsWith("http://");
        if (!isHttps && !isHttp) {
            omniInput.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
            return;
        }
        int iconRes = isHttps ? R.drawable.ic_secure_lock : R.drawable.ic_not_secure;
        omniInput.setCompoundDrawablesWithIntrinsicBounds(iconRes, 0, 0, 0);
        omniInput.setCompoundDrawablePadding(12);
        Drawable icon = omniInput.getCompoundDrawables()[0];
        if (icon != null) {
            icon.setTint(getColor(isHttps ? R.color.text_dim : R.color.gold));
        }
    }

    private void switchToTab(int index) {
        webViewContainer.removeAllViews();
        currentTabIndex = index;
        DevilTab tab = tabs.get(index);
        tab.lastActiveTime = System.currentTimeMillis();
        if (tab.isSuspended) {
            resumeSuspendedTab(tab);
        }
        if ("home".equals(tab.type)) {
            webViewContainer.addView(buildHomeView());
            omniInput.setText("");
            updateOmniboxSecurityIndicator(null);
        } else if (tab.hasError) {
            webViewContainer.addView(buildErrorView(tab));
            omniInput.setText(tab.failedUrl);
            updateOmniboxSecurityIndicator(tab.failedUrl);
        } else {
            webViewContainer.addView(tab.webView);
            omniInput.setText(tab.webView.getUrl());
            updateOmniboxSecurityIndicator(tab.webView.getUrl());
        }
        refreshTabChips();
        updateBookmarkStar();
        scheduleSessionSave(); // which tab is active changed
    }

    // ================================================================
    // SMART TAB SUSPENSION (#13) — background tabs that haven't been
    // looked at for a while get their real WebView destroyed to free
    // memory, exactly like Chrome/Edge's "tab discarding". Before that
    // happens, the tab's current URL (and every other open tab's, for a
    // full picture) is saved into the user's own account box on the
    // backend — so nothing is ever silently lost, and it's there even if
    // this device's local state somehow got cleared. Tapping a suspended
    // tab transparently recreates its WebView and reloads the saved URL —
    // from the user's point of view the tab was just sitting there.
    // ================================================================
    private static final long TAB_SUSPEND_IDLE_MS = 10 * 60 * 1000; // 10 minutes background = suspend
    private final Handler tabSuspendHandler = new Handler(Looper.getMainLooper());

    private void scheduleTabSuspensionCheck() {
        tabSuspendHandler.postDelayed(() -> {
            checkAndSuspendIdleTabs();
            scheduleTabSuspensionCheck();
        }, 60_000); // check once a minute — cheap, and suspension itself only fires after 10 idle minutes
    }

    private void checkAndSuspendIdleTabs() {
        long now = System.currentTimeMillis();
        boolean suspendedAny = false;
        for (int i = 0; i < tabs.size(); i++) {
            DevilTab tab = tabs.get(i);
            if (i == currentTabIndex) continue; // never suspend the tab you're actually looking at
            if (tab.isSuspended) continue;
            if (!"web".equals(tab.type)) continue; // Speed Dial tabs have nothing to free
            if (tab.isIncognito) continue; // incognito never persists anywhere, suspension included
            if (now - tab.lastActiveTime < TAB_SUSPEND_IDLE_MS) continue;
            if (suspendTab(tab)) suspendedAny = true;
        }
        if (suspendedAny) syncOpenTabsMetadataToBackend();
    }

    private boolean suspendTab(DevilTab tab) {
        if (tab.webView == null) return false;
        String url = tab.webView.getUrl();
        if (url == null || url.isEmpty() || url.equals("about:blank")) return false;
        tab.suspendedUrl = url;
        tab.isSuspended = true;
        tab.webView.stopLoading();
        tab.webView.destroy(); // the actual memory reclaim — not just hidden, genuinely torn down
        tab.webView = null;
        updateTabChip(tab);
        return true;
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void resumeSuspendedTab(DevilTab tab) {
        createWebViewForTab(tab); // sets tab.webView to a fresh, fully-configured WebView
        tab.isSuspended = false;
        tab.hasError = false;
        if (!tab.suspendedUrl.isEmpty()) {
            tab.webView.loadUrl(tab.suspendedUrl);
        }
    }

    // ---- Lightweight sync: only the "tabs" field, so this doesn't touch
    // passwords/bookmarks/history/shortcuts/downloads. Sends every
    // currently open non-incognito tab's URL+title — not just the one
    // being suspended — so the account box always reflects a full,
    // current picture of what's open, from any device. ----
    private void syncOpenTabsMetadataToBackend() {
        if (backendUrl.isEmpty() || authToken.isEmpty()) return;
        networkExecutor.execute(() -> {
            try {
                JSONArray tabsArr = new JSONArray();
                for (DevilTab tab : tabs) {
                    if (tab.isIncognito) continue;
                    if (!"web".equals(tab.type)) continue;
                    String url = tab.isSuspended ? tab.suspendedUrl : (tab.webView != null ? tab.webView.getUrl() : "");
                    if (url == null || url.isEmpty()) continue;
                    JSONObject o = new JSONObject();
                    o.put("id", tab.id);
                    o.put("title", tab.title);
                    o.put("url", url);
                    o.put("suspended", tab.isSuspended);
                    tabsArr.put(o);
                }
                JSONObject body = new JSONObject();
                body.put("tabs", tabsArr);
                httpPostJson(backendUrl + "/vault/sync", body, authToken);
            } catch (Exception ignored) {
                // best-effort — suspension itself already happened locally either way
            }
        });
    }

    // ================================================================
    // SPEED DIAL HOMEPAGE — shown when a tab is in "home" state.
    // Search happens via the persistent top omnibox (kept as one shared
    // search bar rather than duplicating a second one inside this view).
    // ================================================================
    // ================================================================
    // HOME SCREEN — redesigned Sep 2026 (UC-style audit pass 1 of 4).
    // Adds: a wallpaper layer (user-selectable, "Home Style"), a
    // prominent search pill that focuses the existing shared omnibox
    // (still just one real search bar per the original design note),
    // rounded speed-dial cards instead of plain circles, an inline
    // "+" add-your-own-shortcut card, and Most Visited as compact
    // cards instead of bare rows. Advanced tools stay out of this
    // screen entirely — that move is redesign pass 3 (Tools hub).
    // ================================================================
    private View buildHomeView() {
        FrameLayout wallpaperLayer = new FrameLayout(this);
        wallpaperLayer.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        applyHomeWallpaper(wallpaperLayer);

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        wallpaperLayer.addView(scroll);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 32, 24, 32);
        scroll.addView(root);

        // ---- Prominent search pill — focuses the persistent top omnibox ----
        LinearLayout searchPill = new LinearLayout(this);
        searchPill.setOrientation(LinearLayout.HORIZONTAL);
        searchPill.setGravity(android.view.Gravity.CENTER_VERTICAL);
        searchPill.setBackgroundResource(R.drawable.bg_home_search_pill);
        searchPill.setPadding(32, 26, 32, 26);
        LinearLayout.LayoutParams pillParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        pillParams.bottomMargin = 32;
        searchPill.setLayoutParams(pillParams);

        TextView searchIcon = new TextView(this);
        searchIcon.setText("🔍");
        searchIcon.setTextSize(13);
        searchPill.addView(searchIcon);

        TextView searchHint = new TextView(this);
        searchHint.setText("Search or type a URL");
        searchHint.setTextColor(getColor(R.color.text_dim));
        searchHint.setTextSize(12.5f);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        hintParams.weight = 1;
        hintParams.leftMargin = 20;
        searchHint.setLayoutParams(hintParams);
        searchPill.addView(searchHint);
        searchPill.setOnClickListener(v -> focusOmnibox());
        root.addView(searchPill);

        // ---- Shortcuts grid (4 columns of wider rounded cards + trailing "+" card) ----
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        root.addView(grid);

        for (Shortcut sc : shortcuts) {
            grid.addView(buildShortcutTile(sc));
        }
        grid.addView(buildAddShortcutTile());

        // ---- Most Visited ----
        List<Shortcut> mostVisited = getMostVisited(5);
        if (!mostVisited.isEmpty()) {
            TextView label = new TextView(this);
            label.setText("MOST VISITED");
            label.setTextColor(ThemeManager.getAccentColor(this));
            label.setTextSize(10);
            label.setLetterSpacing(0.08f);
            LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            labelParams.setMargins(8, 44, 0, 12);
            label.setLayoutParams(labelParams);
            root.addView(label);

            LinearLayout mvCard = new LinearLayout(this);
            mvCard.setOrientation(LinearLayout.VERTICAL);
            mvCard.setBackgroundResource(R.drawable.bg_home_card);
            mvCard.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            for (Shortcut mv : mostVisited) {
                mvCard.addView(buildMostVisitedRow(mv));
            }
            root.addView(mvCard);
        }

        // ---- Bottom action row: Manage Cards + Home Style ----
        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams actionRowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        actionRowParams.topMargin = 32;
        actionRow.setLayoutParams(actionRowParams);

        TextView manageCards = new TextView(this);
        manageCards.setText("⚙  Manage Cards");
        manageCards.setTextColor(getColor(R.color.text_primary));
        manageCards.setTextSize(11);
        manageCards.setGravity(android.view.Gravity.CENTER);
        manageCards.setPadding(20, 24, 20, 24);
        manageCards.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams mcParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        mcParams.weight = 1;
        mcParams.rightMargin = 8;
        manageCards.setLayoutParams(mcParams);
        manageCards.setOnClickListener(v -> showManageCardsDialog());
        actionRow.addView(manageCards);

        TextView homeStyle = new TextView(this);
        homeStyle.setText("🎨  Home Style");
        homeStyle.setTextColor(getColor(R.color.text_primary));
        homeStyle.setTextSize(11);
        homeStyle.setGravity(android.view.Gravity.CENTER);
        homeStyle.setPadding(20, 24, 20, 24);
        homeStyle.setBackgroundResource(R.drawable.bg_toolbar_btn);
        LinearLayout.LayoutParams hsParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        hsParams.weight = 1;
        hsParams.leftMargin = 8;
        homeStyle.setLayoutParams(hsParams);
        homeStyle.setOnClickListener(v -> showHomeStyleDialog());
        actionRow.addView(homeStyle);

        root.addView(actionRow);

        return wallpaperLayer;
    }

    /** Focuses the single shared top omnibox and opens the keyboard — the
     *  home search pill is an entry point to it, not a second search bar. */
    private void focusOmnibox() {
        if (omniInput == null) return;
        omniInput.requestFocus();
        omniInput.selectAll();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(omniInput, InputMethodManager.SHOW_IMPLICIT);
    }

    /** Applies the user's chosen Home Style wallpaper gradient as the
     *  background of the given container. Falls back to a plain color if
     *  the saved index is out of range (e.g. after a HOME_WALLPAPERS resize). */
    private void applyHomeWallpaper(View container) {
        int index = prefs.getInt("home_wallpaper_index", 0);

        if (index == HOME_WALLPAPER_CUSTOM_IMAGE_INDEX) {
            File imgFile = new File(getFilesDir(), HOME_WALLPAPER_IMAGE_FILENAME);
            if (imgFile.exists() && container instanceof FrameLayout) {
                Bitmap bmp = android.graphics.BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                if (bmp != null) {
                    FrameLayout frame = (FrameLayout) container;
                    frame.setBackground(null);
                    ImageView imageView = new ImageView(this);
                    imageView.setLayoutParams(new FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                    imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    imageView.setImageBitmap(bmp);
                    frame.addView(imageView, 0);
                    // Readability overlay (Design v2's "personal image" spec calls
                    // for one explicitly) so shortcut/search-pill text stays
                    // legible over an arbitrary user photo of any brightness.
                    View scrim = new View(this);
                    scrim.setLayoutParams(new FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                    scrim.setBackgroundColor(0x66000000);
                    frame.addView(scrim, 1);
                    return;
                }
            }
            // Fell through: file missing/unreadable — reset to Default and
            // continue below with the normal gradient path instead of
            // leaving Home with no background at all.
            prefs.edit().putInt("home_wallpaper_index", 0).apply();
            index = 0;
        }

        if (index < 0 || index >= HOME_WALLPAPERS.length) index = 0;
        Object[] wp = HOME_WALLPAPERS[index];
        int startColor = getColor((int) wp[1]);
        int endColor = getColor((int) wp[2]);
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{startColor, endColor});
        container.setBackground(bg);
    }

    /**
     * Copies a Photo-Picker-selected image into app-internal storage so it
     * survives process death (the picker's Uri read grant does not). Runs
     * on a background thread — called from homeImagePickerLauncher above.
     */
    private boolean copyImageToInternalStorage(android.net.Uri sourceUri) {
        try (java.io.InputStream in = getContentResolver().openInputStream(sourceUri);
             FileOutputStream out = new FileOutputStream(new File(getFilesDir(), HOME_WALLPAPER_IMAGE_FILENAME))) {
            if (in == null) return false;
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void showHomeStyleDialog() {
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(24, 16, 24, 16);

        int current = prefs.getInt("home_wallpaper_index", 0);
        AlertDialog[] dialogHolder = new AlertDialog[1];

        for (int i = 0; i < HOME_WALLPAPERS.length; i++) {
            final int idx = i;
            Object[] wp = HOME_WALLPAPERS[i];
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setPadding(16, 20, 16, 20);
            row.setBackgroundResource(R.drawable.bg_home_card);
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rowParams.bottomMargin = 12;
            row.setLayoutParams(rowParams);

            View swatch = new View(this);
            swatch.setLayoutParams(new LinearLayout.LayoutParams(56, 56));
            GradientDrawable swatchBg = new GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{getColor((int) wp[1]), getColor((int) wp[2])});
            swatchBg.setCornerRadius(12);
            swatch.setBackground(swatchBg);
            row.addView(swatch);

            TextView name = new TextView(this);
            name.setText((idx == current ? "✓  " : "") + (String) wp[0]);
            name.setTextColor(getColor(R.color.text_primary));
            name.setTextSize(12.5f);
            LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            nameParams.leftMargin = 20;
            name.setLayoutParams(nameParams);
            row.addView(name);

            row.setOnClickListener(v -> {
                prefs.edit().putInt("home_wallpaper_index", idx).apply();
                if (dialogHolder[0] != null) dialogHolder[0].dismiss();
                refreshHomeIfShown();
            });
            list.addView(row);
        }

        // Personal Image (Design v2's Theme Center "personal image" section)
        LinearLayout imageRow = new LinearLayout(this);
        imageRow.setOrientation(LinearLayout.HORIZONTAL);
        imageRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        imageRow.setPadding(16, 20, 16, 20);
        imageRow.setBackgroundResource(R.drawable.bg_home_card);
        LinearLayout.LayoutParams imageRowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        imageRowParams.bottomMargin = 12;
        imageRow.setLayoutParams(imageRowParams);

        TextView imageIcon = new TextView(this);
        imageIcon.setText("🖼️");
        imageIcon.setTextSize(22);
        imageIcon.setLayoutParams(new LinearLayout.LayoutParams(56, 56, 0));
        imageIcon.setGravity(android.view.Gravity.CENTER);
        imageRow.addView(imageIcon);

        TextView imageLabel = new TextView(this);
        boolean usingCustomImage = current == HOME_WALLPAPER_CUSTOM_IMAGE_INDEX;
        imageLabel.setText((usingCustomImage ? "✓  " : "") + "Personal Image" + (usingCustomImage ? "" : " — choose a photo"));
        imageLabel.setTextColor(getColor(R.color.text_primary));
        imageLabel.setTextSize(12.5f);
        LinearLayout.LayoutParams imageLabelParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        imageLabelParams.leftMargin = 20;
        imageLabel.setLayoutParams(imageLabelParams);
        imageRow.addView(imageLabel);

        imageRow.setOnClickListener(v -> {
            if (dialogHolder[0] != null) dialogHolder[0].dismiss();
            homeImagePickerLauncher.launch(new androidx.activity.result.PickVisualMediaRequest.Builder()
                    .setMediaType(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE)
                    .build());
        });
        list.addView(imageRow);

        ScrollView scrollView = new ScrollView(this);
        scrollView.addView(list);

        dialogHolder[0] = new AccentDialogBuilder(this)
                .setTitle("Home Style")
                .setView(scrollView)
                .setNegativeButton("Close", null)
                .create();
        dialogHolder[0].show();
    }

    private View buildShortcutTile(Shortcut sc) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(android.view.Gravity.CENTER);
        tile.setBackgroundResource(R.drawable.bg_home_card);
        tile.setPadding(8, 20, 8, 16);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        params.height = LinearLayout.LayoutParams.WRAP_CONTENT;
        params.setMargins(6, 6, 6, 6);
        tile.setLayoutParams(params);

        TextView badge = new TextView(this);
        badge.setText(sc.name.substring(0, 1).toUpperCase());
        badge.setTextColor(Color.WHITE);
        badge.setTextSize(16);
        badge.setGravity(android.view.Gravity.CENTER);
        badge.setLayoutParams(new LinearLayout.LayoutParams(72, 72));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(18);
        bg.setColor(sc.color);
        badge.setBackground(bg);
        tile.addView(badge);

        TextView name = new TextView(this);
        name.setText(sc.name);
        name.setTextColor(getColor(R.color.text_dim));
        name.setTextSize(9.5f);
        name.setGravity(android.view.Gravity.CENTER);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        nameParams.topMargin = 10;
        name.setLayoutParams(nameParams);
        tile.addView(name);

        tile.setOnClickListener(v -> navigate(sc.url));
        tile.setOnLongClickListener(v -> {
            confirmRemoveShortcut(sc);
            return true;
        });
        return tile;
    }

    /** Trailing "+" card in the speed-dial grid — opens the add-custom-shortcut
     *  dialog directly, distinct from the fuller Manage Cards toggle list. */
    private View buildAddShortcutTile() {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(android.view.Gravity.CENTER);
        float density = getResources().getDisplayMetrics().density;
        tile.setBackground(ThemeManager.buildAddCardDrawable(this, 14 * density, 1.5f * density, 6 * density, 4 * density));
        tile.setPadding(8, 20, 8, 16);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        params.height = LinearLayout.LayoutParams.WRAP_CONTENT;
        params.setMargins(6, 6, 6, 6);
        tile.setLayoutParams(params);

        TextView plus = new TextView(this);
        plus.setText("+");
        plus.setTextColor(ThemeManager.getAccentColor(this));
        plus.setTextSize(22);
        plus.setGravity(android.view.Gravity.CENTER);
        plus.setLayoutParams(new LinearLayout.LayoutParams(72, 72));
        tile.addView(plus);

        TextView name = new TextView(this);
        name.setText("Add");
        name.setTextColor(getColor(R.color.text_dim));
        name.setTextSize(9.5f);
        name.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        nameParams.topMargin = 10;
        name.setLayoutParams(nameParams);
        tile.addView(name);

        tile.setOnClickListener(v -> showAddCustomShortcutDialog());
        return tile;
    }

    private void showAddCustomShortcutDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 24, 48, 0);

        EditText nameInput = new EditText(this);
        nameInput.setHint("Name (e.g. My Bank)");
        nameInput.setTextColor(getColor(R.color.text_primary));
        nameInput.setHintTextColor(getColor(R.color.text_dim));
        layout.addView(nameInput);

        EditText urlInput = new EditText(this);
        urlInput.setHint("https://example.com");
        urlInput.setTextColor(getColor(R.color.text_primary));
        urlInput.setHintTextColor(getColor(R.color.text_dim));
        LinearLayout.LayoutParams urlParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        urlParams.topMargin = 16;
        urlInput.setLayoutParams(urlParams);
        layout.addView(urlInput);

        // A small fixed palette for custom shortcuts — keeps them visually
        // consistent with the default set instead of a random color per add.
        int[] palette = {
                Color.parseColor("#8E5CE0"), Color.parseColor("#E0568E"),
                Color.parseColor("#4A9BD9"), Color.parseColor("#4CAF7D"),
                Color.parseColor("#E0A85C"), Color.parseColor("#D95C5C")
        };
        int chosenColor = palette[new java.util.Random().nextInt(palette.length)];

        new AccentDialogBuilder(this)
                .setTitle("Add Shortcut")
                .setView(layout)
                .setPositiveButton("Add", (d, w) -> {
                    String name = nameInput.getText().toString().trim();
                    String url = urlInput.getText().toString().trim();
                    if (name.isEmpty() || url.isEmpty()) {
                        Toast.makeText(this, "Name and URL are required", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (!url.startsWith("http://") && !url.startsWith("https://")) {
                        url = "https://" + url;
                    }
                    shortcuts.add(new Shortcut(name, url, chosenColor));
                    saveShortcuts();
                    refreshHomeIfShown();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void confirmRemoveShortcut(Shortcut sc) {
        new AccentDialogBuilder(this)
                .setTitle("Remove Shortcut")
                .setMessage("Remove \"" + sc.name + "\" from your Speed Dial?")
                .setPositiveButton("Remove", (d, w) -> {
                    shortcuts.remove(sc);
                    saveShortcuts();
                    refreshHomeIfShown();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private View buildMostVisitedRow(Shortcut mv) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(16, 20, 16, 20);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        row.setLayoutParams(rowParams);

        TextView badge = new TextView(this);
        badge.setText(mv.name.substring(0, 1).toUpperCase());
        badge.setTextColor(Color.WHITE);
        badge.setTextSize(11);
        badge.setGravity(android.view.Gravity.CENTER);
        badge.setLayoutParams(new LinearLayout.LayoutParams(44, 44));
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setShape(GradientDrawable.RECTANGLE);
        badgeBg.setCornerRadius(10);
        badgeBg.setColor(mv.color);
        badge.setBackground(badgeBg);
        row.addView(badge);

        TextView title = new TextView(this);
        title.setText(mv.name);
        title.setTextColor(getColor(R.color.text_primary));
        title.setTextSize(11.5f);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleParams.weight = 1;
        titleParams.leftMargin = 20;
        title.setLayoutParams(titleParams);
        row.addView(title);

        row.setOnClickListener(v -> navigate(mv.url));
        return row;
    }

    // ================================================================
    // MANAGE CARDS — add/remove shortcuts shown on the Speed Dial
    // ================================================================
    private void showManageCardsDialog() {
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        grid.setPadding(24, 24, 24, 24);

        ScrollView scrollView = new ScrollView(this);
        scrollView.addView(grid);

        AlertDialog dialog = new AccentDialogBuilder(this)
                .setTitle("Manage Shortcuts")
                .setView(scrollView)
                .setPositiveButton("Done", null)
                .create();

        for (Object[] entry : DEFAULT_SHORTCUTS) {
            String name = (String) entry[0];
            String url = (String) entry[1];
            int color = Color.parseColor((String) entry[2]);
            boolean isActive = isShortcutActive(url);

            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(android.view.Gravity.CENTER);
            tile.setPadding(12, 16, 12, 16);
            tile.setAlpha(isActive ? 1f : 0.35f);
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = 0;
            params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            tile.setLayoutParams(params);

            TextView circle = new TextView(this);
            circle.setText(name.substring(0, 1).toUpperCase());
            circle.setTextColor(Color.WHITE);
            circle.setTextSize(15);
            circle.setGravity(android.view.Gravity.CENTER);
            circle.setLayoutParams(new LinearLayout.LayoutParams(80, 80));
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.OVAL);
            bg.setColor(color);
            circle.setBackground(bg);
            tile.addView(circle);

            TextView label = new TextView(this);
            label.setText(name);
            label.setTextColor(getColor(R.color.text_dim));
            label.setTextSize(9);
            label.setGravity(android.view.Gravity.CENTER);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.topMargin = 6;
            label.setLayoutParams(lp);
            tile.addView(label);

            tile.setOnClickListener(v -> {
                toggleShortcut(name, url, color);
                dialog.dismiss();
                showManageCardsDialog(); // reopen refreshed so the change is visible immediately
            });

            grid.addView(tile);
        }

        dialog.show();
    }

    private boolean isShortcutActive(String url) {
        for (Shortcut s : shortcuts) {
            if (s.url.equals(url)) return true;
        }
        return false;
    }

    private void toggleShortcut(String name, String url, int color) {
        for (int i = 0; i < shortcuts.size(); i++) {
            if (shortcuts.get(i).url.equals(url)) {
                shortcuts.remove(i);
                saveShortcuts();
                refreshHomeIfShown();
                return;
            }
        }
        shortcuts.add(new Shortcut(name, url, color));
        saveShortcuts();
        refreshHomeIfShown();
    }

    private void refreshHomeIfShown() {
        DevilTab tab = currentTab();
        if (tab != null && "home".equals(tab.type)) {
            switchToTab(currentTabIndex);
        }
    }

    // ================================================================
    // PASSWORD MANAGER & AUTOFILL — credentials are AES-256 encrypted at
    // rest on-device (Android Keystore-backed via Jetpack Security). If
    // backend sync is set up, they're ALSO end-to-end encrypted with a
    // separate Vault Passphrase (see below) before ever leaving the device
    // — the backend only ever stores ciphertext, never plain text.
    // Capture happens by injecting a small JS listener on password-form
    // submits; autofill happens by injecting JS to fill matching fields
    // when a saved site loads.
    // ================================================================
    private SharedPreferences createSecurePrefs() {
        try {
            MasterKey masterKey = new MasterKey.Builder(this)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();
            return EncryptedSharedPreferences.create(
                    this,
                    "nex_passwords_secure",
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
        } catch (Exception e) {
            // Extremely unlikely (Keystore unavailable) — fall back to a
            // plain-but-still-app-private prefs file rather than crashing.
            return getSharedPreferences("nex_passwords_fallback", MODE_PRIVATE);
        }
    }

    private List<SavedCredential> loadCredentials() {
        List<SavedCredential> result = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(securePrefs.getString("credentials", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                result.add(new SavedCredential(o.getString("domain"), o.getString("username"), o.getString("password")));
            }
        } catch (Exception ignored) {}
        return result;
    }

    private void saveCredentialsList(List<SavedCredential> list) {
        try {
            JSONArray arr = new JSONArray();
            for (SavedCredential c : list) {
                JSONObject o = new JSONObject();
                o.put("domain", c.domain);
                o.put("username", c.username);
                o.put("password", c.password);
                arr.put(o);
            }
            securePrefs.edit().putString("credentials", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void upsertCredential(String domain, String username, String password) {
        List<SavedCredential> list = loadCredentials();
        boolean found = false;
        for (SavedCredential c : list) {
            if (c.domain.equals(domain) && c.username.equals(username)) {
                c.password = password;
                found = true;
                break;
            }
        }
        if (!found) list.add(new SavedCredential(domain, username, password));
        saveCredentialsList(list);
    }

    private void deleteCredential(String domain, String username) {
        List<SavedCredential> list = loadCredentials();
        list.removeIf(c -> c.domain.equals(domain) && c.username.equals(username));
        saveCredentialsList(list);
    }

    private List<SavedCredential> findCredentialsForDomain(String domain) {
        List<SavedCredential> result = new ArrayList<>();
        for (SavedCredential c : loadCredentials()) {
            if (c.domain.equals(domain)) result.add(c);
        }
        return result;
    }

    private SavedCredential findCredentialForDomainAndUsername(String domain, String username) {
        if (domain == null || domain.isEmpty() || username == null || username.isEmpty()) return null;
        for (SavedCredential c : loadCredentials()) {
            if (domain.equalsIgnoreCase(c.domain) && username.equalsIgnoreCase(c.username)) return c;
        }
        return null;
    }

    private String buildAutofillLoginJs(String username, String password) {
        String u = JSONObject.quote(username == null ? "" : username);
        String p = JSONObject.quote(password == null ? "" : password);
        return "(function(){"
                + "var pwd=document.querySelector('input[type=password]');"
                + "var user=document.querySelector('input[type=email],input[autocomplete=username],input[name*=email i],input[name*=user i],input[type=text]');"
                + "if(!pwd)return 'password_field_missing';"
                + "if(user){user.focus();user.value=" + u + ";user.dispatchEvent(new Event('input',{bubbles:true}));user.dispatchEvent(new Event('change',{bubbles:true}));}"
                + "pwd.focus();pwd.value=" + p + ";pwd.dispatchEvent(new Event('input',{bubbles:true}));pwd.dispatchEvent(new Event('change',{bubbles:true}));"
                + "return user ? 'filled' : 'password_only';"
                + "})()";
    }

    private String extractDomain(String url) {
        try {
            String host = Uri.parse(url).getHost();
            return host != null ? host : "";
        } catch (Exception e) {
            return "";
        }
    }

    // JS injected after each page load to watch for password-form submits.
    // Only attaches once per form (data-nex-bound guard) so repeat calls on
    // dynamic pages don't stack duplicate listeners.
    private static final String CAPTURE_JS =
            "(function(){"
            + "document.querySelectorAll('form').forEach(function(f){"
            + "  var pwd=f.querySelector('input[type=password]');"
            + "  if(!pwd||f.dataset.nexBound)return;"
            + "  f.dataset.nexBound='1';"
            + "  f.addEventListener('submit', function(){"
            + "    var user=f.querySelector('input[type=email],input[type=text],input[autocomplete=username]');"
            + "    try{NexPasswordCapture.postMessage(JSON.stringify({u:user?user.value:'',p:pwd.value}));}catch(e){}"
            + "  });"
            + "});"
            + "})()";

    private String buildAutofillJs(String username, String password) {
        // JSON string quoting is also valid JavaScript string quoting and safely
        // handles quotes, backslashes, newlines and other credential characters.
        String u = JSONObject.quote(username == null ? "" : username);
        String p = JSONObject.quote(password == null ? "" : password);
        return "(function(){"
                + "var pwd=document.querySelector('input[type=password]');"
                + "if(!pwd)return;"
                + "var user=document.querySelector('input[type=email],input[type=text],input[autocomplete=username]');"
                + "if(user){user.value=" + u + ";user.dispatchEvent(new Event('input',{bubbles:true}));}"
                + "pwd.value=" + p + ";pwd.dispatchEvent(new Event('input',{bubbles:true}));"
                + "})()";
    }

    // Bridges JS form-submit events back to Android. Runs on a WebView
    // background thread — always hop to mainHandler before touching UI.
    private class NexJsBridge {
        private final DevilTab tab;
        NexJsBridge(DevilTab tab) { this.tab = tab; }

        // Legacy path — ONLY used on phones whose WebView is too old for
        // WebMessageListener. Same message shape as the listener path below.
        @JavascriptInterface
        public void postMessage(String json) {
            handleCapturedLogin(tab, json);
        }
    }

    /** Shared by both bridges. `json` = {"u": username, "p": password}. */
    private void handleCapturedLogin(DevilTab tab, String json) {
        try {
            JSONObject o = new JSONObject(json);
            String password = o.optString("p", "");
            String username = o.optString("u", "");
            if (password.isEmpty() || password.length() > 512 || username.length() > 512) return;
            mainHandler.post(() -> promptSavePassword(tab, username, password));
        } catch (Exception ignored) { /* malformed message from a page: ignore */ }
    }

    /** True only if `origin` (what the message came from) is the same scheme+host+port
     *  as the page this tab is currently showing. */
    private boolean originMatchesTab(Uri origin, DevilTab tab) {
        if (origin == null || tab.webView == null) return false;
        String current = tab.webView.getUrl();
        if (current == null) return false;
        Uri cur = Uri.parse(current);
        return origin.getScheme() != null && origin.getHost() != null
                && origin.getScheme().equalsIgnoreCase(cur.getScheme())
                && origin.getHost().equalsIgnoreCase(cur.getHost())
                && origin.getPort() == cur.getPort();
    }

    private void promptSavePassword(DevilTab tab, String username, String password) {
        if (!passwordManagerEnabled || tab.isIncognito) return;
        String domain = extractDomain(tab.webView.getUrl());
        if (domain.isEmpty()) return;

        // Don't ask again if we already have this exact username+password saved
        for (SavedCredential c : findCredentialsForDomain(domain)) {
            if (c.username.equals(username) && c.password.equals(password)) return;
        }

        new AccentDialogBuilder(this)
                .setTitle("Save password?")
                .setMessage("Save this login for " + domain + "?")
                .setPositiveButton("Save", (d, w) -> {
                    upsertCredential(domain, username, password);
                    Toast.makeText(this, "Password saved", Toast.LENGTH_SHORT).show();
                    syncFullVaultToBackend(); // silently no-ops if backend/account isn't set up
                })
                .setNegativeButton("Not Now", null)
                .show();
    }

    private void tryAutofill(WebView webView, String url) {
        if (!passwordManagerEnabled) return;
        String domain = extractDomain(url);
        if (domain.isEmpty()) return;
        List<SavedCredential> matches = findCredentialsForDomain(domain);
        if (matches.size() == 1) {
            SavedCredential c = matches.get(0);
            webView.evaluateJavascript(buildAutofillJs(c.username, c.password), null);
        }
    }

    // ================================================================
    // PASSWORDS SCREEN — Settings → Passwords. Real list, real delete,
    // show/hide toggle per row, master enable/disable switch.
    // ================================================================
    private View buildPasswordsView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(buildPageHeader("Passwords", () -> showFullPage(buildSettingsView())));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(24, 16, 24, 24);
        scroll.addView(list);
        root.addView(scroll);

        LinearLayout toggleRow = new LinearLayout(this);
        toggleRow.setOrientation(LinearLayout.HORIZONTAL);
        toggleRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        toggleRow.setPadding(8, 8, 8, 24);
        TextView toggleLabel = new TextView(this);
        toggleLabel.setText("Save & Autofill Passwords");
        toggleLabel.setTextColor(getColor(R.color.text_primary));
        toggleLabel.setTextSize(12);
        LinearLayout.LayoutParams toggleLabelParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        toggleLabelParams.weight = 1;
        toggleLabel.setLayoutParams(toggleLabelParams);
        toggleRow.addView(toggleLabel);
        android.widget.Switch masterToggle = new android.widget.Switch(this);
        masterToggle.setChecked(passwordManagerEnabled);
        tintSwitch(masterToggle);
        masterToggle.setOnClickListener(v -> {
            passwordManagerEnabled = !passwordManagerEnabled;
            prefs.edit().putBoolean("password_manager_enabled", passwordManagerEnabled).apply();
        });
        toggleRow.addView(masterToggle);
        list.addView(toggleRow);

        TextView note = new TextView(this);
        boolean cloudActive = !authToken.isEmpty() && !backendUrl.isEmpty();
        boolean passphraseSet = hasVaultPassphraseSetUp();
        note.setText(cloudActive
                ? ("Encrypted on-device (Android Keystore), and also backed up to your backend account (" + authEmail + ") — every time you save a login, it re-syncs automatically. "
                    + (passphraseSet
                        ? "Passwords are end-to-end encrypted with your Vault Passphrase before they leave this device — the server only ever stores ciphertext it can't read."
                        : "You'll be asked to set a Vault Passphrase the first time a password syncs, so the server never sees them in plain text."))
                : "Encrypted on-device (Android Keystore). Sign in + set a Backend Server in Settings to also back these up to your own server (end-to-end encrypted with a separate Vault Passphrase).");
        note.setTextColor(getColor(R.color.text_dim));
        note.setTextSize(9);
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        noteParams.bottomMargin = 16;
        note.setLayoutParams(noteParams);
        list.addView(note);

        LinearLayout vaultRow = new LinearLayout(this);
        vaultRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams vaultRowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        vaultRowParams.bottomMargin = 8;
        vaultRow.setLayoutParams(vaultRowParams);

        TextView syncBtn = new TextView(this);
        syncBtn.setText("☁ Sync Now");
        syncBtn.setTextColor(getColor(R.color.gold));
        syncBtn.setTextSize(11);
        syncBtn.setGravity(android.view.Gravity.CENTER);
        syncBtn.setPadding(16, 20, 16, 20);
        syncBtn.setBackgroundResource(R.drawable.bg_tab_inactive);
        LinearLayout.LayoutParams syncBtnParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        syncBtnParams.weight = 1;
        syncBtnParams.rightMargin = 8;
        syncBtn.setLayoutParams(syncBtnParams);
        syncBtn.setOnClickListener(v -> syncFullVaultToBackendWithFeedback());
        vaultRow.addView(syncBtn);

        TextView downloadBtn = new TextView(this);
        downloadBtn.setText("⇩ Download Vault File");
        downloadBtn.setTextColor(getColor(R.color.gold));
        downloadBtn.setTextSize(11);
        downloadBtn.setGravity(android.view.Gravity.CENTER);
        downloadBtn.setPadding(16, 20, 16, 20);
        downloadBtn.setBackgroundResource(R.drawable.bg_tab_inactive);
        LinearLayout.LayoutParams downloadBtnParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        downloadBtnParams.weight = 1;
        downloadBtn.setLayoutParams(downloadBtnParams);
        downloadBtn.setOnClickListener(v -> downloadVaultFile());
        vaultRow.addView(downloadBtn);

        list.addView(vaultRow);

        TextView passphraseBtn = new TextView(this);
        passphraseBtn.setText(passphraseSet ? "🔑 Change Vault Passphrase" : "🔑 Set Vault Passphrase");
        passphraseBtn.setTextColor(getColor(R.color.text_dim));
        passphraseBtn.setTextSize(10);
        passphraseBtn.setGravity(android.view.Gravity.CENTER);
        passphraseBtn.setPadding(16, 16, 16, 16);
        LinearLayout.LayoutParams passphraseBtnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        passphraseBtnParams.bottomMargin = 20;
        passphraseBtn.setLayoutParams(passphraseBtnParams);
        passphraseBtn.setOnClickListener(v -> showVaultPassphraseSetupDialog(null));
        list.addView(passphraseBtn);

        List<SavedCredential> creds = loadCredentials();
        if (creds.isEmpty()) {
            list.addView(buildEmptyState("No saved passwords yet — you'll be asked to save one the next time you log into a site"));
        } else {
            for (SavedCredential c : creds) {
                list.addView(buildCredentialRow(c));
            }
        }

        return root;
    }

    private View buildCredentialRow(SavedCredential cred) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(16, 18, 16, 18);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = 6;
        row.setLayoutParams(rowParams);
        row.setBackgroundResource(R.drawable.bg_tab_inactive);

        LinearLayout textCol = new LinearLayout(this);
        textCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textColParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT);
        textColParams.weight = 1;
        textCol.setLayoutParams(textColParams);

        TextView domainView = new TextView(this);
        domainView.setText(cred.domain);
        domainView.setTextColor(getColor(R.color.text_primary));
        domainView.setTextSize(12);
        textCol.addView(domainView);

        TextView userView = new TextView(this);
        userView.setText(cred.username.isEmpty() ? "(no username)" : cred.username);
        userView.setTextColor(getColor(R.color.text_dim));
        userView.setTextSize(9.5f);
        LinearLayout.LayoutParams userParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        userParams.topMargin = 3;
        userView.setLayoutParams(userParams);
        textCol.addView(userView);

        TextView passView = new TextView(this);
        passView.setText(maskPassword(cred.password));
        passView.setTextColor(getColor(R.color.text_dim));
        passView.setTextSize(9.5f);
        LinearLayout.LayoutParams passParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        passParams.topMargin = 2;
        passView.setLayoutParams(passParams);
        textCol.addView(passView);

        row.addView(textCol);

        TextView showBtn = new TextView(this);
        showBtn.setText("👁");
        showBtn.setTextSize(13);
        showBtn.setPadding(16, 8, 16, 8);
        final boolean[] revealed = {false};
        showBtn.setOnClickListener(v -> {
            revealed[0] = !revealed[0];
            passView.setText(revealed[0] ? cred.password : maskPassword(cred.password));
        });
        row.addView(showBtn);

        TextView deleteBtn = new TextView(this);
        deleteBtn.setText("✕");
        deleteBtn.setTextColor(ThemeManager.getAccentColor(this));
        deleteBtn.setTextSize(14);
        deleteBtn.setPadding(16, 8, 8, 8);
        deleteBtn.setOnClickListener(v -> {
            deleteCredential(cred.domain, cred.username);
            showFullPage(buildPasswordsView());
        });
        row.addView(deleteBtn);

        return row;
    }

    private String maskPassword(String password) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < password.length(); i++) sb.append("•");
        return sb.toString();
    }

    // ================================================================
    // PERSISTENCE — shortcuts (Speed Dial) and history (Most Visited),
    // stored locally as JSON in SharedPreferences.
    // ================================================================
    private void loadShortcuts() {
        shortcuts.clear();
        String json = prefs.getString("shortcuts", null);
        if (json == null) {
            for (Object[] entry : DEFAULT_SHORTCUTS) {
                shortcuts.add(new Shortcut((String) entry[0], (String) entry[1], Color.parseColor((String) entry[2])));
            }
            saveShortcuts();
            return;
        }
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                shortcuts.add(new Shortcut(o.getString("name"), o.getString("url"), o.getInt("color")));
            }
        } catch (Exception e) {
            for (Object[] entry : DEFAULT_SHORTCUTS) {
                shortcuts.add(new Shortcut((String) entry[0], (String) entry[1], Color.parseColor((String) entry[2])));
            }
        }
    }

    private void saveShortcuts() {
        try {
            JSONArray arr = new JSONArray();
            for (Shortcut s : shortcuts) {
                JSONObject o = new JSONObject();
                o.put("name", s.name);
                o.put("url", s.url);
                o.put("color", s.color);
                arr.put(o);
            }
            prefs.edit().putString("shortcuts", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    // ================================================================
    // AI WEB MEMORY (#101) — the foundation Semantic History Search
    // (#102) and Browsing Timeline (#103)'s day summaries build on.
    // Whenever a real page finishes loading, a short content snippet
    // (same Reader Mode #96 extraction) is captured alongside the usual
    // url/title/count/timestamp — this is what lets history be searched
    // by MEANING later, not just title/URL text. Deliberately no AI
    // call at capture time (that would mean an API call on every single
    // page visited) — the AI work only happens later, at search time.
    // ================================================================
    private void trackVisit(String url, String title) {
        trackVisit(url, title, null);
    }

    private void trackVisit(String url, String title, WebView view) {
        if (url == null || url.startsWith("about:")) return;
        try {
            JSONArray history = new JSONArray(prefs.getString("history", "[]"));
            JSONArray updated = new JSONArray();
            boolean found = false;
            for (int i = 0; i < history.length(); i++) {
                JSONObject entry = history.getJSONObject(i);
                if (entry.getString("url").equals(url)) {
                    entry.put("count", entry.getInt("count") + 1);
                    entry.put("title", title != null ? title : url);
                    entry.put("ts", System.currentTimeMillis());
                    found = true;
                }
                updated.put(entry);
            }
            if (!found) {
                JSONObject entry = new JSONObject();
                entry.put("url", url);
                entry.put("title", title != null ? title : url);
                entry.put("count", 1);
                entry.put("ts", System.currentTimeMillis());
                updated.put(entry);
            }
            // Cap stored history size
            JSONArray capped = updated;
            if (updated.length() > 200) {
                capped = new JSONArray();
                for (int i = updated.length() - 200; i < updated.length(); i++) {
                    capped.put(updated.get(i));
                }
            }
            prefs.edit().putString("history", capped.toString()).apply();
            scheduleHistorySync();
        } catch (Exception ignored) {}

        if (view != null) {
            view.evaluateJavascript(READER_EXTRACT_JS, raw -> {
                String json = unescapeJsString(raw);
                try {
                    JSONObject obj = new JSONObject(json);
                    String content = obj.optString("text", "");
                    if (!content.trim().isEmpty()) storeHistoryContent(url, content);
                } catch (Exception ignored) {}
            });
        }
    }

    // Kept short (800 chars) — a memory AID for semantic matching
    // later, not a full-page archive.
    private void storeHistoryContent(String url, String content) {
        try {
            JSONArray history = new JSONArray(prefs.getString("history", "[]"));
            for (int i = 0; i < history.length(); i++) {
                JSONObject entry = history.getJSONObject(i);
                if (entry.getString("url").equals(url)) {
                    entry.put("content", content.length() > 800 ? content.substring(0, 800) : content);
                    break;
                }
            }
            prefs.edit().putString("history", history.toString()).apply();
        } catch (Exception ignored) {}
    }

    // ---- History Sync (#40): batches visits for a few seconds (so
    // rapid browsing doesn't fire a network call per page) then pushes
    // the current local history up. The full two-way merge (pulling in
    // what other devices tracked) happens via the explicit "Sync" button
    // in the History tab — this debounced push just keeps the backend
    // copy from going stale between manual syncs. ----
    private final Handler historySyncHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingHistorySync = null;

    private void scheduleHistorySync() {
        if (authToken.isEmpty() || backendUrl.isEmpty()) return;
        if (pendingHistorySync != null) historySyncHandler.removeCallbacks(pendingHistorySync);
        pendingHistorySync = this::pushHistoryToBackend;
        historySyncHandler.postDelayed(pendingHistorySync, 5000);
    }

    private void pushHistoryToBackend() {
        if (authToken.isEmpty() || backendUrl.isEmpty()) return;
        networkExecutor.execute(() -> {
            try {
                JSONArray historyArr = new JSONArray(prefs.getString("history", "[]"));
                JSONObject body = new JSONObject();
                body.put("history", historyArr);
                httpPostJson(backendUrl + "/sync/history", body, authToken);
            } catch (Exception ignored) {
                // best-effort background push — the explicit Sync button
                // in the History tab will reconcile properly either way
            }
        });
    }

    private List<Shortcut> getMostVisited(int limit) {
        List<Shortcut> result = new ArrayList<>();
        try {
            JSONArray history = new JSONArray(prefs.getString("history", "[]"));
            List<JSONObject> entries = new ArrayList<>();
            for (int i = 0; i < history.length(); i++) entries.add(history.getJSONObject(i));
            entries.sort((a, b) -> {
                try { return b.getInt("count") - a.getInt("count"); }
                catch (Exception e) { return 0; }
            });
            for (int i = 0; i < Math.min(limit, entries.size()); i++) {
                JSONObject e = entries.get(i);
                result.add(new Shortcut(e.getString("title"), e.getString("url"), Color.parseColor("#6B4FA0")));
            }
        } catch (Exception ignored) {}
        return result;
    }

    // ---- Tab Relationship Graph: if this tab has children (tabs opened
    // FROM it, via link clicks), offer to close them together with it —
    // handy for cleaning up a whole research/browsing thread at once.
    // Falls straight through to a normal single-tab close if there are
    // none. ----
    // ---- Tab Relationship Graph helper: looks up a tab by id (-1 or an
    // id that's since been closed both correctly return null). ----
    private DevilTab findTabById(int id) {
        if (id < 0) return null;
        for (DevilTab t : tabs) if (t.id == id) return t;
        return null;
    }

    private void closeTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        if (tabs.size() <= 1) {
            Toast.makeText(this, "At least one tab must stay open", Toast.LENGTH_SHORT).show();
            return;
        }
        DevilTab tab = tabs.get(index);

        List<DevilTab> children = new ArrayList<>();
        for (DevilTab t : tabs) {
            if (t.parentTabId == tab.id) children.add(t);
        }

        if (!children.isEmpty()) {
            new AccentDialogBuilder(this)
                    .setTitle("Close Tab")
                    .setMessage(children.size() + " tab" + (children.size() == 1 ? " was" : "s were")
                            + " opened from this one. Close " + (children.size() == 1 ? "it" : "those") + " too?")
                    .setPositiveButton("Close " + (children.size() + 1) + " Tabs", (d, w) -> {
                        for (DevilTab child : new ArrayList<>(children)) {
                            int childIdx = tabs.indexOf(child);
                            if (childIdx >= 0) closeTabInternal(childIdx);
                        }
                        int freshIdx = tabs.indexOf(tab);
                        if (freshIdx >= 0) closeTabInternal(freshIdx);
                    })
                    .setNegativeButton("Just This One", (d, w) -> {
                        int freshIdx = tabs.indexOf(tab);
                        if (freshIdx >= 0) closeTabInternal(freshIdx);
                    })
                    .show();
            return;
        }

        closeTabInternal(index);
    }

    private void closeTabInternal(int index) {
        if (tabs.size() <= 1) {
            Toast.makeText(this, "At least one tab must stay open", Toast.LENGTH_SHORT).show();
            return;
        }
        DevilTab tab = tabs.get(index);
        boolean wasIncognito = tab.isIncognito;
        if (tab.webView != null) tab.webView.destroy();
        tabBarContainer.removeView(tab.chipView);
        tabs.remove(index);

        // Any tabs that pointed to this one as their parent become "roots"
        // rather than dangling references to a tab that's gone.
        for (DevilTab t : tabs) {
            if (t.parentTabId == tab.id) t.parentTabId = -1;
        }

        if (wasIncognito) {
            boolean anyIncognitoLeft = false;
            for (DevilTab t : tabs) if (t.isIncognito) { anyIncognitoLeft = true; break; }
            if (!anyIncognitoLeft) {
                // Last incognito tab closed — leave no trace behind (incognito profile only)
                wipeIncognitoData();
            }
        }

        // Keep pointing at the tab the person was on. Removing a tab to the LEFT of the
        // current one shifts everything down by one; without this the view silently
        // jumped to a different tab. If the CURRENT tab was closed, prefer going back
        // to the tab it was opened from (e.g. a finished OAuth popup).
        if (index < currentTabIndex) {
            currentTabIndex--;
        } else if (index == currentTabIndex) {
            int parentIdx = -1;
            for (int i = 0; i < tabs.size(); i++) {
                if (tabs.get(i).id == tab.parentTabId) { parentIdx = i; break; }
            }
            if (parentIdx >= 0) currentTabIndex = parentIdx;
        }
        if (currentTabIndex >= tabs.size()) {
            currentTabIndex = tabs.size() - 1;
        }
        switchToTab(currentTabIndex);
        updateTabCounter();
    }

    // ---- Tab chip UI (the horizontal strip of open tabs) ----
    private void addTabChip(DevilTab tab) {
        LinearLayout chip = new LinearLayout(this);
        chip.setOrientation(LinearLayout.HORIZONTAL);
        chip.setGravity(android.view.Gravity.CENTER_VERTICAL);
        chip.setPadding(24, 16, 12, 16);
        LinearLayout.LayoutParams chipParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        chipParams.setMargins(4, 0, 4, 0);
        chip.setLayoutParams(chipParams);
        chip.setBackgroundResource(R.drawable.bg_tab_inactive);

        TextView titleView = new TextView(this);
        titleView.setText((tab.isIncognito ? "🕶 " : "") + (tab.isSuspended ? "💤 " : "") + tab.title);
        titleView.setTextColor(getColor(R.color.text_dim));
        titleView.setTextSize(10);
        titleView.setMaxWidth(220);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        chip.addView(titleView);

        TextView closeView = new TextView(this);
        closeView.setText(" ✕");
        closeView.setTextColor(getColor(R.color.text_dim));
        closeView.setTextSize(10);
        closeView.setPadding(12, 0, 0, 0);
        chip.addView(closeView);

        chip.setOnClickListener(v -> {
            int idx = tabs.indexOf(tab);
            if (idx >= 0) switchToTab(idx);
        });
        closeView.setOnClickListener(v -> {
            int idx = tabs.indexOf(tab);
            if (idx >= 0) closeTab(idx);
        });

        tab.chipView = chip;
        tabBarContainer.addView(chip);
    }

    private void updateTabChip(DevilTab tab) {
        if (tab.chipView instanceof LinearLayout) {
            LinearLayout chip = (LinearLayout) tab.chipView;
            TextView titleView = (TextView) chip.getChildAt(0);
            titleView.setText((tab.isIncognito ? "🕶 " : "") + (tab.isSuspended ? "💤 " : "") + tab.title);
        }
    }

    private void refreshTabChips() {
        for (int i = 0; i < tabs.size(); i++) {
            DevilTab tab = tabs.get(i);
            tab.chipView.setBackgroundResource(i == currentTabIndex ?
                    R.drawable.bg_tab_active : R.drawable.bg_tab_inactive);
        }
    }

    private void updateTabCounter() {
        tabCounter.setText(String.valueOf(tabs.size()));
    }

    @Override
    public void onBackPressed() {
        // Exit fullscreen video first, if active
        if (currentFullscreenView != null) {
            WebView wv = currentWebView();
            if (wv != null && wv.getWebChromeClient() != null) {
                wv.getWebChromeClient().onHideCustomView();
            }
            return;
        }
        // Exit Full Screen menu mode next, if active
        if (isFullScreenMode) {
            toggleFullScreen();
            return;
        }
        // Close the Universal Panel drawer first if it's open (it sits on
        // top of everything else, including pageContainer)
        if (isUniversalPanelShown) {
            hideUniversalPanel();
            return;
        }
        // Close any open Settings/Add-ons/Ad Block page overlay
        if (isPageShown) {
            hideFullPage();
            return;
        }
        WebView wv = currentWebView();
        if (wv != null && wv.canGoBack()) {
            wv.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        activityResumed = true;
        mainHandler.removeCallbacks(agentSignalPoller);
        mainHandler.post(agentSignalPoller);
    }

    @Override
    protected void onPause() {
        activityResumed = false;
        flushAdStats();
        // While a task is running (foreground service up) keep polling so queued jobs are still
        // picked up and finished jobs get reported; otherwise stop polling to save battery.
        if (!AgentForegroundService.running) mainHandler.removeCallbacks(agentSignalPoller);
        super.onPause();
        if (reopenTabsOnStartup) saveOpenTabsState();
        // Vault Auto-Lock (#35): leaving the app re-locks Passwords —
        // the next open requires unlocking again, not just a timeout.
        vaultUnlockedAt = 0;
    }

    @Override
    protected void onDestroy() {
        mainHandler.removeCallbacks(agentServiceReconciler);
        mainHandler.removeCallbacks(agentSignalPoller);
        if (AgentForegroundService.running && isFinishing()) {
            // The app is being closed while a task runs. Its lanes die with this Activity, but the
            // job is saved server-side and resumes from its last step on the next launch — tell the
            // person that, with a tap-to-continue notification (the service then stops itself).
            try {
                startService(new Intent(this, AgentForegroundService.class)
                        .setAction(AgentForegroundService.ACTION_APP_CLOSED));
            } catch (Exception ignored) { /* background-start restriction: onTaskRemoved covers it */ }
        }
        tabSuspendHandler.removeCallbacksAndMessages(null);
        sessionSaveHandler.removeCallbacksAndMessages(null);
        if (connectivityManager != null && syncNetworkCallback != null) {
            try { connectivityManager.unregisterNetworkCallback(syncNetworkCallback); } catch (Exception ignored) {}
        }
        for (DevilTab tab : tabs) {
            if (tab.webView != null) tab.webView.destroy();
        }
        networkExecutor.shutdownNow();
        super.onDestroy();
    }
}
