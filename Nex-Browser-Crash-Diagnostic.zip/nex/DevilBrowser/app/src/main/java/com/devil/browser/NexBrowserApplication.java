package com.devil.browser;

import android.app.Application;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;

/** Captures the previous uncaught startup crash so it can be shown on next launch. */
public class NexBrowserApplication extends Application {
    @Override public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                StringWriter sw = new StringWriter();
                error.printStackTrace(new PrintWriter(sw));
                File log = new File(getFilesDir(), "nex_last_crash.txt");
                try (FileWriter writer = new FileWriter(log, false)) {
                    writer.write("Thread: " + thread.getName() + "\n");
                    writer.write(sw.toString());
                }
            } catch (Throwable ignored) { }
            if (previous != null) previous.uncaughtException(thread, error);
        });
    }
}
